// Hooks added here have a bridge allowing communication between the BEX Background Script and the BEX Content Script.
// Note: Events sent from this background script using `bridge.send` can be `listen`'d for by all client BEX bridges for this BEX
// More info: https://quasar.dev/quasar-cli/developing-browser-extensions/background-hooks

import { apiBackground }      from '../../src/bex/apiBackgroundPinia'

export default function attachBackgroundHooks (bridge, allActiveConnections) {

  console.log('attachBackgroundHooks: enter')

  apiBackground(bridge)

  console.log('attachBackgroundHooks: done')
}
