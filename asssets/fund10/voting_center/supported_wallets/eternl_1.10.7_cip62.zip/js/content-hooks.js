// Hooks added here have a bridge allowing communication between the BEX Content Script and the Quasar Application.
// More info: https://quasar.dev/quasar-cli/developing-browser-extensions/content-hooks

import { apiContent }         from '../../src/bex/apiContent'

export default function attachContentHooks(bridge) {

  apiContent(bridge)
}
