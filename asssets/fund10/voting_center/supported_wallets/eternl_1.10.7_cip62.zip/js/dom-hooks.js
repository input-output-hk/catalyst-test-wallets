// Hooks added here have a bridge allowing communication between the Web Page and the BEX Content Script.
// More info: https://quasar.dev/quasar-cli/developing-browser-extensions/dom-hooks

import {
  setWalletNamespace,
  apiDom
}                             from '../../src/bex/apiDom'

if(!window.hasOwnProperty('cardano')) {

  window.cardano              = {}
}

setWalletNamespace(window.cardano)

export default function attachDomHooks(bridge) {

  apiDom(bridge)
}
