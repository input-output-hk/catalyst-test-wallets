(this["webpackChunkccw_frontend"] = this["webpackChunkccw_frontend"] || []).push([[886],{

/***/ 70042:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "V": () => (/* binding */ useCheckTxOnChain)
/* harmony export */ });
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(61959);
/* harmony import */ var src_lib_ExtApiLib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(32035);
/* harmony import */ var src_ccw_lib_Print__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(66620);
/* harmony import */ var src_ccw_lib_core_lib_LibUtils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(80899);
/* harmony import */ var src_data_utils_PendingTxUtils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(47204);
/* harmony import */ var src_data_OfflineDataDb__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(30615);




if (src_ccw_lib_Print__WEBPACK_IMPORTED_MODULE_1__/* ["default"].frontend.checkTxOnChain */ .Z.frontend.checkTxOnChain)
    console.warn('setup: useCheckTxOnChain');


const scanningTxList = (0,vue__WEBPACK_IMPORTED_MODULE_5__/* .reactive */ .qj)([]);
const onChainTxList = (0,vue__WEBPACK_IMPORTED_MODULE_5__/* .reactive */ .qj)([]);
let _scanning = false;
let _timeoutId = -1;
const scanForPendingTx = async (networkId) => {
    if (!networkId)
        return;
    if (_scanning)
        return;
    _scanning = true;
    clearTimeout(_timeoutId);
    const timerStart = Date.now();
    // This list is already filtered by expiration slot as well as known on-chain tx details.
    const pendingTxList = await (0,src_data_utils_PendingTxUtils__WEBPACK_IMPORTED_MODULE_3__/* .getFilteredPendingTxList */ .g)(networkId);
    if (pendingTxList.length > 0) {
        scanningTxList.splice(0, scanningTxList.length, ...pendingTxList.map(item => item.txHash));
        if (src_ccw_lib_Print__WEBPACK_IMPORTED_MODULE_1__/* ["default"].frontend.checkTxOnChain */ .Z.frontend.checkTxOnChain)
            console.log('checkTxOnChain: scan for (' + (Date.now() - timerStart) + 'ms)', scanningTxList);
        const url = '/' + networkId + '/v1/wallet/checktxonchain';
        let res = await src_lib_ExtApiLib__WEBPACK_IMPORTED_MODULE_0__/* .api.post */ .hi.post(url, { txHashList: scanningTxList.map(txHash => (0,src_ccw_lib_core_lib_LibUtils__WEBPACK_IMPORTED_MODULE_2__/* .hexToBytea */ .Ni)(txHash)) }).catch((err) => {
            console.warn('Error: checkTxOnChain: failed (' + (Date.now() - timerStart) + 'ms)', networkId, err);
        });
        if (res) {
            const rpcRes = res.data;
            if (rpcRes && Array.isArray(rpcRes.txOnChain)) {
                // The endpoint returns all known on-chain tx hashes.
                const onChainTxHashList = rpcRes.txOnChain;
                if (src_ccw_lib_Print__WEBPACK_IMPORTED_MODULE_1__/* ["default"].frontend.checkTxOnChain */ .Z.frontend.checkTxOnChain)
                    console.log('checkTxOnChain: done (' + (Date.now() - timerStart) + 'ms)', onChainTxHashList);
                // Get all tx details of those on-chain hashes, if available.
                const txHashList = await (0,src_data_OfflineDataDb__WEBPACK_IMPORTED_MODULE_4__/* .loadKnownTxHashList */ .P5)(networkId, onChainTxHashList);
                // tx hashes of all missing tx details
                const missingTxHashList = onChainTxHashList.filter(txHash => !txHashList.includes(txHash));
                const missingTxList = await (0,src_lib_ExtApiLib__WEBPACK_IMPORTED_MODULE_0__/* .loadTxDetailsList */ .LG)(missingTxHashList, networkId);
                if (missingTxList) {
                    await (0,src_data_OfflineDataDb__WEBPACK_IMPORTED_MODULE_4__/* .saveTxList */ .UY)(networkId, missingTxList.txList);
                }
                for (const txHash of onChainTxHashList) {
                    if (!onChainTxList.includes(txHash))
                        onChainTxList.push(txHash);
                }
            }
        }
    }
    else {
        if (src_ccw_lib_Print__WEBPACK_IMPORTED_MODULE_1__/* ["default"].frontend.checkTxOnChain */ .Z.frontend.checkTxOnChain)
            console.log('checkTxOnChain: skipped (no missing tx details) (' + (Date.now() - timerStart) + 'ms)');
    }
    scanningTxList.splice(0, scanningTxList.length);
    _timeoutId = setTimeout(() => { scanForPendingTx(networkId); }, 20 * 1000);
    _scanning = false;
};
function useCheckTxOnChain() {
    return {
        scanForPendingTx,
        scanningTxList,
        onChainTxList
    };
}
// Webpack hot module replacement needs to dispose the timeout, otherwise we add more timeout loops on each hot reload.
//@ts-ignore
if (false) {}


/***/ }),

/***/ 71885:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* unused harmony exports clearDAppBrowserEntryListDb, reloadDAppBrowserEntryList, saveDAppBrowserEntryList */
/* harmony import */ var src_ccw_lib_Print__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(66620);
/* harmony import */ var idb_with_async_ittr__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(74285);


const dbName = 'eternl-dappbrowser-entrylist';
const dbVersion = 4;
let db;
const upgradeDb = (db) => {
    if (Print.frontend.db.open)
        console.log('DAppBrowserEntryListDb: upgradeDb:', db);
    try {
        let store = db.createObjectStore('dappbrowser-entrylist-mainnet', { keyPath: 'id', autoIncrement: false });
        store.createIndex('by-id', 'id');
    }
    catch (e) { }
    try {
        let store = db.createObjectStore('dappbrowser-entrylist-guild', { keyPath: 'id', autoIncrement: false });
        store.createIndex('by-id', 'id');
    }
    catch (e) { }
    try {
        let store = db.createObjectStore('dappbrowser-entrylist-shareslake', { keyPath: 'id', autoIncrement: false });
        store.createIndex('by-id', 'id');
    }
    catch (e) { }
    try {
        let store = db.createObjectStore('dappbrowser-entrylist-preprod', { keyPath: 'id', autoIncrement: false });
        store.createIndex('by-id', 'id');
    }
    catch (e) { }
    try {
        let store = db.createObjectStore('dappbrowser-entrylist-preview', { keyPath: 'id', autoIncrement: false });
        store.createIndex('by-id', 'id');
    }
    catch (e) { }
};
const clearDb = async (db) => {
    if (Print.frontend.db.open)
        console.log('DAppBrowserEntryListDb: clearDb');
    const storeNames = db.objectStoreNames;
    for (const storeName of storeNames) {
        try {
            await db.clear(storeName);
        }
        catch (e) {
            console.error('DAppBrowserEntryListDb: clearDb:', e);
        }
    }
    if (Print.frontend.db.open)
        console.log('DAppBrowserEntryListDb: clearDb: cleared');
};
const deleteTestnetDb = (db) => {
    if (Print.frontend.db.open)
        console.log('DAppBrowserEntryListDb: deleteTestnetDb');
    //@ts-ignore
    try {
        db.deleteObjectStore('dappbrowser-entrylist-testnet');
    }
    catch (e) { }
    if (Print.frontend.db.open)
        console.log('DAppBrowserEntryListDb: deleteTestnetDb: deleted');
};
const openDb = async (dbName, dbVersion) => {
    if (db) {
        return;
    }
    db = await openDB(dbName, dbVersion, {
        upgrade(db, oldVersion, newVersion, transaction) {
            if (Print.frontend.db.open)
                console.log('DAppBrowserEntryListDb: open.upgrade');
            //TODO: temporary function to clear old testnet db
            deleteTestnetDb(db);
            upgradeDb(db);
        },
        blocked() { console.warn('DAppBrowserEntryListDb: blocked'); },
        blocking() { console.warn('DAppBrowserEntryListDb: blocking'); },
        terminated() { console.warn('DAppBrowserEntryListDb: terminated'); }
    });
    upgradeDb(db);
};
const openDAppBrowserEntryListDb = async () => { await openDb(dbName, dbVersion); };
const clearDAppBrowserEntryListDb = async () => {
    await openDb(dbName, dbVersion);
    if (db) {
        await clearDb(db);
        upgradeDb(db);
    }
};
const reloadDAppBrowserEntryList = async (networkId) => {
    if (Print.frontend.db.reloadDAppBrowserEntryList)
        console.log('DAppBrowserEntryListDb: reloadDAppBrowserEntryList:', networkId);
    if (!db) {
        await openDAppBrowserEntryListDb();
    }
    if (Print.frontend.db.reloadDAppBrowserEntryList)
        console.log('DAppBrowserEntryListDb: reloadDAppBrowserEntryList: db available:', db !== null);
    if (!db) {
        throw new Error('Error: DAppBrowserEntryListDb: reloadDAppBrowserEntryList: database unavailable.');
    }
    const storeName = ('dappbrowser-entrylist-' + networkId);
    const list = (await db.getAll(storeName));
    if (Print.frontend.db.reloadDAppBrowserEntryList)
        console.log('DAppBrowserEntryListDb: reloadDAppBrowserEntryList: done', list);
    return (list.length > 0 ? list[0].list : []);
};
const saveDAppBrowserEntryList = async (networkId, entryList) => {
    if (Print.frontend.db.saveDAppBrowserEntryList)
        console.log('DAppBrowserEntryListDb: saveDAppBrowserEntryList:', entryList);
    if (!db) {
        await openDAppBrowserEntryListDb();
    }
    if (Print.frontend.db.saveDAppBrowserEntryList)
        console.log('DAppBrowserEntryListDb: saveDAppBrowserEntryList: db available:', db !== null);
    if (!db) {
        throw new Error('Error: DAppBrowserEntryListDb: saveDAppBrowserEntryList: database unavailable.');
    }
    const storeName = ('dappbrowser-entrylist-' + networkId);
    const tx = db.transaction(storeName, 'readwrite');
    const store = tx.objectStore(storeName);
    const tmp = {
        id: '0',
        list: JSON.parse(JSON.stringify(entryList))
    };
    await store.put(tmp);
    await tx.done;
    if (Print.frontend.db.saveDAppBrowserEntryList)
        console.log('DAppBrowserEntryListDb: saveDAppBrowserEntryList: done');
};


/***/ }),

/***/ 63691:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "a": () => (/* binding */ deleteOldDb)
/* harmony export */ });
/* harmony import */ var idb_with_async_ittr__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(74285);

const deleteOldDb = async () => {
    await (0,idb_with_async_ittr__WEBPACK_IMPORTED_MODULE_0__/* .deleteDB */ .Lj)('ccvault.io-offlinedata', {
        blocked() { console.warn('OfflineDataDb: deletion blocked'); }
    });
    await (0,idb_with_async_ittr__WEBPACK_IMPORTED_MODULE_0__/* .deleteDB */ .Lj)('ccvault.io-pending-tx', {
        blocked() { console.warn('PendingTxDb: deletion blocked'); }
    });
};


/***/ }),

/***/ 88165:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "_": () => (/* binding */ WalletEvent)
/* harmony export */ });
var WalletEvent;
(function (WalletEvent) {
    WalletEvent["added"] = "added";
    WalletEvent["removed"] = "removed";
    WalletEvent["updated"] = "updated";
    WalletEvent["syncStarted"] = "syncStarted";
    WalletEvent["synced"] = "synced";
    WalletEvent["syncFailed"] = "syncFailed";
    WalletEvent["locked"] = "locked";
    WalletEvent["unlocked"] = "unlocked";
    WalletEvent["deleted"] = "deleted";
    WalletEvent["reset"] = "reset";
})(WalletEvent || (WalletEvent = {}));


/***/ }),

/***/ 46738:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "T": () => (/* binding */ postDataCbor),
/* harmony export */   "r": () => (/* binding */ fetchData)
/* harmony export */ });
/* harmony import */ var src_ccw_lib_core_lib_LibUtils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(80899);

const fetchData = (url, isJSON = true, payload, options, request = new XMLHttpRequest()) => {
    return new Promise((resolve, reject) => {
        const oReq = request;
        oReq.onload = function () {
            if (oReq.status !== 200) {
                return reject(oReq);
            }
            let res = oReq.response;
            if (isJSON && (oReq.responseType === '' || oReq.responseType === 'text')) {
                try {
                    res = JSON.parse(res);
                }
                catch (err) {
                    console.error('Error: fetchData: ', err, res, url);
                    return reject(err);
                }
            }
            resolve(res);
        };
        oReq.onerror = function () { return reject(oReq); };
        oReq.onabort = function () { return reject(oReq); };
        oReq.ontimeout = function () { return reject(oReq); };
        if (payload) {
            oReq.open('POST', url);
            oReq.setRequestHeader('Content-Type', 'application/json');
            oReq.timeout = 60000;
            if (options?.header) {
                oReq.setRequestHeader(options.header.name, options.header.value);
            }
            if (options?.responseType) {
                oReq.responseType = options.responseType;
            }
            oReq.send(JSON.stringify(payload));
        }
        else {
            oReq.open('GET', url);
            oReq.timeout = 60000;
            if (options?.header) {
                oReq.setRequestHeader(options.header.name, options.header.value);
            }
            if (options?.responseType) {
                oReq.responseType = options.responseType;
            }
            oReq.send();
        }
    });
};
const postDataCbor = (url, isJSON = true, payload, options) => {
    return new Promise((resolve, reject) => {
        const oReq = new XMLHttpRequest();
        oReq.onload = function () {
            if (oReq.status > 299) {
                return reject(oReq);
            }
            resolve(oReq);
        };
        oReq.onerror = function () { return reject(oReq); };
        oReq.onabort = function () { return reject(oReq); };
        oReq.ontimeout = function () { return reject(oReq); };
        oReq.open('POST', url);
        oReq.setRequestHeader('Content-Type', 'application/cbor');
        oReq.timeout = 60000;
        if (options?.header) {
            oReq.setRequestHeader(options.header.name, options.header.value);
        }
        if (options?.responseType) {
            oReq.responseType = options.responseType;
        }
        oReq.send((0,src_ccw_lib_core_lib_LibUtils__WEBPACK_IMPORTED_MODULE_0__/* .toHexArray */ ._u)(payload));
    });
};


/***/ }),

/***/ 66620:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "K": () => (/* binding */ Print),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const Print = {
    stores: {
        useNetworkIdStore: false,
        useWalletIdStore: false,
        useWalletIdListStore: false,
        useWalletListStore: false,
        useVerifiedTokensStore: false,
        useDecryptedMsgStore: false,
    },
    frontend: {
        useDownload: false,
        useNetworkId: false,
        useAdaSymbol: false,
        useWalletId: false,
        useAppMode: false,
        useTabId: false,
        useNavigation: false,
        useLocalStorage: false,
        useBexStorage: false,
        useTranslation: false,
        useResetScroll: false,
        useChainTip: false,
        useCurrencyAPI: false,
        useEpochParams: false,
        useWalletList: false,
        useActiveWallet: false,
        useDAppWallet: false,
        usePoolAPI: false,
        useDAppBrowserEntries: false,
        useBlacklist: false,
        useDelegationHistory: false,
        useWalletCreation: false,
        useBuildTx: false,
        useLedgerDevice: false,
        useTrezorDevice: false,
        useTokenLib: false,
        useSwapLib: false,
        useAPICall: false,
        useBexBackground: false,
        useCSL: false,
        routes: false,
        storageManagement: false,
        blacklist: false,
        websocket: {
            tip: false,
            client: false,
        },
        db: {
            walletIdListDb: false,
            VerifiedTokensDb: false,
            open: false,
            saveWallet: false,
            deleteWallet: false,
            loadWallet: false,
            reloadWalletList: false,
            reloadWalletIdList: false,
            reloadPoolList: false,
            savePoolList: false,
            reloadDAppBrowserEntryList: false,
            saveDAppBrowserEntryList: false,
            loadTokenMeta: false,
            saveTokenMeta: false,
            loadIPFSImage: false,
            saveIPFSImage: false,
            saveAddressProperty: false,
            loadAddressProperty: false,
            loadTxNote: false,
            loadTxNoteHash: false,
            saveTxNote: false,
            deleteTxNote: false,
            loadData: false,
            saveData: false,
            loadTxHashList: false,
            loadTxList: false,
            loadSaveLock: false,
            saveSaveLock: false,
            loadTx: false,
            saveTx: false,
            saveTxList: false,
            loadPendingTxList: false,
            savePendingTxList: false,
            savePendingTx: false,
            removePendingTx: false,
            loadPendingTx: false,
            loadMilkomedaAsset: false,
            saveMilkomedaAsset: false,
            loadMilkomedaAssetList: false,
            saveMilkomedaAssetList: false,
            loadBlacklist: false,
            saveBlacklist: false,
            loadChart: false,
            saveChart: false,
            loadImageUrl: false,
            saveImageUrl: false,
            loadDecryptedMsg: false,
            saveDecryptedMsg: false,
            delDecryptedMsg: false,
            loadRestrictionList: false,
            saveRestrictionList: false,
            loadAnnouncements: false,
            saveAnnouncements: false,
        },
        worker: {
            init: false,
            getWallet: false,
            getTxListMap: false,
            getUtxoListMap: false,
            addWallet: false,
            setChainTip: false,
            removeWallet: false,
            setActiveAppWallet: false,
            immediatelySyncAppWallet: false,
            resyncAppWallet: false,
            resyncSingleAccount: false,
            pauseSyncing: false,
            unpauseSyncing: false,
            toggleLockWallet: false,
            lockWallet: false,
            unlockWallet: false,
            deleteWallet: false,
            addHDAccount: false,
            removeHDAccount: false,
            addSVAccount: false,
            saveWallet: false,
            getExportJson: false,
            resetWalletName: false,
            toggleLockedUtxo: false,
            updateSpendingPassword: false,
            updateWalletType: false,
            updateLockPassword: false,
            checkPassword: false,
            removeLockPassword: false,
            isLockSet: false,
            updateAddressBook: false,
            updateSetting: false,
            updateWalletNotes: false,
            resetWalletIcon: false,
            resetWalletBackground: false,
            updateCatalystData: false
        },
        bex: {
            all: false,
            syncAccount: false,
        },
        dappbrowser: {
            all: false
        },
        dappexternal: {
            all: false
        },
        dappfunctions: false,
        syncProcess: false,
        syncWallet: false,
        syncHDAccount: false,
        syncSVAccount: false,
        initialUpdateAppWallet: false,
        initialUpdateHDAccount: false,
        syncCCVLockAccount: false,
        syncTxList: false,
        syncTxHashList: false,
        syncSVTxHashList: false,
        loadTxDetails: false,
        txDetailsScheduler: false,
        checkTxOnChain: false,
        syncStakeInfo: false,
        encryptIWallet: false,
        decryptIWallet: false,
        initWalletWorkers: false,
        terminateWalletWorkers: false,
        addAppWallet: false,
        removeAppWallet: false,
        getAppWallet: false,
        getExportJson: false,
        manageWarning: false,
        setActiveAppWallet: false,
        immediatelySyncAppWallet: false,
        toggleLockWallet: false,
        isLockSet: false,
        unlockWallet: false,
        lockWallet: false,
        deleteWallet: false,
        addHDAccount: false,
        removeHDAccount: false,
        addSVAccount: false,
        removeWallet: false,
        resyncAppWallet: false,
        resyncSingleAccount: false,
        setChainTip: false,
        pauseSyncing: false,
        unpauseSyncing: false,
        resetWalletName: false,
        updateSpendingPassword: false,
        updateWalletType: false,
        updateLockPassword: false,
        checkPassword: false,
        updateAddressBook: false,
        updateSetting: false,
        blockFrostInfos: false,
        walletBackground: false,
        updateWalletNote: false
    },
    pooldata: {
        updatePoolLiveDelegation: false,
        updatePoolMetadata: false,
        updatePoolMetaExt: false,
        pullPools: false,
        db: false
    },
    backend: {
        updatePoolList: false,
        api: {
            websocket: false,
            tip: false,
            tipChanged: false
        },
        rpc: {
            get_tip: false,
            sync_tx: false,
            sync_tx_hashes: false,
            sync_tx_details: false,
            sync_stake_info: false,
            sync_stake_info_hashes: false,
            update_pool_live_delegation: false,
            get_pool_live_data: false,
            check_tx_on_chain: false
        },
        useWalletList: false,
        useWalletCreation: false,
        db: {
            open: false,
            query: false,
            saveWallet: false,
            reloadWalletList: false,
            loadWallet: false,
            reloadWalletIdList: false
        },
    },
    lib: {
        decryptionWarning: false,
        wallet: {
            updateBalance: false
        },
        account: {
            expand: false,
            addTxHashes: false,
            addTransactions: false,
            addStakeInfo: false,
            addRewards: false,
            addWithdrawals: false,
            addUtxoHashes: false,
            addUtxos: false,
            addAddresses: false
        },
        address: {
            parseType: false
        },
        milkomeda: {
            initConfig: false,
            getData: false
        }
    },
    cip30: {
        all: false
    },
    cip62: {
        all: false
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Print);


/***/ }),

/***/ 95727:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "R": () => (/* binding */ createIAccount)
});

;// CONCATENATED MODULE: ../ccw-lib2/core/IBaseStore.ts
const createIBaseStore = () => {
    return {
        payment: [],
        change: [],
        external: [],
        stake: [],
        stakeExternal: []
    };
};

;// CONCATENATED MODULE: ../ccw-lib2/core/IKeyStore.ts
const createIKeyStore = () => {
    return {
        payment: [],
        change: [],
        stake: [],
        script: []
    };
};

// EXTERNAL MODULE: ../ccw-lib2/core/IBalance.ts
var IBalance = __webpack_require__(58873);
;// CONCATENATED MODULE: ../ccw-lib2/core/IAccount.ts



const createIAccount = (id, pubBech32, prvBech32Encr, signType, path) => {
    return {
        // INetworkBound
        network: id,
        // IDerivedPrvKey
        // IPubKey
        pub: pubBech32,
        // IPrvKey
        prv: prvBech32Encr,
        signType: signType,
        // IDerivedKey
        path: path,
        index: path[path.length - 1],
        // IUtxoHashList
        utxoHashList: [],
        lockedUtxoHashList: [],
        // ITxHashList
        txHashList: [],
        txNoteList: [],
        // IAccount
        base: createIBaseStore(),
        keys: createIKeyStore(),
        name: null,
        // IAccount: aggregate properties
        lastTxBlockNo: 0,
        balance: (0,IBalance/* createIBalance */.q)(),
        expandRange: -1,
    };
};


/***/ }),

/***/ 72514:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "I": () => (/* binding */ IAppWalletDb)
/* harmony export */ });
// App specific implementation.
// Browser: indexedDb
// NodeJS: JSON or Postgresql
class IAppWalletDb {
    constructor() { }
}


/***/ }),

/***/ 58873:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "q": () => (/* binding */ createIBalance)
/* harmony export */ });
const createIBalance = () => {
    return {
        lovelace: '0',
        rewards: '0',
        total: '0',
        tokenBalance: []
    };
};


/***/ }),

/***/ 70485:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "v": () => (/* binding */ createIBlockBalance)
/* harmony export */ });
const createIBlockBalance = (blockNo) => {
    return {
        lovelace: "0",
        rewards: "0",
        total: "0",
        tokenBalance: [],
        blockNo: blockNo
    };
};


/***/ }),

/***/ 56866:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "J": () => (/* binding */ KeyType),
/* harmony export */   "X": () => (/* binding */ createIAddress)
/* harmony export */ });
var KeyType;
(function (KeyType) {
    KeyType[KeyType["uninitialized"] = 0] = "uninitialized";
    KeyType[KeyType["owned"] = 1] = "owned";
    KeyType[KeyType["external"] = 2] = "external";
})(KeyType || (KeyType = {}));
const createIAddress = (ref) => {
    return {
        bech32: ref.bech32,
        keyType: ref.keyType ?? KeyType.uninitialized
    };
};


/***/ }),

/***/ 31201:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "A": () => (/* binding */ createIPaymentAddress)
/* harmony export */ });
/* unused harmony export createIPaymentAddressList */
/* harmony import */ var _IKeys__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56866);

const createIPaymentAddress = (ref) => {
    return {
        bech32: ref.bech32,
        cred: ref.cred ?? '',
        used: ref.used ?? false,
        keyType: ref.keyType ?? _IKeys__WEBPACK_IMPORTED_MODULE_0__/* .KeyType.uninitialized */ .J.uninitialized
    };
};
const createIPaymentAddressList = (refs) => {
    const list = [];
    if (!refs)
        return list;
    for (const ref of refs) {
        list.push(createIPaymentAddress(ref));
    }
    return list;
};


/***/ }),

/***/ 67547:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "a": () => (/* binding */ createITokenBalance)
/* harmony export */ });
/* unused harmony export createITokenBalanceList */
/* harmony import */ var _lib_CSLUtils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(88181);

const createITokenBalance = (ref, negative = false) => {
    return {
        name: ref.name,
        policy: ref.policy,
        quantity: (negative ? '-' : '') + ref.quantity,
        fingerprint: !ref.fingerprint || ref.fingerprint.length === 0 ? (0,_lib_CSLUtils__WEBPACK_IMPORTED_MODULE_0__/* .getAssetIdBech32 */ .Pn)(ref.policy, ref.name) : ref.fingerprint,
    };
};
const createITokenBalanceList = (refs) => {
    const list = [];
    if (!refs)
        return list;
    for (const ref of refs) {
        list.push(createITokenBalance(ref));
    }
    return list;
};


/***/ }),

/***/ 79130:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "e": () => (/* binding */ createITx)
/* harmony export */ });
/* harmony import */ var _IToken__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(12872);
/* harmony import */ var _ITxMetadata__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(81262);
/* harmony import */ var _IWithdrawal__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6980);
/* harmony import */ var _ITxOut__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(24591);
/* harmony import */ var _ITxBalance__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(68730);
/* harmony import */ var _IBlockBalance__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(70485);
/* harmony import */ var _ITxCertificate__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(31323);
/* harmony import */ var _ITxScript__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(85747);








const createITx = (tx, createBalance = true) => {
    const resTx = {
        txHash: tx?.txHash ?? '',
        deposit: tx?.deposit ?? '0',
        fee: tx?.fee ?? '0',
        totalOutput: tx?.totalOutput ?? '0',
        // bridgeAddr:               tx?.bridgeAddr        ?? null,
        // bridgeFee:                tx?.bridgeFee         ?? null,
        blockIndex: tx?.blockIndex ?? 0,
        size: tx?.size ?? 0,
        invalidBefore: tx?.invalidBefore ?? 0,
        invalidHereafter: tx?.invalidHereafter ?? 0,
        blockNo: tx?.blockNo ?? -1,
        blockTime: tx?.blockTime ?? '',
        blockHash: tx?.blockHash ?? '',
        epochNo: tx?.epochNo ?? 0,
        inputList: (0,_ITxOut__WEBPACK_IMPORTED_MODULE_2__/* .createITxOutList */ .jq)(tx?.inputList ?? []),
        outputList: (0,_ITxOut__WEBPACK_IMPORTED_MODULE_2__/* .createITxOutList */ .jq)(tx?.outputList ?? []),
        referenceInputList: (0,_ITxOut__WEBPACK_IMPORTED_MODULE_2__/* .createITxOutList */ .jq)(tx?.referenceInputList ?? []),
        collateralInputList: (0,_ITxOut__WEBPACK_IMPORTED_MODULE_2__/* .createITxOutList */ .jq)(tx?.collateralInputList ?? []),
        collateralOutputList: (0,_ITxOut__WEBPACK_IMPORTED_MODULE_2__/* .createITxOutList */ .jq)(tx?.collateralOutputList ?? []),
        metadataList: (0,_ITxMetadata__WEBPACK_IMPORTED_MODULE_6__/* .createITxMetadataList */ .Z)(tx?.metadataList ?? []),
        mintList: (0,_IToken__WEBPACK_IMPORTED_MODULE_0__/* .createITokenList */ .GB)(tx?.mintList ?? []),
        withdrawalList: (0,_IWithdrawal__WEBPACK_IMPORTED_MODULE_1__/* .createIWithdrawalList */ .u)(tx?.withdrawalList ?? []),
        certificateList: (0,_ITxCertificate__WEBPACK_IMPORTED_MODULE_4__/* .createITxCertificateList */ .wy)(tx?.certificateList ?? []),
        nativeScriptList: (0,_ITxScript__WEBPACK_IMPORTED_MODULE_5__/* .createITxNativeScriptList */ .Dz)(tx?.nativeScriptList ?? []),
        plutusContractList: (0,_ITxScript__WEBPACK_IMPORTED_MODULE_5__/* .createITxPlutusContractList */ .vN)(tx?.plutusContractList ?? [])
    };
    if (tx?.balance) {
        resTx.balance = tx.balance;
    }
    else if (createBalance) {
        resTx.balance = (0,_ITxBalance__WEBPACK_IMPORTED_MODULE_3__/* .createITxBalance */ .I)();
    }
    if (tx?.accountBalance) {
        resTx.accountBalance = tx.accountBalance;
    }
    else if (createBalance) {
        resTx.accountBalance = (0,_IBlockBalance__WEBPACK_IMPORTED_MODULE_7__/* .createIBlockBalance */ .v)(resTx.blockNo);
    }
    return resTx;
};


/***/ }),

/***/ 68730:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "I": () => (/* binding */ createITxBalance),
/* harmony export */   "f": () => (/* binding */ ITxBalanceType)
/* harmony export */ });
var ITxBalanceType;
(function (ITxBalanceType) {
    ITxBalanceType[ITxBalanceType["uninitialized"] = 0] = "uninitialized";
    ITxBalanceType[ITxBalanceType["withdrawal"] = 1] = "withdrawal";
    // TODO: differentiate between pool registration and stake key registration
    ITxBalanceType[ITxBalanceType["deposit"] = 2] = "deposit";
    ITxBalanceType[ITxBalanceType["receivedTokens"] = 4] = "receivedTokens";
    ITxBalanceType[ITxBalanceType["sentTokens"] = 8] = "sentTokens";
    ITxBalanceType[ITxBalanceType["intraWallet"] = 16] = "intraWallet";
    ITxBalanceType[ITxBalanceType["sentAda"] = 32] = "sentAda";
    ITxBalanceType[ITxBalanceType["receivedAda"] = 64] = "receivedAda";
    ITxBalanceType[ITxBalanceType["external"] = 128] = "external";
    ITxBalanceType[ITxBalanceType["externalWithdrawal"] = 256] = "externalWithdrawal";
})(ITxBalanceType || (ITxBalanceType = {}));
const createITxBalance = () => {
    return {
        in: '0',
        out: '0',
        total: '0',
        ownIn: '0',
        ownOut: '0',
        ownTotal: '0',
        ownWithdrawalTotal: '0',
        colIn: '0',
        colOut: '0',
        colTotal: '0',
        fee: '0',
        deposit: '0',
        ownInTokens: [],
        ownOutTokens: [],
        ownDiffTokens: [],
        colInTokens: [],
        colOutTokens: [],
        colTotalTokens: [],
        type: ITxBalanceType.uninitialized
    };
};


/***/ }),

/***/ 71987:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Gr": () => (/* binding */ purpose),
/* harmony export */   "e2": () => (/* binding */ coin),
/* harmony export */   "tS": () => (/* binding */ chain)
/* harmony export */ });
const purpose = {
    hdwallet: 1852,
    multisig: 1854,
    minting: 1855,
    voting: 1694
};
const coin = {
    ada: 1815
};
const chain = {
    payment: 0,
    change: 1,
    stake: 2
};


/***/ }),

/***/ 42566:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EA": () => (/* binding */ svAccountPath)
/* harmony export */ });
/* unused harmony exports svMinLockAmount, svMaxLockAmount, svInitLockBoost, svMinLockEpochs, svMaxLockEpochs, svMetadataKey, policyMesmerizer, svPoolList */
/* harmony import */ var src_ccw_lib_core_lib_CSLConstants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(71987);

const svAccountPath = [src_ccw_lib_core_lib_CSLConstants__WEBPACK_IMPORTED_MODULE_0__/* .purpose.multisig */ .Gr.multisig, src_ccw_lib_core_lib_CSLConstants__WEBPACK_IMPORTED_MODULE_0__/* .coin.ada */ .e2.ada, 0];
const svMinLockAmount = '500000000'; // 500 ADA
const svMaxLockAmount = '1000000000000'; // 1MM ADA
const svInitLockBoost = 1.135; // 13.5% extra rewards on start
const svMinLockEpochs = 12;
const svMaxLockEpochs = 36;
const svMetadataKey = 3322;
const policyMesmerizer = '6cf6b5cf0fefbe9e69d640d8be84912bb2c9e132671954548790bcfb';
const svPoolList = {
    mainnet: [
        { name: 'sv-p0', id: 'pool16u5trhs7ysdh2e8aadk0p8xp52sczl8s29ay6ythv3sxujmdfeu', accountPubKeyOwner: 'xpub10yzycylh6fyrqkvtp4lceujqf8927pf4lswwj4asg99hcrkt7c8r8s6k5eh0txeqxvlxjz4a9tpg5wz7d9njnen2wka3afjrvkgg8acdfec7v', accountStakeKey: 'stake1uyy3wq6uj7d4muaryxturw2k6vzyvf8mckxc034cht7kaeczm0v74' },
        { name: 'sv-p1', id: 'pool1rn25pylervsvvxytr8ur56tf347zcrwaumpesrv97mfl70d4syy', accountPubKeyOwner: 'xpub1235n5c4jelk343n75u854prdd4lapfmhqn7962keet0jzfxynwvragljxtyvuwgtqf0tg0krkfesv72r8vqj7cnyv89zmxlccv4049gwkvx6t', accountStakeKey: 'stake1u90ghl5vhlmsadvelpy7jwseykhkurcds3u63w3h7zj7xws3pr43y' },
        { name: 'sv-p2', id: 'pool1e7nfdwhwc3a888v7myz3xulkcxuzl9k9yq82ud4qgssh2hw2wj9', accountPubKeyOwner: 'xpub1rxx235hwxad3g7yv0szkcftw5hk2dklqyg4s6gtvgw87j5rpm4fj9qhsx0j80r3s0v6844pxv4cmxe8rds6ldag8lrz0j9gn5ye0hucjvuxqg', accountStakeKey: 'stake1ux96py504z6s6fny9495hcu9jdp9a8mrqv4gf6uucnf43kgz9xgnh' },
        { name: 'sv-p3', id: 'pool1lfzn653ntzj9tfpqxyl8rvhdj2a594dpj9p0wq9klw54xypjqkq', accountPubKeyOwner: 'xpub1mlmkc2quyqnnwttwerjlf7pxlz5ltydrr327skdmgy6xe032annw52v4zuska5ndm5my49c9v353ys2k8ndq49w2w9rtle8y3z2sf3glws6v7', accountStakeKey: 'stake1ux9fpkev56g43l4nrpnjp9nvrck59jkmfvn9n9sk9lcwm9cmfmau3' },
        { name: 'sv-p4', id: 'pool1sfjaflutnn7dccfcy62plt4p5lw3tyeccj7mmea69yv5j0kh9xr', accountPubKeyOwner: 'xpub1ekjn4eeeutuzvmf0cfwp4nx5cqz4kkj4ahe7e8687hnnu28mfskr0v7v3dlwnhz7musmx4p72gxsqk66umdqlme67ysexd58ds2j7ssjdlf8z', accountStakeKey: 'stake1u93dfy578rl8cw0avchzy7w2y4hjqzp63u45a6trlh8dcls37agax' },
        { name: 'sv-p5', id: 'pool1vmusmdg6pm2cneclgpuglddre0d2nzumu44kw2w8wckp5jl7qp5', accountPubKeyOwner: 'xpub1ml2tff8y8va5unm7lldynemrt856uh4gdc0ekrx05hrwkt26czwh33lz5jh743gj7hyhd3ukjkmsnktn67llr0ww5yqm99hh04v2smsz0s6ll', accountStakeKey: 'stake1uygaeyqvfkcmhaex5zsdcj96r9a9ajuwrhy2qm8t2d7wuzctv27xg' },
        { name: 'sv-p6', id: 'pool1wah8tme6d9hwzm9kqcn2z744ej33r0awlccxv97cj9cm2ww3z9v', accountPubKeyOwner: 'xpub10hm4clcr7xquyuz7krz29fhvckfy2cd320ew54wy8rha5dq5mgfmxk7z04ukzmmu9u0yjyuu0uvd9reev9ua2mlx7aypetdqpnga4hclhp7nz', accountStakeKey: 'stake1u8asz3ztcwp2avqmdcer5wdz7z0nwl9dnh8nupxh53fu97sxz8pnh' },
        { name: 'sv-p7', id: 'pool130k088m5gpeeqmc4f2edjrhwq2fpsvd96n9mq86exqdcg0x90g2', accountPubKeyOwner: 'xpub1dqn90alduyynd0kknwy9z3vtl6qsxulfl0qgjn28mh3wv0c7lwam99tvdd8s6zymgv40y697dk8eckafvduhmmkwmqjpftlx0hj0etcktvpkp', accountStakeKey: 'stake1u8cpl6ykzy0ezy2wc95wuqqws2xsjmpq8egdr5fzudrhxqgrnprsl' },
        { name: 'sv-p8', id: 'pool1cu49r3wxzswgnvaht55y8c8n0snwlkrp5t05hcgefaprghn98ln', accountPubKeyOwner: 'xpub120tjgvmwcx77zjddr9v400p420tsajnvz80zpwc5qv807mgj0mymxzvzmk9tfj7cgzc6pn0vzzxa5glry8wqletmjngnf547ahtk0lgzkmfq5', accountStakeKey: 'stake1u83wur2rvvngqynvwjvn76kyvev0wd65pzgweadwal3nnxcls6up7' },
        { name: 'sv-p9', id: 'pool1hd35dlffm2msa8fa0zv9lgqeaphwj6vcpwxfwk4mysgeuhkuazw', accountPubKeyOwner: 'xpub1vn69ujmpz5rdn54rdst9d3nhaul8vsw7nmhujea99dsg0zz7pjkllcyrz38fyhqgzvvy832sup8zcyz7zymqxna3443kyxvl2860lrqzpsawx', accountStakeKey: 'stake1uxkpt85zhe3jh4cy57ch4rkcnt746ykky07ncz7h7cq6jlgal2suz' },
    ],
    guild: [
        { name: 'sv-p0', id: 'pool1pe6aymtlvgefq466crertdautm2lqrvq7k7vx6dmhytywlvfhyl', accountPubKeyOwner: 'xpub1nch05456m9v3yzl3cxppwfe8vxeq36glsk3aacm2hj35xls04gcp8xuh42dgyndzzyawa9xzrytpn00pnwj7a7sd54nu8svhng5gnvsq85yaa', accountStakeKey: 'stake_test1ur5ae0h8wpc7dp2qjgws62k4a96cm4wwjdzzs44j503kdmckjt7cs' },
        { name: 'sv-p1', id: 'pool1rhwdtvjfgzh2yk3d2w93p4l42kv7ncjj9av8g3emt0hhxfugypp', accountPubKeyOwner: 'xpub1yud2c25xuquusp9r6zm5ggyv49738k0eus64z8kr6nf2s8axrrvd0kmkl7c6uwh4lhp29gfesy8sq03wt92y7aqfq87y6f7js8vewsq5smy59', accountStakeKey: 'stake_test1upaxzf0ts8z6leexm3w2fe6v5amkexa3qgh5xmpe7npga7c833pyx' }
    ]
};


/***/ }),

/***/ 56782:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "U": () => (/* binding */ GenesisStore)
});

;// CONCATENATED MODULE: ../ccw-lib2/network/mainnet/alonzo.json
const alonzo_namespaceObject = JSON.parse('{"lovelacePerUTxOWord":34482,"executionPrices":{"prSteps":{"numerator":721,"denominator":10000000},"prMem":{"numerator":577,"denominator":10000}},"maxTxExUnits":{"exUnitsMem":10000000,"exUnitsSteps":10000000000},"maxBlockExUnits":{"exUnitsMem":50000000,"exUnitsSteps":40000000000},"maxValueSize":5000,"collateralPercentage":150,"maxCollateralInputs":3}');
;// CONCATENATED MODULE: ../ccw-lib2/network/guild/alonzo.json
const guild_alonzo_namespaceObject = JSON.parse('{"collateralPercentage":1,"maxBlockExUnits":{"exUnitsMem":500000000000,"exUnitsSteps":500000000000},"maxCollateralInputs":5,"maxValueSize":4000,"executionPrices":{"prMem":0.1,"prSteps":0.1},"lovelacePerUTxOWord":1,"maxTxExUnits":{"exUnitsMem":500000000000,"exUnitsSteps":500000000000}}');
;// CONCATENATED MODULE: ../ccw-lib2/network/shareslake/alonzo.json
const shareslake_alonzo_namespaceObject = JSON.parse('{"collateralPercentage":150,"maxTxExUnits":{"exUnitsMem":10000000,"exUnitsSteps":10000000000},"maxBlockExUnits":{"exUnitsMem":50000000,"exUnitsSteps":40000000000},"maxCollateralInputs":3,"maxValueSize":5000,"executionPrices":{"prSteps":{"numerator":721,"denominator":10000000},"prMem":{"numerator":577,"denominator":10000}},"lovelacePerUTxOWord":34482}');
;// CONCATENATED MODULE: ../ccw-lib2/network/preprod/alonzo.json
const preprod_alonzo_namespaceObject = JSON.parse('{"lovelacePerUTxOWord":34482,"executionPrices":{"prSteps":{"numerator":721,"denominator":10000000},"prMem":{"numerator":577,"denominator":10000}},"maxTxExUnits":{"exUnitsMem":10000000,"exUnitsSteps":10000000000},"maxBlockExUnits":{"exUnitsMem":50000000,"exUnitsSteps":40000000000},"maxValueSize":5000,"collateralPercentage":150,"maxCollateralInputs":3}');
;// CONCATENATED MODULE: ../ccw-lib2/network/preview/alonzo.json
const preview_alonzo_namespaceObject = JSON.parse('{"lovelacePerUTxOWord":34482,"executionPrices":{"prSteps":{"numerator":721,"denominator":10000000},"prMem":{"numerator":577,"denominator":10000}},"maxTxExUnits":{"exUnitsMem":10000000,"exUnitsSteps":10000000000},"maxBlockExUnits":{"exUnitsMem":50000000,"exUnitsSteps":40000000000},"maxValueSize":5000,"collateralPercentage":150,"maxCollateralInputs":3}');
;// CONCATENATED MODULE: ../ccw-lib2/network/mainnet/shelley.json
const shelley_namespaceObject = JSON.parse('{"activeSlotsCoeff":0.05,"protocolParams":{"protocolVersion":{"minor":0,"major":2},"decentralisationParam":1,"eMax":18,"extraEntropy":{"tag":"NeutralNonce"},"maxTxSize":16384,"maxBlockBodySize":65536,"maxBlockHeaderSize":1100,"minFeeA":44,"minFeeB":155381,"minUTxOValue":1000000,"poolDeposit":500000000,"minPoolCost":340000000,"keyDeposit":2000000,"nOpt":150,"rho":0.003,"tau":0.2,"a0":0.3},"updateQuorum":5,"networkId":"Mainnet","initialFunds":{},"maxLovelaceSupply":45000000000000000,"networkMagic":764824073,"epochLength":432000,"systemStart":"2017-09-23T21:44:51Z","slotsPerKESPeriod":129600,"slotLength":1,"maxKESEvolutions":62,"securityParam":2160}');
;// CONCATENATED MODULE: ../ccw-lib2/network/guild/shelley.json
const guild_shelley_namespaceObject = JSON.parse('{"maxLovelaceSupply":45000000000000000,"securityParam":36,"slotsPerKESPeriod":129600,"updateQuorum":1,"activeSlotsCoeff":0.05,"protocolParams":{"minUTxOValue":1000000,"eMax":18,"extraEntropy":{"tag":"NeutralNonce"},"minFeeB":1000,"tau":0.1,"maxBlockBodySize":65536,"minPoolCost":340000000,"minFeeA":1,"maxTxSize":16384,"nOpt":10,"maxBlockHeaderSize":1100,"keyDeposit":2000000,"protocolVersion":{"minor":0,"major":2},"poolDeposit":500000000,"a0":0.3,"rho":0.0003,"decentralisationParam":0.8},"networkMagic":141,"maxKESEvolutions":62,"networkId":"Testnet","slotLength":1,"systemStart":"2021-12-09T22:55:22Z","epochLength":3600}');
;// CONCATENATED MODULE: ../ccw-lib2/network/shareslake/shelley.json
const shareslake_shelley_namespaceObject = JSON.parse('{"maxLovelaceSupply":10000000000000000,"securityParam":2160,"slotsPerKESPeriod":129600,"updateQuorum":5,"activeSlotsCoeff":0.1,"protocolParams":{"minUTxOValue":1000000,"eMax":18,"extraEntropy":{"tag":"NeutralNonce"},"minFeeB":1000,"tau":0,"maxBlockBodySize":65536,"minPoolCost":100000000,"minFeeA":3,"maxTxSize":16384,"nOpt":150,"maxBlockHeaderSize":1100,"keyDeposit":2000000,"protocolVersion":{"minor":0,"major":2},"poolDeposit":300000000,"a0":0.2,"rho":0,"decentralisationParam":1},"networkMagic":777333,"initialFunds":{},"maxKESEvolutions":60,"networkId":"Mainnet","slotLength":1,"systemStart":"2022-04-26T22:58:07Z","epochLength":259200}');
;// CONCATENATED MODULE: ../ccw-lib2/network/preprod/shelley.json
const preprod_shelley_namespaceObject = JSON.parse('{"activeSlotsCoeff":0.05,"epochLength":432000,"maxKESEvolutions":62,"maxLovelaceSupply":45000000000000000,"networkId":"Testnet","networkMagic":1,"protocolParams":{"protocolVersion":{"minor":0,"major":2},"decentralisationParam":1,"eMax":18,"extraEntropy":{"tag":"NeutralNonce"},"maxTxSize":16384,"maxBlockBodySize":65536,"maxBlockHeaderSize":1100,"minFeeA":44,"minFeeB":155381,"minUTxOValue":1000000,"poolDeposit":500000000,"minPoolCost":340000000,"keyDeposit":2000000,"nOpt":150,"rho":0.003,"tau":0.2,"a0":0.3},"securityParam":2160,"slotLength":1,"slotsPerKESPeriod":129600,"systemStart":"2022-06-01T00:00:00Z","updateQuorum":5}');
;// CONCATENATED MODULE: ../ccw-lib2/network/preview/shelley.json
const preview_shelley_namespaceObject = JSON.parse('{"activeSlotsCoeff":0.05,"epochLength":86400,"maxKESEvolutions":62,"maxLovelaceSupply":45000000000000000,"networkId":"Testnet","networkMagic":2,"protocolParams":{"protocolVersion":{"minor":0,"major":6},"decentralisationParam":1,"eMax":18,"extraEntropy":{"tag":"NeutralNonce"},"maxTxSize":16384,"maxBlockBodySize":65536,"maxBlockHeaderSize":1100,"minFeeA":44,"minFeeB":155381,"minUTxOValue":1000000,"poolDeposit":500000000,"minPoolCost":340000000,"keyDeposit":2000000,"nOpt":150,"rho":0.003,"tau":0.2,"a0":0.3},"securityParam":432,"slotLength":1,"slotsPerKESPeriod":129600,"systemStart":"2022-10-25T00:00:00Z","updateQuorum":5}');
;// CONCATENATED MODULE: ../ccw-lib2/network/mainnet/byron.json
const byron_namespaceObject = JSON.parse('{"blockVersionData":{"heavyDelThd":"300000000000","maxBlockSize":"2000000","maxHeaderSize":"2000000","maxProposalSize":"700","maxTxSize":"4096","mpcThd":"20000000000000","scriptVersion":0,"slotDuration":"20000","softforkRule":{"initThd":"900000000000000","minThd":"600000000000000","thdDecrement":"50000000000000"},"txFeePolicy":{"multiplier":"43946000000","summand":"155381000000000"},"unlockStakeEpoch":"18446744073709551615","updateImplicit":"10000","updateProposalThd":"100000000000000","updateVoteThd":"1000000000000"},"ftsSeed":"76617361206f7061736120736b6f766f726f64612047677572646120626f726f64612070726f766f6461","protocolConsts":{"k":2160,"protocolMagic":764824073,"vssMaxTTL":6,"vssMinTTL":2},"startTime":1506203091}');
;// CONCATENATED MODULE: ../ccw-lib2/network/guild/byron.json
const guild_byron_namespaceObject = JSON.parse('{"startTime":1639090522,"blockVersionData":{"scriptVersion":0,"slotDuration":"100","maxBlockSize":"641000","maxHeaderSize":"200000","maxTxSize":"4096","maxProposalSize":"700","mpcThd":"200000","heavyDelThd":"300000","updateVoteThd":"100000","updateProposalThd":"100000","updateImplicit":"10000","softforkRule":{"initThd":"900000","minThd":"600000","thdDecrement":"100000"},"txFeePolicy":{"summand":"0","multiplier":"439460"},"unlockStakeEpoch":"184467"},"protocolConsts":{"k":36,"protocolMagic":141},"avvmDistr":{}}');
;// CONCATENATED MODULE: ../ccw-lib2/network/shareslake/byron.json
const shareslake_byron_namespaceObject = JSON.parse('{"startTime":1651013887,"blockVersionData":{"scriptVersion":0,"slotDuration":"1000","maxBlockSize":"2000000","maxHeaderSize":"2000000","maxTxSize":"4096","maxProposalSize":"700","mpcThd":"20000000000000","heavyDelThd":"300000000000","updateVoteThd":"1000000000000","updateProposalThd":"100000000000000","updateImplicit":"10000","softforkRule":{"initThd":"900000000000000","minThd":"600000000000000","thdDecrement":"50000000000000"},"txFeePolicy":{"summand":"155381000000000","multiplier":"43946000000"},"unlockStakeEpoch":"18446744073709551615"},"protocolConsts":{"k":2160,"protocolMagic":777333}}');
;// CONCATENATED MODULE: ../ccw-lib2/network/preprod/byron.json
const preprod_byron_namespaceObject = JSON.parse('{"startTime":1654041600,"blockVersionData":{"scriptVersion":0,"slotDuration":"20000","maxBlockSize":"2000000","maxHeaderSize":"2000000","maxTxSize":"4096","maxProposalSize":"700","mpcThd":"20000000000000","heavyDelThd":"300000000000","updateVoteThd":"1000000000000","updateProposalThd":"100000000000000","updateImplicit":"10000","softforkRule":{"initThd":"900000000000000","minThd":"600000000000000","thdDecrement":"50000000000000"},"txFeePolicy":{"summand":"155381000000000","multiplier":"43946000000"},"unlockStakeEpoch":"18446744073709551615"},"protocolConsts":{"k":2160,"protocolMagic":1}}');
;// CONCATENATED MODULE: ../ccw-lib2/network/preview/byron.json
const preview_byron_namespaceObject = JSON.parse('{"startTime":1666656000,"blockVersionData":{"scriptVersion":0,"slotDuration":"20000","maxBlockSize":"2000000","maxHeaderSize":"2000000","maxTxSize":"4096","maxProposalSize":"700","mpcThd":"20000000000000","heavyDelThd":"300000000000","updateVoteThd":"1000000000000","updateProposalThd":"100000000000000","updateImplicit":"10000","softforkRule":{"initThd":"900000000000000","minThd":"600000000000000","thdDecrement":"50000000000000"},"txFeePolicy":{"summand":"155381000000000","multiplier":"43946000000"},"unlockStakeEpoch":"18446744073709551615"},"protocolConsts":{"k":432,"protocolMagic":2}}');
;// CONCATENATED MODULE: ../ccw-lib2/network/GenesisStore.ts















const GenesisStore = {
    mainnet: {
        alonzo: alonzo_namespaceObject,
        shelley: shelley_namespaceObject,
        byron: byron_namespaceObject
    },
    guild: {
        alonzo: guild_alonzo_namespaceObject,
        shelley: guild_shelley_namespaceObject,
        byron: guild_byron_namespaceObject
    },
    shareslake: {
        alonzo: shareslake_alonzo_namespaceObject,
        shelley: shareslake_shelley_namespaceObject,
        byron: shareslake_byron_namespaceObject
    },
    preprod: {
        alonzo: preprod_alonzo_namespaceObject,
        shelley: preprod_shelley_namespaceObject,
        byron: preprod_byron_namespaceObject
    },
    preview: {
        alonzo: preview_alonzo_namespaceObject,
        shelley: preview_shelley_namespaceObject,
        byron: preview_byron_namespaceObject
    },
};


/***/ }),

/***/ 13022:
/***/ (() => {

/* (ignored) */

/***/ }),

/***/ 52361:
/***/ (() => {

/* (ignored) */

/***/ }),

/***/ 94616:
/***/ (() => {

/* (ignored) */

/***/ })

}]);
//# sourceMappingURL=886.js.map