"use strict";
(this["webpackChunkccw_frontend"] = this["webpackChunkccw_frontend"] || []).push([[185],{

/***/ 19960:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ SignData)
});

// EXTERNAL MODULE: ./node_modules/@vue/runtime-core/dist/runtime-core.esm-bundler.js
var runtime_core_esm_bundler = __webpack_require__(83673);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/SignData.vue?vue&type=template&id=1480eff8&ts=true

const _hoisted_1 = { class: "cc-page-wallet cc-text-sz" };
function render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridButtonSecondary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonSecondary");
    const _component_SignDataConfirm = (0,runtime_core_esm_bundler/* resolveComponent */.up)("SignDataConfirm");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_1, [
        (_ctx.activeAccount && _ctx.activeWalletData && _ctx.addrCbor && _ctx.payload)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_SignDataConfirm, {
                key: 0,
                onSubmit: _ctx.onSigned,
                onErrorProof: _ctx.onErrorProofs,
                onErrorBadRequest: _ctx.onErrorBadRequest,
                account: _ctx.activeAccount,
                wallet: _ctx.activeWalletData,
                addr: _ctx.addrCbor,
                payload: _ctx.payload,
                "text-id": "wallet.signdata.step.confirm"
            }, {
                btnBack: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonSecondary, {
                        label: _ctx.it('common.label.cancel'),
                        link: _ctx.onCancel,
                        type: "button",
                        class: "col-start-0 col-span-6 sm:col-start-0 sm:col-span-3"
                    }, null, 8, ["label", "link"])
                ]),
                _: 1
            }, 8, ["onSubmit", "onErrorProof", "onErrorBadRequest", "account", "wallet", "addr", "payload"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
    ]));
}

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/SignData.vue?vue&type=template&id=1480eff8&ts=true

// EXTERNAL MODULE: ./node_modules/@vue/reactivity/dist/reactivity.esm-bundler.js
var reactivity_esm_bundler = __webpack_require__(61959);
// EXTERNAL MODULE: ./node_modules/quasar/src/composables/use-quasar.js
var use_quasar = __webpack_require__(48825);
// EXTERNAL MODULE: ./src/composables/ccw/useTranslation.ts
var useTranslation = __webpack_require__(19376);
// EXTERNAL MODULE: ./src/composables/ccw/store/useActiveWallet.ts
var useActiveWallet = __webpack_require__(52144);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/signdata/SignDataConfirm.vue + 7 modules
var SignDataConfirm = __webpack_require__(7274);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridHeadline.vue + 3 modules
var GridHeadline = __webpack_require__(63593);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridText.vue + 4 modules
var GridText = __webpack_require__(96834);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridButtonPrimary.vue + 3 modules
var GridButtonPrimary = __webpack_require__(12559);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridButtonSecondary.vue + 3 modules
var GridButtonSecondary = __webpack_require__(72713);
// EXTERNAL MODULE: ./src/lib/utils/useLocalStorage.ts
var useLocalStorage = __webpack_require__(34787);
// EXTERNAL MODULE: ./src/lib/utils/useBexStorage.ts
var useBexStorage = __webpack_require__(6296);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/SignData.vue?vue&type=script&lang=ts

;









/* harmony default export */ const SignDatavue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'SignData',
    components: {
        GridHeadline: GridHeadline/* default */.Z,
        GridText: GridText/* default */.Z,
        GridButtonPrimary: GridButtonPrimary/* default */.Z,
        GridButtonSecondary: GridButtonSecondary/* default */.Z,
        SignDataConfirm: SignDataConfirm/* default */.Z
    },
    setup() {
        const { it } = (0,useTranslation/* useTranslation */.$)();
        const { activeAccount, activeWalletData } = (0,useActiveWallet/* useActiveWallet */.r)();
        const $q = (0,use_quasar/* default */.Z)();
        const addrCbor = (0,reactivity_esm_bundler/* ref */.iH)(null);
        const payload = (0,reactivity_esm_bundler/* ref */.iH)(null);
        function initSignData(account) {
            addrCbor.value = (0,useLocalStorage/* getSignDataAddr */.bL)();
            payload.value = (0,useLocalStorage/* getSignDataPayload */.CD)();
        }
        (0,runtime_core_esm_bundler/* watchEffect */.m0)(() => {
            if (activeAccount.value) {
                initSignData(activeAccount.value);
            }
        });
        function onErrorProofs() {
            console.log('onErrorProofs: signData');
            //@ts-ignore
            if ($q.bex) {
                const eventFail = {
                    eventResponseKey: '',
                    data: {
                        api: 'onSignData',
                        payload: {
                            origin: useBexStorage/* bexOrigin.value */.g0.value ?? ''
                        },
                        response: {
                            success: false,
                            error: {
                                code: useBexStorage/* DataSignErrorCode.ProofGeneration */.wr.ProofGeneration,
                                info: 'wallet does not hold all keys to sign data'
                            }
                        }
                    }
                };
                console.log('sending fail:', eventFail.data);
                //@ts-ignore
                $q.bex.send('eternl.to.bg', eventFail.data);
            }
        }
        function onErrorBadRequest() {
            console.log('onErrorBadRequest: signData');
            //@ts-ignore
            if ($q.bex) {
                const eventFail = {
                    eventResponseKey: '',
                    data: {
                        api: 'onSignData',
                        payload: {
                            origin: useBexStorage/* bexOrigin.value */.g0.value ?? ''
                        },
                        response: {
                            success: false,
                            error: {
                                code: useBexStorage/* DataSignErrorCode.InvalidFormat */.wr.InvalidFormat,
                                info: 'invalid data format'
                            }
                        }
                    }
                };
                console.log('sending fail:', eventFail.data);
                //@ts-ignore
                $q.bex.send('eternl.to.bg', eventFail.data);
            }
        }
        function onCancel() {
            console.log('onCancel: signData');
            //@ts-ignore
            if ($q.bex) {
                const eventFail = {
                    eventResponseKey: '',
                    data: {
                        api: 'onSignData',
                        payload: {
                            origin: useBexStorage/* bexOrigin.value */.g0.value ?? ''
                        },
                        response: {
                            success: false,
                            error: {
                                code: useBexStorage/* DataSignErrorCode.UserDeclined */.wr.UserDeclined,
                                info: 'user declined to sign data'
                            }
                        }
                    }
                };
                console.log('sending fail:', eventFail.data);
                //@ts-ignore
                $q.bex.send('eternl.to.bg', eventFail.data);
            }
        }
        function onSigned(payload) {
            console.log('onSigned: signedData', payload.signedData);
            if (payload && payload.signedData) {
                //@ts-ignore
                if ($q.bex) {
                    const eventSuccess = {
                        eventResponseKey: '',
                        data: {
                            api: 'onSignData',
                            payload: {
                                origin: useBexStorage/* bexOrigin.value */.g0.value ?? ''
                            },
                            response: {
                                signedData: payload.signedData,
                                success: true
                            }
                        }
                    };
                    console.log('sending success:', eventSuccess.data);
                    //@ts-ignore
                    $q.bex.send('eternl.to.bg', eventSuccess.data);
                }
            }
        }
        (0,runtime_core_esm_bundler/* onErrorCaptured */.d1)((e, instance, info) => {
            $q.notify({
                type: 'negative',
                message: 'error: ' + (e?.message ?? 'no error message') + ' info: ' + info,
                position: 'top-left',
                timeout: 225000
            });
            console.error('SignData: onErrorCaptured', e);
            setTimeout(() => { onCancel(); }, 225000);
            return true;
        });
        return {
            it,
            activeAccount,
            activeWalletData,
            addrCbor,
            payload,
            onCancel,
            onSigned,
            onErrorProofs,
            onErrorBadRequest
        };
    }
}));

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/SignData.vue?vue&type=script&lang=ts
 
// EXTERNAL MODULE: ./node_modules/vue-loader/dist/exportHelper.js
var exportHelper = __webpack_require__(74260);
;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/SignData.vue




;
const __exports__ = /*#__PURE__*/(0,exportHelper/* default */.Z)(SignDatavue_type_script_lang_ts, [['render',render]])

/* harmony default export */ const SignData = (__exports__);

/***/ })

}]);
//# sourceMappingURL=185.js.map