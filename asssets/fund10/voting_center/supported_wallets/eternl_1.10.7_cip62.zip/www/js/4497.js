"use strict";
(this["webpackChunkccw_frontend"] = this["webpackChunkccw_frontend"] || []).push([[4497],{

/***/ 36289:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Eq": () => (/* binding */ VotePlanId),
/* harmony export */   "OB": () => (/* binding */ Payload),
/* harmony export */   "T2": () => (/* binding */ ElectionPublicKey),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "Zr": () => (/* binding */ Settings),
/* harmony export */   "aW": () => (/* binding */ VoteCast),
/* harmony export */   "iL": () => (/* binding */ VoteCastTxBuilder)
/* harmony export */ });
/* unused harmony exports Certificate, Fragment, FragmentId, initSync */
/* harmony import */ var core_js_modules_es_typed_array_uint8_array_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(76105);
/* harmony import */ var core_js_modules_es_typed_array_uint8_array_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_uint8_array_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_typed_array_at_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(15123);
/* harmony import */ var core_js_modules_es_typed_array_at_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_at_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_typed_array_fill_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(88836);
/* harmony import */ var core_js_modules_es_typed_array_fill_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_fill_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_typed_array_find_last_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4331);
/* harmony import */ var core_js_modules_es_typed_array_find_last_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_find_last_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_typed_array_find_last_index_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(57648);
/* harmony import */ var core_js_modules_es_typed_array_find_last_index_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_find_last_index_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_typed_array_set_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(98685);
/* harmony import */ var core_js_modules_es_typed_array_set_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_set_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_typed_array_sort_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(12396);
/* harmony import */ var core_js_modules_es_typed_array_sort_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_sort_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_esnext_typed_array_to_reversed_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4260);
/* harmony import */ var core_js_modules_esnext_typed_array_to_reversed_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_typed_array_to_reversed_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_esnext_typed_array_to_sorted_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(26887);
/* harmony import */ var core_js_modules_esnext_typed_array_to_sorted_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_typed_array_to_sorted_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_esnext_typed_array_with_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(75221);
/* harmony import */ var core_js_modules_esnext_typed_array_with_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_typed_array_with_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(65663);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_typed_array_int32_array_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(68455);
/* harmony import */ var core_js_modules_es_typed_array_int32_array_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_int32_array_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_error_cause_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(76701);
/* harmony import */ var core_js_modules_es_error_cause_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_error_cause_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(10071);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_web_url_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(17965);
/* harmony import */ var core_js_modules_web_url_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_web_url_search_params_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(66016);
/* harmony import */ var core_js_modules_web_url_search_params_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_search_params_js__WEBPACK_IMPORTED_MODULE_15__);
/* module decorator */ module = __webpack_require__.hmd(module);
















let wasm;
const cachedTextDecoder = new TextDecoder('utf-8', {
  ignoreBOM: true,
  fatal: true
});
cachedTextDecoder.decode();
let cachedUint8Memory0 = new Uint8Array();
function getUint8Memory0() {
  if (cachedUint8Memory0.byteLength === 0) {
    cachedUint8Memory0 = new Uint8Array(wasm.memory.buffer);
  }
  return cachedUint8Memory0;
}
function getStringFromWasm0(ptr, len) {
  return cachedTextDecoder.decode(getUint8Memory0().subarray(ptr, ptr + len));
}
const heap = new Array(32).fill(undefined);
heap.push(undefined, null, true, false);
let heap_next = heap.length;
function addHeapObject(obj) {
  if (heap_next === heap.length) heap.push(heap.length + 1);
  const idx = heap_next;
  heap_next = heap[idx];
  heap[idx] = obj;
  return idx;
}
function getObject(idx) {
  return heap[idx];
}
function dropObject(idx) {
  if (idx < 36) return;
  heap[idx] = heap_next;
  heap_next = idx;
}
function takeObject(idx) {
  const ret = getObject(idx);
  dropObject(idx);
  return ret;
}
let WASM_VECTOR_LEN = 0;
const cachedTextEncoder = new TextEncoder('utf-8');
const encodeString = typeof cachedTextEncoder.encodeInto === 'function' ? function (arg, view) {
  return cachedTextEncoder.encodeInto(arg, view);
} : function (arg, view) {
  const buf = cachedTextEncoder.encode(arg);
  view.set(buf);
  return {
    read: arg.length,
    written: buf.length
  };
};
function passStringToWasm0(arg, malloc, realloc) {
  if (realloc === undefined) {
    const buf = cachedTextEncoder.encode(arg);
    const ptr = malloc(buf.length);
    getUint8Memory0().subarray(ptr, ptr + buf.length).set(buf);
    WASM_VECTOR_LEN = buf.length;
    return ptr;
  }
  let len = arg.length;
  let ptr = malloc(len);
  const mem = getUint8Memory0();
  let offset = 0;
  for (; offset < len; offset++) {
    const code = arg.charCodeAt(offset);
    if (code > 0x7F) break;
    mem[ptr + offset] = code;
  }
  if (offset !== len) {
    if (offset !== 0) {
      arg = arg.slice(offset);
    }
    ptr = realloc(ptr, len, len = offset + arg.length * 3);
    const view = getUint8Memory0().subarray(ptr + offset, ptr + len);
    const ret = encodeString(arg, view);
    offset += ret.written;
  }
  WASM_VECTOR_LEN = offset;
  return ptr;
}
let cachedInt32Memory0 = new Int32Array();
function getInt32Memory0() {
  if (cachedInt32Memory0.byteLength === 0) {
    cachedInt32Memory0 = new Int32Array(wasm.memory.buffer);
  }
  return cachedInt32Memory0;
}
function passArray8ToWasm0(arg, malloc) {
  const ptr = malloc(arg.length * 1);
  getUint8Memory0().set(arg, ptr / 1);
  WASM_VECTOR_LEN = arg.length;
  return ptr;
}
function _assertClass(instance, klass) {
  if (!(instance instanceof klass)) {
    throw new Error(`expected instance of ${klass.name}`);
  }
  return instance.ptr;
}
function getArrayU8FromWasm0(ptr, len) {
  return getUint8Memory0().subarray(ptr / 1, ptr / 1 + len);
}
function handleError(f, args) {
  try {
    return f.apply(this, args);
  } catch (e) {
    wasm.__wbindgen_exn_store(addHeapObject(e));
  }
}
/**
*/
class Certificate {
  static __wrap(ptr) {
    const obj = Object.create(Certificate.prototype);
    obj.ptr = ptr;
    return obj;
  }
  __destroy_into_raw() {
    const ptr = this.ptr;
    this.ptr = 0;
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm.__wbg_certificate_free(ptr);
  }
  /**
  * @param {VoteCast} vote_cast
  * @returns {Certificate}
  */
  static vote_cast(vote_cast) {
    _assertClass(vote_cast, VoteCast);
    var ptr0 = vote_cast.ptr;
    vote_cast.ptr = 0;
    const ret = wasm.certificate_vote_cast(ptr0);
    return Certificate.__wrap(ret);
  }
}
/**
*/
class ElectionPublicKey {
  static __wrap(ptr) {
    const obj = Object.create(ElectionPublicKey.prototype);
    obj.ptr = ptr;
    return obj;
  }
  __destroy_into_raw() {
    const ptr = this.ptr;
    this.ptr = 0;
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm.__wbg_electionpublickey_free(ptr);
  }
  /**
  * @param {string} hex_data
  * @returns {ElectionPublicKey}
  */
  static from_hex(hex_data) {
    try {
      const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
      const ptr0 = passStringToWasm0(hex_data, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
      const len0 = WASM_VECTOR_LEN;
      wasm.electionpublickey_from_hex(retptr, ptr0, len0);
      var r0 = getInt32Memory0()[retptr / 4 + 0];
      var r1 = getInt32Memory0()[retptr / 4 + 1];
      var r2 = getInt32Memory0()[retptr / 4 + 2];
      if (r2) {
        throw takeObject(r1);
      }
      return ElectionPublicKey.__wrap(r0);
    } finally {
      wasm.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
  * @param {Uint8Array} bytes
  * @returns {ElectionPublicKey}
  */
  static from_bytes(bytes) {
    try {
      const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
      const ptr0 = passArray8ToWasm0(bytes, wasm.__wbindgen_malloc);
      const len0 = WASM_VECTOR_LEN;
      wasm.electionpublickey_from_bytes(retptr, ptr0, len0);
      var r0 = getInt32Memory0()[retptr / 4 + 0];
      var r1 = getInt32Memory0()[retptr / 4 + 1];
      var r2 = getInt32Memory0()[retptr / 4 + 2];
      if (r2) {
        throw takeObject(r1);
      }
      return ElectionPublicKey.__wrap(r0);
    } finally {
      wasm.__wbindgen_add_to_stack_pointer(16);
    }
  }
}
/**
*/
class Fragment {
  static __wrap(ptr) {
    const obj = Object.create(Fragment.prototype);
    obj.ptr = ptr;
    return obj;
  }
  __destroy_into_raw() {
    const ptr = this.ptr;
    this.ptr = 0;
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm.__wbg_fragment_free(ptr);
  }
  /**
  * @returns {FragmentId}
  */
  id() {
    const ret = wasm.fragment_id(this.ptr);
    return FragmentId.__wrap(ret);
  }
  /**
  * @param {Uint8Array} bytes
  * @returns {Fragment}
  */
  static from_bytes(bytes) {
    try {
      const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
      const ptr0 = passArray8ToWasm0(bytes, wasm.__wbindgen_malloc);
      const len0 = WASM_VECTOR_LEN;
      wasm.fragment_from_bytes(retptr, ptr0, len0);
      var r0 = getInt32Memory0()[retptr / 4 + 0];
      var r1 = getInt32Memory0()[retptr / 4 + 1];
      var r2 = getInt32Memory0()[retptr / 4 + 2];
      if (r2) {
        throw takeObject(r1);
      }
      return Fragment.__wrap(r0);
    } finally {
      wasm.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
  * @returns {Uint8Array}
  */
  to_bytes() {
    try {
      const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
      wasm.fragment_to_bytes(retptr, this.ptr);
      var r0 = getInt32Memory0()[retptr / 4 + 0];
      var r1 = getInt32Memory0()[retptr / 4 + 1];
      var r2 = getInt32Memory0()[retptr / 4 + 2];
      var r3 = getInt32Memory0()[retptr / 4 + 3];
      if (r3) {
        throw takeObject(r2);
      }
      var v0 = getArrayU8FromWasm0(r0, r1).slice();
      wasm.__wbindgen_free(r0, r1 * 1);
      return v0;
    } finally {
      wasm.__wbindgen_add_to_stack_pointer(16);
    }
  }
}
/**
* Identifier of a block fragment
*/
class FragmentId {
  static __wrap(ptr) {
    const obj = Object.create(FragmentId.prototype);
    obj.ptr = ptr;
    return obj;
  }
  __destroy_into_raw() {
    const ptr = this.ptr;
    this.ptr = 0;
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm.__wbg_fragmentid_free(ptr);
  }
}
/**
*/
class Payload {
  static __wrap(ptr) {
    const obj = Object.create(Payload.prototype);
    obj.ptr = ptr;
    return obj;
  }
  __destroy_into_raw() {
    const ptr = this.ptr;
    this.ptr = 0;
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm.__wbg_payload_free(ptr);
  }
  /**
  * @param {number} choice
  * @returns {Payload}
  */
  static new_public(choice) {
    const ret = wasm.payload_new_public(choice);
    return Payload.__wrap(ret);
  }
  /**
  * @param {VotePlanId} vote_plan
  * @param {number} options
  * @param {number} choice
  * @param {ElectionPublicKey} public_key
  * @returns {Payload}
  */
  static new_private(vote_plan, options, choice, public_key) {
    try {
      const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
      _assertClass(vote_plan, VotePlanId);
      _assertClass(public_key, ElectionPublicKey);
      wasm.payload_new_private(retptr, vote_plan.ptr, options, choice, public_key.ptr);
      var r0 = getInt32Memory0()[retptr / 4 + 0];
      var r1 = getInt32Memory0()[retptr / 4 + 1];
      var r2 = getInt32Memory0()[retptr / 4 + 2];
      if (r2) {
        throw takeObject(r1);
      }
      return Payload.__wrap(r0);
    } finally {
      wasm.__wbindgen_add_to_stack_pointer(16);
    }
  }
}
/**
* Encapsulates blockchain settings needed for some operations.
*/
class Settings {
  static __wrap(ptr) {
    const obj = Object.create(Settings.prototype);
    obj.ptr = ptr;
    return obj;
  }
  __destroy_into_raw() {
    const ptr = this.ptr;
    this.ptr = 0;
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm.__wbg_settings_free(ptr);
  }
  /**
  * @param {string} json
  * @returns {Settings}
  */
  static from_json(json) {
    try {
      const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
      const ptr0 = passStringToWasm0(json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
      const len0 = WASM_VECTOR_LEN;
      wasm.settings_from_json(retptr, ptr0, len0);
      var r0 = getInt32Memory0()[retptr / 4 + 0];
      var r1 = getInt32Memory0()[retptr / 4 + 1];
      var r2 = getInt32Memory0()[retptr / 4 + 2];
      if (r2) {
        throw takeObject(r1);
      }
      return Settings.__wrap(r0);
    } finally {
      wasm.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
  * @returns {string}
  */
  to_json() {
    try {
      const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
      wasm.settings_to_json(retptr, this.ptr);
      var r0 = getInt32Memory0()[retptr / 4 + 0];
      var r1 = getInt32Memory0()[retptr / 4 + 1];
      var r2 = getInt32Memory0()[retptr / 4 + 2];
      var r3 = getInt32Memory0()[retptr / 4 + 3];
      var ptr0 = r0;
      var len0 = r1;
      if (r3) {
        ptr0 = 0;
        len0 = 0;
        throw takeObject(r2);
      }
      return getStringFromWasm0(ptr0, len0);
    } finally {
      wasm.__wbindgen_add_to_stack_pointer(16);
      wasm.__wbindgen_free(ptr0, len0);
    }
  }
}
/**
*/
class VoteCast {
  static __wrap(ptr) {
    const obj = Object.create(VoteCast.prototype);
    obj.ptr = ptr;
    return obj;
  }
  __destroy_into_raw() {
    const ptr = this.ptr;
    this.ptr = 0;
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm.__wbg_votecast_free(ptr);
  }
  /**
  * @param {VotePlanId} vote_plan
  * @param {number} proposal_index
  * @param {Payload} payload
  * @returns {VoteCast}
  */
  static new(vote_plan, proposal_index, payload) {
    _assertClass(vote_plan, VotePlanId);
    var ptr0 = vote_plan.ptr;
    vote_plan.ptr = 0;
    _assertClass(payload, Payload);
    var ptr1 = payload.ptr;
    payload.ptr = 0;
    const ret = wasm.votecast_new(ptr0, proposal_index, ptr1);
    return VoteCast.__wrap(ret);
  }
}
/**
*/
class VoteCastTxBuilder {
  static __wrap(ptr) {
    const obj = Object.create(VoteCastTxBuilder.prototype);
    obj.ptr = ptr;
    return obj;
  }
  __destroy_into_raw() {
    const ptr = this.ptr;
    this.ptr = 0;
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm.__wbg_votecasttxbuilder_free(ptr);
  }
  /**
  * Initializing of the VoteCastTxBuilder
  * @param {Settings} settings
  * @param {VoteCast} vote_cast
  * @returns {VoteCastTxBuilder}
  */
  static new(settings, vote_cast) {
    _assertClass(settings, Settings);
    var ptr0 = settings.ptr;
    settings.ptr = 0;
    _assertClass(vote_cast, VoteCast);
    var ptr1 = vote_cast.ptr;
    vote_cast.ptr = 0;
    const ret = wasm.votecasttxbuilder_new(ptr0, ptr1);
    return VoteCastTxBuilder.__wrap(ret);
  }
  /**
  * First step of the VoteCast transaction building process
  *
  * The `account` parameter gives the Ed25519Extended private key
  * of the account.
  * @param {string} hex_account_id
  * @returns {VoteCastTxBuilder}
  */
  prepare_tx(hex_account_id) {
    try {
      const ptr = this.__destroy_into_raw();
      const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
      const ptr0 = passStringToWasm0(hex_account_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
      const len0 = WASM_VECTOR_LEN;
      wasm.votecasttxbuilder_prepare_tx(retptr, ptr, ptr0, len0);
      var r0 = getInt32Memory0()[retptr / 4 + 0];
      var r1 = getInt32Memory0()[retptr / 4 + 1];
      var r2 = getInt32Memory0()[retptr / 4 + 2];
      if (r2) {
        throw takeObject(r1);
      }
      return VoteCastTxBuilder.__wrap(r0);
    } finally {
      wasm.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
  * Get a transaction signing data
  * @returns {Uint8Array}
  */
  get_sign_data() {
    try {
      const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
      wasm.votecasttxbuilder_get_sign_data(retptr, this.ptr);
      var r0 = getInt32Memory0()[retptr / 4 + 0];
      var r1 = getInt32Memory0()[retptr / 4 + 1];
      var r2 = getInt32Memory0()[retptr / 4 + 2];
      var r3 = getInt32Memory0()[retptr / 4 + 3];
      if (r3) {
        throw takeObject(r2);
      }
      var v0 = getArrayU8FromWasm0(r0, r1).slice();
      wasm.__wbindgen_free(r0, r1 * 1);
      return v0;
    } finally {
      wasm.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
  * Finish step of building VoteCast fragment with passing an already signed transaction data
  * @param {string} hex_signature
  * @returns {Fragment}
  */
  build_tx(hex_signature) {
    try {
      const ptr = this.__destroy_into_raw();
      const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
      const ptr0 = passStringToWasm0(hex_signature, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
      const len0 = WASM_VECTOR_LEN;
      wasm.votecasttxbuilder_build_tx(retptr, ptr, ptr0, len0);
      var r0 = getInt32Memory0()[retptr / 4 + 0];
      var r1 = getInt32Memory0()[retptr / 4 + 1];
      var r2 = getInt32Memory0()[retptr / 4 + 2];
      if (r2) {
        throw takeObject(r1);
      }
      return Fragment.__wrap(r0);
    } finally {
      wasm.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
  * Finish step of signing and building VoteCast fragment
  * @param {string} hex_account
  * @returns {Fragment}
  */
  sign_tx(hex_account) {
    try {
      const ptr = this.__destroy_into_raw();
      const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
      const ptr0 = passStringToWasm0(hex_account, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
      const len0 = WASM_VECTOR_LEN;
      wasm.votecasttxbuilder_sign_tx(retptr, ptr, ptr0, len0);
      var r0 = getInt32Memory0()[retptr / 4 + 0];
      var r1 = getInt32Memory0()[retptr / 4 + 1];
      var r2 = getInt32Memory0()[retptr / 4 + 2];
      if (r2) {
        throw takeObject(r1);
      }
      return Fragment.__wrap(r0);
    } finally {
      wasm.__wbindgen_add_to_stack_pointer(16);
    }
  }
}
/**
*/
class VotePlanId {
  static __wrap(ptr) {
    const obj = Object.create(VotePlanId.prototype);
    obj.ptr = ptr;
    return obj;
  }
  __destroy_into_raw() {
    const ptr = this.ptr;
    this.ptr = 0;
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm.__wbg_voteplanid_free(ptr);
  }
  /**
  * @param {string} hex_data
  * @returns {VotePlanId}
  */
  static from_hex(hex_data) {
    try {
      const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
      const ptr0 = passStringToWasm0(hex_data, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
      const len0 = WASM_VECTOR_LEN;
      wasm.voteplanid_from_hex(retptr, ptr0, len0);
      var r0 = getInt32Memory0()[retptr / 4 + 0];
      var r1 = getInt32Memory0()[retptr / 4 + 1];
      var r2 = getInt32Memory0()[retptr / 4 + 2];
      if (r2) {
        throw takeObject(r1);
      }
      return VotePlanId.__wrap(r0);
    } finally {
      wasm.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
  * @param {Uint8Array} bytes
  * @returns {VotePlanId}
  */
  static from_bytes(bytes) {
    try {
      const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
      const ptr0 = passArray8ToWasm0(bytes, wasm.__wbindgen_malloc);
      const len0 = WASM_VECTOR_LEN;
      wasm.voteplanid_from_bytes(retptr, ptr0, len0);
      var r0 = getInt32Memory0()[retptr / 4 + 0];
      var r1 = getInt32Memory0()[retptr / 4 + 1];
      var r2 = getInt32Memory0()[retptr / 4 + 2];
      if (r2) {
        throw takeObject(r1);
      }
      return VotePlanId.__wrap(r0);
    } finally {
      wasm.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
  * @returns {Uint8Array}
  */
  to_bytes() {
    try {
      const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
      wasm.voteplanid_to_bytes(retptr, this.ptr);
      var r0 = getInt32Memory0()[retptr / 4 + 0];
      var r1 = getInt32Memory0()[retptr / 4 + 1];
      var r2 = getInt32Memory0()[retptr / 4 + 2];
      var r3 = getInt32Memory0()[retptr / 4 + 3];
      if (r3) {
        throw takeObject(r2);
      }
      var v0 = getArrayU8FromWasm0(r0, r1).slice();
      wasm.__wbindgen_free(r0, r1 * 1);
      return v0;
    } finally {
      wasm.__wbindgen_add_to_stack_pointer(16);
    }
  }
}
async function load(module, imports) {
  if (typeof Response === 'function' && module instanceof Response) {
    if (typeof WebAssembly.instantiateStreaming === 'function') {
      try {
        return await WebAssembly.instantiateStreaming(module, imports);
      } catch (e) {
        if (module.headers.get('Content-Type') != 'application/wasm') {
          console.warn("`WebAssembly.instantiateStreaming` failed because your server does not serve wasm with `application/wasm` MIME type. Falling back to `WebAssembly.instantiate` which is slower. Original error:\n", e);
        } else {
          throw e;
        }
      }
    }
    const bytes = await module.arrayBuffer();
    return await WebAssembly.instantiate(bytes, imports);
  } else {
    const instance = await WebAssembly.instantiate(module, imports);
    if (instance instanceof WebAssembly.Instance) {
      return {
        instance,
        module
      };
    } else {
      return instance;
    }
  }
}
function getImports() {
  const imports = {};
  imports.wbg = {};
  imports.wbg.__wbindgen_string_new = function (arg0, arg1) {
    const ret = getStringFromWasm0(arg0, arg1);
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_randomFillSync_6894564c2c334c42 = function () {
    return handleError(function (arg0, arg1, arg2) {
      getObject(arg0).randomFillSync(getArrayU8FromWasm0(arg1, arg2));
    }, arguments);
  };
  imports.wbg.__wbindgen_object_drop_ref = function (arg0) {
    takeObject(arg0);
  };
  imports.wbg.__wbg_getRandomValues_805f1c3d65988a5a = function () {
    return handleError(function (arg0, arg1) {
      getObject(arg0).getRandomValues(getObject(arg1));
    }, arguments);
  };
  imports.wbg.__wbg_crypto_e1d53a1d73fb10b8 = function (arg0) {
    const ret = getObject(arg0).crypto;
    return addHeapObject(ret);
  };
  imports.wbg.__wbindgen_is_object = function (arg0) {
    const val = getObject(arg0);
    const ret = typeof val === 'object' && val !== null;
    return ret;
  };
  imports.wbg.__wbg_process_038c26bf42b093f8 = function (arg0) {
    const ret = getObject(arg0).process;
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_versions_ab37218d2f0b24a8 = function (arg0) {
    const ret = getObject(arg0).versions;
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_node_080f4b19d15bc1fe = function (arg0) {
    const ret = getObject(arg0).node;
    return addHeapObject(ret);
  };
  imports.wbg.__wbindgen_is_string = function (arg0) {
    const ret = typeof getObject(arg0) === 'string';
    return ret;
  };
  imports.wbg.__wbg_msCrypto_6e7d3e1f92610cbb = function (arg0) {
    const ret = getObject(arg0).msCrypto;
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_require_78a3dcfbdba9cbce = function () {
    return handleError(function () {
      const ret = module.require;
      return addHeapObject(ret);
    }, arguments);
  };
  imports.wbg.__wbindgen_is_function = function (arg0) {
    const ret = typeof getObject(arg0) === 'function';
    return ret;
  };
  imports.wbg.__wbg_newnoargs_b5b063fc6c2f0376 = function (arg0, arg1) {
    const ret = new Function(getStringFromWasm0(arg0, arg1));
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_call_97ae9d8645dc388b = function () {
    return handleError(function (arg0, arg1) {
      const ret = getObject(arg0).call(getObject(arg1));
      return addHeapObject(ret);
    }, arguments);
  };
  imports.wbg.__wbindgen_object_clone_ref = function (arg0) {
    const ret = getObject(arg0);
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_self_6d479506f72c6a71 = function () {
    return handleError(function () {
      const ret = self.self;
      return addHeapObject(ret);
    }, arguments);
  };
  imports.wbg.__wbg_window_f2557cc78490aceb = function () {
    return handleError(function () {
      const ret = window.window;
      return addHeapObject(ret);
    }, arguments);
  };
  imports.wbg.__wbg_globalThis_7f206bda628d5286 = function () {
    return handleError(function () {
      const ret = globalThis.globalThis;
      return addHeapObject(ret);
    }, arguments);
  };
  imports.wbg.__wbg_global_ba75c50d1cf384f4 = function () {
    return handleError(function () {
      const ret = __webpack_require__.g.global;
      return addHeapObject(ret);
    }, arguments);
  };
  imports.wbg.__wbindgen_is_undefined = function (arg0) {
    const ret = getObject(arg0) === undefined;
    return ret;
  };
  imports.wbg.__wbg_call_168da88779e35f61 = function () {
    return handleError(function (arg0, arg1, arg2) {
      const ret = getObject(arg0).call(getObject(arg1), getObject(arg2));
      return addHeapObject(ret);
    }, arguments);
  };
  imports.wbg.__wbg_buffer_3f3d764d4747d564 = function (arg0) {
    const ret = getObject(arg0).buffer;
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_new_8c3f0052272a457a = function (arg0) {
    const ret = new Uint8Array(getObject(arg0));
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_set_83db9690f9353e79 = function (arg0, arg1, arg2) {
    getObject(arg0).set(getObject(arg1), arg2 >>> 0);
  };
  imports.wbg.__wbg_length_9e1ae1900cb0fbd5 = function (arg0) {
    const ret = getObject(arg0).length;
    return ret;
  };
  imports.wbg.__wbg_newwithlength_f5933855e4f48a19 = function (arg0) {
    const ret = new Uint8Array(arg0 >>> 0);
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_subarray_58ad4efbb5bcb886 = function (arg0, arg1, arg2) {
    const ret = getObject(arg0).subarray(arg1 >>> 0, arg2 >>> 0);
    return addHeapObject(ret);
  };
  imports.wbg.__wbindgen_throw = function (arg0, arg1) {
    throw new Error(getStringFromWasm0(arg0, arg1));
  };
  imports.wbg.__wbindgen_memory = function () {
    const ret = wasm.memory;
    return addHeapObject(ret);
  };
  return imports;
}
function initMemory(imports, maybe_memory) {}
function finalizeInit(instance, module) {
  wasm = instance.exports;
  init.__wbindgen_wasm_module = module;
  cachedInt32Memory0 = new Int32Array();
  cachedUint8Memory0 = new Uint8Array();
  return wasm;
}
function initSync(module) {
  const imports = getImports();
  initMemory(imports);
  if (!(module instanceof WebAssembly.Module)) {
    module = new WebAssembly.Module(module);
  }
  const instance = new WebAssembly.Instance(module, imports);
  return finalizeInit(instance, module);
}
async function init(input) {
  if (typeof input === 'undefined') {
    input = new URL(/* asset import */ __webpack_require__(22926), __webpack_require__.b);
  }
  const imports = getImports();
  if (typeof input === 'string' || typeof Request === 'function' && input instanceof Request || typeof URL === 'function' && input instanceof URL) {
    input = fetch(input);
  }
  initMemory(imports);
  const {
    instance,
    module
  } = await load(await input, imports);
  return finalizeInit(instance, module);
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (init);

/***/ }),

/***/ 82875:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ CIP62SignVotes)
});

// EXTERNAL MODULE: ./node_modules/@vue/runtime-core/dist/runtime-core.esm-bundler.js
var runtime_core_esm_bundler = __webpack_require__(83673);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/CIP62SignVotes.vue?vue&type=template&id=4d7a74a6&ts=true

const _hoisted_1 = { class: "cc-page-wallet cc-text-sz" };
function render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridButtonSecondary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonSecondary");
    const _component_SignVotesConfirm = (0,runtime_core_esm_bundler/* resolveComponent */.up)("SignVotesConfirm");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_1, [
        (_ctx.activeAccount && _ctx.activeWalletData && _ctx.vote.votes.length > 0)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_SignVotesConfirm, {
                key: 0,
                onSubmit: _ctx.onSigned,
                onErrorProof: _ctx.onErrorProofs,
                onErrorBadRequest: _ctx.onErrorBadRequest,
                account: _ctx.activeAccount,
                wallet: _ctx.activeWalletData,
                votes: _ctx.vote.votes,
                "vote-settings": _ctx.vote.settings,
                "text-id": "dapps.voting.sign"
            }, {
                btnBack: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonSecondary, {
                        label: _ctx.it('common.label.cancel'),
                        link: _ctx.onCancel,
                        type: "button",
                        class: "col-start-0 col-span-6 sm:col-start-0 sm:col-span-3"
                    }, null, 8, ["label", "link"])
                ]),
                _: 1
            }, 8, ["onSubmit", "onErrorProof", "onErrorBadRequest", "account", "wallet", "votes", "vote-settings"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
    ]));
}

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/CIP62SignVotes.vue?vue&type=template&id=4d7a74a6&ts=true

// EXTERNAL MODULE: ./node_modules/quasar/src/composables/use-quasar.js
var use_quasar = __webpack_require__(48825);
// EXTERNAL MODULE: ./src/composables/ccw/useTranslation.ts
var useTranslation = __webpack_require__(19376);
// EXTERNAL MODULE: ./src/composables/ccw/store/useActiveWallet.ts
var useActiveWallet = __webpack_require__(52144);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/voting/SignVotesConfirm.vue?vue&type=template&id=17f24928&ts=true

const SignVotesConfirmvue_type_template_id_17f24928_ts_true_hoisted_1 = {
    key: 3,
    class: "col-span-12 grid grid-cols-12 cc-gap"
};
const _hoisted_2 = {
    key: 4,
    class: "relative col-span-12 -top-2"
};
const _hoisted_3 = {
    key: 5,
    class: "relative col-span-12 -top-2 grid grid-cols-12 mt-1"
};
const _hoisted_4 = { class: "col-span-12 flex flex-row flex-nowrap items-center whitespace-pre-wrap cc-text-sz" };
const _hoisted_5 = { class: "col-span-12 pb-1 pr-1 whitespace-pre-wrap overflow-auto" };
function SignVotesConfirmvue_type_template_id_17f24928_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridHeadline = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridHeadline");
    const _component_GridText = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridText");
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    const _component_LedgerTransport = (0,runtime_core_esm_bundler/* resolveComponent */.up)("LedgerTransport");
    const _component_IconInfo = (0,runtime_core_esm_bundler/* resolveComponent */.up)("IconInfo");
    const _component_IconError = (0,runtime_core_esm_bundler/* resolveComponent */.up)("IconError");
    const _component_GridFormSignWithPassword = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridFormSignWithPassword");
    const _component_GridButtonPrimary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonPrimary");
    const _component_vue_json_pretty = (0,runtime_core_esm_bundler/* resolveComponent */.up)("vue-json-pretty");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, [
        (_ctx.showLabel)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridHeadline, {
                key: 0,
                label: _ctx.it(_ctx.textId + '.label'),
                class: "col-span-12"
            }, null, 8, ["label"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (_ctx.showLabel)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridText, {
                key: 1,
                text: _ctx.it(_ctx.textId + (_ctx.isMnemonic ? '.caption.mnemonic' : '.caption.hardware')),
                class: "col-span-12 cc-text-sz"
            }, null, 8, ["text"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (_ctx.showLabel)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridSpace, {
                key: 2,
                hr: "",
                class: "col-span-12 my-0.5 sm:mt-2"
            }))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (_ctx.isReadOnly)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", SignVotesConfirmvue_type_template_id_17f24928_ts_true_hoisted_1, [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                    text: _ctx.it(_ctx.textId + '.info.readonly')
                }, null, 8, ["text"])
            ]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (_ctx.isLedger && _ctx.hasWebUSB)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_2, [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_LedgerTransport),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, { hr: "" })
            ]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (_ctx.isLedger || _ctx.isTrezor || _ctx.signError.length > 0)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_3, [
                (_ctx.isMnemonic)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridSpace, { key: 0 }))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_4, [
                    (_ctx.signError.length === 0)
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_IconInfo, {
                            key: 0,
                            class: "w-7 flex-none mr-2"
                        }))
                        : ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_IconError, {
                            key: 1,
                            class: "w-7 flex-none mr-2"
                        })),
                    (_ctx.signError.length === 0)
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridText, {
                            key: 2,
                            text: _ctx.it(_ctx.textId + '.info' + (_ctx.isLedger ? '.ledger' : '.trezor'))
                        }, null, 8, ["text"]))
                        : ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridText, {
                            key: 3,
                            text: _ctx.signError
                        }, null, 8, ["text"]))
                ]),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, {
                    hr: "",
                    class: "mt-3"
                })
            ]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (_ctx.isMnemonic)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridFormSignWithPassword, {
                key: 6,
                onSubmit: _ctx.onSubmitPassword,
                onReset: _ctx.onPasswordReset,
                class: "col-span-12",
                autocomplete: "off",
                "skip-validation": ""
            }, {
                btnBack: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                    (0,runtime_core_esm_bundler/* renderSlot */.WI)(_ctx.$slots, "btnBack")
                ]),
                _: 3
            }, 8, ["onSubmit", "onReset"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (_ctx.isLedger || _ctx.isTrezor)
            ? (0,runtime_core_esm_bundler/* renderSlot */.WI)(_ctx.$slots, "btnBack", { key: 7 })
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (_ctx.isLedger || _ctx.isTrezor)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridButtonPrimary, {
                key: 8,
                label: _ctx.it('common.button.sign'),
                link: _ctx.signVotes,
                class: "col-start-7 col-span-6 sm:col-start-10 sm:col-span-3"
            }, null, 8, ["label", "link"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, {
            hr: "",
            class: "mt-2"
        }),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
            label: _ctx.it(_ctx.textId + '.raw')
        }, null, 8, ["label"]),
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_5, [
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                text: _ctx.it(_ctx.textId + '.votes')
            }, null, 8, ["text"]),
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_vue_json_pretty, {
                showLength: "",
                class: "font-mono cc-text-sm",
                showDoubleQuotes: false,
                deep: 0,
                data: _ctx.votes
            }, null, 8, ["data"]),
            (_ctx.voteSettings)
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridText, {
                    key: 0,
                    class: "mt-1",
                    text: _ctx.it(_ctx.textId + '.settings')
                }, null, 8, ["text"]))
                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
            (_ctx.voteSettings)
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_vue_json_pretty, {
                    key: 1,
                    showLength: "",
                    class: "font-mono cc-text-sm",
                    showDoubleQuotes: false,
                    deep: 0,
                    data: _ctx.voteSettings
                }, null, 8, ["data"]))
                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
        ])
    ], 64));
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/voting/SignVotesConfirm.vue?vue&type=template&id=17f24928&ts=true

// EXTERNAL MODULE: ./node_modules/@vue/reactivity/dist/reactivity.esm-bundler.js
var reactivity_esm_bundler = __webpack_require__(61959);
// EXTERNAL MODULE: ./src/composables/ccw/store/useBuildTx_v3.ts + 1 modules
var useBuildTx_v3 = __webpack_require__(72107);
// EXTERNAL MODULE: ./src/composables/ccw/store/useVoteLib.ts
var useVoteLib = __webpack_require__(24198);
// EXTERNAL MODULE: ./src/composables/ccw/useNetworkId.ts
var useNetworkId = __webpack_require__(36648);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridHeadline.vue + 3 modules
var GridHeadline = __webpack_require__(63593);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridText.vue + 4 modules
var GridText = __webpack_require__(96834);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridTextArea.vue + 4 modules
var GridTextArea = __webpack_require__(15660);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridSpace.vue + 4 modules
var GridSpace = __webpack_require__(14740);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridInput.vue + 4 modules
var GridInput = __webpack_require__(27209);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridButtonSecondary.vue + 3 modules
var GridButtonSecondary = __webpack_require__(72713);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridButtonPrimary.vue + 3 modules
var GridButtonPrimary = __webpack_require__(12559);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/icons/IconInfo.vue + 4 modules
var IconInfo = __webpack_require__(31599);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/icons/IconCheck.vue + 4 modules
var IconCheck = __webpack_require__(59548);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/icons/IconError.vue + 4 modules
var IconError = __webpack_require__(66934);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/icons/IconLockClosed.vue + 4 modules
var IconLockClosed = __webpack_require__(18807);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/forms/GridFormSignWithPassword.vue + 3 modules
var GridFormSignWithPassword = __webpack_require__(58315);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/settings/LedgerTransport.vue + 4 modules
var LedgerTransport = __webpack_require__(44844);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/JsonTableView.vue + 4 modules
var JsonTableView = __webpack_require__(19932);
// EXTERNAL MODULE: ./src/components/ccw/common/CopyToClipboard.vue + 3 modules
var CopyToClipboard = __webpack_require__(85243);
// EXTERNAL MODULE: ./node_modules/vue-json-pretty/lib/vue-json-pretty.js
var vue_json_pretty = __webpack_require__(6061);
var vue_json_pretty_default = /*#__PURE__*/__webpack_require__.n(vue_json_pretty);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/CSLUtils.ts
var CSLUtils = __webpack_require__(58173);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/LibUtils.ts
var LibUtils = __webpack_require__(10751);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/VoteLib.ts
var VoteLib = __webpack_require__(77263);
// EXTERNAL MODULE: ./src/lib/utils/useLocalStorage.ts
var useLocalStorage = __webpack_require__(34787);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/CSLKeys.ts
var CSLKeys = __webpack_require__(7572);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/EncryptLib.ts
var EncryptLib = __webpack_require__(26650);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/CSLConstants.ts
var CSLConstants = __webpack_require__(22798);
// EXTERNAL MODULE: ./src/lib/utils/useAppMode.ts
var useAppMode = __webpack_require__(4254);
// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.push.js
var es_array_push = __webpack_require__(65663);
// EXTERNAL MODULE: ../ccw-lib2/Print.ts
var Print = __webpack_require__(72302);
// EXTERNAL MODULE: ./src/lib/@catalyst-core/wallet-wasm-js/wallet_wasm_js.js
var wallet_wasm_js = __webpack_require__(36289);
;// CONCATENATED MODULE: ./src/lib/CardanoWalletJsLib.ts

if (Print/* default.frontend.useCSL */.Z.frontend.useCSL)
    console.log('setup: CardanoWalletJsLib');
globalThis['wwjInitialized'] = false;

(async () => {
    globalThis['wwjInitialized'] = !!(await (0,wallet_wasm_js/* default */.ZP)('/wasm/wwj-v0.8.5.wasm'));
    if (Print/* default.frontend.useCSL */.Z.frontend.useCSL)
        console.log('init: CardanoWalletJsLib:', globalThis['wwjInitialized']);
})();


;// CONCATENATED MODULE: ./src/lib/@catalyst-core/wallet-js/index.js


class BlockDate {
  constructor(epoch, slot) {
    this.epoch = epoch;
    this.slot = slot;
  }
}
class Settings {
  constructor(json) {
    this.settings = wallet_wasm_js/* Settings.from_json */.Zr.from_json(json);
  }
  to_json() {
    return this.settings.to_json();
  }
}
class Proposal {
  constructor(votePlan, proposalIndex, voteOptions, voteEncKey) {
    this.votePlan = votePlan;
    this.proposalIndex = proposalIndex;
    this.voteOptions = voteOptions;
    this.voteEncKey = voteEncKey;
  }
}
class Vote {
  constructor(proposal, choice, purpose) {
    this.proposal = proposal;
    this.choice = choice;
    this.purpose = purpose;
  }
}
function wallet_js_signVotes(votes, settings, accountId, privateKey) {
  let tx_builders = [];
  for (let i = 0; i < votes.length; i++) {
    let vote = votes[i];
    let payload;
    if (vote.proposal.voteOptions != undefined && vote.proposal.voteEncKey != undefined) {
      payload = wallet_wasm_js/* Payload.new_private */.OB.new_private(wallet_wasm_js/* VotePlanId.from_hex */.Eq.from_hex(vote.proposal.votePlan), vote.proposal.voteOptions, vote.choice, wallet_wasm_js/* ElectionPublicKey.from_hex */.T2.from_hex(vote.proposal.voteEncKey));
    } else {
      payload = wallet_wasm_js/* Payload.new_public */.OB.new_public(vote.choice);
    }
    let voteCast = wallet_wasm_js/* VoteCast.new */.aW["new"](wallet_wasm_js/* VotePlanId.from_hex */.Eq.from_hex(vote.proposal.votePlan), vote.proposal.proposalIndex, payload);
    let builder = wallet_wasm_js/* VoteCastTxBuilder.new */.iL["new"](settings.settings, voteCast);
    let tx_builder = builder.prepare_tx(accountId);
    tx_builders.push(tx_builder);
  }
  return tx_builders;
}
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/voting/SignVotesConfirm.vue?vue&type=script&lang=ts

;






























/* harmony default export */ const SignVotesConfirmvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'SignVotesConfirm',
    components: {
        LedgerTransport: LedgerTransport/* default */.Z,
        CopyToClipboard: CopyToClipboard/* default */.Z,
        GridFormSignWithPassword: GridFormSignWithPassword/* default */.Z,
        GridHeadline: GridHeadline/* default */.Z,
        GridText: GridText/* default */.Z,
        GridTextArea: GridTextArea/* default */.Z,
        GridSpace: GridSpace/* default */.Z,
        GridInput: GridInput/* default */.Z,
        GridButtonSecondary: GridButtonSecondary/* default */.Z,
        GridButtonPrimary: GridButtonPrimary/* default */.Z,
        IconInfo: IconInfo/* default */.Z,
        IconCheck: IconCheck/* default */.Z,
        IconError: IconError/* default */.Z,
        IconLockClosed: IconLockClosed/* default */.Z,
        JsonTableView: JsonTableView/* default */.Z,
        VueJsonPretty: (vue_json_pretty_default())
    },
    props: {
        type: { type: String, required: false, default: '' },
        textId: { type: String, required: true, default: '' },
        showLabel: { type: Boolean, required: false, default: true },
        account: { type: Object, required: true },
        wallet: { type: Object, required: true },
        votes: { type: Array, required: true },
        voteSettings: { type: Object, required: false }
    },
    emits: ['submit', 'errorProof', 'errorBadRequest'],
    setup(props, { emit }) {
        const { it } = (0,useTranslation/* useTranslation */.$)();
        const { networkId } = (0,useNetworkId/* useNetworkId */.h)();
        const $q = (0,use_quasar/* default */.Z)();
        const {} = (0,useBuildTx_v3/* useBuildTxV3 */.b)(); // Need to init this to use LedgerTransport component
        const { pullProposals } = (0,useVoteLib/* useVoteLib */.n)();
        const proposals = (0,reactivity_esm_bundler/* ref */.iH)([]);
        const path = (0,VoteLib/* getVoteKeyPath */.T8)(props.account.index);
        const spendingPassword = (0,reactivity_esm_bundler/* ref */.iH)('');
        const signedVotes = (0,reactivity_esm_bundler/* ref */.iH)([]);
        const signError = (0,reactivity_esm_bundler/* ref */.iH)('');
        const isMnemonic = props.account.signType === 'mnemonic' ?? false;
        const isLedger = props.account.signType === 'ledger' ?? false;
        const isTrezor = props.account.signType === 'trezor' ?? false;
        const isReadOnly = props.account.signType === 'readonly' ?? false;
        (0,runtime_core_esm_bundler/* watch */.YP)(spendingPassword, () => signError.value = '');
        function getVoteKey(walletId) {
            const additionalKeys = (0,useLocalStorage/* getAdditionalKeyList */.Ju)();
            let voteKey = null;
            if (additionalKeys) {
                voteKey = additionalKeys[walletId]?.find(k => (0,LibUtils/* isSameArray */.EZ)(k.path, path)) ?? null;
            }
            return voteKey;
        }
        async function onSubmitPassword(payload) {
            spendingPassword.value = payload.password;
            signVotes();
        }
        function onPasswordReset() {
            signError.value = '';
        }
        function onSubmit() { emit('submit', { signedVotes: signedVotes.value }); }
        async function signVotes() {
            signedVotes.value.splice(0);
            if (isLedger || isTrezor) {
                $q.loading.show({
                    message: it(props.textId + '.loading.' + props.account.signType),
                    html: true
                });
            }
            const accVoteKey = getVoteKey(props.wallet.id);
            if (!accVoteKey) {
                emit('errorProof');
                return;
            }
            const voteKey = (0,VoteLib/* createVoteKey */.KB)(accVoteKey.pub, accVoteKey.index, 0);
            if (isMnemonic) {
                try {
                    const accountPrv = (0,CSLKeys/* createPrvAccount */.b0)((0,EncryptLib/* decryptText */._V)(props.wallet.root?.prv ?? '', spendingPassword.value), CSLConstants/* purpose.voting */.Gr.voting, voteKey.path[2]);
                    const prvKeyHex = (0,CSLUtils/* getPrv */.wf)((0,CSLKeys/* createPrvPayment */.bU)(accountPrv, voteKey.index)).to_raw_key().to_hex();
                    const accountId = (0,CSLUtils/* getPub */.y5)(voteKey.pub).to_raw_key().to_hex();
                    const wwjSettings = new Settings(JSON.stringify(props.voteSettings));
                    const wwjVotes = [];
                    for (const vote of props.votes) {
                        const proposal = new Proposal(vote.proposal.votePlanId, vote.proposal.proposalIndex, vote.proposal.voteOptions, vote.proposal.voteEncKey);
                        const wwjVote = new Vote(proposal, vote.choice, vote.purpose);
                        wwjVotes.push(wwjVote);
                    }
                    const tx_builders = wallet_js_signVotes(wwjVotes, wwjSettings, accountId);
                    signedVotes.value.push(...tx_builders.map((tx_builder) => {
                        return (0,LibUtils/* toHexString */.zv)(tx_builder.sign_tx(prvKeyHex).to_bytes());
                    }));
                }
                catch (err) {
                    console.error(err);
                    signError.value = err.message ?? err.toString();
                    return;
                }
            }
            else {
                emit('errorBadRequest', 'HW devices not supported currently');
            }
            if (isLedger || isTrezor) {
                $q.loading.hide();
            }
            if (signError.value.length === 0 && signedVotes.value.length !== props.votes.length) {
                signError.value = it(props.textId + '.error.incomplete');
            }
            if (signError.value.length === 0) {
                onSubmit();
            }
        }
        (0,runtime_core_esm_bundler/* onMounted */.bv)(async () => {
            if (!networkId.value) {
                return;
            }
            proposals.value = await pullProposals(networkId.value);
        });
        return {
            it,
            isMnemonic,
            isLedger,
            isTrezor,
            isReadOnly,
            hasWebUSB: useAppMode/* hasWebUSB */.d$,
            spendingPassword,
            signError,
            signVotes,
            onSubmit,
            onSubmitPassword,
            onPasswordReset
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/voting/SignVotesConfirm.vue?vue&type=script&lang=ts
 
// EXTERNAL MODULE: ./node_modules/vue-loader/dist/exportHelper.js
var exportHelper = __webpack_require__(74260);
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/voting/SignVotesConfirm.vue




;
const __exports__ = /*#__PURE__*/(0,exportHelper/* default */.Z)(SignVotesConfirmvue_type_script_lang_ts, [['render',SignVotesConfirmvue_type_template_id_17f24928_ts_true_render]])

/* harmony default export */ const SignVotesConfirm = (__exports__);
// EXTERNAL MODULE: ./src/lib/utils/useBexStorage.ts
var useBexStorage = __webpack_require__(6296);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/CIP62SignVotes.vue?vue&type=script&lang=ts

;






/* harmony default export */ const CIP62SignVotesvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'CIP62SignVotes',
    components: {
        GridButtonSecondary: GridButtonSecondary/* default */.Z,
        SignVotesConfirm: SignVotesConfirm
    },
    setup() {
        const { it } = (0,useTranslation/* useTranslation */.$)();
        const { activeAccount, activeWalletData } = (0,useActiveWallet/* useActiveWallet */.r)();
        const $q = (0,use_quasar/* default */.Z)();
        const vote = (0,useLocalStorage/* getCIP62Votes */.lW)();
        function onErrorProofs() {
            //@ts-ignore
            if ($q.bex) {
                const eventFail = {
                    eventResponseKey: '',
                    data: {
                        api: 'onCIP62SignVotes',
                        payload: {
                            origin: useBexStorage/* bexOrigin.value */.g0.value ?? ''
                        },
                        response: {
                            success: false,
                            error: {
                                code: useBexStorage/* CIP62ErrorCode.ProofGeneration */.AV.ProofGeneration,
                                info: 'wallet does not hold key to sign votes'
                            }
                        }
                    }
                };
                console.warn('CIP62SignVotes failed:', eventFail.data);
                //@ts-ignore
                $q.bex.send('eternl.to.bg', eventFail.data);
            }
        }
        function onErrorBadRequest(error) {
            console.warn('CIP62SignVotes: onErrorBadRequest:', error);
            onErrorProofs();
        }
        function onCancel() {
            //@ts-ignore
            if ($q.bex) {
                const eventFail = {
                    eventResponseKey: '',
                    data: {
                        api: 'onCIP62SignVotes',
                        payload: {
                            origin: useBexStorage/* bexOrigin.value */.g0.value ?? ''
                        },
                        response: {
                            success: false,
                            error: {
                                code: useBexStorage/* CIP62ErrorCode.UserDeclined */.AV.UserDeclined,
                                info: 'user declined to sign votes'
                            }
                        }
                    }
                };
                console.warn('CIP62SignVotes cancelled:', eventFail.data);
                //@ts-ignore
                $q.bex.send('eternl.to.bg', eventFail.data);
            }
        }
        function onSigned(payload) {
            console.log('CIP62SignVotes: onSigned:', payload.signedVotes);
            if (payload && payload.signedVotes.length === vote.votes.length) {
                //@ts-ignore
                if ($q.bex) {
                    const eventSuccess = {
                        eventResponseKey: '',
                        data: {
                            api: 'onCIP62SignVotes',
                            payload: {
                                origin: useBexStorage/* bexOrigin.value */.g0.value ?? ''
                            },
                            response: {
                                cip62SignedVotes: payload.signedVotes,
                                success: true
                            }
                        }
                    };
                    //@ts-ignore
                    $q.bex.send('eternl.to.bg', eventSuccess.data);
                }
            }
            else {
                onCancel();
            }
        }
        (0,runtime_core_esm_bundler/* onErrorCaptured */.d1)((e, instance, info) => {
            $q.notify({
                type: 'negative',
                message: 'error: ' + (e?.message ?? 'no error message') + ' info: ' + info,
                position: 'top-left',
                timeout: 225000
            });
            console.error('CIP62SignVotes: onErrorCaptured', e);
            setTimeout(() => { onCancel(); }, 225000);
            return true;
        });
        return {
            it,
            activeAccount,
            activeWalletData,
            vote,
            onCancel,
            onSigned,
            onErrorProofs,
            onErrorBadRequest
        };
    }
}));

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/CIP62SignVotes.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/CIP62SignVotes.vue




;
const CIP62SignVotes_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(CIP62SignVotesvue_type_script_lang_ts, [['render',render]])

/* harmony default export */ const CIP62SignVotes = (CIP62SignVotes_exports_);

/***/ }),

/***/ 22926:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "f4189e96ccfbea496dbe.wasm";

/***/ })

}]);
//# sourceMappingURL=4497.js.map