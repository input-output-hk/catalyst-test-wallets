"use strict";
(this["webpackChunkccw_frontend"] = this["webpackChunkccw_frontend"] || []).push([[616],{

/***/ 37351:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ CIP62Credentials)
});

// EXTERNAL MODULE: ./node_modules/@vue/runtime-core/dist/runtime-core.esm-bundler.js
var runtime_core_esm_bundler = __webpack_require__(83673);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/CIP62Credentials.vue?vue&type=template&id=43e85e74&ts=true

const _hoisted_1 = { class: "cc-page-wallet cc-text-sz dark:text-cc-gray-dark" };
function render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridButtonSecondary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonSecondary");
    const _component_VoteKeyConfirm = (0,runtime_core_esm_bundler/* resolveComponent */.up)("VoteKeyConfirm");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_1, [
        (_ctx.activeAccount && _ctx.activeWalletData)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_VoteKeyConfirm, {
                key: 0,
                onSubmit: _ctx.onSigned,
                account: _ctx.activeAccount,
                wallet: _ctx.activeWalletData,
                "text-id": "dapps.voting.key"
            }, {
                btnBack: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonSecondary, {
                        label: _ctx.it('common.label.cancel'),
                        link: _ctx.onCancel,
                        type: "button",
                        class: "col-start-0 col-span-6 sm:col-start-0 sm:col-span-3"
                    }, null, 8, ["label", "link"])
                ]),
                _: 1
            }, 8, ["onSubmit", "account", "wallet"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
    ]));
}

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/CIP62Credentials.vue?vue&type=template&id=43e85e74&ts=true

// EXTERNAL MODULE: ./node_modules/quasar/src/composables/use-quasar.js
var use_quasar = __webpack_require__(48825);
// EXTERNAL MODULE: ./src/composables/ccw/useTranslation.ts
var useTranslation = __webpack_require__(19376);
// EXTERNAL MODULE: ./src/composables/ccw/store/useActiveWallet.ts
var useActiveWallet = __webpack_require__(52144);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/voting/VoteKeyConfirm.vue + 4 modules
var VoteKeyConfirm = __webpack_require__(46535);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridButtonSecondary.vue + 3 modules
var GridButtonSecondary = __webpack_require__(72713);
// EXTERNAL MODULE: ./src/lib/utils/useBexStorage.ts
var useBexStorage = __webpack_require__(6296);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/CIP62Credentials.vue?vue&type=script&lang=ts

;





/* harmony default export */ const CIP62Credentialsvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'CIP62Credentials',
    components: {
        GridButtonSecondary: GridButtonSecondary/* default */.Z,
        VoteKeyConfirm: VoteKeyConfirm/* default */.Z
    },
    setup() {
        const { it } = (0,useTranslation/* useTranslation */.$)();
        const { activeWalletData, activeAccount } = (0,useActiveWallet/* useActiveWallet */.r)();
        const $q = (0,use_quasar/* default */.Z)();
        function onErrorProofs() {
            //@ts-ignore
            if ($q.bex) {
                const eventFail = {
                    eventResponseKey: '',
                    data: {
                        api: 'onCIP62GetVotingCredentials',
                        payload: {
                            origin: useBexStorage/* bexOrigin.value */.g0.value ?? ''
                        },
                        response: {
                            success: false,
                            error: {
                                code: useBexStorage/* CIP62ErrorCode.ProofGeneration */.AV.ProofGeneration,
                                info: 'unable to generate account voting key'
                            }
                        }
                    }
                };
                //@ts-ignore
                $q.bex.send('eternl.to.bg', eventFail.data);
            }
        }
        function onCancel() {
            //@ts-ignore
            if ($q.bex) {
                const eventFail = {
                    eventResponseKey: '',
                    data: {
                        api: 'onCIP62GetVotingCredentials',
                        payload: {
                            origin: useBexStorage/* bexOrigin.value */.g0.value ?? ''
                        },
                        response: {
                            success: false,
                            error: {
                                code: useBexStorage/* CIP62ErrorCode.UserDeclined */.AV.UserDeclined,
                                info: 'user declined to sign'
                            }
                        }
                    }
                };
                //@ts-ignore
                $q.bex.send('eternl.to.bg', eventFail.data);
            }
        }
        function onSigned() {
            //@ts-ignore
            if ($q.bex) {
                const eventSuccess = {
                    eventResponseKey: '',
                    data: {
                        api: 'onCIP62GetVotingCredentials',
                        payload: {
                            origin: useBexStorage/* bexOrigin.value */.g0.value ?? ''
                        },
                        response: {
                            success: true
                        }
                    }
                };
                //@ts-ignore
                $q.bex.send('eternl.to.bg', eventSuccess.data);
            }
        }
        (0,runtime_core_esm_bundler/* onErrorCaptured */.d1)((e, instance, info) => {
            $q.notify({
                type: 'negative',
                message: 'error: ' + (e?.message ?? 'no error message') + ' info: ' + info,
                position: 'top-left',
                timeout: 225000
            });
            console.error('CIP62Credentials: onErrorCaptured', e);
            setTimeout(() => {
                onErrorProofs();
            }, 225000);
            return true;
        });
        return {
            it,
            activeWalletData,
            activeAccount,
            onCancel,
            onSigned
        };
    }
}));

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/CIP62Credentials.vue?vue&type=script&lang=ts
 
// EXTERNAL MODULE: ./node_modules/vue-loader/dist/exportHelper.js
var exportHelper = __webpack_require__(74260);
;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/CIP62Credentials.vue




;
const __exports__ = /*#__PURE__*/(0,exportHelper/* default */.Z)(CIP62Credentialsvue_type_script_lang_ts, [['render',render]])

/* harmony default export */ const CIP62Credentials = (__exports__);

/***/ })

}]);
//# sourceMappingURL=616.js.map