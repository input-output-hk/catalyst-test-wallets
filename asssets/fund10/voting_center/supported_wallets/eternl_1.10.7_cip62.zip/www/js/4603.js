"use strict";
(this["webpackChunkccw_frontend"] = this["webpackChunkccw_frontend"] || []).push([[4603,5134],{

/***/ 67234:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ TxViewer)
});

// EXTERNAL MODULE: ./node_modules/@vue/runtime-core/dist/runtime-core.esm-bundler.js
var runtime_core_esm_bundler = __webpack_require__(83673);
// EXTERNAL MODULE: ./node_modules/@vue/runtime-dom/dist/runtime-dom.esm-bundler.js
var runtime_dom_esm_bundler = __webpack_require__(98880);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/TxViewer.vue?vue&type=template&id=5c030150&ts=true

const _hoisted_1 = /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("div", {
    class: "absolute top-0 left-0 cc-text-color cc-text-sz z-50",
    id: "ccvaultio-modal"
}, null, -1);
const _hoisted_2 = { class: "absolute w-full max-w-full h-full bg-img bg-gray-50 overflow-y-auto flex flex-col flex-nowrap justify-start items-start p-4" };
const _hoisted_3 = { class: "relative w-full flex flex-col space-y-2" };
function render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridHeadline = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridHeadline");
    const _component_GridText = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridText");
    const _component_GridLoading = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridLoading");
    const _component_GridTxListEntry = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridTxListEntry");
    const _component_GridButtonPrimary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonPrimary");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, [
        _hoisted_1,
        (0,runtime_core_esm_bundler/* createElementVNode */._)("main", _hoisted_2, [
            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_3, [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                    label: "Paste Tx cbor:",
                    class: "text-sm"
                }),
                (0,runtime_core_esm_bundler/* withDirectives */.wy)((0,runtime_core_esm_bundler/* createElementVNode */._)("textarea", {
                    "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => ((_ctx.editor) = $event)),
                    class: "w-full text-xs h-32"
                }, null, 512), [
                    [runtime_dom_esm_bundler/* vModelText */.nr, _ctx.editor]
                ]),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                    label: "Transaction:",
                    class: "text-sm"
                }),
                (!_ctx.unsignedTx)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridText, {
                        key: 0,
                        text: "(parsing might take a while)",
                        class: "text-sm"
                    }))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridLoading, { active: _ctx.isLoading }, null, 8, ["active"]),
                (_ctx.unsignedTx && !_ctx.isLoading)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridTxListEntry, {
                        key: 1,
                        tx: _ctx.unsignedTx,
                        "network-id": _ctx.networkId,
                        "always-open": "",
                        "staging-tx": ""
                    }, null, 8, ["tx", "network-id"]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
            ]),
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonPrimary, {
                class: "px-4 mt-2",
                link: _ctx.submitTx,
                label: "Send",
                icon: "mdi mdi-import"
            }, null, 8, ["link"])
        ])
    ], 64));
}

;// CONCATENATED MODULE: ./src/pages/ccw/TxViewer.vue?vue&type=template&id=5c030150&ts=true

// EXTERNAL MODULE: ./node_modules/@vue/reactivity/dist/reactivity.esm-bundler.js
var reactivity_esm_bundler = __webpack_require__(61959);
// EXTERNAL MODULE: ./node_modules/quasar/src/composables/use-quasar.js
var use_quasar = __webpack_require__(48825);
// EXTERNAL MODULE: ./src/composables/ccw/useTranslation.ts
var useTranslation = __webpack_require__(19376);
// EXTERNAL MODULE: ./src/composables/ccw/useNetworkId.ts
var useNetworkId = __webpack_require__(36648);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/tx/TxParser.ts
var TxParser = __webpack_require__(90095);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/txlist/GridTxListEntry.vue + 79 modules
var GridTxListEntry = __webpack_require__(55075);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridHeadline.vue + 3 modules
var GridHeadline = __webpack_require__(63593);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridText.vue + 4 modules
var GridText = __webpack_require__(96834);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridButtonPrimary.vue + 3 modules
var GridButtonPrimary = __webpack_require__(12559);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridLoading.vue + 4 modules
var GridLoading = __webpack_require__(54753);
// EXTERNAL MODULE: ./src/lib/ExtApiLib.ts
var ExtApiLib = __webpack_require__(1553);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/TxViewer.vue?vue&type=script&lang=ts

;









/* harmony default export */ const TxViewervue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'TxViewer',
    components: {
        GridText: GridText/* default */.Z,
        GridHeadline: GridHeadline/* default */.Z,
        GridTxListEntry: GridTxListEntry/* default */.Z,
        GridLoading: GridLoading/* default */.Z,
        GridButtonPrimary: GridButtonPrimary/* default */.Z
    },
    setup() {
        const { t } = (0,useTranslation/* useTranslation */.$)();
        const { networkId } = (0,useNetworkId/* useNetworkId */.h)();
        const $q = (0,use_quasar/* default */.Z)();
        (0,runtime_core_esm_bundler/* onErrorCaptured */.d1)((e, instance, info) => {
            $q.notify({
                type: 'negative',
                message: 'error: ' + (e?.message ?? 'no error message') + ' info: ' + info,
                position: 'top-left',
                timeout: 20000
            });
            console.error('Layout: onErrorCaptured', e);
            return true;
        });
        const editor = (0,reactivity_esm_bundler/* ref */.iH)('');
        const isLoading = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const unsignedTx = (0,reactivity_esm_bundler/* ref */.iH)(null);
        (0,runtime_core_esm_bundler/* watchEffect */.m0)(() => {
            console.log('input:', editor.value);
            isLoading.value = true;
            (0,runtime_core_esm_bundler/* nextTick */.Y3)(async () => {
                if (editor.value.length === 0 || !networkId.value) {
                    isLoading.value = false;
                    return;
                }
                const parsed = editor.value.replace(/<[^>]*>/g, '');
                console.log('parsed: ', parsed);
                try {
                    console.log('Try decoding transaction.');
                    const convertedTx = await (0,TxParser/* convertTxCborToITx */.RS)(networkId.value, parsed, ExtApiLib/* loadTxDetailsList */.LG);
                    unsignedTx.value = convertedTx.tx;
                    console.log("convertedTx.tx", convertedTx.tx);
                    $q.notify({
                        type: 'positive',
                        message: 'tx cbor parsed',
                        position: 'top-left',
                        timeout: 4000
                    });
                }
                catch (e) {
                    // Should not be a TransactionBody as CIP-30 declares that a Transaction CBOR should be provided, but check anyway.
                    // If tx body deserialization also fails, thrown error is to be caught in calling component
                    // try {
                    //
                    //   console.log('Try decoding transaction body.')
                    //
                    //   const cslTxBody       = getTransactionBody(parsed)
                    //
                    //   console.log('cslTxBody: ', cslTxBody)
                    //
                    //   convertedTx           = await convertTxToITx(account, cslTxBody,
                    //     null, null, loadTxDetailsList)
                    //
                    //   unsignedTx.value      = convertedTx.tx
                    //
                    //   $q.notify({
                    //
                    //     type:               'positive',
                    //     message:            'txBody cbor parsed',
                    //     position:           'top-left',
                    //     timeout:            4000
                    //   })
                    //
                    // } catch (e: any) {
                    //
                    //   console.log('e: ', e)
                    //
                    //   unsignedTx.value      = null
                    //
                    //   $q.notify({
                    //
                    //     type:               'negative',
                    //     message:            'error: could not parse: ' + parsed,
                    //     position:           'top-left',
                    //     timeout:            4000
                    //   })
                    // }
                }
                isLoading.value = false;
            });
        });
        const submitTx = async () => {
            console.log("Submit ", unsignedTx);
            const parsed = editor.value.replace(/<[^>]*>/g, '');
            const resCode = await (0,ExtApiLib/* sendTransaction */.T7)('preview', parsed, 'cc');
            console.log("resCode", resCode);
        };
        return {
            t,
            onErrorCaptured: runtime_core_esm_bundler/* onErrorCaptured */.d1,
            networkId,
            unsignedTx,
            editor,
            isLoading,
            submitTx
        };
    }
}));

;// CONCATENATED MODULE: ./src/pages/ccw/TxViewer.vue?vue&type=script&lang=ts
 
// EXTERNAL MODULE: ./node_modules/vue-loader/dist/exportHelper.js
var exportHelper = __webpack_require__(74260);
;// CONCATENATED MODULE: ./src/pages/ccw/TxViewer.vue




;
const __exports__ = /*#__PURE__*/(0,exportHelper/* default */.Z)(TxViewervue_type_script_lang_ts, [['render',render]])

/* harmony default export */ const TxViewer = (__exports__);

/***/ })

}]);
//# sourceMappingURL=4603.js.map