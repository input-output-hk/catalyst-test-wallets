"use strict";
(this["webpackChunkccw_frontend"] = this["webpackChunkccw_frontend"] || []).push([[6200],{

/***/ 11250:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Import)
});

// EXTERNAL MODULE: ./node_modules/@vue/runtime-core/dist/runtime-core.esm-bundler.js
var runtime_core_esm_bundler = __webpack_require__(83673);
// EXTERNAL MODULE: ./node_modules/@vue/shared/dist/shared.esm-bundler.js
var shared_esm_bundler = __webpack_require__(62323);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/Import.vue?vue&type=template&id=cb18e78e&ts=true

const _hoisted_1 = { class: "min-h-16 sm:min-h-20 w-full max-w-full p-3 text-center flex flex-col flex-nowrap justify-center items-center border-t border-b mb-px cc-text-sz cc-bg-white-0" };
const _hoisted_2 = { class: "cc-text-semi-bold" };
const _hoisted_3 = { class: "" };
const _hoisted_4 = { class: "cc-page-wallet cc-text-sz" };
function render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_ImportWalletJson = (0,runtime_core_esm_bundler/* resolveComponent */.up)("ImportWalletJson");
    const _component_ImportAccountKey = (0,runtime_core_esm_bundler/* resolveComponent */.up)("ImportAccountKey");
    const _component_Page = (0,runtime_core_esm_bundler/* resolveComponent */.up)("Page");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_Page, {
        containerCSS: '',
        "align-top": ""
    }, {
        header: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_1, [
                (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_2, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('wallet.imports.headline')), 1),
                (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_3, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('wallet.imports.caption')), 1)
            ])
        ]),
        content: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_4, [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_ImportWalletJson),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_ImportAccountKey)
            ])
        ]),
        _: 1
    }));
}

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/Import.vue?vue&type=template&id=cb18e78e&ts=true

// EXTERNAL MODULE: ./src/composables/ccw/useTranslation.ts
var useTranslation = __webpack_require__(19376);
// EXTERNAL MODULE: ./src/components/ccw/Page.vue + 21 modules
var Page = __webpack_require__(53707);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/add/ImportWalletJson.vue?vue&type=template&id=294685ac&ts=true

const ImportWalletJsonvue_type_template_id_294685ac_ts_true_hoisted_1 = { class: "w-full col-span-12 lg:col-span-6 grid grid-cols-12 cc-gap" };
const ImportWalletJsonvue_type_template_id_294685ac_ts_true_hoisted_2 = {
    type: "file",
    id: "files",
    name: "files[]",
    multiple: "",
    ref: "inputRef",
    hidden: ""
};
function ImportWalletJsonvue_type_template_id_294685ac_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridHeadline = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridHeadline");
    const _component_GridText = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridText");
    const _component_GridButtonPrimary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonPrimary");
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    const _component_InfoModal = (0,runtime_core_esm_bundler/* resolveComponent */.up)("InfoModal");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", ImportWalletJsonvue_type_template_id_294685ac_ts_true_hoisted_1, [
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
            label: _ctx.it('wallet.imports.json.headline'),
            "do-capitalize": false
        }, null, 8, ["label"]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
            text: _ctx.it('wallet.imports.json.caption')
        }, null, 8, ["text"]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonPrimary, {
            class: "col-span-8 lg:col-span-9",
            link: _ctx.importWallet,
            label: _ctx.it('common.label.importWallet'),
            icon: "mdi mdi-import"
        }, null, 8, ["link", "label"]),
        (0,runtime_core_esm_bundler/* createElementVNode */._)("input", ImportWalletJsonvue_type_template_id_294685ac_ts_true_hoisted_2, null, 512),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, {
            hr: "",
            class: "my-0.5 sm:my-2"
        }),
        (_ctx.showInfoModal)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_InfoModal, {
                key: 0,
                caption: _ctx.it('common.walletCreation.restart'),
                title: _ctx.it('common.label.notice'),
                onClose: _ctx.onHideModal,
                onConfirm: _ctx.onHideModal
            }, null, 8, ["caption", "title", "onClose", "onConfirm"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
    ]));
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/add/ImportWalletJson.vue?vue&type=template&id=294685ac&ts=true

// EXTERNAL MODULE: ./node_modules/@vue/reactivity/dist/reactivity.esm-bundler.js
var reactivity_esm_bundler = __webpack_require__(61959);
// EXTERNAL MODULE: ./node_modules/quasar/src/composables/use-quasar.js
var use_quasar = __webpack_require__(48825);
// EXTERNAL MODULE: ./src/composables/ccw/useNavigation.ts
var useNavigation = __webpack_require__(52439);
// EXTERNAL MODULE: ./src/composables/ccw/useNetworkId.ts
var useNetworkId = __webpack_require__(36648);
// EXTERNAL MODULE: ./src/composables/ccw/store/useWalletList.ts
var useWalletList = __webpack_require__(4905);
// EXTERNAL MODULE: ./src/composables/ccw/store/useWalletCreation.ts
var useWalletCreation = __webpack_require__(68139);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridHeadline.vue + 3 modules
var GridHeadline = __webpack_require__(63593);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridButtonPrimary.vue + 3 modules
var GridButtonPrimary = __webpack_require__(12559);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridButtonSecondary.vue + 3 modules
var GridButtonSecondary = __webpack_require__(72713);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridText.vue + 4 modules
var GridText = __webpack_require__(96834);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridSpace.vue + 4 modules
var GridSpace = __webpack_require__(14740);
// EXTERNAL MODULE: ./src/components/ccw/modal/InfoModal.vue + 4 modules
var InfoModal = __webpack_require__(82172);
// EXTERNAL MODULE: ../ccw-lib2/core/IWalletDBEntry.ts
var IWalletDBEntry = __webpack_require__(82669);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/add/ImportWalletJson.vue?vue&type=script&lang=ts


;












/* harmony default export */ const ImportWalletJsonvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'ImportWalletJson',
    components: {
        GridText: GridText/* default */.Z,
        GridSpace: GridSpace/* default */.Z,
        GridButtonPrimary: GridButtonPrimary/* default */.Z,
        GridButtonSecondary: GridButtonSecondary/* default */.Z,
        GridHeadline: GridHeadline/* default */.Z,
        InfoModal: InfoModal/* default */.Z
    },
    setup() {
        const { it } = (0,useTranslation/* useTranslation */.$)();
        const { openWallet, openWalletPage } = (0,useNavigation/* useNavigation */.HJ)();
        const { networkId } = (0,useNetworkId/* useNetworkId */.h)();
        const $q = (0,use_quasar/* default */.Z)();
        const inputRef = (0,reactivity_esm_bundler/* ref */.iH)(null);
        const { reloadWalletList, hasWalletWithId, hasWalletWithName, getWalletByName } = (0,useWalletList/* useWalletList */.M)();
        const { createWalletFromDBEntry } = (0,useWalletCreation/* useWalletCreation */.c)();
        const showInfoModal = (0,reactivity_esm_bundler/* ref */.iH)(false);
        function onHandleFileSelect(e) {
            const files = e.target.files;
            for (const file of files) {
                if (!file.type.match('application/json')) {
                    continue;
                }
                const reader = new FileReader();
                reader.onload = async (re) => {
                    try {
                        const loadedFile = JSON.parse(re.target.result);
                        const dbEntry = (0,IWalletDBEntry/* createIWalletDBEntry */.bR)(loadedFile, loadedFile.name, loadedFile.groupName, loadedFile.deviceId);
                        (0,IWalletDBEntry/* updateIWalletDBEntry */.wc)(dbEntry, loadedFile);
                        if ((0,IWalletDBEntry/* isValidIWalletDBEntry */.vZ)(dbEntry)) {
                            if (networkId.value !== dbEntry.network) {
                                // TODO: Dialog: Ask user whether to switch network to import this wallet.
                                throw new Error('Error: Import wallet: wrong network id. Choose correct network first.');
                            }
                            if (!networkId.value) {
                                throw new Error('Error: No active network.');
                            }
                            if (hasWalletWithId(dbEntry.id)) {
                                $q.notify({
                                    type: 'warning',
                                    message: it('wallet.imports.message.duplicateId').replace('###walletname###', dbEntry.name),
                                    position: 'top-left'
                                });
                                openWallet(dbEntry.id);
                                return;
                            }
                            if (hasWalletWithName(dbEntry.name)) {
                                $q.notify({
                                    type: 'warning',
                                    message: it('wallet.imports.message.duplicateName').replace('###walletname###', dbEntry.name),
                                    position: 'top-left'
                                });
                                openWalletPage('WalletSettings', getWalletByName(dbEntry.name).dbEntry.id);
                                return;
                            }
                            const walletId = await createWalletFromDBEntry(dbEntry);
                            await reloadWalletList();
                            $q.notify({
                                type: 'positive',
                                message: it('wallet.imports.message.success'),
                                position: 'top-left'
                            });
                            openWallet(walletId);
                        }
                    }
                    catch (err) {
                        let errorMessage = it('wallet.imports.message.faildb');
                        if (err.message) {
                            if (err.message.toLowerCase().includes('invalid mnemonic checksum')) {
                                errorMessage = it('wallet.imports.message.failmnemonic');
                            }
                            else {
                                errorMessage = err.message;
                            }
                            $q.notify({
                                type: 'negative',
                                message: errorMessage,
                                position: 'top-left'
                            });
                        }
                        else {
                            showInfoModal.value = true;
                        }
                        console.error('CreateWallet:', err.message);
                    }
                };
                reader.readAsText(file);
            }
        }
        (0,runtime_core_esm_bundler/* onMounted */.bv)(() => {
            if (inputRef.value) {
                inputRef.value.addEventListener('change', onHandleFileSelect, false);
            }
        });
        function importWallet() {
            if (inputRef.value)
                inputRef.value.click();
        }
        function onHideModal() {
            showInfoModal.value = false;
        }
        return {
            it,
            inputRef,
            importWallet,
            showInfoModal,
            onHideModal
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/add/ImportWalletJson.vue?vue&type=script&lang=ts
 
// EXTERNAL MODULE: ./node_modules/vue-loader/dist/exportHelper.js
var exportHelper = __webpack_require__(74260);
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/add/ImportWalletJson.vue




;
const __exports__ = /*#__PURE__*/(0,exportHelper/* default */.Z)(ImportWalletJsonvue_type_script_lang_ts, [['render',ImportWalletJsonvue_type_template_id_294685ac_ts_true_render]])

/* harmony default export */ const ImportWalletJson = (__exports__);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/add/ImportAccountKey.vue?vue&type=template&id=08e3c626&ts=true

const ImportAccountKeyvue_type_template_id_08e3c626_ts_true_hoisted_1 = { class: "w-full col-span-12 lg:col-span-6 grid grid-cols-12 cc-gap" };
function ImportAccountKeyvue_type_template_id_08e3c626_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridHeadline = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridHeadline");
    const _component_GridText = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridText");
    const _component_GridButtonPrimary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonPrimary");
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", ImportAccountKeyvue_type_template_id_08e3c626_ts_true_hoisted_1, [
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
            label: _ctx.it('common.accountkey.headline'),
            "do-capitalize": false
        }, null, 8, ["label"]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
            text: _ctx.it('common.accountkey.caption')
        }, null, 8, ["text"]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonPrimary, {
            class: "col-span-8 lg:col-span-9",
            link: () => { _ctx.gotoPage('WalletImportKey'); },
            label: _ctx.it('common.accountkey.button.label'),
            icon: "mdi mdi-import"
        }, null, 8, ["link", "label"]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, {
            hr: "",
            class: "my-0.5 sm:my-2"
        })
    ]));
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/add/ImportAccountKey.vue?vue&type=template&id=08e3c626&ts=true

;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/add/ImportAccountKey.vue?vue&type=script&lang=ts







/* harmony default export */ const ImportAccountKeyvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'ImportAccountKey',
    components: {
        GridHeadline: GridHeadline/* default */.Z,
        GridText: GridText/* default */.Z,
        GridButtonPrimary: GridButtonPrimary/* default */.Z,
        GridSpace: GridSpace/* default */.Z
    },
    setup() {
        const { it } = (0,useTranslation/* useTranslation */.$)();
        const { gotoPage } = (0,useNavigation/* useNavigation */.HJ)();
        return {
            it,
            gotoPage
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/add/ImportAccountKey.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/add/ImportAccountKey.vue




;
const ImportAccountKey_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(ImportAccountKeyvue_type_script_lang_ts, [['render',ImportAccountKeyvue_type_template_id_08e3c626_ts_true_render]])

/* harmony default export */ const ImportAccountKey = (ImportAccountKey_exports_);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/Import.vue?vue&type=script&lang=ts





/* harmony default export */ const Importvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'ImportWallet',
    components: {
        Page: Page/* default */.Z,
        ImportWalletJson: ImportWalletJson,
        ImportAccountKey: ImportAccountKey
    },
    setup() {
        const { it } = (0,useTranslation/* useTranslation */.$)();
        return {
            it
        };
    }
}));

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/Import.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/pages/ccw/wallet/Import.vue




;
const Import_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(Importvue_type_script_lang_ts, [['render',render]])

/* harmony default export */ const Import = (Import_exports_);

/***/ })

}]);
//# sourceMappingURL=6200.js.map