"use strict";
(this["webpackChunkccw_frontend"] = this["webpackChunkccw_frontend"] || []).push([[6331,5134],{

/***/ 53431:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ AppLayout)
});

// EXTERNAL MODULE: ./node_modules/@vue/runtime-core/dist/runtime-core.esm-bundler.js
var runtime_core_esm_bundler = __webpack_require__(83673);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/layouts/ccw/AppLayout.vue?vue&type=template&id=1b5d5d7c&scoped=true&ts=true

const _withScopeId = n => ((0,runtime_core_esm_bundler/* pushScopeId */.dD)("data-v-1b5d5d7c"), n = n(), (0,runtime_core_esm_bundler/* popScopeId */.Cn)(), n);
const _hoisted_1 = {
    class: "relative w-full h-full cc-layout-px cc-layout-py cc-text-color flex flex-col flex-nowrap",
    id: "cc-layout-container"
};
const _hoisted_2 = /*#__PURE__*/ _withScopeId(() => /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("div", {
    class: "fixed inset-0 bg-gradient-to-r from-slate-350 to-stone-300 dark:from-slate-900 dark:to-stone-900",
    id: "cc-background-iframe-container"
}, null, -1));
const _hoisted_3 = {
    class: "relative flex-grow w-full flex-1 cc-site-max-width mx-auto flex flex-col flex-nowrap",
    id: "cc-main-container"
};
const _hoisted_4 = {
    class: "relative flex-1 flex-grow-1 h-full overflow-hidden cc-rounded-la cc-shadow flex flex-row flex-nowrap",
    style: { "min-height": "222px" }
};
const _hoisted_5 = { class: "relative flex-1 w-full h-full" };
const _hoisted_6 = { class: "relative w-full h-full cc-rounded-la flex flex-row flex-nowrap cc-bg-light-1" };
const _hoisted_7 = { class: "relative h-full flex-1 overflow-hidden focus:outline-none flex flex-col flex-nowrap cc-text-sz" };
const _hoisted_8 = /*#__PURE__*/ _withScopeId(() => /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("div", {
    class: "absolute top-0 left-0 cc-text-color cc-text-sz z-50",
    id: "ccvaultio-modal"
}, null, -1));
const _hoisted_9 = /*#__PURE__*/ _withScopeId(() => /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("div", {
    class: "absolute top-0 left-0 cc-text-color cc-text-sz z-50",
    id: "eternl-modal"
}, null, -1));
const _hoisted_10 = /*#__PURE__*/ _withScopeId(() => /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("div", {
    class: "absolute top-0 left-0 cc-text-color cc-text-sz z-100",
    id: "eternl-dapp-store-iframe"
}, null, -1));
const _hoisted_11 = /*#__PURE__*/ _withScopeId(() => /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("div", {
    class: "absolute top-0 left-0 cc-text-color cc-text-sz z-[110]",
    id: "eternl-dapp-store-sign"
}, null, -1));
function render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_Header = (0,runtime_core_esm_bundler/* resolveComponent */.up)("Header");
    const _component_EpochProgress = (0,runtime_core_esm_bundler/* resolveComponent */.up)("EpochProgress");
    const _component_BannerMoving = (0,runtime_core_esm_bundler/* resolveComponent */.up)("BannerMoving");
    const _component_router_view = (0,runtime_core_esm_bundler/* resolveComponent */.up)("router-view");
    const _component_NavSidebar = (0,runtime_core_esm_bundler/* resolveComponent */.up)("NavSidebar");
    const _component_Footer = (0,runtime_core_esm_bundler/* resolveComponent */.up)("Footer");
    const _component_DAppIframes = (0,runtime_core_esm_bundler/* resolveComponent */.up)("DAppIframes");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, [
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_1, [
            _hoisted_2,
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_Header),
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_EpochProgress),
            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_3, [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_BannerMoving),
                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_4, [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_5, [
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_6, [
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("main", _hoisted_7, [
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_router_view)
                            ])
                        ])
                    ]),
                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_NavSidebar)
                ])
            ]),
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_Footer)
        ]),
        _hoisted_8,
        _hoisted_9,
        _hoisted_10,
        _hoisted_11,
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_DAppIframes)
    ], 64));
}

;// CONCATENATED MODULE: ./src/layouts/ccw/AppLayout.vue?vue&type=template&id=1b5d5d7c&scoped=true&ts=true

// EXTERNAL MODULE: ./node_modules/quasar/src/composables/use-quasar.js
var use_quasar = __webpack_require__(48825);
// EXTERNAL MODULE: ./src/composables/ccw/useTranslation.ts
var useTranslation = __webpack_require__(19376);
// EXTERNAL MODULE: ./src/composables/ccw/useNetworkId.ts
var useNetworkId = __webpack_require__(36648);
// EXTERNAL MODULE: ./src/composables/ccw/store/useFormatter.ts
var useFormatter = __webpack_require__(16938);
// EXTERNAL MODULE: ./src/composables/ccw/store/useBuildTx_v3.ts + 1 modules
var useBuildTx_v3 = __webpack_require__(72107);
// EXTERNAL MODULE: ./src/composables/ccw/store/usePoolAPI.ts
var usePoolAPI = __webpack_require__(8614);
// EXTERNAL MODULE: ./src/composables/ccw/store/useCurrencyAPI.ts
var useCurrencyAPI = __webpack_require__(9438);
// EXTERNAL MODULE: ./src/composables/ccw/store/useTokenLib_v2.ts + 1 modules
var useTokenLib_v2 = __webpack_require__(74510);
// EXTERNAL MODULE: ./src/composables/ccw/store/useSwapLib.ts
var useSwapLib = __webpack_require__(22653);
// EXTERNAL MODULE: ./src/composables/ccw/store/useBlacklist.ts
var useBlacklist = __webpack_require__(28135);
// EXTERNAL MODULE: ./src/composables/ccw/store/useDAppBrowserEntries.ts + 1 modules
var useDAppBrowserEntries = __webpack_require__(39715);
// EXTERNAL MODULE: ./src/stores/useVerifiedTokensStore.ts + 1 modules
var useVerifiedTokensStore = __webpack_require__(52392);
// EXTERNAL MODULE: ./src/stores/useDecryptedMsgStore.ts
var useDecryptedMsgStore = __webpack_require__(27437);
// EXTERNAL MODULE: ./src/data/PendingTxDb.ts
var PendingTxDb = __webpack_require__(59025);
// EXTERNAL MODULE: ./src/components/ccw/Header.vue + 28 modules
var Header = __webpack_require__(34928);
// EXTERNAL MODULE: ./src/components/ccw/header/EpochProgress.vue + 5 modules
var EpochProgress = __webpack_require__(81780);
// EXTERNAL MODULE: ./src/components/ccw/Footer.vue + 14 modules
var Footer = __webpack_require__(78542);
// EXTERNAL MODULE: ./node_modules/@vue/runtime-dom/dist/runtime-dom.esm-bundler.js
var runtime_dom_esm_bundler = __webpack_require__(98880);
// EXTERNAL MODULE: ./node_modules/@vue/shared/dist/shared.esm-bundler.js
var shared_esm_bundler = __webpack_require__(62323);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/banners/BannerMoving.vue?vue&type=template&id=fc81f2c2&ts=true

const BannerMovingvue_type_template_id_fc81f2c2_ts_true_hoisted_1 = {
    key: 0,
    class: "relative flex-grow-0 mb-1.5 w-full cc-rounded-la cc-banner-green flex justify-center items-center text-center p-1 sm:p-2 h-80"
};
const BannerMovingvue_type_template_id_fc81f2c2_ts_true_hoisted_2 = { class: "cc-text-extra-bold block text-base sm:text-lg sm:-mb-1" };
const BannerMovingvue_type_template_id_fc81f2c2_ts_true_hoisted_3 = { class: "cc-text-extra-bold block text-sm sm:text-base cc-text-blue" };
const BannerMovingvue_type_template_id_fc81f2c2_ts_true_hoisted_4 = { class: "cc-text-extra-bold block text-sm sm:text-base darker" };
function BannerMovingvue_type_template_id_fc81f2c2_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_IconButton = (0,runtime_core_esm_bundler/* resolveComponent */.up)("IconButton");
    return (_ctx.isBannerOpen)
        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", BannerMovingvue_type_template_id_fc81f2c2_ts_true_hoisted_1, [
            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", {
                class: "cc-text-extra-bold w-full cursor-pointer",
                onClick: _cache[0] || (_cache[0] = (0,runtime_dom_esm_bundler/* withModifiers */.iM)(
                //@ts-ignore
                (...args) => (_ctx.onClicked && _ctx.onClicked(...args)), ["stop"]))
            }, [
                (0,runtime_core_esm_bundler/* createElementVNode */._)("span", BannerMovingvue_type_template_id_fc81f2c2_ts_true_hoisted_2, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('banner.moving.line0.part0')), 1),
                (0,runtime_core_esm_bundler/* createElementVNode */._)("span", BannerMovingvue_type_template_id_fc81f2c2_ts_true_hoisted_3, [
                    (0,runtime_core_esm_bundler/* createTextVNode */.Uk)((0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('banner.moving.line1.part0')) + " ", 1),
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("b", null, [
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("i", null, [
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("u", null, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('banner.moving.line1.part1')), 1)
                        ])
                    ]),
                    (0,runtime_core_esm_bundler/* createTextVNode */.Uk)(" " + (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('banner.moving.line1.part2')), 1)
                ]),
                (0,runtime_core_esm_bundler/* createElementVNode */._)("span", BannerMovingvue_type_template_id_fc81f2c2_ts_true_hoisted_4, [
                    (0,runtime_core_esm_bundler/* createTextVNode */.Uk)((0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('banner.moving.line3.part0')) + " ", 1),
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("i", null, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('banner.moving.line3.part1')), 1),
                    (0,runtime_core_esm_bundler/* createTextVNode */.Uk)(" " + (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('banner.moving.line3.part2')), 1)
                ])
            ]),
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_IconButton, {
                class: "w-10 h-10 absolute -right-1 -top-1 text-xl sm:text-2xl darker",
                icon: 'mdi mdi-close-box-outline',
                "aria-label": 'hide banner',
                onClick: (0,runtime_dom_esm_bundler/* withModifiers */.iM)(_ctx.onClickedClose, ["stop"])
            }, null, 8, ["onClick"])
        ]))
        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true);
}

;// CONCATENATED MODULE: ./src/components/ccw/banners/BannerMoving.vue?vue&type=template&id=fc81f2c2&ts=true

// EXTERNAL MODULE: ./node_modules/@vue/reactivity/dist/reactivity.esm-bundler.js
var reactivity_esm_bundler = __webpack_require__(61959);
// EXTERNAL MODULE: ./src/lib/ExtStorageLib.ts + 1 modules
var ExtStorageLib = __webpack_require__(40736);
;// CONCATENATED MODULE: ./src/composables/ccw/state/useBanner.ts


const useBanner = (bannerId, timeOut = 23 * 60 * 60 * 1000) => {
    // all properties in this function
    // > Each call will create a local copy of that functionality.
    const open = (0,reactivity_esm_bundler/* ref */.iH)(true);
    const openBanner = () => { open.value = true; };
    const closeBanner = () => {
        open.value = false;
        (0,ExtStorageLib/* setCloseBannerIdDate */.FI)(bannerId);
    };
    const isBannerVisible = (0,runtime_core_esm_bundler/* computed */.Fl)(() => (0,ExtStorageLib/* getCloseBannerIdDate */.wv)(bannerId) + timeOut < Date.now());
    const isBannerOpen = (0,runtime_core_esm_bundler/* computed */.Fl)(() => open.value && isBannerVisible.value);
    return {
        openBanner,
        closeBanner,
        isBannerOpen
    };
};

;// CONCATENATED MODULE: ./src/composables/ccw/state/useExtension.ts
const checkExtensionExists = () => {
    //@ts-ignore
    return window?.cardano?.eternl?.name === 'eternl';
};
const openExtensionOrStore = (target = '_self') => {
    if (checkExtensionExists()) {
        window.open('chrome-extension://kmhcihpebfmpgmihbkipmjlmmioameka/www/index.html#/full', target);
    }
    else {
        window.open('https://chrome.google.com/webstore/detail/kmhcihpebfmpgmihbkipmjlmmioameka', target);
    }
};
const openHome = (target = '_self') => {
    window.open('https://eternl.io', target, 'noopener,noreferrer');
};
const useExtension = () => {
    return {
        checkExtensionExists,
        openExtensionOrStore,
        openHome
    };
};

// EXTERNAL MODULE: ./src/components/ccw/common/IconButton.vue + 3 modules
var IconButton = __webpack_require__(45995);
// EXTERNAL MODULE: ./src/boot/app.parameters.ts
var app_parameters = __webpack_require__(56629);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/banners/BannerMoving.vue?vue&type=script&lang=ts







/* harmony default export */ const BannerMovingvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'BannerMoving',
    components: {
        IconButton: IconButton/* default */.Z
    },
    setup() {
        const { it } = (0,useTranslation/* useTranslation */.$)();
        const { isBannerOpen, closeBanner } = useBanner('moving');
        const { openHome } = useExtension();
        function onClicked() { openHome('_blank'); }
        function onClickedClose() { closeBanner(); }
        return {
            it,
            isBannerOpen: (0,runtime_core_esm_bundler/* computed */.Fl)(() => (app_parameters/* isOldApp */.Zp && !ExtStorageLib/* isBexApp.value */.mo.value && ExtStorageLib/* appMode.value */.pd.value === 'normal' && isBannerOpen.value)),
            onClicked,
            onClickedClose
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/banners/BannerMoving.vue?vue&type=script&lang=ts
 
// EXTERNAL MODULE: ./node_modules/vue-loader/dist/exportHelper.js
var exportHelper = __webpack_require__(74260);
;// CONCATENATED MODULE: ./src/components/ccw/banners/BannerMoving.vue




;
const __exports__ = /*#__PURE__*/(0,exportHelper/* default */.Z)(BannerMovingvue_type_script_lang_ts, [['render',BannerMovingvue_type_template_id_fc81f2c2_ts_true_render]])

/* harmony default export */ const BannerMoving = (__exports__);
// EXTERNAL MODULE: ./src/components/ccw/NavSidebar.vue + 119 modules
var NavSidebar = __webpack_require__(54918);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/dapps/DAppIframes.vue?vue&type=template&id=5712b174&ts=true

const DAppIframesvue_type_template_id_5712b174_ts_true_hoisted_1 = {
    key: 0,
    class: "absolute top-0 left-0 w-0 h-0 overflow-hidden"
};
function DAppIframesvue_type_template_id_5712b174_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_DAppIframe = (0,runtime_core_esm_bundler/* resolveComponent */.up)("DAppIframe");
    return (_ctx.dappWalletData && _ctx.dappAccount && _ctx.allowInit)
        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", DAppIframesvue_type_template_id_5712b174_ts_true_hoisted_1, [
            ((0,runtime_core_esm_bundler/* openBlock */.wg)(true), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, (0,runtime_core_esm_bundler/* renderList */.Ko)(_ctx.entryList, (item) => {
                return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_DAppIframe, {
                    key: item.id + '_iframe_modal',
                    wallet: _ctx.dappWalletData,
                    account: _ctx.dappAccount,
                    "dapp-connect": item,
                    "is-staging": _ctx.isStaging,
                    "html-id": item.id
                }, null, 8, ["wallet", "account", "dapp-connect", "is-staging", "html-id"]));
            }), 128))
        ]))
        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true);
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/dapps/DAppIframes.vue?vue&type=template&id=5712b174&ts=true

// EXTERNAL MODULE: ./src/composables/ccw/store/useDAppWallet.ts
var useDAppWallet = __webpack_require__(35053);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/dapps/DAppIframe.vue + 17 modules
var DAppIframe = __webpack_require__(2494);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/dapps/DAppIframes.vue?vue&type=script&lang=ts





/* harmony default export */ const DAppIframesvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'DAppIframes',
    components: {
        DAppIframe: DAppIframe/* default */.Z
    },
    setup() {
        const { dappAccount, dappWalletData } = (0,useDAppWallet/* useDAppWallet */.I)();
        const { entryList } = (0,useDAppBrowserEntries/* useDAppBrowserEntries */.y)();
        const allowInit = (0,reactivity_esm_bundler/* ref */.iH)(false);
        (0,runtime_core_esm_bundler/* onMounted */.bv)(() => { (0,runtime_core_esm_bundler/* nextTick */.Y3)(() => { allowInit.value = true; }); });
        return {
            entryList,
            allowInit,
            dappAccount,
            dappWalletData,
            isStaging: app_parameters/* isStaging */.cm
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/dapps/DAppIframes.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/dapps/DAppIframes.vue




;
const DAppIframes_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(DAppIframesvue_type_script_lang_ts, [['render',DAppIframesvue_type_template_id_5712b174_ts_true_render]])

/* harmony default export */ const DAppIframes = (DAppIframes_exports_);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/layouts/ccw/AppLayout.vue?vue&type=script&lang=ts

;



















/* harmony default export */ const AppLayoutvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'AppLayout',
    components: {
        Header: Header/* default */.Z,
        EpochProgress: EpochProgress/* default */.Z,
        Footer: Footer/* default */.Z,
        NavSidebar: NavSidebar/* default */.Z,
        BannerMoving: BannerMoving,
        DAppIframes: DAppIframes,
    },
    setup() {
        const $q = (0,use_quasar/* default */.Z)();
        (0,runtime_core_esm_bundler/* onErrorCaptured */.d1)((e, instance, info) => {
            console.error('Layout: onErrorCaptured', e);
            $q.notify({
                type: 'negative',
                message: 'error: ' + (e?.message ?? 'no error message') + ' info: ' + info,
                position: 'top-left',
                timeout: 20000
            });
            return true;
        });
        // Initialize stores
        const verifiedTokensStore = (0,useVerifiedTokensStore/* useVerifiedTokensStore */.Z)();
        const { t } = (0,useTranslation/* useTranslation */.$)();
        const { networkId, isCustomNetwork } = (0,useNetworkId/* useNetworkId */.h)();
        const { initFormatter } = (0,useFormatter/* useFormatter */.G)();
        const { loadDecryptedMsgMapFromStore } = (0,useDecryptedMsgStore/* useDecryptedMsgStore */.i)();
        loadDecryptedMsgMapFromStore();
        initFormatter();
        (0,useBuildTx_v3/* useBuildTxV3 */.b)(); // Necessary to keep tmp values when navigating away from wallet details.
        (0,useTokenLib_v2/* useTokenLibV2 */.P)(); // Necessary to load token metadata in the background
        const { loadSwapRoutes } = (0,useSwapLib/* useSwapLib */.a)(); // Necessary to load swap routes and token metadata in the background, dependent on useTokenLibV2
        loadSwapRoutes();
        if (networkId.value) {
            (0,PendingTxDb/* loadPendingTxList */.cg)(networkId.value);
        }
        const { loadPoolList } = (0,usePoolAPI/* usePoolAPI */.b)();
        loadPoolList();
        const { loadDAppEntryList } = (0,useDAppBrowserEntries/* useDAppBrowserEntries */.y)();
        loadDAppEntryList(true);
        const { pullCurrencyData } = (0,useCurrencyAPI/* useCurrencyAPI */.b)();
        if (!isCustomNetwork.value) {
            pullCurrencyData();
        } // Should only be called once
        const { loadBlacklist } = (0,useBlacklist/* useBlacklist */.P)();
        loadBlacklist();
        const onFocus = () => {
            // add any task that needs to run when Eternl window regains focus
            if (networkId.value) {
                (0,PendingTxDb/* loadPendingTxList */.cg)(networkId.value);
            }
        };
        const onUnFocus = () => {
            // add any task that needs to run when Eternl window loses focus
        };
        window.removeEventListener('focus', onFocus);
        window.removeEventListener('blur', onUnFocus);
        window.addEventListener('focus', onFocus);
        window.addEventListener('blur', onUnFocus);
        return {
            t,
            onErrorCaptured: runtime_core_esm_bundler/* onErrorCaptured */.d1
        };
    }
}));

;// CONCATENATED MODULE: ./src/layouts/ccw/AppLayout.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/layouts/ccw/AppLayout.vue




;


const AppLayout_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(AppLayoutvue_type_script_lang_ts, [['render',render],['__scopeId',"data-v-1b5d5d7c"]])

/* harmony default export */ const AppLayout = (AppLayout_exports_);

/***/ })

}]);
//# sourceMappingURL=6331.js.map