"use strict";
(this["webpackChunkccw_frontend"] = this["webpackChunkccw_frontend"] || []).push([[6308],{

/***/ 21084:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Pair)
});

// EXTERNAL MODULE: ./node_modules/@vue/runtime-core/dist/runtime-core.esm-bundler.js
var runtime_core_esm_bundler = __webpack_require__(83673);
// EXTERNAL MODULE: ./node_modules/@vue/shared/dist/shared.esm-bundler.js
var shared_esm_bundler = __webpack_require__(62323);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/Pair.vue?vue&type=template&id=243b869d&ts=true

const _hoisted_1 = { class: "min-h-16 sm:min-h-20 w-full max-w-full p-3 text-center flex flex-col flex-nowrap justify-center items-center border-t border-b mb-px cc-text-sz cc-bg-white-0" };
const _hoisted_2 = { class: "cc-text-semi-bold" };
const _hoisted_3 = { class: "" };
const _hoisted_4 = { class: "cc-page-wallet cc-text-sz" };
const _hoisted_5 = { class: "col-span-12 flex flex-row flex-nowrap" };
const _hoisted_6 = {
    key: 1,
    class: "col-span-12 flex flex-row flex-nowrap items-center"
};
const _hoisted_7 = {
    key: 2,
    class: "col-span-12 grid grid-cols-12 cc-gap"
};
const _hoisted_8 = {
    key: 3,
    class: "col-span-12 grid grid-cols-12 cc-gap"
};
function render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_InfoModal = (0,runtime_core_esm_bundler/* resolveComponent */.up)("InfoModal");
    const _component_AccountCreationOverlay = (0,runtime_core_esm_bundler/* resolveComponent */.up)("AccountCreationOverlay");
    const _component_GridHeadline = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridHeadline");
    const _component_GridText = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridText");
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    const _component_GridRadioGroup = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridRadioGroup");
    const _component_GridButtonPrimary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonPrimary");
    const _component_GridButtonSecondary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonSecondary");
    const _component_GridFormAccountSelection = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridFormAccountSelection");
    const _component_IconInfo = (0,runtime_core_esm_bundler/* resolveComponent */.up)("IconInfo");
    const _component_IconWarning = (0,runtime_core_esm_bundler/* resolveComponent */.up)("IconWarning");
    const _component_LedgerTransport = (0,runtime_core_esm_bundler/* resolveComponent */.up)("LedgerTransport");
    const _component_TrezorDerivationType = (0,runtime_core_esm_bundler/* resolveComponent */.up)("TrezorDerivationType");
    const _component_GridFormWalletName = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridFormWalletName");
    const _component_GridSteps = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSteps");
    const _component_Page = (0,runtime_core_esm_bundler/* resolveComponent */.up)("Page");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_Page, {
        containerCSS: '',
        "align-top": ""
    }, {
        header: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_1, [
                (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_2, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('wallet.pair.headline')), 1),
                (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_3, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('wallet.pair.caption')), 1)
            ])
        ]),
        content: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
            (_ctx.showInfoModal)
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_InfoModal, {
                    key: 0,
                    caption: _ctx.it('common.walletCreation.restart'),
                    title: _ctx.it('common.label.notice'),
                    onClose: _ctx.onHideModal,
                    onConfirm: _ctx.onHideModal
                }, null, 8, ["caption", "title", "onClose", "onConfirm"]))
                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
            (_ctx.walletCreateInProgress)
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_AccountCreationOverlay, {
                    key: 1,
                    status: _ctx.walletCreationStatus
                }, null, 8, ["status"]))
                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_4, [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSteps, {
                    onBack: _ctx.goBack,
                    steps: _ctx.optionsSteps,
                    currentStep: _ctx.currentStep,
                    "small-c-s-s": "pr-20 xs:pr-20 lg:pr-24"
                }, {
                    step0: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                            label: _ctx.it('wallet.pair.step.type.headline'),
                            class: ""
                        }, null, 8, ["label"]),
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                            text: _ctx.it('wallet.pair.step.type.caption'),
                            class: "cc-text-sz"
                        }, null, 8, ["text"]),
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, {
                            hr: "",
                            class: "my-0.5 sm:my-2"
                        }),
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridRadioGroup, {
                            id: "hw_wallet_pairing",
                            name: "hw_wallet_pairing",
                            options: _ctx.optionsHWtype,
                            onSelected: _ctx.onSelectedHWType
                        }, null, 8, ["options", "onSelected"]),
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonPrimary, {
                            class: "col-start-7 col-span-6 lg:col-start-10 lg:col-span-3",
                            label: _ctx.it('wallet.pair.step.type.button.next'),
                            link: _ctx.gotoNextStepAccountSelection,
                            disabled: _ctx.selectedOptionHWType === null
                        }, null, 8, ["label", "link", "disabled"])
                    ]),
                    step1: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridFormAccountSelection, {
                            onSubmit: _ctx.gotoNextStepConnectHWDevice,
                            class: "col-span-12",
                            "text-id": "wallet.restore.step.password"
                        }, {
                            btnBack: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonSecondary, {
                                    label: 'Back',
                                    link: _ctx.goBack,
                                    class: "col-start-0 col-span-12 lg:col-start-0 lg:col-span-3"
                                }, null, 8, ["link"])
                            ]),
                            _: 1
                        }, 8, ["onSubmit"])
                    ]),
                    step2: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                            label: _ctx.it('wallet.pair.step.connect.headline'),
                            class: ""
                        }, null, 8, ["label"]),
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_5, [
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_IconInfo, { class: "w-7 flex-none mr-2" }),
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                                text: _ctx.it('wallet.pair.step.connect.caption.' + _ctx.selectedOptionHWType?.id),
                                class: "cc-text-sz"
                            }, null, 8, ["text"])
                        ]),
                        ((_ctx.it('wallet.pair.step.connect.notice.' + _ctx.selectedOptionHWType?.id)).length !== 0)
                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridSpace, {
                                key: 0,
                                hr: "",
                                class: "my-2"
                            }))
                            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                        ((_ctx.it('wallet.pair.step.connect.notice.' + _ctx.selectedOptionHWType?.id)).length !== 0)
                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_6, [
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_IconWarning, { class: "w-7 flex-none mr-2" }),
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                                    text: _ctx.it('wallet.pair.step.connect.notice.' + _ctx.selectedOptionHWType?.id),
                                    class: "cc-text-sz"
                                }, null, 8, ["text"])
                            ]))
                            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, {
                            hr: "",
                            class: "mt-2"
                        }),
                        (_ctx.selectedOptionHWType?.id === 'ledger')
                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_7, [
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_LedgerTransport),
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, {
                                    hr: "",
                                    class: "mb-2"
                                })
                            ]))
                            : (_ctx.selectedOptionHWType?.id === 'trezor')
                                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_8, [
                                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_TrezorDerivationType, { onUpdate: _ctx.onTrezorDerivationTypeUpdate }, null, 8, ["onUpdate"]),
                                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, {
                                        hr: "",
                                        class: "mb-2"
                                    })
                                ]))
                                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                        (_ctx.connectError.length !== 0)
                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridText, {
                                key: 4,
                                text: _ctx.connectError,
                                class: "cc-text-sz cc-input-error cc-rounded p-2"
                            }, null, 8, ["text"]))
                            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                        (_ctx.connectError.length !== 0)
                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridSpace, {
                                key: 5,
                                hr: "",
                                class: "mt-2"
                            }))
                            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, { dense: "" }),
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonSecondary, {
                            class: "col-start-0 col-span-6 lg:col-start-7 lg:col-span-3",
                            label: _ctx.it('wallet.pair.step.connect.button.back'),
                            link: _ctx.goBack
                        }, null, 8, ["label", "link"]),
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonPrimary, {
                            class: "col-span-6 lg:col-span-3",
                            label: _ctx.it('wallet.pair.step.connect.button.next'),
                            link: _ctx.gotoNextStepWalletName
                        }, null, 8, ["label", "link"])
                    ]),
                    step3: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridFormWalletName, {
                            class: "col-span-12",
                            "text-id": "wallet.pair.step.name",
                            "prefilled-wallet-name": _ctx.deviceName,
                            "is-update": false,
                            onSubmit: _ctx.gotoNextStepWalletCreation
                        }, {
                            btnBack: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonSecondary, {
                                    class: "col-start-0 col-span-12 lg:col-start-0 lg:col-span-3",
                                    label: _ctx.it('wallet.pair.step.name.button.back'),
                                    link: _ctx.goBack
                                }, null, 8, ["label", "link"])
                            ]),
                            _: 1
                        }, 8, ["prefilled-wallet-name", "onSubmit"])
                    ]),
                    _: 1
                }, 8, ["onBack", "steps", "currentStep"])
            ])
        ]),
        _: 1
    }));
}

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/Pair.vue?vue&type=template&id=243b869d&ts=true

// EXTERNAL MODULE: ./node_modules/@vue/reactivity/dist/reactivity.esm-bundler.js
var reactivity_esm_bundler = __webpack_require__(61959);
// EXTERNAL MODULE: ./node_modules/quasar/src/composables/use-quasar.js
var use_quasar = __webpack_require__(48825);
// EXTERNAL MODULE: ./src/composables/ccw/useNetworkId.ts
var useNetworkId = __webpack_require__(36648);
// EXTERNAL MODULE: ./src/composables/ccw/useTranslation.ts
var useTranslation = __webpack_require__(19376);
// EXTERNAL MODULE: ./src/composables/ccw/useNavigation.ts
var useNavigation = __webpack_require__(52439);
// EXTERNAL MODULE: ./src/composables/ccw/store/useWalletList.ts
var useWalletList = __webpack_require__(4905);
// EXTERNAL MODULE: ./src/composables/ccw/store/useWalletCreation.ts
var useWalletCreation = __webpack_require__(68139);
// EXTERNAL MODULE: ./src/composables/ccw/store/useTrezorDevice.ts
var useTrezorDevice = __webpack_require__(83368);
// EXTERNAL MODULE: ./src/composables/ccw/store/useLedgerDevice.ts
var useLedgerDevice = __webpack_require__(47617);
// EXTERNAL MODULE: ./src/components/ccw/Page.vue + 21 modules
var Page = __webpack_require__(53707);
// EXTERNAL MODULE: ./src/components/ccw/modal/InfoModal.vue + 4 modules
var InfoModal = __webpack_require__(82172);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridHeadline.vue + 3 modules
var GridHeadline = __webpack_require__(63593);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridText.vue + 4 modules
var GridText = __webpack_require__(96834);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridSpace.vue + 4 modules
var GridSpace = __webpack_require__(14740);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridSteps.vue + 14 modules
var GridSteps = __webpack_require__(58217);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridRadioGroup.vue + 4 modules
var GridRadioGroup = __webpack_require__(46837);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridButtonPrimary.vue + 3 modules
var GridButtonPrimary = __webpack_require__(12559);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridButtonSecondary.vue + 3 modules
var GridButtonSecondary = __webpack_require__(72713);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/forms/GridFormWalletName.vue + 3 modules
var GridFormWalletName = __webpack_require__(81839);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/icons/IconInfo.vue + 4 modules
var IconInfo = __webpack_require__(31599);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/icons/IconWarning.vue + 4 modules
var IconWarning = __webpack_require__(97515);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/settings/LedgerTransport.vue + 4 modules
var LedgerTransport = __webpack_require__(44844);
// EXTERNAL MODULE: ./node_modules/@vue/runtime-dom/dist/runtime-dom.esm-bundler.js
var runtime_dom_esm_bundler = __webpack_require__(98880);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/settings/TrezorDerivationType.vue?vue&type=template&id=5dfbeaf7&ts=true

const TrezorDerivationTypevue_type_template_id_5dfbeaf7_ts_true_hoisted_1 = { class: "col-span-12 flex flex-col" };
function TrezorDerivationTypevue_type_template_id_5dfbeaf7_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridRadioGroup = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridRadioGroup");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", TrezorDerivationTypevue_type_template_id_5dfbeaf7_ts_true_hoisted_1, [
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", {
            class: "flex flex-row flex-nowrap items-center whitespace-pre-wrap cursor-pointer",
            onClick: _cache[0] || (_cache[0] = ($event) => (_ctx.showDerivationTypeSelection = !_ctx.showDerivationTypeSelection))
        }, [
            (0,runtime_core_esm_bundler/* createElementVNode */._)("i", {
                class: (0,shared_esm_bundler/* normalizeClass */.C_)(["cc-text-md mr-2", _ctx.showDerivationTypeSelection ? 'mdi mdi-chevron-down' : 'mdi mdi-chevron-right'])
            }, null, 2),
            (0,runtime_core_esm_bundler/* createElementVNode */._)("span", null, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('wallet.pair.setting.trezor.label')), 1)
        ]),
        (0,runtime_core_esm_bundler/* withDirectives */.wy)((0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridRadioGroup, {
            class: "mt-2",
            id: "trezor_derivation_type",
            name: "trezor_derivation_type",
            options: _ctx.optionsDerivationType,
            "default-id": "trezor",
            onSelected: _ctx.onSelectedDerivationType
        }, null, 8, ["options", "onSelected"]), [
            [runtime_dom_esm_bundler/* vShow */.F8, _ctx.showDerivationTypeSelection]
        ])
    ]));
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/settings/TrezorDerivationType.vue?vue&type=template&id=5dfbeaf7&ts=true

;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/settings/TrezorDerivationType.vue?vue&type=script&lang=ts




/* harmony default export */ const TrezorDerivationTypevue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'TrezorDerivationType',
    components: { GridRadioGroup: GridRadioGroup/* default */.Z },
    emits: ['update'],
    setup(props, { emit }) {
        const { it } = (0,useTranslation/* useTranslation */.$)();
        const showDerivationTypeSelection = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const optionsDerivationType = [
            { id: 'trezor', label: 'Trezor ' + it('wallet.pair.setting.trezor.derivation.default'), caption: it('wallet.pair.setting.trezor.derivation.trezor') },
            { id: 'icarus', label: 'Icarus', caption: it('wallet.pair.setting.trezor.derivation.icarus') },
            { id: 'ledger', label: 'Ledger', caption: it('wallet.pair.setting.trezor.derivation.ledger') }
        ];
        function onSelectedDerivationType(option) {
            switch (option.id) {
                case 'trezor':
                    emit('update', useTrezorDevice/* trezorDerivationType.ICARUS_TREZOR */.e.ICARUS_TREZOR);
                    console.log(option.id);
                    break;
                case 'icarus':
                    emit('update', useTrezorDevice/* trezorDerivationType.ICARUS */.e.ICARUS);
                    console.log(option.id);
                    break;
                case 'ledger':
                    emit('update', useTrezorDevice/* trezorDerivationType.LEDGER */.e.LEDGER);
                    console.log(option.id);
                    break;
            }
        }
        return {
            it,
            showDerivationTypeSelection,
            optionsDerivationType,
            onSelectedDerivationType
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/settings/TrezorDerivationType.vue?vue&type=script&lang=ts
 
// EXTERNAL MODULE: ./node_modules/vue-loader/dist/exportHelper.js
var exportHelper = __webpack_require__(74260);
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/settings/TrezorDerivationType.vue




;
const __exports__ = /*#__PURE__*/(0,exportHelper/* default */.Z)(TrezorDerivationTypevue_type_script_lang_ts, [['render',TrezorDerivationTypevue_type_template_id_5dfbeaf7_ts_true_render]])

/* harmony default export */ const TrezorDerivationType = (__exports__);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/forms/GridFormAccountSelection.vue + 4 modules
var GridFormAccountSelection = __webpack_require__(28566);
// EXTERNAL MODULE: ./src/components/ccw/overlay/AccountCreationOverlay.vue + 4 modules
var AccountCreationOverlay = __webpack_require__(21928);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/CSLConstants.ts
var CSLConstants = __webpack_require__(22798);
// EXTERNAL MODULE: ./src/lib/utils/WalletCreationStatusMapper.ts
var WalletCreationStatusMapper = __webpack_require__(7387);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/Pair.vue?vue&type=script&lang=ts

;

























/* harmony default export */ const Pairvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'Pair',
    components: {
        Page: Page/* default */.Z,
        InfoModal: InfoModal/* default */.Z,
        LedgerTransport: LedgerTransport/* default */.Z,
        TrezorDerivationType: TrezorDerivationType,
        GridSpace: GridSpace/* default */.Z,
        GridHeadline: GridHeadline/* default */.Z,
        GridText: GridText/* default */.Z,
        GridSteps: GridSteps/* default */.Z,
        GridRadioGroup: GridRadioGroup/* default */.Z,
        GridButtonPrimary: GridButtonPrimary/* default */.Z,
        GridButtonSecondary: GridButtonSecondary/* default */.Z,
        GridFormWalletName: GridFormWalletName/* default */.Z,
        GridFormAccountSelection: GridFormAccountSelection/* default */.Z,
        AccountCreationOverlay: AccountCreationOverlay/* default */.Z,
        IconInfo: IconInfo/* default */.Z,
        IconWarning: IconWarning/* default */.Z
    },
    setup() {
        const { networkId } = (0,useNetworkId/* useNetworkId */.h)();
        const { it } = (0,useTranslation/* useTranslation */.$)();
        const { openWallet } = (0,useNavigation/* useNavigation */.HJ)();
        const { setWalletName, setAccountPubBech32List, generateWalletIdFromPubBech32, createWallet, setNumberOfAccounts, setDiscoverAccounts, setWalletCreationHook } = (0,useWalletCreation/* useWalletCreation */.c)();
        const { reloadWalletList, hasWalletWithId } = (0,useWalletList/* useWalletList */.M)();
        const { initiateTrezor, getTrezorPublicKey } = (0,useTrezorDevice/* useTrezorDevice */.S)();
        const { initiateLedger, getLedgerSerial, getLedgerPublicKey } = (0,useLedgerDevice/* useLedgerDevice */.t)();
        const $q = (0,use_quasar/* default */.Z)();
        const currentStep = (0,reactivity_esm_bundler/* ref */.iH)(0);
        const selectedOptionHWType = (0,reactivity_esm_bundler/* ref */.iH)(null);
        const selectedTrezorDT = (0,reactivity_esm_bundler/* ref */.iH)();
        const connectError = (0,reactivity_esm_bundler/* ref */.iH)('');
        const deviceName = (0,reactivity_esm_bundler/* ref */.iH)('');
        const walletCreateInProgress = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const walletCreationStatus = (0,reactivity_esm_bundler/* ref */.iH)('');
        const walletIdSuffix = (0,reactivity_esm_bundler/* ref */.iH)();
        const showInfoModal = (0,reactivity_esm_bundler/* ref */.iH)(false);
        let deviceId;
        function resetInputs() {
            connectError.value = '';
            deviceName.value = '';
            setWalletName('');
            setAccountPubBech32List([]);
        }
        resetInputs();
        function goBack() {
            if (currentStep.value === 1) {
                currentStep.value = 0;
            }
            else if (currentStep.value === 2) {
                currentStep.value = 1;
                resetInputs();
            }
            else if (currentStep.value === 3) {
                currentStep.value = 2;
                resetInputs();
            }
        }
        const numberOfAccount = (0,reactivity_esm_bundler/* ref */.iH)(1);
        function gotoNextStepConnectHWDevice(payload) {
            setNumberOfAccounts(payload.accountNumber);
            setDiscoverAccounts(false);
            numberOfAccount.value = payload.accountNumber;
            currentStep.value = 2;
        }
        const ledger = (0,reactivity_esm_bundler/* ref */.iH)();
        async function gotoNextStepWalletName() {
            if (selectedOptionHWType.value === null) {
                return;
            }
            connectError.value = '';
            $q.loading.show({
                message: it('wallet.pair.step.connect.loading.' + selectedOptionHWType.value.id),
                html: true
            });
            let signType = 'ledger';
            if (selectedOptionHWType.value.id === 'ledger') {
                try {
                    const serial = await getLedgerSerial();
                    deviceId = serial;
                    deviceName.value = 'Ledger-' + serial;
                    const pubKeyList = await getLedgerPublicKey(CSLConstants/* purpose.hdwallet */.Gr.hdwallet, -1, numberOfAccount.value);
                    setWalletName(deviceName.value);
                    setAccountPubBech32List(pubKeyList);
                }
                catch (err) {
                    connectError.value = 'Ledger not found!';
                    connectError.value = err.message;
                }
            }
            else if (selectedOptionHWType.value.id === 'trezor') {
                signType = 'trezor';
                try {
                    const features = await initiateTrezor();
                    deviceId = features.device_id ?? undefined;
                    const pubKeyList = await getTrezorPublicKey(CSLConstants/* purpose.hdwallet */.Gr.hdwallet, -1, numberOfAccount.value, [], selectedTrezorDT.value ?? useTrezorDevice/* trezorDerivationType.ICARUS_TREZOR */.e.ICARUS_TREZOR);
                    deviceName.value = 'Trezor-' + features.label ?? '';
                    switch (selectedTrezorDT.value) {
                        case useTrezorDevice/* trezorDerivationType.ICARUS_TREZOR */.e.ICARUS_TREZOR:
                            walletIdSuffix.value = 't';
                            break;
                        case useTrezorDevice/* trezorDerivationType.ICARUS */.e.ICARUS:
                            walletIdSuffix.value = 'i';
                            break;
                        case useTrezorDevice/* trezorDerivationType.LEDGER */.e.LEDGER:
                            walletIdSuffix.value = 'l';
                            break;
                        default: walletIdSuffix.value = 't';
                    }
                    setWalletName(deviceName.value);
                    setAccountPubBech32List(pubKeyList);
                }
                catch (err) {
                    connectError.value = err.message;
                }
            }
            $q.loading.hide();
            if (!connectError.value) {
                try {
                    const walletId = generateWalletIdFromPubBech32(networkId.value, signType, walletIdSuffix.value);
                    if (hasWalletWithId(walletId)) {
                        $q.notify({
                            type: 'warning',
                            message: it('wallet.pair.message.duplicate'),
                            position: 'top-left'
                        });
                        openWallet(walletId);
                    }
                    else {
                        currentStep.value = 3;
                    }
                }
                catch (err) {
                    connectError.value = err.message;
                }
            }
        }
        async function gotoNextStepWalletCreation(payload) {
            setWalletCreationHook(async (status) => {
                walletCreationStatus.value = (0,WalletCreationStatusMapper/* getStatusInfo */.I)(status, it);
            });
            walletCreateInProgress.value = true;
            if (selectedOptionHWType.value === null) {
                return;
            }
            deviceName.value = payload.walletName;
            setWalletName(payload.walletName);
            try {
                if (!networkId.value) {
                    throw new Error('Error: No active network.');
                }
                const walletId = await createWallet(networkId.value, selectedOptionHWType.value.id, deviceId, walletIdSuffix.value);
                await reloadWalletList();
                $q.notify({
                    type: 'positive',
                    message: it('wallet.pair.message.success'),
                    position: 'top-left'
                });
                openWallet(walletId);
            }
            catch (err) {
                console.error('CreateWallet: Error:', err.message);
                walletCreateInProgress.value = false;
                showInfoModal.value = true;
            }
        }
        function onSelectedHWType(option) {
            selectedOptionHWType.value = option;
        }
        function onTrezorDerivationTypeUpdate(derivationType) {
            selectedTrezorDT.value = derivationType;
        }
        function gotoNextStepAccountSelection() {
            if (selectedOptionHWType.value !== null) {
                connectError.value = '';
                currentStep.value = 1;
            }
        }
        const optionsSteps = (0,reactivity_esm_bundler/* reactive */.qj)([
            { id: 'type', label: it('wallet.pair.step.type.label') },
            { id: 'account', label: it('wallet.restore.step.account.label') },
            { id: 'connect', label: it('wallet.pair.step.connect.label') },
            { id: 'name', label: it('wallet.pair.step.name.label') }
        ]);
        const optionsHWtype = (0,reactivity_esm_bundler/* reactive */.qj)([
            { id: 'ledger', label: it('wallet.pair.step.type.option.ledger.label'), caption: it('wallet.pair.step.type.option.ledger.caption') },
            { id: 'trezor', label: it('wallet.pair.step.type.option.trezor.label'), caption: it('wallet.pair.step.type.option.trezor.caption') }
        ]);
        function onHideModal() {
            showInfoModal.value = false;
        }
        return {
            it,
            optionsSteps,
            currentStep,
            connectError,
            deviceName,
            optionsHWtype,
            selectedOptionHWType,
            onSelectedHWType,
            onTrezorDerivationTypeUpdate,
            goBack,
            gotoNextStepConnectHWDevice,
            gotoNextStepWalletName,
            gotoNextStepWalletCreation,
            gotoNextStepAccountSelection,
            walletCreationStatus,
            walletCreateInProgress,
            onHideModal,
            showInfoModal
        };
    }
}));

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/Pair.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/pages/ccw/wallet/Pair.vue




;
const Pair_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(Pairvue_type_script_lang_ts, [['render',render]])

/* harmony default export */ const Pair = (Pair_exports_);

/***/ })

}]);
//# sourceMappingURL=6308.js.map