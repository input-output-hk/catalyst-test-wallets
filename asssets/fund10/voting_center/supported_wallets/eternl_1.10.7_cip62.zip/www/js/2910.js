"use strict";
(this["webpackChunkccw_frontend"] = this["webpackChunkccw_frontend"] || []).push([[2910,5134],{

/***/ 98363:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ DApps)
});

// EXTERNAL MODULE: ./node_modules/@vue/runtime-core/dist/runtime-core.esm-bundler.js
var runtime_core_esm_bundler = __webpack_require__(83673);
// EXTERNAL MODULE: ./node_modules/@vue/runtime-dom/dist/runtime-dom.esm-bundler.js
var runtime_dom_esm_bundler = __webpack_require__(98880);
// EXTERNAL MODULE: ./node_modules/@vue/shared/dist/shared.esm-bundler.js
var shared_esm_bundler = __webpack_require__(62323);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/DApps.vue?vue&type=template&id=abaea9a4&ts=true

const _hoisted_1 = { class: "relative w-full h-full cc-rounded flex flex-row-reverse flex-nowrap dark:text-cc-gray-dark" };
const _hoisted_2 = { class: "relative h-full flex-1 overflow-hidden focus:outline-none flex flex-col flex-nowrap" };
const _hoisted_3 = { class: "h-16 sm:h-20 w-full max-w-full flex flex-row flex-nowrap justify-center items-center border-t border-b mb-px cc-text-sx-dense cc-bg-white-0" };
const _hoisted_4 = {
    key: 0,
    class: "relative w-full h-full flex flex-row flex-nowrap justify-center xs:justify-between items-center max-w-6xl px-3 lg:px-6 xl:px-6 space-x-2"
};
const _hoisted_5 = { class: "relative mr-2 block h-8 sm:h-10 w-8 sm:w-10" };
const _hoisted_6 = { class: "relative h-full flex-1 flex flex-col flex-nowrap justify-center items-start cc-text-semi-bold" };
const _hoisted_7 = { class: "mb-0.5" };
const _hoisted_8 = {
    key: 0,
    class: "mdi mdi-circle text-xs-dense ml-0 cc-text-green",
    style: { "line-height": "0.0rem" }
};
const _hoisted_9 = { class: "cc-text-color-caption cc-text-xxs-dense" };
const _hoisted_10 = { class: "" };
const _hoisted_11 = {
    key: 0,
    class: "cc-text-medium"
};
const _hoisted_12 = ["innerHTML"];
const _hoisted_13 = {
    key: 2,
    class: "cc-text-medium"
};
const _hoisted_14 = {
    key: 3,
    class: "cc-text-medium"
};
const _hoisted_15 = { class: "relative h-full flex-1 flex flex-col flex-nowrap justify-center items-end cc-text-semi-bold" };
const _hoisted_16 = { class: "mb-0.5" };
const _hoisted_17 = {
    key: 0,
    class: "mdi mdi-circle text-xs-dense mr-0.5 cc-text-green",
    style: { "line-height": "0.0rem" }
};
const _hoisted_18 = {
    key: 1,
    class: "relative w-full h-full flex flex-row flex-nowrap justify-center xs:justify-between items-center max-w-6xl px-3 lg:px-6 xl:px-6 space-x-2"
};
const _hoisted_19 = /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("div", { class: "relative mr-2 block h-8 sm:h-10 w-8 sm:w-10 border-gray-300 dark:border-gray-600 border cc-rounded" }, null, -1);
const _hoisted_20 = { class: "relative h-full flex-1 flex flex-col flex-nowrap justify-center items-center cc-text-semi-bold" };
const _hoisted_21 = { class: "mb-0.5" };
const _hoisted_22 = {
    key: 2,
    class: "relative w-full h-full flex flex-row flex-nowrap justify-center xs:justify-between items-center max-w-6xl px-3 lg:px-6 xl:px-6 space-x-2"
};
const _hoisted_23 = /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("div", { class: "relative mr-2 block h-8 sm:h-10 w-8 sm:w-10 border-gray-300 dark:border-gray-600 border cc-rounded" }, null, -1);
const _hoisted_24 = { class: "relative h-full flex-1 flex flex-col flex-nowrap justify-center items-center cc-text-semi-bold" };
const _hoisted_25 = { class: "mb-0.5" };
const _hoisted_26 = { class: "cc-page-wallet cc-text-sz dark:text-cc-gray mb-12" };
const _hoisted_27 = { class: "flex cc-bg-light-1 bottom-8 w-full align-middle justify-center text-center sm:hidden" };
const _hoisted_28 = /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("i", { class: "mdi mdi-star text-2xl" }, null, -1);
const _hoisted_29 = /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("p", null, "Favorites", -1);
const _hoisted_30 = [
    _hoisted_28,
    _hoisted_29
];
const _hoisted_31 = /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("i", { class: "mdi mdi-application text-2xl" }, null, -1);
const _hoisted_32 = /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("p", null, "DApps", -1);
const _hoisted_33 = [
    _hoisted_31,
    _hoisted_32
];
const _hoisted_34 = /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("i", { class: "mdi mdi-cloud-print text-2xl" }, null, -1);
const _hoisted_35 = /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("p", null, "Mint", -1);
const _hoisted_36 = [
    _hoisted_34,
    _hoisted_35
];
const _hoisted_37 = /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("i", { class: "mdi mdi-connection text-2xl" }, null, -1);
const _hoisted_38 = /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("p", null, "Account", -1);
const _hoisted_39 = [
    _hoisted_37,
    _hoisted_38
];
function render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_WalletIcon = (0,runtime_core_esm_bundler/* resolveComponent */.up)("WalletIcon");
    const _component_Balance = (0,runtime_core_esm_bundler/* resolveComponent */.up)("Balance");
    const _component_q_spinner = (0,runtime_core_esm_bundler/* resolveComponent */.up)("q-spinner");
    const _component_DAppBrowser = (0,runtime_core_esm_bundler/* resolveComponent */.up)("DAppBrowser");
    const _component_DAppsAccountList = (0,runtime_core_esm_bundler/* resolveComponent */.up)("DAppsAccountList");
    const _component_GridTabs = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridTabs");
    const _component_Page = (0,runtime_core_esm_bundler/* resolveComponent */.up)("Page");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_1, [
        (0,runtime_core_esm_bundler/* createElementVNode */._)("main", _hoisted_2, [
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_Page, {
                containerCSS: '',
                "align-top": "",
                "add-scroll": true
            }, {
                header: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_3, [
                        (_ctx.activeWalletName)
                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_4, [
                                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", {
                                    class: "flex-none flex w-auto min-w-48 sm:min-w-60 h-12 sm:h-14 flex-row flex-nowrap justify-start items-start cc-area-light-1 px-2 py-2 cursor-pointer cc-btn-tertiary-light",
                                    onClick: _cache[0] || (_cache[0] = (0,runtime_dom_esm_bundler/* withModifiers */.iM)(
                                    //@ts-ignore
                                    (...args) => (_ctx.gotoAccountList && _ctx.gotoAccountList(...args)), ["stop", "prevent"]))
                                }, [
                                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_5, [
                                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_WalletIcon, {
                                            "icon-seed": _ctx.plateImagePart,
                                            "icon-data": _ctx.plateDataPart
                                        }, null, 8, ["icon-seed", "icon-data"])
                                    ]),
                                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_6, [
                                        (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_7, [
                                            (0,runtime_core_esm_bundler/* createElementVNode */._)("span", null, [
                                                (0,runtime_core_esm_bundler/* createTextVNode */.Uk)((0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.activeWalletName) + (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.plateTextPart ? ' ' : '') + " ", 1),
                                                (_ctx.isDappWallet)
                                                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("i", _hoisted_8))
                                                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                                            ]),
                                            (_ctx.activeWalletSignType === 'readonly')
                                                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("i", {
                                                    key: 0,
                                                    class: (0,shared_esm_bundler/* normalizeClass */.C_)(["mdi mdi-cash-lock text-md cc-text-highlight", _ctx.isDappWallet ? 'ml-1' : '']),
                                                    style: { "line-height": "0.1rem" }
                                                }, null, 2))
                                                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                                        ]),
                                        (_ctx.activeWalletData)
                                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_Balance, {
                                                key: 0,
                                                balance: _ctx.activeWalletData?.balance,
                                                syncing: _ctx.isActiveWalletSyncing,
                                                preparing: _ctx.isActiveWalletPreparing,
                                                onOnClickedSync: _ctx.onSyncWallet,
                                                "hide-currency": "",
                                                dense: ""
                                            }, null, 8, ["balance", "syncing", "preparing", "onOnClickedSync"]))
                                            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                                        (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_9, [
                                            (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_10, (0,shared_esm_bundler/* toDisplayString */.zw)('(' + _ctx.plateTextPart + ')'), 1),
                                            (!_ctx.isActiveWalletLocked && !_ctx.isActiveWalletPreparing)
                                                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("span", _hoisted_11, " (" + (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.isActiveWalletSyncing ? 'syncing for' : 'synced') + " ", 1))
                                                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                                            (!_ctx.isActiveWalletLocked && !_ctx.isActiveWalletPreparing)
                                                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("span", {
                                                    key: 1,
                                                    class: "cc-text-medium font-mono",
                                                    innerHTML: _ctx.lastSync
                                                }, null, 8, _hoisted_12))
                                                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                                            (!_ctx.isActiveWalletLocked && !_ctx.isActiveWalletPreparing)
                                                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("span", _hoisted_13, "s " + (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.isActiveWalletSyncing ? '' : 'ago') + ")", 1))
                                                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                                            (_ctx.isActiveWalletPreparing)
                                                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("span", _hoisted_14, " (initializing, " + (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.lastSync) + "s) ", 1))
                                                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                                        ])
                                    ])
                                ]),
                                (_ctx.activeAccount)
                                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", {
                                        key: 0,
                                        class: "flex-none cc-none xs:flex w-auto min-w-48 h-12 sm:h-14 flex-row flex-nowrap justify-start items-start cc-area-light-1 px-2 py-2 cursor-pointer cc-btn-tertiary-light",
                                        onClick: _cache[1] || (_cache[1] = (0,runtime_dom_esm_bundler/* withModifiers */.iM)(
                                        //@ts-ignore
                                        (...args) => (_ctx.gotoAccountList && _ctx.gotoAccountList(...args)), ["stop", "prevent"]))
                                    }, [
                                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_15, [
                                            (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_16, [
                                                (_ctx.isDappAccount)
                                                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("i", _hoisted_17))
                                                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                                                (0,runtime_core_esm_bundler/* createTextVNode */.Uk)((0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.getDAppAccountName(null, _ctx.activeAccount?.pub)), 1)
                                            ]),
                                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_Balance, {
                                                balance: _ctx.activeAccount?.balance,
                                                syncing: _ctx.isActiveWalletSyncing,
                                                preparing: _ctx.isActiveWalletPreparing,
                                                onOnClickedSync: _ctx.onSyncWallet,
                                                "icons-left": "",
                                                "hide-sync-button": ""
                                            }, null, 8, ["balance", "syncing", "preparing", "onOnClickedSync"])
                                        ])
                                    ]))
                                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                            ]))
                            : (_ctx.isLoading)
                                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_18, [
                                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", {
                                        class: "flex-none flex w-48 h-12 sm:h-14 flex-row flex-nowrap justify-start items-start cc-area-light-1 px-2 py-2 cursor-pointer cc-btn-tertiary-light",
                                        onClick: _cache[2] || (_cache[2] = (0,runtime_dom_esm_bundler/* withModifiers */.iM)(
                                        //@ts-ignore
                                        (...args) => (_ctx.gotoAccountList && _ctx.gotoAccountList(...args)), ["stop", "prevent"]))
                                    }, [
                                        _hoisted_19,
                                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_20, [
                                            (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_21, [
                                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_q_spinner)
                                            ])
                                        ])
                                    ])
                                ]))
                                : ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_22, [
                                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", {
                                        class: "flex-none flex w-48 h-12 sm:h-14 flex-row flex-nowrap justify-start items-start cc-area-light-1 px-2 py-2 cursor-pointer cc-btn-tertiary-light",
                                        onClick: _cache[3] || (_cache[3] = (0,runtime_dom_esm_bundler/* withModifiers */.iM)(
                                        //@ts-ignore
                                        (...args) => (_ctx.gotoAccountList && _ctx.gotoAccountList(...args)), ["stop", "prevent"]))
                                    }, [
                                        _hoisted_23,
                                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_24, [
                                            (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_25, [
                                                (0,runtime_core_esm_bundler/* createElementVNode */._)("span", null, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('common.label.clickToSelect')), 1)
                                            ])
                                        ])
                                    ])
                                ]))
                    ])
                ]),
                content: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_26, [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridTabs, {
                            tabs: _ctx.optionsTabs,
                            index: _ctx.tabIndex,
                            hideTabsOnMobile: "",
                            onSelection: _ctx.onTabChanged
                        }, {
                            tab0: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_DAppBrowser, {
                                    title: "Favs",
                                    "filter-matching": "",
                                    "only-favs": "",
                                    onNoFavs: _ctx.handleNoFavs,
                                    onAllCategories: _ctx.handleAllCategories
                                }, null, 8, ["onNoFavs", "onAllCategories"])
                            ]),
                            tab1: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_DAppBrowser, {
                                    title: "Supported DApps",
                                    filterArray: ['mint', 'anvil', 'aidev', 'nmkr'],
                                    filterMatching: false,
                                    onAllCategories: _ctx.handleAllCategories
                                }, null, 8, ["onAllCategories"])
                            ]),
                            tab2: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_DAppBrowser, {
                                    title: "Supported Mints",
                                    filterArray: ['mint', 'anvil', 'aidev', 'nmkr'],
                                    onAllCategories: _ctx.handleAllCategories
                                }, null, 8, ["onAllCategories"])
                            ]),
                            tab3: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_DAppBrowser, {
                                    title: "NMKR Projects",
                                    filterArray: ['nmkr'],
                                    "show-category": false,
                                    "show-promoted": false,
                                    onAllCategories: _ctx.handleAllCategories
                                }, null, 8, ["onAllCategories"])
                            ]),
                            tab4: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_DAppsAccountList)
                            ]),
                            _: 1
                        }, 8, ["tabs", "index", "onSelection"])
                    ])
                ]),
                bottomNavigation: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_27, [
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", {
                            class: (0,shared_esm_bundler/* normalizeClass */.C_)(["flex-auto basis-0 py-1", { 'cc-bg-light-0': _ctx.tabIndex === 0 }]),
                            onClick: _cache[4] || (_cache[4] = ($event) => (_ctx.onTabChanged(0)))
                        }, _hoisted_30, 2),
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", {
                            class: (0,shared_esm_bundler/* normalizeClass */.C_)(["flex-auto basis-0 py-1", { 'cc-bg-light-0': _ctx.tabIndex === 1 }]),
                            onClick: _cache[5] || (_cache[5] = ($event) => (_ctx.onTabChanged(1)))
                        }, _hoisted_33, 2),
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", {
                            class: (0,shared_esm_bundler/* normalizeClass */.C_)(["flex-auto basis-0 py-1", { 'cc-bg-light-0': _ctx.tabIndex === 2 }]),
                            onClick: _cache[6] || (_cache[6] = ($event) => (_ctx.onTabChanged(2)))
                        }, _hoisted_36, 2),
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", {
                            class: (0,shared_esm_bundler/* normalizeClass */.C_)(["flex-auto basis-0 py-1", { 'cc-bg-light-0': _ctx.tabIndex === 3 }]),
                            onClick: _cache[7] || (_cache[7] = ($event) => (_ctx.gotoAccountList()))
                        }, _hoisted_39, 2)
                    ])
                ]),
                _: 1
            })
        ])
    ]));
}

;// CONCATENATED MODULE: ./src/pages/ccw/DApps.vue?vue&type=template&id=abaea9a4&ts=true

// EXTERNAL MODULE: ./node_modules/@vue/reactivity/dist/reactivity.esm-bundler.js
var reactivity_esm_bundler = __webpack_require__(61959);
// EXTERNAL MODULE: ./node_modules/quasar/src/composables/use-quasar.js
var use_quasar = __webpack_require__(48825);
// EXTERNAL MODULE: ./src/composables/ccw/useTranslation.ts
var useTranslation = __webpack_require__(19376);
// EXTERNAL MODULE: ./src/composables/ccw/useTimestamp.ts
var useTimestamp = __webpack_require__(53199);
// EXTERNAL MODULE: ./src/composables/ccw/store/useDAppBrowserEvents.ts
var useDAppBrowserEvents = __webpack_require__(62007);
// EXTERNAL MODULE: ./src/composables/ccw/store/useDAppWallet.ts
var useDAppWallet = __webpack_require__(35053);
// EXTERNAL MODULE: ./src/components/ccw/Page.vue + 21 modules
var Page = __webpack_require__(53707);
// EXTERNAL MODULE: ./src/components/ccw/common/Balance.vue + 4 modules
var Balance = __webpack_require__(17664);
// EXTERNAL MODULE: ./src/components/ccw/common/TabButton.vue + 4 modules
var TabButton = __webpack_require__(72750);
// EXTERNAL MODULE: ./src/components/ccw/common/IconButton.vue + 3 modules
var IconButton = __webpack_require__(45995);
// EXTERNAL MODULE: ./src/components/ccw/wallet/WalletIcon.vue + 5 modules
var WalletIcon = __webpack_require__(46333);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridTabs.vue + 4 modules
var GridTabs = __webpack_require__(49510);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/dapps/DAppBrowser.vue?vue&type=template&id=028d37dc&ts=true

const DAppBrowservue_type_template_id_028d37dc_ts_true_hoisted_1 = { class: "col-span-12 grid grid-cols-12 cc-gap cc-text-sz" };
const DAppBrowservue_type_template_id_028d37dc_ts_true_hoisted_2 = {
    key: 0,
    class: "cc-grid"
};
const DAppBrowservue_type_template_id_028d37dc_ts_true_hoisted_3 = {
    key: 6,
    class: "absolute top-0 left-0 w-0 h-0 overflow-hidden"
};
function DAppBrowservue_type_template_id_028d37dc_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridTextArea = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridTextArea");
    const _component_DAppBrowserURLInput = (0,runtime_core_esm_bundler/* resolveComponent */.up)("DAppBrowserURLInput");
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    const _component_GridHeadline = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridHeadline");
    const _component_DAppBrowserFavoriteEntry = (0,runtime_core_esm_bundler/* resolveComponent */.up)("DAppBrowserFavoriteEntry");
    const _component_DAppIframe = (0,runtime_core_esm_bundler/* resolveComponent */.up)("DAppIframe");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", DAppBrowservue_type_template_id_028d37dc_ts_true_hoisted_1, [
        (!(_ctx.dappWalletData && _ctx.dappAccount))
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridTextArea, {
                key: 0,
                label: _ctx.it('dapps.browser.account.label'),
                text: _ctx.it('dapps.browser.account.text'),
                icon: _ctx.it('dapps.browser.account.icon'),
                html: "",
                class: "col-span-12",
                "text-c-s-s": "cc-text-normal text-justify",
                css: "cc-rounded cc-banner-warning"
            }, null, 8, ["label", "text", "icon"]))
            : (_ctx.isStaging || _ctx.isIosApp)
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridTextArea, {
                    key: 1,
                    label: _ctx.it('dapps.browser.urlInput.label'),
                    text: _ctx.it('dapps.browser.urlInput.text'),
                    icon: _ctx.it('dapps.browser.urlInput.icon'),
                    html: "",
                    class: "col-span-12",
                    "text-c-s-s": "cc-text-normal text-justify",
                    css: "cc-rounded cc-banner-blue"
                }, null, 8, ["label", "text", "icon"]))
                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (_ctx.isStaging || _ctx.isIosApp)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_DAppBrowserURLInput, {
                key: 2,
                onSubmit: _ctx.onURL,
                "text-id": "dapps.browser.urlInput",
                disabled: !(_ctx.dappWalletData && _ctx.dappAccount)
            }, null, 8, ["onSubmit", "disabled"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (_ctx.isStaging || _ctx.isIosApp)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridSpace, {
                key: 3,
                hr: "",
                class: "col-span-12 my-0.5 sm:my-2"
            }))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
            label: _ctx.isIosApp ? _ctx.it('dapps.browser.recentlyConnected') : _ctx.title
        }, null, 8, ["label"]),
        (_ctx.showPromoted)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(true), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, { key: 4 }, (0,runtime_core_esm_bundler/* renderList */.Ko)(_ctx.promotedList, (item) => {
                return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_DAppBrowserFavoriteEntry, {
                    key: item.id + '_pl',
                    "dapp-connect": item,
                    "is-staging": _ctx.isStaging,
                    "is-featured": true,
                    "html-id": item.id,
                    onConnect: _ctx.handleConnect,
                    onDisconnect: _ctx.handleDisconnect,
                    onMaximize: _ctx.handleMaximize,
                    class: "col-span-12 h-24 sm:h-40 xl:h-40"
                }, null, 8, ["dapp-connect", "is-staging", "html-id", "onConnect", "onDisconnect", "onMaximize"]));
            }), 128))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        ((0,runtime_core_esm_bundler/* openBlock */.wg)(true), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, (0,runtime_core_esm_bundler/* renderList */.Ko)(_ctx.categories, (category) => {
            return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", {
                class: "cc-grid",
                key: category.label + '_cat'
            }, [
                (category.list.length > 0)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", DAppBrowservue_type_template_id_028d37dc_ts_true_hoisted_2, [
                        (category.list.length > 0)
                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridSpace, {
                                key: 0,
                                hr: "",
                                class: "col-span-12 my-0.5 sm:my-2"
                            }))
                            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                        (_ctx.showCategory)
                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridHeadline, {
                                key: 1,
                                label: category.label,
                                class: "col-span-12"
                            }, null, 8, ["label"]))
                            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                        ((0,runtime_core_esm_bundler/* openBlock */.wg)(true), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, (0,runtime_core_esm_bundler/* renderList */.Ko)(category.list, (item) => {
                            return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_DAppBrowserFavoriteEntry, {
                                key: item.id + '_fl_' + category.label,
                                "dapp-connect": item,
                                "is-staging": _ctx.isStaging,
                                "is-featured": true,
                                "html-id": item.id,
                                "only-favs": _ctx.onlyFavs,
                                onConnect: _ctx.handleConnect,
                                onDisconnect: _ctx.handleDisconnect,
                                onMaximize: _ctx.handleMaximize,
                                onFavChanged: _ctx.handleFavChanged,
                                class: "col-span-6 xl:col-span-4 h-16 xs:h-20 sm:h-24 xl:h-32"
                            }, null, 8, ["dapp-connect", "is-staging", "html-id", "only-favs", "onConnect", "onDisconnect", "onMaximize", "onFavChanged"]));
                        }), 128))
                    ]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
            ]));
        }), 128)),
        (_ctx.normalList.length > 0)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridSpace, {
                key: 5,
                hr: "",
                class: "col-span-12 my-0.5 sm:my-2"
            }))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        ((0,runtime_core_esm_bundler/* openBlock */.wg)(true), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, (0,runtime_core_esm_bundler/* renderList */.Ko)(_ctx.normalList, (item) => {
            return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_DAppBrowserFavoriteEntry, {
                key: item.id + '_nl',
                "dapp-connect": item,
                "is-staging": _ctx.isStaging,
                "is-featured": false,
                "html-id": item.id,
                onConnect: _ctx.handleConnect,
                onDisconnect: _ctx.handleDisconnect,
                onMaximize: _ctx.handleMaximize,
                onFavChanged: _ctx.handleFavChanged,
                class: "col-span-6 xl:col-span-4 h-10"
            }, null, 8, ["dapp-connect", "is-staging", "html-id", "onConnect", "onDisconnect", "onMaximize", "onFavChanged"]));
        }), 128)),
        (_ctx.allowInit && _ctx.dappWalletData && _ctx.dappAccount)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", DAppBrowservue_type_template_id_028d37dc_ts_true_hoisted_3, [
                ((0,runtime_core_esm_bundler/* openBlock */.wg)(true), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, (0,runtime_core_esm_bundler/* renderList */.Ko)(_ctx.normalList, (item) => {
                    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_DAppIframe, {
                        key: item.id + '_iframe_modal',
                        wallet: _ctx.dappWalletData,
                        account: _ctx.dappAccount,
                        "dapp-connect": item,
                        "is-staging": _ctx.isStaging,
                        "html-id": item.id,
                        onReady: ($event) => (_ctx.onIframeReady(item))
                    }, null, 8, ["wallet", "account", "dapp-connect", "is-staging", "html-id", "onReady"]));
                }), 128))
            ]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
    ]));
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/dapps/DAppBrowser.vue?vue&type=template&id=028d37dc&ts=true

// EXTERNAL MODULE: ./src/composables/ccw/useNetworkId.ts
var useNetworkId = __webpack_require__(36648);
// EXTERNAL MODULE: ./src/composables/ccw/store/useDAppBrowserEntries.ts + 1 modules
var useDAppBrowserEntries = __webpack_require__(39715);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridHeadline.vue + 3 modules
var GridHeadline = __webpack_require__(63593);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridSpace.vue + 4 modules
var GridSpace = __webpack_require__(14740);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridText.vue + 4 modules
var GridText = __webpack_require__(96834);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridTextArea.vue + 4 modules
var GridTextArea = __webpack_require__(15660);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/dapps/DAppBrowserFavoriteEntry.vue?vue&type=template&id=3ca17255&ts=true

const DAppBrowserFavoriteEntryvue_type_template_id_3ca17255_ts_true_hoisted_1 = ["src"];
const DAppBrowserFavoriteEntryvue_type_template_id_3ca17255_ts_true_hoisted_2 = {
    key: 3,
    class: "grow h-auto text-left pl-4"
};
const DAppBrowserFavoriteEntryvue_type_template_id_3ca17255_ts_true_hoisted_3 = /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("i", { class: "mdi mdi-trash-can-outline text-gray-400 drop-shadow text-xl" }, null, -1);
const DAppBrowserFavoriteEntryvue_type_template_id_3ca17255_ts_true_hoisted_4 = [
    DAppBrowserFavoriteEntryvue_type_template_id_3ca17255_ts_true_hoisted_3
];
const DAppBrowserFavoriteEntryvue_type_template_id_3ca17255_ts_true_hoisted_5 = {
    key: 0,
    class: "relative w-5 h-5 border-2 cc-border-green shadow rounded-md"
};
const DAppBrowserFavoriteEntryvue_type_template_id_3ca17255_ts_true_hoisted_6 = /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("div", { class: "relative mt-0.5 ml-0.5 w-3 h-3 cc-bg-green drop-shadow rounded-sm" }, null, -1);
const DAppBrowserFavoriteEntryvue_type_template_id_3ca17255_ts_true_hoisted_7 = [
    DAppBrowserFavoriteEntryvue_type_template_id_3ca17255_ts_true_hoisted_6
];
const DAppBrowserFavoriteEntryvue_type_template_id_3ca17255_ts_true_hoisted_8 = {
    key: 1,
    class: "relative w-5 h-5 border-2 border-gray-400 shadow rounded-md bg-blue-500/5"
};
const DAppBrowserFavoriteEntryvue_type_template_id_3ca17255_ts_true_hoisted_9 = /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("div", { class: "relative mt-1 ml-1 w-2 h-2 bg-gray-400 drop-shadow rounded-sm" }, null, -1);
const DAppBrowserFavoriteEntryvue_type_template_id_3ca17255_ts_true_hoisted_10 = [
    DAppBrowserFavoriteEntryvue_type_template_id_3ca17255_ts_true_hoisted_9
];
function DAppBrowserFavoriteEntryvue_type_template_id_3ca17255_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    return (_ctx.entry && (_ctx.onlyFavs ? _ctx.isFav : true))
        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", {
            key: 0,
            class: (0,shared_esm_bundler/* normalizeClass */.C_)(["relative cc-area-light text-center cursor-pointer overflow-hidden flex flex-row flex-nowrap justify-start items-center", _ctx.isFeatured ? '' : 'space-x-2 px-2 py-2'])
        }, [
            (!_ctx.isFav)
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("i", {
                    key: 0,
                    onClick: _cache[0] || (_cache[0] = ($event) => (_ctx.toggleFavorite(_ctx.htmlId))),
                    class: "mdi mdi-star-outline absolute left-1 top-1 text-2xl text-gray-400"
                }))
                : ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("i", {
                    key: 1,
                    onClick: _cache[1] || (_cache[1] = ($event) => (_ctx.toggleFavorite(_ctx.htmlId))),
                    class: "mdi mdi-star absolute left-1 top-1 text-2xl cc-text-green"
                })),
            (_ctx.isFeatured && _ctx.entry.image[_ctx.entry.type])
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("img", {
                    key: 2,
                    onClick: _cache[2] || (_cache[2] = (0,runtime_dom_esm_bundler/* withModifiers */.iM)(
                    //@ts-ignore
                    (...args) => (_ctx.handleMaximize && _ctx.handleMaximize(...args)), ["prevent", "stop"])),
                    src: _ctx.imageURL(),
                    class: "w-full h-full object-cover",
                    alt: ""
                }, null, 8, DAppBrowserFavoriteEntryvue_type_template_id_3ca17255_ts_true_hoisted_1))
                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
            (!_ctx.isFeatured || !_ctx.imageURL())
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", DAppBrowserFavoriteEntryvue_type_template_id_3ca17255_ts_true_hoisted_2, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.entry?.label), 1))
                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
            (!_ctx.isFeatured || _ctx.isIosApp)
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("button", {
                    key: 4,
                    class: (0,shared_esm_bundler/* normalizeClass */.C_)(["absolute right-8 sm:right-9 w-6 h-8 cc-rounded cc-text-lg flex justify-center items-center", _ctx.isFeatured ? 'top-0 sm:top-1' : 'top-1']),
                    onClick: _cache[3] || (_cache[3] = (0,runtime_dom_esm_bundler/* withModifiers */.iM)(
                    //@ts-ignore
                    (...args) => (_ctx.handleDelete && _ctx.handleDelete(...args)), ["stop", "prevent"]))
                }, DAppBrowserFavoriteEntryvue_type_template_id_3ca17255_ts_true_hoisted_4, 2))
                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
            (0,runtime_core_esm_bundler/* createElementVNode */._)("button", {
                class: (0,shared_esm_bundler/* normalizeClass */.C_)(["absolute right-1 sm:right-2 top-0 sm:top-1 w-6 h-8 cc-rounded cc-text-lg flex justify-center items-center", _ctx.isFeatured ? 'top-0 sm:top-1' : 'top-1 sm:top-1']),
                onClick: _cache[4] || (_cache[4] = (0,runtime_dom_esm_bundler/* withModifiers */.iM)(
                //@ts-ignore
                (...args) => (_ctx.handleConnect && _ctx.handleConnect(...args)), ["stop", "prevent"]))
            }, [
                (_ctx.dappConnect.isConnected)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", DAppBrowserFavoriteEntryvue_type_template_id_3ca17255_ts_true_hoisted_5, DAppBrowserFavoriteEntryvue_type_template_id_3ca17255_ts_true_hoisted_7))
                    : ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", DAppBrowserFavoriteEntryvue_type_template_id_3ca17255_ts_true_hoisted_8, DAppBrowserFavoriteEntryvue_type_template_id_3ca17255_ts_true_hoisted_10))
            ], 2)
        ], 2))
        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true);
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/dapps/DAppBrowserFavoriteEntry.vue?vue&type=template&id=3ca17255&ts=true

// EXTERNAL MODULE: ./src/composables/ccw/store/entries/IDappConnect.ts
var IDappConnect = __webpack_require__(97562);
// EXTERNAL MODULE: ./src/boot/app.parameters.ts
var app_parameters = __webpack_require__(56629);
// EXTERNAL MODULE: ./src/lib/utils/useAppMode.ts
var useAppMode = __webpack_require__(4254);
// EXTERNAL MODULE: ./src/lib/ExtStorageLib.ts + 1 modules
var ExtStorageLib = __webpack_require__(40736);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/dapps/DAppBrowserFavoriteEntry.vue?vue&type=script&lang=ts





/* harmony default export */ const DAppBrowserFavoriteEntryvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'DAppBrowserFavoriteEntry',
    emits: ['connect', 'disconnect', 'maximize', 'favChanged'],
    props: {
        dappConnect: { type: Object, required: true },
        isStaging: { type: Boolean, required: true },
        isFeatured: { type: Boolean, required: true },
        onlyFavs: { type: Boolean, required: false },
        htmlId: { type: String, required: true }
    },
    setup(props, { emit }) {
        function handleMaximize() { emit('maximize', props.dappConnect); }
        function handleConnect() { emit('connect', props.dappConnect); }
        function handleDelete() { emit('disconnect', props.dappConnect); }
        const entry = (0,IDappConnect/* getIDAppConnectEntry */.J)(props.dappConnect, props.isStaging);
        const imageURL = () => {
            if (!entry || !entry.image[entry.type]) {
                return null;
            }
            return entry.image[entry.type]?.startsWith('http') ? entry.image[entry.type] : (app_parameters/* apiURL.toString */.QH.toString() + entry.image[entry.type]);
        };
        const isFav = (0,reactivity_esm_bundler/* ref */.iH)((0,ExtStorageLib/* getDBEFav */.VU)(props.htmlId));
        function toggleFavorite(id) {
            const _isFav = (0,ExtStorageLib/* getDBEFav */.VU)(id);
            (0,ExtStorageLib/* setDBEFav */.JE)(id, !_isFav);
            isFav.value = !_isFav;
            emit('favChanged', props.dappConnect);
        }
        return {
            handleMaximize,
            handleConnect,
            handleDelete,
            toggleFavorite,
            isFav,
            isIosApp: useAppMode/* isIosApp */.jv,
            entry,
            imageURL
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/dapps/DAppBrowserFavoriteEntry.vue?vue&type=script&lang=ts
 
// EXTERNAL MODULE: ./node_modules/vue-loader/dist/exportHelper.js
var exportHelper = __webpack_require__(74260);
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/dapps/DAppBrowserFavoriteEntry.vue




;
const __exports__ = /*#__PURE__*/(0,exportHelper/* default */.Z)(DAppBrowserFavoriteEntryvue_type_script_lang_ts, [['render',DAppBrowserFavoriteEntryvue_type_template_id_3ca17255_ts_true_render]])

/* harmony default export */ const DAppBrowserFavoriteEntry = (__exports__);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/dapps/DAppBrowserURLInput.vue?vue&type=template&id=116674b3&ts=true

function DAppBrowserURLInputvue_type_template_id_116674b3_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_IconGlobe = (0,runtime_core_esm_bundler/* resolveComponent */.up)("IconGlobe");
    const _component_GridInputAutocomplete = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridInputAutocomplete");
    const _component_ScanQrCode = (0,runtime_core_esm_bundler/* resolveComponent */.up)("ScanQrCode");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, [
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridInputAutocomplete, {
            "input-text": _ctx.urlInput,
            "onUpdate:input-text": _cache[0] || (_cache[0] = ($event) => ((_ctx.urlInput) = $event)),
            "input-error": _ctx.urlInputError,
            "onUpdate:input-error": _cache[1] || (_cache[1] = ($event) => ((_ctx.urlInputError) = $event)),
            onEnter: _ctx.onSubmit,
            onReset: _ctx.onReset,
            onPaste: _ctx.onPaste,
            "input-id": 'urlInput',
            "input-hint": _ctx.it(_ctx.textId + '.hint'),
            autocomplete: "off",
            "input-disabled": _ctx.disabled,
            alwaysShowInfo: false,
            showReset: _ctx.urlInput.length > 0,
            "input-type": "text",
            "auto-complete-items": _ctx.autocompleteList,
            class: "col-span-10 md:col-span-11"
        }, {
            "icon-prepend": (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_IconGlobe, { class: "h-5 w-5" })
            ]),
            _: 1
        }, 8, ["input-text", "input-error", "onEnter", "onReset", "onPaste", "input-hint", "input-disabled", "showReset", "auto-complete-items"]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_ScanQrCode, {
            onDecode: _ctx.onQrCode,
            disabled: _ctx.disabled,
            "button-css": "col-span-2 md:col-span-1 h-10 sm:h-11"
        }, null, 8, ["onDecode", "disabled"])
    ], 64));
}

// EXTERNAL MODULE: ./src/components/ccw/common/Tooltip.vue + 3 modules
var Tooltip = __webpack_require__(30105);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/babel-loader/lib/index.js??clonedRuleSet-2.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/icons/IconGlobe.vue?vue&type=template&id=6d0bc23a

const IconGlobevue_type_template_id_6d0bc23a_hoisted_1 = {
  xmlns: "http://www.w3.org/2000/svg",
  class: "h-6 w-6",
  fill: "none",
  viewBox: "0 0 24 24",
  stroke: "currentColor",
  "stroke-width": "2"
};
const IconGlobevue_type_template_id_6d0bc23a_hoisted_2 = /*#__PURE__*/(0,runtime_core_esm_bundler/* createElementVNode */._)("path", {
  "stroke-linecap": "round",
  "stroke-linejoin": "round",
  d: "M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
}, null, -1);
const IconGlobevue_type_template_id_6d0bc23a_hoisted_3 = [IconGlobevue_type_template_id_6d0bc23a_hoisted_2];
function IconGlobevue_type_template_id_6d0bc23a_render(_ctx, _cache, $props, $setup, $data, $options) {
  return (0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("svg", IconGlobevue_type_template_id_6d0bc23a_hoisted_1, IconGlobevue_type_template_id_6d0bc23a_hoisted_3);
}
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/icons/IconGlobe.vue?vue&type=template&id=6d0bc23a

;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/babel-loader/lib/index.js??clonedRuleSet-2.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/icons/IconGlobe.vue?vue&type=script&lang=js
/* harmony default export */ const IconGlobevue_type_script_lang_js = ({
  name: 'IconGlobe'
});
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/icons/IconGlobe.vue?vue&type=script&lang=js
 
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/icons/IconGlobe.vue




;
const IconGlobe_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(IconGlobevue_type_script_lang_js, [['render',IconGlobevue_type_template_id_6d0bc23a_render]])

/* harmony default export */ const IconGlobe = (IconGlobe_exports_);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridInputAutocomplete.vue + 4 modules
var GridInputAutocomplete = __webpack_require__(24640);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/send/ScanQrCode.vue + 12 modules
var ScanQrCode = __webpack_require__(9055);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/send/vue-qrcode-reader/mixins/CommonAPI.vue + 2 modules
var CommonAPI = __webpack_require__(574);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/send/vue-qrcode-reader/misc/scanner.js
var scanner = __webpack_require__(78230);
// EXTERNAL MODULE: ./src/lib/ExtAppWalletManagerLib.ts
var ExtAppWalletManagerLib = __webpack_require__(12736);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/dapps/DAppBrowserURLInput.vue?vue&type=script&lang=ts









const updateAddressBook = ExtAppWalletManagerLib/* AWM.updateAddressBook */.b.updateAddressBook;
/* harmony default export */ const DAppBrowserURLInputvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'DAppBrowserURLInput',
    components: {
        IconGlobe: IconGlobe,
        GridInputAutocomplete: GridInputAutocomplete/* default */.Z,
        ScanQrCode: ScanQrCode/* default */.Z,
        Tooltip: Tooltip/* default */.Z
    },
    props: {
        textId: { type: String, required: true, default: 'dapps.browser.urlInput' },
        disabled: { type: Boolean, required: false, default: false },
    },
    emits: ['submit'],
    mixins: [CommonAPI/* default */.Z],
    setup(props, { emit }) {
        const { it } = (0,useTranslation/* useTranslation */.$)();
        const urlInput = (0,reactivity_esm_bundler/* ref */.iH)('');
        const urlInputError = (0,reactivity_esm_bundler/* ref */.iH)('');
        function validateUrlInput() {
            urlInputError.value = '';
            if (!urlInput.value || urlInput.value.length === 0) {
                return;
            }
            const url = urlInput.value;
            return !!url;
        }
        let timeoutId = -1;
        (0,runtime_core_esm_bundler/* watch */.YP)(urlInput, () => {
            clearTimeout(timeoutId);
            timeoutId = setTimeout(async () => {
                validateUrlInput();
            }, 350);
        });
        function onReset() {
            urlInput.value = '';
            urlInputError.value = '';
        }
        function onSubmit(force = false) {
            if (validateUrlInput()) {
                let url = urlInput.value;
                if (!url.startsWith('http')) {
                    url = 'https://' + url;
                }
                emit('submit', url);
                onReset();
            }
        }
        function onQrCode(payload) {
            urlInput.value = payload.content;
            document.getElementById('urlInput')?.focus();
        }
        /**
         * On paste search for longest word in input and take this as send address.
         *
         * If pasted content is an image, assume a qr code, parse it and search in there.
         *
         * @param e
         */
        const onPaste = async (e) => {
            e.stopPropagation();
            e.preventDefault();
            let clipboardData = (e.clipboardData?.getData('Text') ?? '');
            const items = e.clipboardData?.items;
            if (items) {
                let clipboardData1 = await getQrCodeData(items);
                if (clipboardData1) {
                    clipboardData = clipboardData1;
                }
            }
            urlInput.value = clipboardData
                .trim()
                .split(/(\s+)/)
                .sort((a, b) => a.length - b.length)
                .pop() ?? '';
        };
        const getQrCodeData = async (items) => {
            for (let i = 0; i < items.length; i++) {
                if (items[i] && items[i].type.indexOf("image") == -1)
                    continue;
                if (items[i].kind === "file") {
                    const blob = items[i].getAsFile();
                    if (blob) {
                        const scannedCode = await (0,scanner/* processFile */.$E)(blob);
                        if (scannedCode.content) {
                            return scannedCode.content;
                        }
                    }
                }
            }
            return null;
        };
        const autocompleteList = [];
        const favoriteList = [];
        return {
            it,
            urlInput,
            urlInputError,
            onReset,
            onSubmit,
            onPaste,
            onQrCode,
            favoriteList,
            autocompleteList
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/dapps/DAppBrowserURLInput.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/dapps/DAppBrowserURLInput.vue




;
const DAppBrowserURLInput_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(DAppBrowserURLInputvue_type_script_lang_ts, [['render',DAppBrowserURLInputvue_type_template_id_116674b3_ts_true_render]])

/* harmony default export */ const DAppBrowserURLInput = (DAppBrowserURLInput_exports_);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/dapps/DAppIframe.vue + 17 modules
var DAppIframe = __webpack_require__(2494);
// EXTERNAL MODULE: ./src/lib/utils/useLocalStorage.ts
var useLocalStorage = __webpack_require__(34787);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/dapps/DAppBrowser.vue?vue&type=script&lang=ts
















/* harmony default export */ const DAppBrowservue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'DAppBrowser',
    props: {
        title: { type: String, required: true, default: 'Supported DApps' },
        filterArray: { type: Array, required: false, default: [] },
        filterMatching: { type: Boolean, required: false, default: true },
        onlyFavs: { type: Boolean, required: false },
        showPromoted: { type: Boolean, required: false, default: true },
        showCategory: { type: Boolean, required: false, default: true }
    },
    emits: ['noFavs', 'allCategories'],
    components: {
        GridText: GridText/* default */.Z,
        GridTextArea: GridTextArea/* default */.Z,
        GridSpace: GridSpace/* default */.Z,
        GridHeadline: GridHeadline/* default */.Z,
        DAppBrowserFavoriteEntry: DAppBrowserFavoriteEntry,
        DAppBrowserURLInput: DAppBrowserURLInput,
        DAppIframe: DAppIframe/* default */.Z
    },
    setup(props, { emit }) {
        const { it } = (0,useTranslation/* useTranslation */.$)();
        const { networkId } = (0,useNetworkId/* useNetworkId */.h)();
        const { dappAccount, dappWalletData } = (0,useDAppWallet/* useDAppWallet */.I)();
        const { entryList } = (0,useDAppBrowserEntries/* useDAppBrowserEntries */.y)();
        const { emitEvent } = (0,useDAppBrowserEvents/* useDAppBrowserEvents */.R)();
        const iframeList = (0,reactivity_esm_bundler/* reactive */.qj)([]);
        const promotedList = (0,reactivity_esm_bundler/* reactive */.qj)([]);
        const featuredList = (0,reactivity_esm_bundler/* reactive */.qj)([]);
        const normalList = (0,reactivity_esm_bundler/* reactive */.qj)([]);
        const categories = (0,reactivity_esm_bundler/* reactive */.qj)([]);
        const allCategories = (0,reactivity_esm_bundler/* reactive */.qj)([]);
        function handleMaximize(item) { emitEvent(useDAppBrowserEvents/* DAppEntryEvent.maximize */.d.maximize, item.id); }
        function handleConnect(item) { emitEvent(useDAppBrowserEvents/* DAppEntryEvent.connect */.d.connect, item.id); }
        function handleDisconnect(item) {
            emitEvent(useDAppBrowserEvents/* DAppEntryEvent.disconnect */.d.disconnect, item.id);
            for (let i = iframeList.length - 1; i >= 0; i--) {
                if (iframeList[i].id === item.id) {
                    iframeList.splice(i, 1);
                }
            }
            updateLists();
        }
        function handleFavChanged(item) {
            updateLists();
        }
        let toUpdateLists = -1;
        let updatingLists = false;
        function updateLists() {
            clearTimeout(toUpdateLists);
            toUpdateLists = setTimeout(() => {
                actuallyUpdateList();
            }, 10);
        }
        function ifEntryInArray(targetArray, filterList) {
            for (const targetEntry of targetArray) {
                for (const filterEntry of filterList) {
                    if (targetEntry == filterEntry) {
                        return true;
                    }
                }
            }
            return false;
        }
        function actuallyUpdateList() {
            if (updatingLists)
                return;
            updatingLists = true;
            promotedList.splice(0);
            featuredList.splice(0);
            normalList.splice(0);
            for (const entry of iframeList) {
                if (!useAppMode/* isIosApp */.jv && entry.staging.isPromoted) {
                    promotedList.push(entry);
                }
                else if (entry.keywords.length > 0) {
                    featuredList.push(entry);
                }
                else if (entry.keywords.length === 0) {
                    normalList.push(entry);
                }
            }
            categories.splice(0);
            allCategories.splice(0);
            const filterArray = props.filterArray;
            const filterMatching = props.filterMatching;
            for (const entry of featuredList) {
                for (const cat of entry.categories) {
                    allCategories.push(cat);
                    if (props.onlyFavs && !(0,useLocalStorage/* getDBEFav */.VU)(entry.id))
                        continue;
                    if (filterArray.length === 0 || ifEntryInArray(entry.categories, filterArray) == filterMatching) {
                        let category = categories.find(item => item.label === cat);
                        if (!category) {
                            category = { label: cat, list: [] };
                            categories.push(category);
                        }
                        category.list.push(entry);
                    }
                }
            }
            if (props.onlyFavs) {
                if (categories.length === 0) {
                    emit('noFavs');
                }
            }
            emit('allCategories', allCategories);
            categories.sort((a, b) => a.label.localeCompare(b.label));
            (0,useLocalStorage/* setRecentlyConnected */.II)(networkId.value, iframeList);
            updatingLists = false;
        }
        function onURL(url) {
            const tmp = new URL(url);
            const origin = tmp.protocol + '//' + tmp.host + '/';
            const label = tmp.host;
            const id = 'db_' + label;
            let browserEntry = null;
            for (const entry of entryList) {
                if (entry.keywords.some(word => word === tmp.host)) {
                    browserEntry = entry;
                    break;
                }
            }
            if (!browserEntry) {
                browserEntry = (0,reactivity_esm_bundler/* reactive */.qj)({
                    id: id,
                    keywords: [],
                    autoConnect: true,
                    isConnected: false,
                    categories: [],
                    staging: {
                        type: 'free',
                        label: label,
                        caption: '',
                        description: '',
                        isPromoted: false,
                        promotion: '',
                        url: url,
                        origin: origin,
                        image: {
                            promoted: '',
                            platinum: '',
                            gold: '',
                            silver: '',
                            free: '',
                        }
                    },
                    production: {
                        type: 'free',
                        label: label,
                        caption: '',
                        description: '',
                        isPromoted: false,
                        promotion: '',
                        url: url,
                        origin: origin,
                        image: {
                            promoted: '',
                            platinum: '',
                            gold: '',
                            silver: '',
                            free: '',
                        }
                    }
                });
            }
            const iframe = iframeList.find((item) => item.id === browserEntry.id);
            if (iframe) {
                emitEvent(useDAppBrowserEvents/* DAppEntryEvent.maximize */.d.maximize, iframe.id);
            }
            else {
                if (!iframeList.some(item => item.id === browserEntry.id)) {
                    iframeList.push(browserEntry);
                    (0,useLocalStorage/* setDBEFav */.JE)(browserEntry.id, true);
                    updateLists();
                    if (!browserEntry.autoConnect) {
                        emitEvent(useDAppBrowserEvents/* DAppEntryEvent.maximize */.d.maximize, browserEntry.id);
                    }
                }
            }
        }
        function onIframeReady(item) {
            if (item && item.autoConnect) {
                item.autoConnect = false;
                updateLists();
                emitEvent(useDAppBrowserEvents/* DAppEntryEvent.maximize */.d.maximize, item.id);
            }
        }
        function syncEntryList(entryList) {
            for (const entry of entryList) {
                const index = iframeList.findIndex(item => item.id === entry.id);
                if (index < 0) {
                    !useAppMode/* isIosApp */.jv && iframeList.push(entry);
                }
                else if (entry !== iframeList[index]) {
                    iframeList.splice(index, 1, entry);
                }
            }
            for (const entry of iframeList) {
                if (!entryList.some(item => item.id === entry.id)) {
                    entry.isConnected = false;
                }
            }
            updateLists();
        }
        (0,runtime_core_esm_bundler/* watchEffect */.m0)(() => {
            syncEntryList(entryList);
        });
        const allowInit = (0,reactivity_esm_bundler/* ref */.iH)(false);
        (0,runtime_core_esm_bundler/* onMounted */.bv)(() => {
            (0,runtime_core_esm_bundler/* nextTick */.Y3)(() => {
                allowInit.value = true;
                updateLists();
            });
        });
        return {
            it,
            dappAccount,
            dappWalletData,
            handleMaximize,
            handleConnect,
            handleDisconnect,
            handleFavChanged,
            promotedList,
            featuredList,
            normalList,
            categories,
            entryList,
            isStaging: app_parameters/* isStaging */.cm,
            isIosApp: useAppMode/* isIosApp */.jv,
            onURL,
            iframeList,
            allowInit,
            onIframeReady
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/dapps/DAppBrowser.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/dapps/DAppBrowser.vue




;
const DAppBrowser_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(DAppBrowservue_type_script_lang_ts, [['render',DAppBrowservue_type_template_id_028d37dc_ts_true_render]])

/* harmony default export */ const DAppBrowser = (DAppBrowser_exports_);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/dapps/DAppsAccountList.vue?vue&type=template&id=262e92fa&ts=true

const DAppsAccountListvue_type_template_id_262e92fa_ts_true_hoisted_1 = { class: "cc-grid" };
const DAppsAccountListvue_type_template_id_262e92fa_ts_true_hoisted_2 = {
    key: 0,
    class: "cc-grid"
};
const DAppsAccountListvue_type_template_id_262e92fa_ts_true_hoisted_3 = { class: "col-span-12 grid grid-cols-12 cc-gap mb-2" };
const DAppsAccountListvue_type_template_id_262e92fa_ts_true_hoisted_4 = ["selected", "value"];
function DAppsAccountListvue_type_template_id_262e92fa_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridHeadline = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridHeadline");
    const _component_GridText = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridText");
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    const _component_GridTextArea = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridTextArea");
    const _component_DAppsAccountItem = (0,runtime_core_esm_bundler/* resolveComponent */.up)("DAppsAccountItem");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", DAppsAccountListvue_type_template_id_262e92fa_ts_true_hoisted_1, [
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
            label: _ctx.it('dapps.accountSelection.headline')
        }, null, 8, ["label"]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
            text: _ctx.it('dapps.accountSelection.caption')
        }, null, 8, ["text"]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, { hr: "" }),
        (_ctx.filteredWalletList.length > 0)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", DAppsAccountListvue_type_template_id_262e92fa_ts_true_hoisted_2, [
                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", DAppsAccountListvue_type_template_id_262e92fa_ts_true_hoisted_3, [
                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                        class: "col-span-12",
                        label: 'Select DApp Wallet'
                    }),
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("select", {
                        class: "col-span-12 sm:col-span-6 xl:col-span-4 cc-rounded-la cc-dropdown cc-text-sm",
                        required: true,
                        onChange: _cache[0] || (_cache[0] = ($event) => (_ctx.onSelectWallet($event)))
                    }, [
                        ((0,runtime_core_esm_bundler/* openBlock */.wg)(true), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, (0,runtime_core_esm_bundler/* renderList */.Ko)(_ctx.filteredWalletList, (wallet) => {
                            return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("option", {
                                key: wallet.dbEntry.id,
                                selected: wallet.dbEntry.id === _ctx.selectedWalletId,
                                value: wallet.dbEntry.id
                            }, (0,shared_esm_bundler/* toDisplayString */.zw)(wallet.dbEntry.name + ((wallet.dbEntry.id === _ctx.dappWalletId) ? ' (' + _ctx.it('dapps.accountSelection.selectedWallet') + ')' : '')), 9, DAppsAccountListvue_type_template_id_262e92fa_ts_true_hoisted_4));
                        }), 128))
                    ], 32)
                ])
            ]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (_ctx.isReadOnly)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridTextArea, {
                key: 1,
                icon: _ctx.it('wallet.summary.setDAppAccount.warning.readOnly.icon'),
                text: _ctx.it('wallet.summary.setDAppAccount.warning.readOnly.text'),
                class: "col-span-12",
                "text-c-s-s": "text-justify flex justify-start items-center",
                css: "cc-rounded cc-banner-warning"
            }, null, 8, ["icon", "text"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, { hr: "" }),
        ((0,runtime_core_esm_bundler/* openBlock */.wg)(true), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, (0,runtime_core_esm_bundler/* renderList */.Ko)(_ctx.accountList, (account) => {
            return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_DAppsAccountItem, {
                key: account.pub,
                wallet: _ctx.selectedWallet,
                account: account,
                "is-active-account": false,
                "is-dapp-account": account.pub === (_ctx.dappAccount?.pub ?? ''),
                syncing: false,
                onOnSetDAppAccount: _ctx.onSetDAppAccount
            }, null, 8, ["wallet", "account", "is-dapp-account", "onOnSetDAppAccount"]));
        }), 128))
    ]));
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/dapps/DAppsAccountList.vue?vue&type=template&id=262e92fa&ts=true

// EXTERNAL MODULE: ./src/composables/ccw/store/useWalletList.ts
var useWalletList = __webpack_require__(4905);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/dapps/DAppsAccountItem.vue?vue&type=template&id=076df036&ts=true

const DAppsAccountItemvue_type_template_id_076df036_ts_true_hoisted_1 = { class: "col-span-12 sm:col-span-6 xl:col-span-4 grid grid-cols-12 cc-gap" };
function DAppsAccountItemvue_type_template_id_076df036_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_AccountItemBalance = (0,runtime_core_esm_bundler/* resolveComponent */.up)("AccountItemBalance");
    const _component_GridButtonPrimary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonPrimary");
    const _component_GridButtonWarning = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonWarning");
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", DAppsAccountItemvue_type_template_id_076df036_ts_true_hoisted_1, [
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_AccountItemBalance, {
            account: _ctx.account,
            wallet: _ctx.wallet,
            "is-active-account": _ctx.isActiveAccount,
            "is-dapp-account": _ctx.isDappAccount,
            "is-dapp-account-list": "",
            syncing: _ctx.syncing
        }, null, 8, ["account", "wallet", "is-active-account", "is-dapp-account", "syncing"]),
        (!_ctx.isDappAccount)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridButtonPrimary, {
                key: 0,
                label: _ctx.it('wallet.summary.setDAppAccount.button.enable.label'),
                class: "col-span-12",
                link: _ctx.onSetDAppAccount
            }, null, 8, ["label", "link"]))
            : ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridButtonWarning, {
                key: 1,
                label: _ctx.it('wallet.summary.setDAppAccount.button.disable.label'),
                class: "col-span-12",
                "btn-style": "cc-text-md cc-btn-warning-yellow",
                link: _ctx.onSetDAppAccount
            }, null, 8, ["label", "link"])),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, {
            hr: "",
            class: "mt-1.5 col-span-12"
        })
    ]));
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/dapps/DAppsAccountItem.vue?vue&type=template&id=076df036&ts=true

// EXTERNAL MODULE: ./src/components/ccw/grid/v2/accounts/AccountItemBalance.vue + 4 modules
var AccountItemBalance = __webpack_require__(20285);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridButtonPrimary.vue + 3 modules
var GridButtonPrimary = __webpack_require__(12559);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridButtonWarning.vue + 3 modules
var GridButtonWarning = __webpack_require__(63691);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/dapps/DAppsAccountItem.vue?vue&type=script&lang=ts






/* harmony default export */ const DAppsAccountItemvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'DAppsAccountItem',
    emits: [
        'onSetDAppAccount'
    ],
    components: {
        GridButtonPrimary: GridButtonPrimary/* default */.Z,
        GridButtonWarning: GridButtonWarning/* default */.Z,
        GridSpace: GridSpace/* default */.Z,
        AccountItemBalance: AccountItemBalance/* default */.Z
    },
    props: {
        wallet: { type: Object, required: true },
        account: { type: Object, required: true },
        isActiveAccount: { type: Boolean, required: true },
        isDappAccount: { type: Boolean, required: true },
        syncing: { type: Boolean, required: true }
    },
    setup(props, { emit }) {
        const { it } = (0,useTranslation/* useTranslation */.$)();
        function onSetDAppAccount() {
            emit('onSetDAppAccount', props.account.pub);
        }
        return {
            it,
            onSetDAppAccount
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/dapps/DAppsAccountItem.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/dapps/DAppsAccountItem.vue




;
const DAppsAccountItem_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(DAppsAccountItemvue_type_script_lang_ts, [['render',DAppsAccountItemvue_type_template_id_076df036_ts_true_render]])

/* harmony default export */ const DAppsAccountItem = (DAppsAccountItem_exports_);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/AccountLib.ts
var AccountLib = __webpack_require__(19276);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/dapps/DAppsAccountList.vue?vue&type=script&lang=ts










/* harmony default export */ const DAppsAccountListvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'DAppsAccountList',
    emits: [
        'onSetDAppAccount'
    ],
    components: {
        DAppsAccountItem: DAppsAccountItem,
        GridHeadline: GridHeadline/* default */.Z,
        GridText: GridText/* default */.Z,
        GridTextArea: GridTextArea/* default */.Z,
        GridSpace: GridSpace/* default */.Z
    },
    setup() {
        const { it } = (0,useTranslation/* useTranslation */.$)();
        const { dappWalletData, dappWallet, dappWalletId, dappAccount, setDAppAccount, } = (0,useDAppWallet/* useDAppWallet */.I)();
        const { walletList } = (0,useWalletList/* useWalletList */.M)();
        const selectedWallet = (0,reactivity_esm_bundler/* ref */.iH)(dappWallet.value?.wallet ?? null);
        const selectedWalletId = (0,reactivity_esm_bundler/* ref */.iH)(dappWalletId.value);
        const isReadOnly = (0,runtime_core_esm_bundler/* computed */.Fl)(() => selectedWallet.value?.signType === 'readonly' ?? false);
        const accountList = (0,runtime_core_esm_bundler/* computed */.Fl)(() => selectedWallet.value?.accounts.filter(account => (0,AccountLib/* isHDAccountPath */._B)(account)) ?? []);
        const filteredWalletList = (0,runtime_core_esm_bundler/* computed */.Fl)(() => walletList.filter(item => !item.locked));
        const doSelectWallet = (walletId) => {
            if (!walletId) {
                return;
            }
            const appWallet = walletList.find(item => item.dbEntry.id === walletId);
            if (appWallet && appWallet.wallet) {
                selectedWalletId.value = walletId;
                selectedWallet.value = appWallet.wallet;
            }
            else {
                selectedWalletId.value = null;
                selectedWallet.value = null;
            }
        };
        const onSelectWallet = (event) => {
            doSelectWallet(event.target.options[event.target.options.selectedIndex].value.toLowerCase());
        };
        (0,runtime_core_esm_bundler/* watchEffect */.m0)(() => {
            const _dappWalletData = dappWalletData.value;
            if (_dappWalletData && selectedWallet.value === null && selectedWalletId.value !== _dappWalletData.id) {
                selectedWalletId.value = _dappWalletData.id;
                selectedWallet.value = _dappWalletData;
            }
        });
        const onSelectWalletIdOnInit = () => {
            if (filteredWalletList.value.length > 0) {
                const _dappWalletData = dappWalletData.value;
                if (!_dappWalletData && selectedWallet.value === null && selectedWalletId.value === null) {
                    doSelectWallet(filteredWalletList.value[0].dbEntry.id);
                }
            }
        };
        onSelectWalletIdOnInit();
        if (selectedWalletId.value === null) {
            const stopWatch = (0,runtime_core_esm_bundler/* watch */.YP)(() => filteredWalletList.value.length, (lengthNew, lengthOld) => {
                if (lengthNew > 0) {
                    onSelectWalletIdOnInit();
                    stopWatch();
                }
            });
        }
        function onSetDAppAccount(pub) {
            if (dappAccount.value?.pub === pub) {
                setDAppAccount(null, null);
            }
            else if (selectedWalletId.value) {
                setDAppAccount(selectedWalletId.value, pub);
            }
        }
        return {
            it,
            filteredWalletList,
            accountList,
            isReadOnly,
            selectedWallet,
            selectedWalletId,
            onSelectWallet,
            dappWalletId,
            dappAccount,
            onSetDAppAccount,
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/dapps/DAppsAccountList.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/dapps/DAppsAccountList.vue




;
const DAppsAccountList_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(DAppsAccountListvue_type_script_lang_ts, [['render',DAppsAccountListvue_type_template_id_262e92fa_ts_true_render]])

/* harmony default export */ const DAppsAccountList = (DAppsAccountList_exports_);
// EXTERNAL MODULE: ./src/lib/ExtBackground.ts
var ExtBackground = __webpack_require__(61953);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/DApps.vue?vue&type=script&lang=ts

;















const immediatelySyncAppWallet = ExtAppWalletManagerLib/* AWM.immediatelySyncAppWallet */.b.immediatelySyncAppWallet;
const toggleLockWallet = ExtAppWalletManagerLib/* AWM.toggleLockWallet */.b.toggleLockWallet;
/* harmony default export */ const DAppsvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'DApps',
    components: {
        Page: Page/* default */.Z,
        Balance: Balance/* default */.Z,
        TabButton: TabButton/* default */.Z,
        WalletIcon: WalletIcon/* default */.Z,
        IconButton: IconButton/* default */.Z,
        GridTabs: GridTabs/* default */.Z,
        DAppBrowser: DAppBrowser,
        DAppsAccountList: DAppsAccountList
    },
    setup() {
        const { it } = (0,useTranslation/* useTranslation */.$)();
        const { dappAccount, dappWalletId, dappWalletName, dappWalletSignType, dappWalletData, dappWalletPlate, dappWalletLastSync, isDappWalletLocked, isDappWalletSyncing, isDappWalletPreparing, getDAppAccountName } = (0,useDAppWallet/* useDAppWallet */.I)();
        const { addObserver, removeObserver } = (0,useDAppBrowserEvents/* useDAppBrowserEvents */.R)();
        const { timestamp } = (0,useTimestamp/* useTimestamp */.Z)();
        const $q = (0,use_quasar/* default */.Z)();
        (0,runtime_core_esm_bundler/* onErrorCaptured */.d1)((e) => { console.error('DApps: onErrorCaptured', e); return true; });
        const plateImagePart = (0,reactivity_esm_bundler/* ref */.iH)('');
        const plateTextPart = (0,reactivity_esm_bundler/* ref */.iH)('');
        const plateDataPart = (0,reactivity_esm_bundler/* ref */.iH)('');
        (0,runtime_core_esm_bundler/* watchEffect */.m0)(() => {
            if (dappWalletPlate.value) {
                const plate = dappWalletPlate.value;
                if (plate.image) {
                    plateImagePart.value = plate.image;
                    plateTextPart.value = plate.text;
                    plateDataPart.value = plate.data;
                }
            }
        });
        const lastSync = (0,reactivity_esm_bundler/* ref */.iH)('-');
        (0,runtime_core_esm_bundler/* watchEffect */.m0)(() => {
            if (dappWalletId.value === null) {
                lastSync.value = '-';
            }
            else {
                const ls = Math.floor(dappWalletLastSync.value > 0 ? dappWalletLastSync.value : timestamp.value);
                const seconds = Math.floor((timestamp.value - ls) / 1000) + 1;
                lastSync.value = (seconds < 10 ? '0' : '') + seconds;
                (0,ExtBackground/* removeBackground */.X1)();
            }
        });
        async function onSyncWallet() {
            if (dappWalletId.value) {
                const success = await immediatelySyncAppWallet(dappWalletId.value);
                if (!success) {
                    $q.notify('Skipped wallet sync. Please wait for a few seconds.');
                }
            }
        }
        const tabIndex = (0,reactivity_esm_bundler/* ref */.iH)(0);
        const isDappWallet = (0,runtime_core_esm_bundler/* computed */.Fl)(() => (dappWalletId.value));
        const isDappAccount = (0,runtime_core_esm_bundler/* computed */.Fl)(() => (dappAccount.value?.pub ?? null));
        const isLoading = (0,reactivity_esm_bundler/* ref */.iH)(true);
        const optionsTabs = (0,reactivity_esm_bundler/* reactive */.qj)([
            { id: 'favs', label: it('dapps.menu.favorites'), index: 0, hidden: false },
            { id: 'browser', label: it('dapps.menu.browser'), index: 1, hidden: false },
            { id: 'mint', label: it('dapps.menu.mint'), index: 2, hidden: false },
            { id: 'nmkr', label: it('dapps.menu.nmkr'), index: 3, hidden: true },
            { id: 'connect', label: it('dapps.menu.connect'), index: 4, hidden: false }
        ]);
        function handleAllCategories(allCategories) {
            optionsTabs[3].hidden = !allCategories.includes('nmkr');
        }
        function gotoAccountList() {
            tabIndex.value = 4;
        }
        let hintShown = false;
        function handleNoFavs() {
            tabIndex.value = 1;
            if (!hintShown) {
                hintShown = true;
                $q.notify({
                    type: 'warning',
                    message: it('dapps.browser.favs.nofavs'),
                    position: 'top-left'
                });
            }
        }
        function onTabChanged(index) {
            if (tabIndex.value !== index) {
                tabIndex.value = index;
            }
        }
        const onDAppEntryEvent = async (event, dappId) => {
            if (!dappAccount.value) {
                tabIndex.value = 3;
            }
        };
        (0,runtime_core_esm_bundler/* onMounted */.bv)(() => { (0,runtime_core_esm_bundler/* nextTick */.Y3)(() => { setTimeout(() => { isLoading.value = false; }, 3000); }); });
        (0,runtime_core_esm_bundler/* onMounted */.bv)(() => { (0,runtime_core_esm_bundler/* nextTick */.Y3)(() => { addObserver({ callback: onDAppEntryEvent, event: useDAppBrowserEvents/* DAppEntryEvent.maximize */.d.maximize }); }); });
        (0,runtime_core_esm_bundler/* onUnmounted */.Ah)(() => { removeObserver({ callback: onDAppEntryEvent, event: useDAppBrowserEvents/* DAppEntryEvent.maximize */.d.maximize }); });
        return {
            it,
            appMode: ExtStorageLib/* appMode */.pd,
            isActiveWalletLocked: isDappWalletLocked,
            isActiveWalletSyncing: isDappWalletSyncing,
            isActiveWalletPreparing: isDappWalletPreparing,
            activeWalletName: dappWalletName,
            activeWalletSignType: dappWalletSignType,
            activeWalletData: dappWalletData,
            activeAccount: dappAccount,
            isDappWallet,
            isDappAccount,
            getDAppAccountName,
            onErrorCaptured: runtime_core_esm_bundler/* onErrorCaptured */.d1,
            plateImagePart,
            plateTextPart,
            plateDataPart,
            lastSync,
            onSyncWallet,
            gotoAccountList,
            handleNoFavs,
            optionsTabs,
            onTabChanged,
            tabIndex,
            isLoading,
            handleAllCategories,
        };
    }
}));

;// CONCATENATED MODULE: ./src/pages/ccw/DApps.vue?vue&type=script&lang=ts
 
// EXTERNAL MODULE: ./node_modules/quasar/src/components/spinner/QSpinner.js
var QSpinner = __webpack_require__(6833);
// EXTERNAL MODULE: ./node_modules/@quasar/app/lib/webpack/runtime.auto-import.js
var runtime_auto_import = __webpack_require__(7518);
var runtime_auto_import_default = /*#__PURE__*/__webpack_require__.n(runtime_auto_import);
;// CONCATENATED MODULE: ./src/pages/ccw/DApps.vue




;
const DApps_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(DAppsvue_type_script_lang_ts, [['render',render]])

/* harmony default export */ const DApps = (DApps_exports_);
;

runtime_auto_import_default()(DAppsvue_type_script_lang_ts, 'components', {QSpinner: QSpinner/* default */.Z});


/***/ })

}]);
//# sourceMappingURL=2910.js.map