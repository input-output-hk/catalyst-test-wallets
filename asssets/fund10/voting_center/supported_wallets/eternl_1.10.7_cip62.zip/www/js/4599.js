"use strict";
(this["webpackChunkccw_frontend"] = this["webpackChunkccw_frontend"] || []).push([[4599],{

/***/ 95804:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Wallet)
});

// EXTERNAL MODULE: ./node_modules/@vue/runtime-core/dist/runtime-core.esm-bundler.js
var runtime_core_esm_bundler = __webpack_require__(83673);
// EXTERNAL MODULE: ./node_modules/@vue/runtime-dom/dist/runtime-dom.esm-bundler.js
var runtime_dom_esm_bundler = __webpack_require__(98880);
// EXTERNAL MODULE: ./node_modules/@vue/shared/dist/shared.esm-bundler.js
var shared_esm_bundler = __webpack_require__(62323);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/Wallet.vue?vue&type=template&id=d64d8a80&scoped=true&ts=true

const _withScopeId = n => ((0,runtime_core_esm_bundler/* pushScopeId */.dD)("data-v-d64d8a80"), n = n(), (0,runtime_core_esm_bundler/* popScopeId */.Cn)(), n);
const _hoisted_1 = { class: "h-16 md:h-20 w-full max-w-full flex flex-row flex-nowrap justify-center items-center border-t border-b mb-px cc-text-sx-dense cc-bg-white-0 overflow-hidden" };
const _hoisted_2 = {
    key: 0,
    class: "relative w-full h-full flex flex-row flex-nowrap justify-between items-center max-w-6xl px-1 xxs:px-3 lg:px-6 xl:px-6 space-x-2"
};
const _hoisted_3 = { class: "relative mr-2 block h-8 sm:h-10 w-8 sm:w-10" };
const _hoisted_4 = { class: "relative h-full flex-1 flex flex-col flex-nowrap justify-center items-start cc-text-semi-bold" };
const _hoisted_5 = { class: "mb-0.5" };
const _hoisted_6 = {
    key: 0,
    class: "mdi mdi-circle text-xs-dense ml-0 cc-text-green",
    style: { "line-height": "0.0rem" }
};
const _hoisted_7 = {
    key: 1,
    class: "cc-text-color-caption cc-text-xxs-dense cc-text-medium"
};
const _hoisted_8 = {
    key: 2,
    class: "cc-text-color-caption cc-text-xxs-dense cc-text-medium"
};
const _hoisted_9 = /*#__PURE__*/ _withScopeId(() => /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("i", { class: "mdi mdi-sync" }, null, -1));
const _hoisted_10 = { key: 1 };
const _hoisted_11 = { key: 0 };
const _hoisted_12 = { key: 1 };
const _hoisted_13 = { key: 2 };
const _hoisted_14 = { key: 2 };
const _hoisted_15 = { key: 3 };
const _hoisted_16 = { key: 4 };
const _hoisted_17 = { key: 5 };
const _hoisted_18 = {
    key: 6,
    class: "font-mono"
};
const _hoisted_19 = { key: 7 };
const _hoisted_20 = {
    key: 8,
    class: "font-mono"
};
const _hoisted_21 = { key: 9 };
const _hoisted_22 = /*#__PURE__*/ _withScopeId(() => /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("div", { class: "cc-none xxxs:block grow w-px" }, null, -1));
const _hoisted_23 = {
    key: 0,
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 24 24",
    class: "cc-fill-green w-full h-full"
};
const _hoisted_24 = /*#__PURE__*/ _withScopeId(() => /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("path", { d: "M 20.59375 2 L 17.09375 5.5 L 15.1875 3.59375 C 14.3875 2.79375 13.20625 2.79375 12.40625 3.59375 L 9.90625 6.09375\r\n  L 8.90625 5.09375 L 7.5 6.5 L 17.5 16.5 L 18.90625 15.09375 L 17.90625 14.09375\r\n  L 20.40625 11.59375 C 21.20625 10.79375 21.20625 9.6125 20.40625 8.8125 L 18.5 6.90625\r\n  L 22 3.40625 L 20.59375 2 z M 6.40625 7.59375 L 5 9 L 6 10 L 3.59375 12.40625 C 2.79375 13.20625 2.79375 14.3875 3.59375 15.1875\r\n  L 5.5 17.09375 L 2 20.59375 L 3.40625 22 L 6.90625 18.5 L 8.8125 20.40625 C 9.6125 21.20625 10.79375 21.20625 11.59375 20.40625\r\n  L 14 18 L 15 19 L 16.40625 17.59375 L 6.40625 7.59375 z" }, null, -1));
const _hoisted_25 = [
    _hoisted_24
];
const _hoisted_26 = {
    key: 1,
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 24 24",
    class: "cc-fill w-full h-full"
};
const _hoisted_27 = /*#__PURE__*/ _withScopeId(() => /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("path", { d: "M 14.8125 2 C 14.3125 2 13.80625 2.19375 13.40625 2.59375 L 11.90625 4.09375 L 10.90625 3.09375 L 9.5 4.5\r\n  L 11.8125 6.8125 L 9.1875 9.40625 L 10.59375 10.8125 L 13.1875 8.1875 L 15.8125 10.8125 L 13.1875 13.40625\r\n  L 14.59375 14.8125 L 17.1875 12.1875 L 19.5 14.5 L 20.90625 13.09375 L 19.90625 12.09375 L 21.40625 10.59375\r\n  C 22.20625 9.79375 22.20625 8.6125 21.40625 7.8125 L 19.5 5.90625 L 22 3.40625 L 20.59375 2 L 18.09375 4.5\r\n  L 16.1875 2.59375 C 15.7875 2.19375 15.3125 2 14.8125 2 z M 4.40625 9.59375 L 3 11 L 4 12 L 2.59375 13.40625\r\n  C 1.79375 14.20625 1.79375 15.3875 2.59375 16.1875 L 4.5 18.09375 L 2 20.59375 L 3.40625 22 L 5.90625 19.5\r\n  L 7.8125 21.40625 C 8.6125 22.20625 9.79375 22.20625 10.59375 21.40625 L 12 20 L 13 21 L 14.40625 19.59375 L 4.40625 9.59375 z" }, null, -1));
const _hoisted_28 = [
    _hoisted_27
];
const _hoisted_29 = { class: "relative h-full flex-1 flex flex-col flex-nowrap justify-center items-end cc-text-semi-bold" };
const _hoisted_30 = { class: "mb-0.5" };
const _hoisted_31 = {
    key: 0,
    class: "mdi mdi-circle text-xs-dense mr-0.5 cc-text-green",
    style: { "line-height": "0.0rem" }
};
const _hoisted_32 = /*#__PURE__*/ _withScopeId(() => /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("div", { class: "flex flex-col space-y-1 justify-center items-center font-bold" }, [
    /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("span", null, "Buy"),
    /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("span", null, "ADA")
], -1));
const _hoisted_33 = [
    _hoisted_32
];
const _hoisted_34 = {
    key: 1,
    class: "w-full h-full flex flex-row flex-nowrap justify-center xs:justify-between items-center max-w-6xl pl-3 sm:pl-4 lg:pl-6 pr-3 sm:pr-2 lg:pr-4"
};
const _hoisted_35 = /*#__PURE__*/ _withScopeId(() => /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("div", { class: "flex-none inline-flex h-14 flex-row flex-nowrap justify-center items-center ml-10 xs:ml-0" }, [
    /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("span", null, " ")
], -1));
const _hoisted_36 = [
    _hoisted_35
];
const _hoisted_37 = {
    key: 0,
    class: "w-full max-w-full flex flex-col flex-nowrap justify-center items-center border-t border-b cc-menu-group"
};
const _hoisted_38 = {
    class: "relative overflow-x-auto overflow-hidden w-full flex flex-row flex-nowrap items-start justify-center px-2.5 space-x-1.5 xxs:space-x-1 sm:space-x-0 md:space-x-1",
    "aria-label": "Tabs"
};
const _hoisted_39 = {
    key: 2,
    class: "col-span-12 pt-18 sm:pt-36 relative flex-1 flex justify-center items-center"
};
const _hoisted_40 = {
    key: 0,
    class: "flex flex-col flex-nowrap justify-center items-center"
};
const _hoisted_41 = {
    key: 1,
    class: "flex flex-col flex-nowrap justify-center items-center"
};
const _hoisted_42 = /*#__PURE__*/ _withScopeId(() => /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("i", { class: "mdi mdi-lock-outline text-6xl sm:text-9xl" }, null, -1));
const _hoisted_43 = /*#__PURE__*/ _withScopeId(() => /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("span", { class: "text-lg sm:text-2xl" }, "Wallet is locked", -1));
const _hoisted_44 = [
    _hoisted_42,
    _hoisted_43
];
function render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_WalletIcon = (0,runtime_core_esm_bundler/* resolveComponent */.up)("WalletIcon");
    const _component_Balance = (0,runtime_core_esm_bundler/* resolveComponent */.up)("Balance");
    const _component_Tooltip = (0,runtime_core_esm_bundler/* resolveComponent */.up)("Tooltip");
    const _component_TabButton = (0,runtime_core_esm_bundler/* resolveComponent */.up)("TabButton");
    const _component_router_view = (0,runtime_core_esm_bundler/* resolveComponent */.up)("router-view");
    const _component_q_spinner_dots = (0,runtime_core_esm_bundler/* resolveComponent */.up)("q-spinner-dots");
    const _component_Page = (0,runtime_core_esm_bundler/* resolveComponent */.up)("Page");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_Page, {
        containerCSS: '',
        "align-top": "",
        "add-scroll": true
    }, {
        header: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_1, [
                (_ctx.activeWalletName)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_2, [
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", {
                            class: "flex-none flex w-auto min-w-48 sm:min-w-60 h-12 sm:h-14 flex-row flex-nowrap justify-start items-start cc-area-light-1 px-2 py-2 cursor-pointer cc-btn-tertiary-light",
                            onClick: _cache[0] || (_cache[0] = (0,runtime_dom_esm_bundler/* withModifiers */.iM)(
                            //@ts-ignore
                            (...args) => (_ctx.gotoAccountList && _ctx.gotoAccountList(...args)), ["stop", "prevent"]))
                        }, [
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_3, [
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_WalletIcon, {
                                    "icon-seed": _ctx.plateImagePart,
                                    "icon-data": _ctx.plateDataPart
                                }, null, 8, ["icon-seed", "icon-data"])
                            ]),
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_4, [
                                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_5, [
                                    (0,runtime_core_esm_bundler/* createElementVNode */._)("span", null, [
                                        (0,runtime_core_esm_bundler/* createTextVNode */.Uk)((0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.activeWalletName + ' '), 1),
                                        (_ctx.isDappWallet)
                                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("i", _hoisted_6))
                                            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                                    ]),
                                    (_ctx.activeWalletSignType === 'readonly')
                                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("i", {
                                            key: 0,
                                            class: (0,shared_esm_bundler/* normalizeClass */.C_)(["mdi mdi-cash-lock mt-px text-md cc-text-highlight", _ctx.isDappWallet ? 'ml-1' : '']),
                                            style: { "line-height": "0.1rem" }
                                        }, null, 2))
                                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                                ]),
                                (_ctx.activeWalletData)
                                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_Balance, {
                                        key: 0,
                                        balance: _ctx.activeWalletData?.balance,
                                        syncing: _ctx.isActiveWalletSyncing,
                                        preparing: _ctx.isActiveWalletPreparing,
                                        onOnClickedSync: _ctx.onSyncWallet,
                                        "hide-currency": ""
                                    }, null, 8, ["balance", "syncing", "preparing", "onOnClickedSync"]))
                                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                                (_ctx.isActiveWalletLocked)
                                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("span", _hoisted_7, "(locked)"))
                                    : ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("span", _hoisted_8, [
                                        (_ctx.activeWalletEnabledManualSync)
                                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_Tooltip, {
                                                key: 0,
                                                anchor: "bottom middle",
                                                "transition-show": "scale",
                                                "transition-hide": "scale"
                                            }, {
                                                default: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                                                    (0,runtime_core_esm_bundler/* createTextVNode */.Uk)((0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('wallet.manualsync.info')) + " ", 1),
                                                    _hoisted_9,
                                                    (0,runtime_core_esm_bundler/* createTextVNode */.Uk)(". ")
                                                ]),
                                                _: 1
                                            }))
                                            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                                        (_ctx.activeWalletEnabledManualSync)
                                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("span", _hoisted_10, [
                                                (0,runtime_core_esm_bundler/* createTextVNode */.Uk)("Manual, "),
                                                (_ctx.isActiveWalletSyncing)
                                                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("span", _hoisted_11, " syncing for"))
                                                    : (!(_ctx.lastSync1 || _ctx.lastSync2) && _ctx.activeWalletEnabledManualSync)
                                                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("span", _hoisted_12, " not synced yet"))
                                                        : ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("span", _hoisted_13, " synced"))
                                            ]))
                                            : (_ctx.isActiveWalletPreparing)
                                                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("span", _hoisted_14, "Initializing for"))
                                                : (_ctx.isActiveWalletSyncing)
                                                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("span", _hoisted_15, "Syncing for"))
                                                    : ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("span", _hoisted_16, "Synced")),
                                        (_ctx.lastSync1)
                                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("span", _hoisted_17, " "))
                                            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                                        (_ctx.lastSync1)
                                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("span", _hoisted_18, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.lastSync1), 1))
                                            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                                        (_ctx.lastSync2)
                                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("span", _hoisted_19, " "))
                                            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                                        (_ctx.lastSync2)
                                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("span", _hoisted_20, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.lastSync2), 1))
                                            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                                        ((_ctx.lastSync1 || _ctx.lastSync2) && !_ctx.isActiveWalletSyncing)
                                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("span", _hoisted_21, " ago"))
                                            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                                    ]))
                            ])
                        ]),
                        _hoisted_22,
                        (_ctx.activeAccount && _ctx.isAppModeNormal() && !_ctx.isIosApp)
                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", {
                                key: 0,
                                class: "flex-none flex w-12 sm:w-14 h-12 sm:h-14 flex-row flex-nowrap justify-center items-center cc-area-light-1 px-3 py-3 sm:px-4 sm:py-4 cursor-pointer cc-btn-tertiary-light",
                                onClick: _cache[1] || (_cache[1] = (0,runtime_dom_esm_bundler/* withModifiers */.iM)(
                                //@ts-ignore
                                (...args) => (_ctx.onSetDAppAccount && _ctx.onSetDAppAccount(...args)), ["stop", "prevent"]))
                            }, [
                                (_ctx.isDappAccount)
                                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("svg", _hoisted_23, _hoisted_25))
                                    : ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("svg", _hoisted_26, _hoisted_28))
                            ]))
                            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                        (_ctx.activeAccount)
                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", {
                                key: 1,
                                class: "flex-none cc-none xs:flex w-auto h-12 sm:h-14 flex-row flex-nowrap justify-start items-start cc-area-light-1 px-2 py-2 cursor-pointer cc-btn-tertiary-light",
                                onClick: _cache[2] || (_cache[2] = (0,runtime_dom_esm_bundler/* withModifiers */.iM)(
                                //@ts-ignore
                                (...args) => (_ctx.gotoAccountList && _ctx.gotoAccountList(...args)), ["stop", "prevent"]))
                            }, [
                                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_29, [
                                    (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_30, [
                                        (_ctx.isDappAccount)
                                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("i", _hoisted_31))
                                            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                                        (0,runtime_core_esm_bundler/* createTextVNode */.Uk)((0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.getAccountName(_ctx.activeAccount?.pub)), 1)
                                    ]),
                                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_Balance, {
                                        balance: _ctx.activeAccount?.balance,
                                        syncing: _ctx.isActiveWalletSyncing,
                                        preparing: _ctx.isActiveWalletPreparing,
                                        onOnClickedSync: _ctx.onSyncWallet,
                                        "icons-left": "",
                                        "hide-sync-button": ""
                                    }, null, 8, ["balance", "syncing", "preparing", "onOnClickedSync"])
                                ])
                            ]))
                            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                        (_ctx.networkId === 'mainnet' && _ctx.activeAccount && _ctx.isAppModeNormal() && !_ctx.isIosApp)
                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", {
                                key: 2,
                                class: "cc-none xxxs:flex flex-none w-12 sm:w-14 h-12 sm:h-14 flex-row flex-nowrap justify-center items-center cc-area-light-1 px-3 py-3 sm:px-4 sm:py-4 cursor-pointer cc-btn-tertiary-light",
                                onClick: _cache[3] || (_cache[3] = (0,runtime_dom_esm_bundler/* withModifiers */.iM)(
                                //@ts-ignore
                                (...args) => (_ctx.onOpenWidgetGuardarian && _ctx.onOpenWidgetGuardarian(...args)), ["stop", "prevent"]))
                            }, _hoisted_33))
                            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                    ]))
                    : ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_34, _hoisted_36))
            ]),
            (_ctx.appMode !== 'sign')
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_37, [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("nav", _hoisted_38, [
                        ((0,runtime_core_esm_bundler/* openBlock */.wg)(true), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, (0,runtime_core_esm_bundler/* renderList */.Ko)(_ctx.options, (item, index) => {
                            return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_TabButton, {
                                key: index,
                                label: item.label,
                                "label-short": item.labelShort,
                                "label-c-s-s": item.labelCSS,
                                icon: item.icon,
                                "icon-c-s-s": 'text-xl ' + item.iconCSS ?? '',
                                "border-c-s-s": item.borderCSS ?? '',
                                "border-active-c-s-s": item.borderActiveCSS ?? '',
                                link: null,
                                active: item.link === _ctx.selectedPage,
                                onClicked: ($event) => (_ctx.switchSelected(item.link))
                            }, null, 8, ["label", "label-short", "label-c-s-s", "icon", "icon-c-s-s", "border-c-s-s", "border-active-c-s-s", "active", "onClicked"]));
                        }), 128))
                    ])
                ]))
                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
        ]),
        content: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
            (!_ctx.isActiveWalletLocked && _ctx.activeWalletData && _ctx.activeWalletData?.accounts.length > 0)
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_router_view, { key: 0 }))
                : ((_ctx.isActiveWalletLocked && _ctx.activeWalletData) || (_ctx.isActiveWalletLocked && (_ctx.selectedPage === 'WalletSettings' || _ctx.selectedPage === 'WalletVerification')))
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_router_view, { key: 1 }))
                    : ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_39, [
                        (!_ctx.activeWalletId)
                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_40, [
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_q_spinner_dots, {
                                    color: "gray",
                                    size: "3em"
                                })
                            ]))
                            : (_ctx.isActiveWalletLocked)
                                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_41, _hoisted_44))
                                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                    ]))
        ]),
        _: 1
    }));
}

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/Wallet.vue?vue&type=template&id=d64d8a80&scoped=true&ts=true

// EXTERNAL MODULE: ./node_modules/@vue/reactivity/dist/reactivity.esm-bundler.js
var reactivity_esm_bundler = __webpack_require__(61959);
// EXTERNAL MODULE: ./node_modules/vue-router/dist/vue-router.mjs
var vue_router = __webpack_require__(28339);
// EXTERNAL MODULE: ./node_modules/quasar/src/composables/use-quasar.js
var use_quasar = __webpack_require__(48825);
// EXTERNAL MODULE: ./src/composables/ccw/useNetworkId.ts
var useNetworkId = __webpack_require__(36648);
// EXTERNAL MODULE: ./src/composables/ccw/useTranslation.ts
var useTranslation = __webpack_require__(19376);
// EXTERNAL MODULE: ./src/composables/ccw/useTimestamp.ts
var useTimestamp = __webpack_require__(53199);
// EXTERNAL MODULE: ./src/composables/ccw/useNavigation.ts
var useNavigation = __webpack_require__(52439);
// EXTERNAL MODULE: ./src/composables/ccw/store/useActiveWallet.ts
var useActiveWallet = __webpack_require__(52144);
// EXTERNAL MODULE: ./src/composables/ccw/store/useWalletList.ts
var useWalletList = __webpack_require__(4905);
// EXTERNAL MODULE: ./src/composables/ccw/store/useDAppWallet.ts
var useDAppWallet = __webpack_require__(35053);
// EXTERNAL MODULE: ./src/composables/ccw/state/useMainMenuOpen.ts
var useMainMenuOpen = __webpack_require__(33008);
// EXTERNAL MODULE: ./src/composables/ccw/store/useSwapLib.ts
var useSwapLib = __webpack_require__(22653);
// EXTERNAL MODULE: ./src/components/ccw/Page.vue + 21 modules
var Page = __webpack_require__(53707);
// EXTERNAL MODULE: ./src/components/ccw/wallet/WalletIcon.vue + 5 modules
var WalletIcon = __webpack_require__(46333);
// EXTERNAL MODULE: ./src/components/ccw/common/Balance.vue + 4 modules
var Balance = __webpack_require__(17664);
// EXTERNAL MODULE: ./src/components/ccw/common/TabButton.vue + 4 modules
var TabButton = __webpack_require__(72750);
// EXTERNAL MODULE: ./src/components/ccw/common/IconButton.vue + 3 modules
var IconButton = __webpack_require__(45995);
// EXTERNAL MODULE: ./src/components/ccw/common/Tooltip.vue + 3 modules
var Tooltip = __webpack_require__(30105);
// EXTERNAL MODULE: ./src/lib/ExtStorageLib.ts + 1 modules
var ExtStorageLib = __webpack_require__(40736);
// EXTERNAL MODULE: ./src/lib/utils/useAppMode.ts
var useAppMode = __webpack_require__(4254);
// EXTERNAL MODULE: ./src/lib/ExtAppWalletManagerLib.ts
var ExtAppWalletManagerLib = __webpack_require__(12736);
// EXTERNAL MODULE: ./src/lib/ExtBackground.ts
var ExtBackground = __webpack_require__(61953);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/Wallet.vue?vue&type=script&lang=ts


;



















const immediatelySyncAppWallet = ExtAppWalletManagerLib/* AWM.immediatelySyncAppWallet */.b.immediatelySyncAppWallet;
const toggleLockWallet = ExtAppWalletManagerLib/* AWM.toggleLockWallet */.b.toggleLockWallet;
/* harmony default export */ const Walletvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'Wallet',
    components: {
        Page: Page/* default */.Z,
        Balance: Balance/* default */.Z,
        TabButton: TabButton/* default */.Z,
        WalletIcon: WalletIcon/* default */.Z,
        IconButton: IconButton/* default */.Z,
        Tooltip: Tooltip/* default */.Z
    },
    setup() {
        const route = (0,vue_router/* useRoute */.yj)();
        const { networkId, isCustomNetwork } = (0,useNetworkId/* useNetworkId */.h)();
        const { gotoWalletPage } = (0,useNavigation/* useNavigation */.HJ)();
        const { it } = (0,useTranslation/* useTranslation */.$)();
        const { openMainMenu } = (0,useMainMenuOpen/* useMainMenuOpen */.T)();
        const { swapRouteList } = (0,useSwapLib/* useSwapLib */.a)();
        const { isActiveWalletLocked, isActiveWalletSyncing, isActiveWalletPreparing, activeWalletId, activeWalletName, activeWalletLastSync, activeWalletSignType, activeWalletEnabledManualSync, activeWalletPlate, activeWalletBackground, activeWalletData, activeAccount } = (0,useActiveWallet/* useActiveWallet */.r)();
        const { getAccountName } = (0,useWalletList/* useWalletList */.M)();
        const { dappWalletId, dappAccount, setDAppAccount } = (0,useDAppWallet/* useDAppWallet */.I)();
        const { timestamp } = (0,useTimestamp/* useTimestamp */.Z)();
        const $q = (0,use_quasar/* default */.Z)();
        const options = (0,reactivity_esm_bundler/* ref */.iH)([]);
        let isSwapEnabled = swapRouteList.value.length > 0;
        function createMenu(locked) {
            let menuOptions = [
                {
                    position: 1,
                    label: it('menu.wallet.account.label'),
                    labelShort: it('menu.wallet.account.labelShort'),
                    icon: it('menu.wallet.account.icon'),
                    link: 'Summary',
                    selected: true
                },
                {
                    position: 2,
                    label: it('menu.wallet.transactions.label'),
                    labelShort: it('menu.wallet.transactions.labelShort'),
                    icon: it('menu.wallet.transactions.icon'),
                    link: 'Transactions',
                    selected: false
                },
                {
                    position: 3,
                    label: it('menu.wallet.send.label'),
                    labelShort: it('menu.wallet.send.labelShort'),
                    icon: it('menu.wallet.send.icon'),
                    link: 'Send',
                    selected: false
                },
                {
                    position: 5,
                    label: it('menu.wallet.receive.label'),
                    labelShort: it('menu.wallet.receive.labelShort'),
                    icon: it('menu.wallet.receive.icon'),
                    link: 'Receive',
                    selected: false
                },
                {
                    position: 6,
                    label: it('menu.wallet.staking.label'),
                    labelShort: it('menu.wallet.staking.labelShort'),
                    icon: it('menu.wallet.staking.icon'),
                    link: 'Staking',
                    selected: false
                }
            ];
            if (!isCustomNetwork.value) {
                if ($q.screen.gt.xs) {
                    // menuOptions.push(
                    //   {
                    //     position:           7,
                    //     label:              it('menu.wallet.stakingvault.label'),
                    //     labelShort:         it('menu.wallet.stakingvault.labelShort'),
                    //     labelCSS:           'cc-text-purple-light',
                    //     icon:               it('menu.wallet.stakingvault.icon'),
                    //     iconCSS:            'cc-text-purple-light',
                    //     borderCSS:          'cc-menu-button-sv',
                    //     borderActiveCSS:    'cc-menu-button-sv-active',
                    //     link:               'StakingVault',
                    //     selected:           false
                    //   }
                    // )
                }
                menuOptions.push({
                    position: 8,
                    label: it('menu.wallet.voting.label'),
                    labelShort: it('menu.wallet.voting.labelShort'),
                    icon: it('menu.wallet.voting.icon'),
                    link: 'Voting',
                    selected: false
                });
                if (isSwapEnabled) {
                    menuOptions.push({
                        position: 4,
                        label: it('menu.wallet.swap.label'),
                        labelShort: it('menu.wallet.swap.labelShort'),
                        icon: it('menu.wallet.swap.icon'),
                        link: 'Swap',
                        selected: false
                    });
                }
            }
            // Add settings as last item
            menuOptions.push({
                position: 99,
                label: it('menu.wallet.settings.label'),
                labelShort: it('menu.wallet.settings.labelShort'),
                icon: it('menu.wallet.settings.icon'),
                link: 'WalletSettings',
                selected: false
            });
            const menuOptionsLocked = [
                {
                    position: 99,
                    label: it('menu.wallet.settings.label'),
                    labelShort: it('menu.wallet.settings.labelShort'),
                    icon: it('menu.wallet.settings.icon'),
                    link: 'WalletSettings',
                    selected: false
                }
            ];
            if (locked) {
                options.value.push(...menuOptionsLocked);
            }
            else {
                options.value.push(...menuOptions.sort((a, b) => a.position - b.position));
            }
        }
        (0,runtime_core_esm_bundler/* watchEffect */.m0)(() => {
            if (networkId.value) {
                options.value.splice(0);
                isSwapEnabled = swapRouteList.value.length > 0;
                if (activeWalletId.value) {
                    createMenu(isActiveWalletLocked.value);
                }
            }
        });
        const selectedPage = (0,reactivity_esm_bundler/* ref */.iH)(null);
        (0,runtime_core_esm_bundler/* watchEffect */.m0)(() => {
            selectedPage.value = route.name?.toString() ?? '';
            if (isActiveWalletLocked.value) {
                // gotoWalletPage('WalletSettings')
            }
        });
        function switchSelected(value) { if (activeWalletId.value) {
            gotoWalletPage(value);
        } }
        (0,runtime_core_esm_bundler/* watch */.YP)(selectedPage, (newPage, oldPage) => { if (route.name !== newPage) {
            switchSelected(newPage);
        } });
        (0,runtime_core_esm_bundler/* onErrorCaptured */.d1)((e) => { console.error('Wallet: onErrorCaptured', e); return true; });
        const plateImagePart = (0,reactivity_esm_bundler/* ref */.iH)('');
        // const plateTextPart:  Ref<string> = ref('')
        const plateDataPart = (0,reactivity_esm_bundler/* ref */.iH)('');
        (0,runtime_core_esm_bundler/* watchEffect */.m0)(() => {
            if (activeWalletPlate.value) {
                const plate = activeWalletPlate.value;
                if (plate.image) {
                    plateImagePart.value = plate.image;
                    // plateTextPart.value   = plate.text
                    plateDataPart.value = plate.data;
                }
            }
        });
        const lastSync1 = (0,reactivity_esm_bundler/* ref */.iH)('');
        const lastSync2 = (0,reactivity_esm_bundler/* ref */.iH)('');
        const lastWalledId = (0,reactivity_esm_bundler/* ref */.iH)(null);
        (0,runtime_core_esm_bundler/* watchEffect */.m0)(() => {
            if (activeWalletId.value === null) {
                lastSync1.value = '';
                lastSync2.value = '';
            }
            else {
                lastWalledId.value = activeWalletId.value;
                let ls = activeWalletLastSync.value;
                if (activeWalletLastSync.value <= 0 && activeWalletEnabledManualSync.value) {
                    lastSync1.value = '';
                    lastSync2.value = '';
                    return;
                }
                ls = Math.floor(activeWalletLastSync.value > 0 ? activeWalletLastSync.value : timestamp.value);
                let totalSeconds = Math.floor((timestamp.value - ls) / 1000) + 1;
                let _seconds = totalSeconds % 60;
                let _minutes = Math.floor(totalSeconds / 60) % 60;
                let _hours = Math.floor(totalSeconds / 3600) % 24;
                let _days = Math.floor(totalSeconds / 86400);
                if (totalSeconds < 60) {
                    lastSync1.value = '';
                    lastSync2.value = _seconds + 's';
                }
                else if (totalSeconds < 3600) {
                    lastSync1.value = _minutes + 'm';
                    lastSync2.value = _seconds + 's';
                }
                else if (totalSeconds < 86400) {
                    lastSync1.value = _hours + 'h';
                    lastSync2.value = _minutes + 'm';
                }
                else {
                    lastSync1.value = _days + 'd';
                    lastSync2.value = _hours + 'h';
                }
                const network = networkId.value;
                if (network && lastWalledId.value !== activeWalletId.value) {
                    (0,ExtBackground/* removeBackground */.X1)();
                    (0,ExtBackground/* setWalletBackground */.li)(network, activeWalletBackground.value);
                }
            }
        });
        async function onSyncWallet() {
            if (activeWalletId.value) {
                const success = await immediatelySyncAppWallet(activeWalletId.value, true);
                if (!success) {
                    $q.notify('Skipped wallet sync. Please wait for a few seconds.');
                }
            }
        }
        function gotoAccountList() {
            if (ExtStorageLib/* appMode.value */.pd.value === 'sign') {
                // do nothing
            }
            else {
                gotoWalletPage('Summary', 'accounts');
            }
        }
        const isDappWallet = (0,runtime_core_esm_bundler/* computed */.Fl)(() => (dappWalletId.value && (dappWalletId.value === activeWalletId.value)));
        const isDappAccount = (0,runtime_core_esm_bundler/* computed */.Fl)(() => (dappAccount.value?.pub ?? null) === activeAccount.value?.pub);
        function onSetDAppAccount() {
            const pub = activeAccount.value?.pub;
            if (dappAccount.value?.pub === pub) {
                setDAppAccount(null, null);
            }
            else if (activeWalletId.value && pub) {
                setDAppAccount(activeWalletId.value, pub);
            }
        }
        function onOpenWidgetGuardarian() {
            const url = 'https://guardarian.com/calculator/v1?' +
                'partner_api_token=8ad2d888-3f72-4328-8c5d-dd62865f23be&' +
                'theme=dark&type=narrow&' +
                'default_crypto_currency=ADA&' +
                'crypto_currencies_list=%5B%7B%22ticker%22%3A%22ADA%22%2C%22network%22%3A%22ADA%22%7D%5D';
            window.open(url, undefined, 'noopener,noreferrer');
            gotoWalletPage('Receive');
        }
        return {
            it,
            networkId,
            appMode: ExtStorageLib/* appMode */.pd,
            isActiveWalletLocked,
            isActiveWalletSyncing,
            isActiveWalletPreparing,
            activeWalletId,
            activeWalletName,
            activeWalletSignType,
            activeWalletData,
            getAccountName,
            activeWalletEnabledManualSync,
            activeAccount,
            isDappWallet,
            isDappAccount,
            options,
            selectedPage,
            switchSelected,
            onErrorCaptured: runtime_core_esm_bundler/* onErrorCaptured */.d1,
            plateImagePart,
            // plateTextPart,
            plateDataPart,
            lastSync1,
            lastSync2,
            onSyncWallet,
            gotoWalletPage,
            gotoAccountList,
            onSetDAppAccount,
            onOpenWidgetGuardarian,
            openMainMenu,
            isAppModeNormal: ExtStorageLib/* isAppModeNormal */.Rz,
            isIosApp: useAppMode/* isIosApp */.jv
        };
    }
}));

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/Wallet.vue?vue&type=script&lang=ts
 
// EXTERNAL MODULE: ./node_modules/vue-loader/dist/exportHelper.js
var exportHelper = __webpack_require__(74260);
// EXTERNAL MODULE: ./node_modules/quasar/src/components/spinner/QSpinnerDots.js
var QSpinnerDots = __webpack_require__(34765);
// EXTERNAL MODULE: ./node_modules/@quasar/app/lib/webpack/runtime.auto-import.js
var runtime_auto_import = __webpack_require__(7518);
var runtime_auto_import_default = /*#__PURE__*/__webpack_require__.n(runtime_auto_import);
;// CONCATENATED MODULE: ./src/pages/ccw/wallet/Wallet.vue




;


const __exports__ = /*#__PURE__*/(0,exportHelper/* default */.Z)(Walletvue_type_script_lang_ts, [['render',render],['__scopeId',"data-v-d64d8a80"]])

/* harmony default export */ const Wallet = (__exports__);
;

runtime_auto_import_default()(Walletvue_type_script_lang_ts, 'components', {QSpinnerDots: QSpinnerDots/* default */.Z});


/***/ })

}]);
//# sourceMappingURL=4599.js.map