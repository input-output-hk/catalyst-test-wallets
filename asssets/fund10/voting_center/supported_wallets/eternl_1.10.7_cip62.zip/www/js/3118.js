"use strict";
(this["webpackChunkccw_frontend"] = this["webpackChunkccw_frontend"] || []).push([[3118],{

/***/ 43118:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "_copyToClipboard": () => (/* binding */ _copyToClipboard)
/* harmony export */ });
const _copyToClipboard = async (textToCopy) => {
    try {
        await navigator.clipboard.writeText(textToCopy);
        return true;
    }
    catch (e) {
        console.error(e);
        throw e;
    }
};


/***/ })

}]);
//# sourceMappingURL=3118.js.map