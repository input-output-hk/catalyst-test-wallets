"use strict";
(this["webpackChunkccw_frontend"] = this["webpackChunkccw_frontend"] || []).push([[900],{

/***/ 73265:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Settings)
});

// EXTERNAL MODULE: ./node_modules/@vue/runtime-core/dist/runtime-core.esm-bundler.js
var runtime_core_esm_bundler = __webpack_require__(83673);
// EXTERNAL MODULE: ./node_modules/@vue/shared/dist/shared.esm-bundler.js
var shared_esm_bundler = __webpack_require__(62323);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/Settings.vue?vue&type=template&id=6b75aa3b&ts=true

const _hoisted_1 = {
    key: 0,
    class: "cc-page-wallet cc-text-sz dark:text-cc-gray"
};
const _hoisted_2 = {
    key: 0,
    class: "col-span-12 flex flex-col flex-nowrap justify-center items-center"
};
const _hoisted_3 = { class: "flex flex-row flex-nowrap items-center" };
const _hoisted_4 = { class: "col-span-12 grid grid-cols-12 cc-gap" };
const _hoisted_5 = { class: "col-span-12 grid grid-cols-12 cc-gap-lg lg:ml-6" };
const _hoisted_6 = { class: "col-span-12 grid grid-cols-12 cc-gap-lg lg:ml-6" };
const _hoisted_7 = { class: "col-span-12 grid grid-cols-12 cc-gap-lg lg:ml-6 bg-cc-dark" };
const _hoisted_8 = { class: "col-span-12 grid grid-cols-12 cc-gap-lg ml-6" };
const _hoisted_9 = { class: "col-span-12 grid grid-cols-12 cc-gap-lg ml-6" };
const _hoisted_10 = { class: "col-span-12 grid grid-cols-12 cc-gap-lg lg:ml-6" };
const _hoisted_11 = { class: "col-span-12 lg:ml-6 p-2 grid grid-cols-12 cc-gap cc-rounded cc-ring-red mb-2" };
const _hoisted_12 = { class: "col-span-12 flex flex-row flex-nowrap justify-center items-center whitespace-pre-wrap cc-text-bold cc-text-red-light" };
const _hoisted_13 = { class: "col-span-12 grid grid-cols-12 cc-gap" };
function render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_IconWarning = (0,runtime_core_esm_bundler/* resolveComponent */.up)("IconWarning");
    const _component_GridText = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridText");
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    const _component_UnlockWallet = (0,runtime_core_esm_bundler/* resolveComponent */.up)("UnlockWallet");
    const _component_GridHeadline = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridHeadline");
    const _component_GridFormWalletName = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridFormWalletName");
    const _component_GridFormPasswordReset = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridFormPasswordReset");
    const _component_SettingsItem = (0,runtime_core_esm_bundler/* resolveComponent */.up)("SettingsItem");
    const _component_GridFormLockPasswordSetting = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridFormLockPasswordSetting");
    const _component_GridFormWalletIcon = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridFormWalletIcon");
    const _component_GridFormWalletBackground = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridFormWalletBackground");
    const _component_AddressBook = (0,runtime_core_esm_bundler/* resolveComponent */.up)("AddressBook");
    const _component_Collateral = (0,runtime_core_esm_bundler/* resolveComponent */.up)("Collateral");
    const _component_ExportWalletJson = (0,runtime_core_esm_bundler/* resolveComponent */.up)("ExportWalletJson");
    const _component_ExportAccountPubKey = (0,runtime_core_esm_bundler/* resolveComponent */.up)("ExportAccountPubKey");
    const _component_ExportCSV = (0,runtime_core_esm_bundler/* resolveComponent */.up)("ExportCSV");
    const _component_ChangeAddress = (0,runtime_core_esm_bundler/* resolveComponent */.up)("ChangeAddress");
    const _component_TokenFragmentation = (0,runtime_core_esm_bundler/* resolveComponent */.up)("TokenFragmentation");
    const _component_ForceWalletResync = (0,runtime_core_esm_bundler/* resolveComponent */.up)("ForceWalletResync");
    const _component_GridButtonSecondary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonSecondary");
    const _component_DeleteWallet = (0,runtime_core_esm_bundler/* resolveComponent */.up)("DeleteWallet");
    const _component_DeregisterWallet = (0,runtime_core_esm_bundler/* resolveComponent */.up)("DeregisterWallet");
    return (!_ctx.reloading)
        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_1, [
            (_ctx.isLocked)
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_2, [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_3, [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_IconWarning, { class: "w-7 flex-none mr-2" }),
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                            text: _ctx.t('wallet.settings.message.unlock'),
                            class: "cc-text-sz"
                        }, null, 8, ["text"])
                    ]),
                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, { hr: "" }),
                    (_ctx.isLocked)
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_UnlockWallet, { key: 0 }))
                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                ]))
                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_4, [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                    label: _ctx.t('wallet.settings.headline')
                }, null, 8, ["label"]),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                    text: _ctx.t('wallet.settings.caption')
                }, null, 8, ["text"]),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, { hr: "" }),
                (!_ctx.isLocked)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_SettingsItem, {
                        key: 0,
                        label: _ctx.t('wallet.settings.nameAndPassword.label'),
                        caption: _ctx.t('wallet.settings.nameAndPassword.caption')
                    }, {
                        setting: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                            (!_ctx.isLocked)
                                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridFormWalletName, {
                                    key: 0,
                                    class: "col-span-12 lg:ml-6",
                                    "prefilled-wallet-name": _ctx.prefilledWalletName,
                                    "prefilled-group-name": _ctx.prefilledGroupName,
                                    "is-update": true,
                                    saving: _ctx.saving,
                                    onSubmit: _ctx.onSubmitWalletNameReset
                                }, null, 8, ["prefilled-wallet-name", "prefilled-group-name", "saving", "onSubmit"]))
                                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                            (_ctx.isMnemonicWallet && !_ctx.isLocked)
                                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridSpace, {
                                    key: 1,
                                    hr: "",
                                    class: "lg:ml-6"
                                }))
                                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                            (_ctx.isMnemonicWallet && !_ctx.isLocked)
                                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridFormPasswordReset, {
                                    key: 2,
                                    "text-id": "form.password.spending",
                                    class: "col-span-12 lg:ml-6",
                                    saving: _ctx.saving,
                                    onSubmit: _ctx.onSubmitPasswordReset
                                }, null, 8, ["saving", "onSubmit"]))
                                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                        ]),
                        _: 1
                    }, 8, ["label", "caption"]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                (!_ctx.isLocked)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_SettingsItem, {
                        key: 1,
                        label: _ctx.t('wallet.settings.accessPassword.label'),
                        caption: _ctx.t('wallet.settings.accessPassword.caption'),
                        openExpanded: _ctx.expandedLock
                    }, {
                        setting: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                            (!_ctx.isLocked)
                                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridFormLockPasswordSetting, {
                                    key: 0,
                                    "text-id": "form.password.access",
                                    class: "col-span-12 lg:ml-6",
                                    saving: _ctx.saving
                                }, null, 8, ["saving"]))
                                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                        ]),
                        _: 1
                    }, 8, ["label", "caption", "openExpanded"]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                (!_ctx.isLocked)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_SettingsItem, {
                        key: 2,
                        label: _ctx.t('wallet.icon.label'),
                        caption: _ctx.t('wallet.icon.caption')
                    }, {
                        setting: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                            (!_ctx.isLocked)
                                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridFormWalletIcon, {
                                    key: 0,
                                    class: "col-span-12 lg:ml-6",
                                    "text-id": "wallet.icon",
                                    "is-update": true,
                                    saving: _ctx.saving,
                                    onSubmit: _ctx.onSubmitWalletIconReset
                                }, null, 8, ["saving", "onSubmit"]))
                                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                        ]),
                        _: 1
                    }, 8, ["label", "caption"]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                (!_ctx.isLocked)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_SettingsItem, {
                        key: 3,
                        label: _ctx.t('wallet.background.label'),
                        caption: _ctx.t('wallet.background.caption')
                    }, {
                        setting: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                            (!_ctx.isLocked)
                                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridFormWalletBackground, {
                                    key: 0,
                                    class: "col-span-12 lg:ml-6",
                                    "text-id": "wallet.background",
                                    "is-update": true,
                                    saving: _ctx.saving,
                                    "background-data": _ctx.activeWalletBackground,
                                    onSubmit: _ctx.onSubmitWalletBackground
                                }, null, 8, ["saving", "background-data", "onSubmit"]))
                                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                        ]),
                        _: 1
                    }, 8, ["label", "caption"]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                (!_ctx.isLocked)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_SettingsItem, {
                        key: 4,
                        label: _ctx.t('wallet.settings.addrbook.label'),
                        caption: _ctx.t('wallet.settings.addrbook.caption')
                    }, {
                        setting: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_5, [
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_AddressBook)
                            ])
                        ]),
                        _: 1
                    }, 8, ["label", "caption"]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                (!_ctx.isLocked)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_SettingsItem, {
                        key: 5,
                        label: _ctx.t('wallet.settings.collateral.label'),
                        caption: _ctx.t('wallet.settings.collateral.caption'),
                        "can-toggle": true,
                        enabled: _ctx.enableCollateral,
                        saving: _ctx.saving,
                        openExpanded: _ctx.expandedCollateral,
                        onEnabledToggle: _ctx.onEnableCollateral
                    }, {
                        setting: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_6, [
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_Collateral, { "enable-collateral": _ctx.enableCollateral }, null, 8, ["enable-collateral"])
                            ])
                        ]),
                        _: 1
                    }, 8, ["label", "caption", "enabled", "saving", "openExpanded", "onEnabledToggle"]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                (!_ctx.isLocked)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_SettingsItem, {
                        key: 6,
                        label: _ctx.t('wallet.settings.advancedUTxOManagement.label'),
                        caption: _ctx.t('wallet.settings.advancedUTxOManagement.caption'),
                        "can-toggle": true,
                        "can-expand": true,
                        enabled: _ctx.advancedUTxO,
                        saving: _ctx.saving,
                        onEnabledToggle: _ctx.onAdvancedUTxOManagementToggle
                    }, {
                        setting: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => []),
                        _: 1
                    }, 8, ["label", "caption", "enabled", "saving", "onEnabledToggle"]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_SettingsItem, {
                    label: _ctx.t('wallet.settings.exports.label'),
                    caption: _ctx.t('wallet.settings.exports.caption')
                }, {
                    setting: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_ExportWalletJson, { class: "ml-6 pr-6" }),
                        (!_ctx.isLocked)
                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_ExportAccountPubKey, {
                                key: 0,
                                class: "ml-6 pr-6 sm:ml-0"
                            }))
                            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, {
                            hr: true,
                            class: "w-full cc-gap-lg green-600"
                        }),
                        (!_ctx.isLocked)
                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_ExportCSV, {
                                key: 1,
                                class: "ml-6 pr-6"
                            }))
                            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                    ]),
                    _: 1
                }, 8, ["label", "caption"]),
                (!_ctx.isLocked)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_SettingsItem, {
                        key: 7,
                        label: _ctx.t('wallet.settings.changeaddr.label'),
                        caption: _ctx.t('wallet.settings.changeaddr.caption'),
                        "can-toggle": true,
                        enabled: _ctx.caEnabled,
                        saving: _ctx.saving,
                        onEnabledToggle: _ctx.onChangeAddressToggle
                    }, {
                        setting: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_7, [
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_ChangeAddress, { onSaveSetting: _ctx.onChangeAddressSave }, null, 8, ["onSaveSetting"])
                            ])
                        ]),
                        _: 1
                    }, 8, ["label", "caption", "enabled", "saving", "onEnabledToggle"]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                (!_ctx.isLocked)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_SettingsItem, {
                        key: 8,
                        label: _ctx.t('wallet.settings.tokenfrag.label'),
                        caption: _ctx.t('wallet.settings.tokenfrag.caption'),
                        "can-toggle": true,
                        enabled: _ctx.tfEnabled,
                        saving: _ctx.saving,
                        onEnabledToggle: _ctx.onTokenFragmentationToggle
                    }, {
                        setting: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_TokenFragmentation, {
                                class: "lg:ml-6",
                                onSaveSetting: _ctx.onTokenFragmentationSave
                            }, null, 8, ["onSaveSetting"])
                        ]),
                        _: 1
                    }, 8, ["label", "caption", "enabled", "saving", "onEnabledToggle"]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                (!_ctx.isLocked)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_SettingsItem, {
                        key: 9,
                        label: _ctx.t('wallet.settings.withdrawal.label'),
                        caption: _ctx.t('wallet.settings.withdrawal.caption'),
                        "can-toggle": true,
                        enabled: _ctx.awEnabled,
                        saving: _ctx.saving,
                        onEnabledToggle: _ctx.onAutoWithdrawalToggle
                    }, {
                        setting: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                                class: "lg:ml-6",
                                text: _ctx.t('wallet.settings.withdrawal.info')
                            }, null, 8, ["text"])
                        ]),
                        _: 1
                    }, 8, ["label", "caption", "enabled", "saving", "onEnabledToggle"]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                (!_ctx.isLocked)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_SettingsItem, {
                        key: 10,
                        label: _ctx.t('wallet.settings.sendall.label'),
                        caption: _ctx.t('wallet.settings.sendall.caption'),
                        "can-toggle": true,
                        "can-expand": true,
                        enabled: _ctx.enableSendAll,
                        saving: _ctx.saving,
                        onEnabledToggle: _ctx.onEnableSendAllToggle
                    }, {
                        setting: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                                class: "lg:ml-6",
                                text: _ctx.t('wallet.settings.sendall.info')
                            }, null, 8, ["text"])
                        ]),
                        _: 1
                    }, 8, ["label", "caption", "enabled", "saving", "onEnabledToggle"]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                (!_ctx.isLocked)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_SettingsItem, {
                        key: 11,
                        label: _ctx.t('wallet.settings.manualsync.label'),
                        caption: _ctx.t('wallet.settings.manualsync.caption'),
                        "can-toggle": true,
                        "can-expand": true,
                        enabled: _ctx.enableManualSync,
                        saving: _ctx.saving,
                        onEnabledToggle: _ctx.onEnableManualSyncToggle
                    }, null, 8, ["label", "caption", "enabled", "saving", "onEnabledToggle"]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                (!_ctx.isLocked)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_SettingsItem, {
                        key: 12,
                        label: _ctx.t('wallet.settings.resync.label'),
                        caption: _ctx.t('wallet.settings.resync.caption')
                    }, {
                        setting: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_8, [
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_ForceWalletResync)
                            ])
                        ]),
                        _: 1
                    }, 8, ["label", "caption"]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                (_ctx.isMnemonicWallet)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_SettingsItem, {
                        key: 13,
                        label: _ctx.t('wallet.settings.verification.label'),
                        caption: _ctx.t('wallet.settings.verification.caption'),
                        "open-expanded": _ctx.expandedVerification
                    }, {
                        setting: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_9, [
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonSecondary, {
                                    label: _ctx.t('wallet.settings.verification.start'),
                                    link: _ctx.setVerification,
                                    class: "col-span-12 xs:col-span-8 sm:col-span-6 xl:col-span-4"
                                }, null, 8, ["label", "link"])
                            ])
                        ]),
                        _: 1
                    }, 8, ["label", "caption", "open-expanded"]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                (_ctx.isMnemonicWallet && _ctx.isLocked)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_SettingsItem, {
                        key: 14,
                        label: _ctx.t('wallet.settings.recovery.label'),
                        caption: _ctx.t('wallet.settings.recovery.caption'),
                        "open-expanded": _ctx.expandedRecovery
                    }, {
                        setting: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_10, [
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonSecondary, {
                                    label: _ctx.t('wallet.settings.recovery.button'),
                                    link: _ctx.goToRecovery,
                                    class: "col-span-12 xs:col-span-8 sm:col-span-6 xl:col-span-4"
                                }, null, 8, ["label", "link"])
                            ])
                        ]),
                        _: 1
                    }, 8, ["label", "caption", "open-expanded"]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_SettingsItem, { label: _ctx.lockedText }, {
                    setting: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_11, [
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_12, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.settings.deldereg.dangerzone')), 1),
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, { hr: "" }),
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_DeleteWallet, { "full-width": _ctx.isLocked }, null, 8, ["full-width"]),
                            (!_ctx.isLocked)
                                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_DeregisterWallet, { key: 0 }))
                                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                        ])
                    ]),
                    _: 1
                }, 8, ["label"])
            ]),
            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_13, [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonSecondary, {
                    label: _ctx.t('wallet.stakingvault.summary.headline'),
                    link: _ctx.gotoStakingVault,
                    class: "col-span-12 xs:col-span-8 sm:col-span-6 xl:col-span-4"
                }, null, 8, ["label", "link"])
            ])
        ]))
        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true);
}

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/Settings.vue?vue&type=template&id=6b75aa3b&ts=true

// EXTERNAL MODULE: ./node_modules/@vue/reactivity/dist/reactivity.esm-bundler.js
var reactivity_esm_bundler = __webpack_require__(61959);
// EXTERNAL MODULE: ./node_modules/quasar/src/composables/use-quasar.js
var use_quasar = __webpack_require__(48825);
// EXTERNAL MODULE: ./node_modules/vue-router/dist/vue-router.mjs
var vue_router = __webpack_require__(28339);
// EXTERNAL MODULE: ./src/composables/ccw/useTranslation.ts
var useTranslation = __webpack_require__(19376);
// EXTERNAL MODULE: ./src/composables/ccw/useNavigation.ts
var useNavigation = __webpack_require__(52439);
// EXTERNAL MODULE: ./src/composables/ccw/store/useActiveWallet.ts
var useActiveWallet = __webpack_require__(52144);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridHeadline.vue + 3 modules
var GridHeadline = __webpack_require__(63593);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridSpace.vue + 4 modules
var GridSpace = __webpack_require__(14740);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridButtonWarning.vue + 3 modules
var GridButtonWarning = __webpack_require__(63691);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridButtonSecondary.vue + 3 modules
var GridButtonSecondary = __webpack_require__(72713);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridText.vue + 4 modules
var GridText = __webpack_require__(96834);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/forms/GridFormWalletName.vue + 3 modules
var GridFormWalletName = __webpack_require__(81839);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/forms/GridFormWalletIcon.vue?vue&type=template&id=ba459f32&ts=true

const GridFormWalletIconvue_type_template_id_ba459f32_ts_true_hoisted_1 = { class: "col-span-12 grid grid-cols-12 cc-gap" };
const GridFormWalletIconvue_type_template_id_ba459f32_ts_true_hoisted_2 = { class: "col-span-12 sm:col-span-6 flex flex-row items-center" };
const GridFormWalletIconvue_type_template_id_ba459f32_ts_true_hoisted_3 = { class: "mr-2" };
const GridFormWalletIconvue_type_template_id_ba459f32_ts_true_hoisted_4 = {
    key: 0,
    class: "col-span-12 sm:col-span-6 flex flex-row items-center"
};
const GridFormWalletIconvue_type_template_id_ba459f32_ts_true_hoisted_5 = { class: "mr-4" };
const GridFormWalletIconvue_type_template_id_ba459f32_ts_true_hoisted_6 = { ref: "imagePreview" };
function GridFormWalletIconvue_type_template_id_ba459f32_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridButtonPrimary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonPrimary");
    const _component_grid_space = (0,runtime_core_esm_bundler/* resolveComponent */.up)("grid-space");
    const _component_GridButtonSecondary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonSecondary");
    const _component_GridForm = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridForm");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridForm, {
        onDoFormReset: _ctx.onReset,
        onDoFormSubmit: _ctx.onSubmit,
        "form-id": "GridFormWalletIcon",
        "reset-button-label": _ctx.it('common.label.reset'),
        "submit-button-label": _ctx.it('common.label.save'),
        "submit-disabled": !_ctx.submitEnabled || _ctx.saving,
        "reset-disabled": _ctx.saving || !_ctx.isChanged
    }, {
        btnBack: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", GridFormWalletIconvue_type_template_id_ba459f32_ts_true_hoisted_1, [
                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", GridFormWalletIconvue_type_template_id_ba459f32_ts_true_hoisted_2, [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("span", GridFormWalletIconvue_type_template_id_ba459f32_ts_true_hoisted_3, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('wallet.icon.upload')) + ": ", 1),
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("input", {
                        ref: "file",
                        class: "hidden mb-2",
                        id: "iconFileUpload",
                        onChange: _cache[0] || (_cache[0] = ($event) => (_ctx.handleFileUpload())),
                        type: "file"
                    }, null, 544),
                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonPrimary, {
                        onClick: _ctx.chooseFiles,
                        class: "col-span-5 inline-block w-48",
                        label: _ctx.it('common.label.selectFile')
                    }, null, 8, ["onClick", "label"])
                ]),
                (_ctx.showImagePreview)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", GridFormWalletIconvue_type_template_id_ba459f32_ts_true_hoisted_4, [
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("span", GridFormWalletIconvue_type_template_id_ba459f32_ts_true_hoisted_5, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('common.label.preview')) + ": ", 1),
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("img", GridFormWalletIconvue_type_template_id_ba459f32_ts_true_hoisted_6, null, 512)
                    ]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_grid_space, { hr: "" })
            ]),
            (_ctx.removeOldUploadDisable)
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridButtonSecondary, {
                    key: 0,
                    label: _ctx.it('common.label.removeCurrentImage'),
                    class: "col-span-12 sm:col-star-1 sm:col-span-3",
                    onClick: _ctx.resetCurrentImage
                }, null, 8, ["label", "onClick"]))
                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
            (!_ctx.removeOldUploadDisable)
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridButtonSecondary, {
                    key: 1,
                    label: _ctx.it('common.label.regenerateIcon'),
                    class: "col-span-12 sm:col-star-4 sm:col-span-3",
                    onClick: _ctx.regenerateIcon
                }, null, 8, ["label", "onClick"]))
                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
        ]),
        _: 1
    }, 8, ["onDoFormReset", "onDoFormSubmit", "reset-button-label", "submit-button-label", "submit-disabled", "reset-disabled"]));
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/forms/GridFormWalletIcon.vue?vue&type=template&id=ba459f32&ts=true

// EXTERNAL MODULE: ./src/components/ccw/grid/v2/forms/GridForm.vue + 3 modules
var GridForm = __webpack_require__(76798);
// EXTERNAL MODULE: ./node_modules/lz-string/libs/lz-string.js
var lz_string = __webpack_require__(55971);
var lz_string_default = /*#__PURE__*/__webpack_require__.n(lz_string);
// EXTERNAL MODULE: ./src/lib/utils/Image.ts
var Image = __webpack_require__(42241);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridButtonPrimary.vue + 3 modules
var GridButtonPrimary = __webpack_require__(12559);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/forms/GridFormWalletIcon.vue?vue&type=script&lang=ts






const { isActiveWalletLocked, activeWalletId, activeWalletData, activeWalletPlate } = (0,useActiveWallet/* useActiveWallet */.r)();



/* harmony default export */ const GridFormWalletIconvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'GridFormWalletIcon',
    components: {
        GridButtonPrimary: GridButtonPrimary/* default */.Z,
        GridForm: GridForm/* default */.Z,
        GridButtonSecondary: GridButtonSecondary/* default */.Z,
        GridSpace: GridSpace/* default */.Z
    },
    emits: ['submit'],
    props: {
        textId: { type: String, required: false, default: '' },
        prefilledWalletName: { type: String, required: false, default: '' },
        prefilledGroupName: { type: String, required: false, default: '' },
        isUpdate: { type: Boolean, required: false, default: false },
        saving: { type: Boolean, required: false, default: false },
        inputCSS: { type: String, default: 'cc-input' },
    },
    setup(props, context) {
        const { it } = (0,useTranslation/* useTranslation */.$)();
        const { setPlateSeed } = (0,useActiveWallet/* useActiveWallet */.r)();
        const file = (0,reactivity_esm_bundler/* ref */.iH)();
        const compressedImageData = (0,reactivity_esm_bundler/* ref */.iH)();
        const imagePreview = (0,reactivity_esm_bundler/* ref */.iH)();
        const showImagePreview = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const canvasRef = (0,reactivity_esm_bundler/* ref */.iH)(null);
        const onSubmit = async () => {
            context.emit('submit', {
                compressedImageData: lz_string_default().compress(compressedImageData.value)
            });
            submitEnabled.value = false;
            onReset();
            removeOldUploadDisable.value = true;
        };
        const onReset = () => {
            file.value.value = '';
            compressedImageData.value = undefined;
            showImagePreview.value = false;
            submitEnabled.value = false;
            if (activeWalletPlate.value?.data) {
                removeOldUploadDisable.value = true;
            }
        };
        const resetCurrentImage = () => {
            file.value.value = '';
            compressedImageData.value = undefined;
            showImagePreview.value = false;
            context.emit('submit', {
                compressedImageData: ''
            });
            removeOldUploadDisable.value = false;
            submitEnabled.value = false;
        };
        const regenerateIcon = async () => {
            var randomSeed = Date.now();
            var random = Math.floor(Math.random() * 255);
            await setPlateSeed(String(randomSeed * random));
        };
        const submitEnabled = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const removeOldUploadDisable = (0,reactivity_esm_bundler/* ref */.iH)(false);
        if (activeWalletPlate.value?.data) {
            removeOldUploadDisable.value = true;
        }
        async function encodeImageFileAsURL(element) {
            if (file.value && file.value.files && file.value.files.length > 0) {
                const fileUploaded = file.value.files[0];
                const resizedImage = await (0,Image/* resizeImageFile */.T)(fileUploaded, 60);
                compressedImageData.value = resizedImage;
                await showPreview();
                let previewImage = imagePreview.value;
                previewImage.height = 35;
                previewImage.width = 35;
                previewImage.src = resizedImage;
                submitEnabled.value = true;
            }
        }
        const showPreview = async () => {
            showImagePreview.value = true;
        };
        const handleFileUpload = async () => {
            await encodeImageFileAsURL(file.value);
        };
        const isChanged = (0,runtime_core_esm_bundler/* computed */.Fl)(() => compressedImageData.value !== undefined);
        const chooseFiles = () => {
            const target = document.getElementById("iconFileUpload");
            if (target !== null) {
                target.click();
            }
        };
        return {
            it,
            file,
            canvasRef,
            imagePreview,
            showImagePreview,
            submitEnabled,
            isChanged,
            handleFileUpload,
            resetCurrentImage,
            regenerateIcon,
            removeOldUploadDisable,
            chooseFiles,
            onSubmit,
            onReset
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/forms/GridFormWalletIcon.vue?vue&type=script&lang=ts
 
// EXTERNAL MODULE: ./node_modules/vue-loader/dist/exportHelper.js
var exportHelper = __webpack_require__(74260);
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/forms/GridFormWalletIcon.vue




;
const __exports__ = /*#__PURE__*/(0,exportHelper/* default */.Z)(GridFormWalletIconvue_type_script_lang_ts, [['render',GridFormWalletIconvue_type_template_id_ba459f32_ts_true_render]])

/* harmony default export */ const GridFormWalletIcon = (__exports__);
// EXTERNAL MODULE: ./node_modules/@vue/runtime-dom/dist/runtime-dom.esm-bundler.js
var runtime_dom_esm_bundler = __webpack_require__(98880);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/forms/GridFormWalletBackground.vue?vue&type=template&id=a7f8e8e4&ts=true

const GridFormWalletBackgroundvue_type_template_id_a7f8e8e4_ts_true_hoisted_1 = { class: "col-span-12 col-start-0 grid grid-cols-12" };
const GridFormWalletBackgroundvue_type_template_id_a7f8e8e4_ts_true_hoisted_2 = { class: "col-span-full" };
const GridFormWalletBackgroundvue_type_template_id_a7f8e8e4_ts_true_hoisted_3 = { class: "grid grid-cols-12" };
const GridFormWalletBackgroundvue_type_template_id_a7f8e8e4_ts_true_hoisted_4 = { class: "col-span-full flex pb-2" };
const GridFormWalletBackgroundvue_type_template_id_a7f8e8e4_ts_true_hoisted_5 = { class: "col-span-full flex" };
const GridFormWalletBackgroundvue_type_template_id_a7f8e8e4_ts_true_hoisted_6 = { class: "col-span-full grid grid-cols-12 pt-3" };
const GridFormWalletBackgroundvue_type_template_id_a7f8e8e4_ts_true_hoisted_7 = { class: "col-span-12 flex flex-col flex-nowrap space-y-2 justify-between items-start" };
const GridFormWalletBackgroundvue_type_template_id_a7f8e8e4_ts_true_hoisted_8 = { class: "w-full cc-px flex flex-row flex-nowrap justify-between items-start" };
const GridFormWalletBackgroundvue_type_template_id_a7f8e8e4_ts_true_hoisted_9 = { class: "cc-text-bold" };
const GridFormWalletBackgroundvue_type_template_id_a7f8e8e4_ts_true_hoisted_10 = { class: "col-span-12 flex pt-2" };
const GridFormWalletBackgroundvue_type_template_id_a7f8e8e4_ts_true_hoisted_11 = { class: "flex-none pr-3" };
const GridFormWalletBackgroundvue_type_template_id_a7f8e8e4_ts_true_hoisted_12 = ["min", "max", "step"];
const GridFormWalletBackgroundvue_type_template_id_a7f8e8e4_ts_true_hoisted_13 = { class: "flex-none pl-3" };
function GridFormWalletBackgroundvue_type_template_id_a7f8e8e4_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_IconPencil = (0,runtime_core_esm_bundler/* resolveComponent */.up)("IconPencil");
    const _component_GridInput = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridInput");
    const _component_GridButtonSecondary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonSecondary");
    const _component_GridForm = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridForm");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridForm, {
        onDoFormReset: _ctx.onReset,
        onDoFormSubmit: _ctx.onSubmit,
        "form-id": _ctx.textId + '.walletname',
        "reset-button-label": _ctx.it(_ctx.textId + '.button.reset'),
        "submit-button-label": _ctx.it(_ctx.textId + '.button.save'),
        "submit-disabled": !_ctx.submitEnabled || _ctx.saving,
        "reset-disabled": _ctx.saving
    }, {
        btnBack: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", GridFormWalletBackgroundvue_type_template_id_a7f8e8e4_ts_true_hoisted_1, [
                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", GridFormWalletBackgroundvue_type_template_id_a7f8e8e4_ts_true_hoisted_2, [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", GridFormWalletBackgroundvue_type_template_id_a7f8e8e4_ts_true_hoisted_3, [
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", GridFormWalletBackgroundvue_type_template_id_a7f8e8e4_ts_true_hoisted_4, [
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridInput, {
                                "input-text": _ctx.tokenPolicyIdValue,
                                "onUpdate:input-text": _cache[0] || (_cache[0] = ($event) => ((_ctx.tokenPolicyIdValue) = $event)),
                                label: _ctx.it('wallet.background.tokenPolicy.label'),
                                class: "",
                                showReset: false,
                                "input-id": "inputBackgroundPolicyId",
                                "input-type": "text",
                                autocomplete: "policy"
                            }, {
                                "icon-prepend": (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_IconPencil, { class: "h-5 w-5" })
                                ]),
                                _: 1
                            }, 8, ["input-text", "label"])
                        ]),
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", GridFormWalletBackgroundvue_type_template_id_a7f8e8e4_ts_true_hoisted_5, [
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridInput, {
                                "input-text": _ctx.tokenNameValue,
                                "onUpdate:input-text": _cache[1] || (_cache[1] = ($event) => ((_ctx.tokenNameValue) = $event)),
                                label: _ctx.it('wallet.background.assetName.label'),
                                "input-info": _ctx.it('wallet.background.assetName.info'),
                                class: "col-start-4 col-span-9",
                                showReset: false,
                                "input-id": "inputBackgroundTokenName",
                                "input-type": "text",
                                autocomplete: "tokenName"
                            }, {
                                "icon-prepend": (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_IconPencil, { class: "h-5 w-5" })
                                ]),
                                _: 1
                            }, 8, ["input-text", "label", "input-info"])
                        ]),
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", GridFormWalletBackgroundvue_type_template_id_a7f8e8e4_ts_true_hoisted_6, [
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", GridFormWalletBackgroundvue_type_template_id_a7f8e8e4_ts_true_hoisted_7, [
                                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", GridFormWalletBackgroundvue_type_template_id_a7f8e8e4_ts_true_hoisted_8, [
                                    (0,runtime_core_esm_bundler/* createElementVNode */._)("label", GridFormWalletBackgroundvue_type_template_id_a7f8e8e4_ts_true_hoisted_9, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('wallet.background.opacity')), 1)
                                ])
                            ]),
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", GridFormWalletBackgroundvue_type_template_id_a7f8e8e4_ts_true_hoisted_10, [
                                (0,runtime_core_esm_bundler/* createElementVNode */._)("span", GridFormWalletBackgroundvue_type_template_id_a7f8e8e4_ts_true_hoisted_11, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.minOpacity) + "%", 1),
                                (0,runtime_core_esm_bundler/* createElementVNode */._)("input", {
                                    class: "flex-1 form-range w-full h-6 p-1 bg-transparent focus:outline-none focus:ring-0 focus:shadow-none",
                                    type: "range",
                                    ref: "bgOpacity",
                                    value: "",
                                    min: _ctx.minOpacity,
                                    max: _ctx.maxOpacity,
                                    step: _ctx.opacitySteps,
                                    onChange: _cache[2] || (_cache[2] =
                                        //@ts-ignore
                                        (...args) => (_ctx.changeOpacity && _ctx.changeOpacity(...args)))
                                }, null, 40, GridFormWalletBackgroundvue_type_template_id_a7f8e8e4_ts_true_hoisted_12),
                                (0,runtime_core_esm_bundler/* createElementVNode */._)("span", GridFormWalletBackgroundvue_type_template_id_a7f8e8e4_ts_true_hoisted_13, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.maxOpacity) + "%", 1)
                            ])
                        ])
                    ])
                ])
            ]),
            (_ctx.showPreviewButton)
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridButtonSecondary, {
                    key: 0,
                    label: _ctx.it('wallet.background.button.preview'),
                    class: "col-start-1 col-span-6 md:col-span-3",
                    onClick: (0,runtime_dom_esm_bundler/* withModifiers */.iM)(_ctx.testBackground, ["stop"])
                }, null, 8, ["label", "onClick"]))
                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
            (!_ctx.showPreviewButton && _ctx.showClearPreviewButton)
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridButtonSecondary, {
                    key: 1,
                    label: _ctx.it('wallet.background.button.clearPreview'),
                    class: "md:col-start-4 col-span-6 md:col-span-3",
                    onClick: (0,runtime_dom_esm_bundler/* withModifiers */.iM)(_ctx.clearPreview, ["stop"])
                }, null, 8, ["label", "onClick"]))
                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
            (_ctx.showRandomMezButton && !_ctx.isBexApp)
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridButtonSecondary, {
                    key: 2,
                    label: _ctx.it('wallet.background.button.randomMez'),
                    class: "col-start-7 col-span-6 md:col-start-4 md:col-span-3",
                    onClick: (0,runtime_dom_esm_bundler/* withModifiers */.iM)(_ctx.randomMez, ["stop"])
                }, null, 8, ["label", "onClick"]))
                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
            (_ctx.showClearBackgroundButton && !_ctx.showClearPreviewButton)
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridButtonSecondary, {
                    key: 3,
                    label: _ctx.it('wallet.background.button.remove'),
                    class: "col-span-6 md:col-span-3",
                    onClick: (0,runtime_dom_esm_bundler/* withModifiers */.iM)(_ctx.removeCurrentBackground, ["stop"])
                }, null, 8, ["label", "onClick"]))
                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
        ]),
        _: 1
    }, 8, ["onDoFormReset", "onDoFormSubmit", "form-id", "reset-button-label", "submit-button-label", "submit-disabled", "reset-disabled"]));
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/forms/GridFormWalletBackground.vue?vue&type=template&id=a7f8e8e4&ts=true

// EXTERNAL MODULE: ./src/components/ccw/grid/v2/icons/IconPencil.vue + 4 modules
var IconPencil = __webpack_require__(44814);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridInput.vue + 4 modules
var GridInput = __webpack_require__(27209);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/forms/elements/GFEWalletName.vue + 3 modules
var GFEWalletName = __webpack_require__(39666);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/forms/elements/GFEGroupName.vue + 3 modules
var GFEGroupName = __webpack_require__(72282);
;// CONCATENATED MODULE: ../ccw-lib2/core/IWalletBackground.ts
const createIWalletBackground = (ref, opacity) => {
    return {
        name: ref.name,
        policy: ref.policy,
        quantity: ref.quantity,
        opacity: opacity,
    };
};

// EXTERNAL MODULE: ../ccw-lib2/core/lib/LibUtils.ts
var LibUtils = __webpack_require__(10751);
// EXTERNAL MODULE: ./src/lib/ExtBackground.ts
var ExtBackground = __webpack_require__(61953);
// EXTERNAL MODULE: ./src/lib/ExtStorageLib.ts + 1 modules
var ExtStorageLib = __webpack_require__(40736);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/forms/GridFormWalletBackground.vue?vue&type=script&lang=ts










;




/* harmony default export */ const GridFormWalletBackgroundvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'GridFormWalletBackground',
    components: {
        GridForm: GridForm/* default */.Z,
        GFEWalletName: GFEWalletName/* default */.Z,
        GFEGroupName: GFEGroupName/* default */.Z,
        IconPencil: IconPencil/* default */.Z,
        GridInput: GridInput/* default */.Z,
        GridButtonSecondary: GridButtonSecondary/* default */.Z,
        GridSpace: GridSpace/* default */.Z
    },
    emits: ['submit'],
    props: {
        textId: { type: String, required: false, default: '' },
        prefilledWalletName: { type: String, required: false, default: '' },
        prefilledGroupName: { type: String, required: false, default: '' },
        isUpdate: { type: Boolean, required: false, default: false },
        saving: { type: Boolean, required: false, default: false },
        inputCSS: { type: String, default: 'cc-input' },
        backgroundData: { type: Object, required: false, default: {} }
    },
    setup(props, context) {
        const { it } = (0,useTranslation/* useTranslation */.$)();
        const { isActiveWalletLocked, activeWalletId, activeWalletData, activeWalletPlate, activeWalletBackground, activeAccount, } = (0,useActiveWallet/* useActiveWallet */.r)();
        const $q = (0,use_quasar/* default */.Z)();
        (0,runtime_core_esm_bundler/* onMounted */.bv)(() => {
            if (props.backgroundData.policy.length > 0) {
                tokenPolicyIdValue.value = props.backgroundData.policy;
                tokenNameValue.value = props.backgroundData.name;
                bgOpacity.value.value = props.backgroundData.opacity;
            }
        });
        const mezPolicy = '6cf6b5cf0fefbe9e69d640d8be84912bb2c9e132671954548790bcfb';
        const mezMax = 9999;
        const minOpacity = 60;
        const maxOpacity = 100;
        const siteOpacity = (0,reactivity_esm_bundler/* ref */.iH)(80);
        const opacitySteps = 0.1;
        const tokenPolicyIdValue = (0,reactivity_esm_bundler/* ref */.iH)('');
        const tokenNameValue = (0,reactivity_esm_bundler/* ref */.iH)('');
        const bgOpacity = (0,reactivity_esm_bundler/* ref */.iH)();
        const previewSetting = (0,reactivity_esm_bundler/* ref */.iH)(createIWalletBackground({
            policy: '',
            name: '',
            quantity: ''
        }, 0));
        const submitEnabled = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const inputDataEqualsSavedData = (0,runtime_core_esm_bundler/* computed */.Fl)(() => {
            return tokenPolicyIdValue.value == props.backgroundData.policy &&
                tokenNameValue.value == props.backgroundData.name;
        });
        const getRandomInt = (max) => {
            return Math.floor(Math.random() * max).toString();
        };
        (0,runtime_core_esm_bundler/* onUnmounted */.Ah)(() => {
            if (previewSetting.value.policy != '') {
                (0,ExtBackground/* removeBackground */.X1)();
                (0,ExtBackground/* setSiteOpacity */.Sp)(maxOpacity);
            }
        });
        const showPreviewButton = (0,runtime_core_esm_bundler/* computed */.Fl)(() => {
            return !inputDataEqualsSavedData.value &&
                tokenPolicyIdValue.value != '' &&
                tokenNameValue.value != '' &&
                isValidOpacity() &&
                previewSetting.value.policy == '';
        });
        const showClearPreviewButton = (0,runtime_core_esm_bundler/* computed */.Fl)(() => {
            return previewSetting.value.policy != '' && !inputDataEqualsSavedData.value;
        });
        const showClearBackgroundButton = (0,runtime_core_esm_bundler/* computed */.Fl)(() => {
            return props.backgroundData.policy != '';
        });
        const showRandomMezButton = (0,runtime_core_esm_bundler/* computed */.Fl)(() => {
            return previewSetting.value.policy == '' && props.backgroundData.policy == '';
        });
        const changeOpacity = (event) => {
            let opacity = getOpacityValue();
            (0,ExtBackground/* setSiteOpacity */.Sp)(opacity);
            submitEnabled.value = true;
        };
        (0,runtime_core_esm_bundler/* watchEffect */.m0)(() => {
            submitEnabled.value = bgOpacity.value?.value !== props.backgroundData.opacity;
        });
        const clearPreview = () => {
            previewSetting.value.policy = '';
            previewSetting.value.name = '';
            previewSetting.value.opacity = siteOpacity.value;
            (0,ExtBackground/* removeBackground */.X1)();
            (0,ExtBackground/* setSiteOpacity */.Sp)(maxOpacity);
            setSavedWalletBackground();
            (0,ExtBackground/* setWalletBackground */.li)(activeAccount.value.network, activeWalletBackground.value);
        };
        const isValidInput = (0,runtime_core_esm_bundler/* computed */.Fl)(() => {
            return tokenPolicyIdValue.value.length > 0 &&
                tokenNameValue.value.length > 0 &&
                Number(bgOpacity.value?.value) > minOpacity &&
                Number(bgOpacity.value?.value) < maxOpacity ||
                (props.backgroundData.policy != '' && tokenPolicyIdValue.value.length == 0 &&
                    props.backgroundData.name != '' && tokenNameValue.value.length == 0);
        });
        const isValidOpacity = () => {
            return bgOpacity.value?.value != null &&
                Number(bgOpacity.value?.value) >= minOpacity &&
                Number(bgOpacity.value?.value) <= maxOpacity;
        };
        const setSavedWalletBackground = () => {
            if (props.backgroundData.policy != '') {
                tokenPolicyIdValue.value = props.backgroundData.policy;
                tokenNameValue.value = props.backgroundData.name;
                bgOpacity.value.value = props.backgroundData.opacity;
            }
        };
        const getOpacityValue = () => {
            return parseInt(bgOpacity.value?.value ?? '80') ?? 80;
        };
        const randomMez = async () => {
            tokenPolicyIdValue.value = mezPolicy;
            let randomInt = getRandomInt(mezMax);
            while (randomInt.length < 4) {
                randomInt = '0' + randomInt;
            }
            tokenNameValue.value = (0,LibUtils/* encodeHex */.U$)('mesmerizer0' + randomInt);
            submitEnabled.value = true;
        };
        const removeCurrentBackground = () => {
            tokenPolicyIdValue.value = '';
            tokenNameValue.value = '';
            (0,ExtBackground/* removeBackground */.X1)();
            (0,ExtBackground/* setSiteOpacity */.Sp)(maxOpacity);
            context.emit('submit', {
                policy: '',
                name: '',
                opacity: maxOpacity
            });
            submitEnabled.value = false;
        };
        const testBackground = async () => {
            const policy = tokenPolicyIdValue.value ?? '';
            const name = tokenNameValue.value ?? '';
            try {
                let backgroundData = await (0,ExtBackground/* getBackgroundData */.C2)(activeAccount.value.network, createIWalletBackground({
                    policy, name, quantity: '0'
                }, parseInt(bgOpacity.value.value)));
                if (backgroundData) {
                    (0,ExtBackground/* addBackgroundIFrame */.fM)();
                    try {
                        (0,ExtBackground/* setBackground */.AY)(backgroundData);
                        (0,ExtBackground/* setSiteOpacity */.Sp)(getOpacityValue());
                        previewSetting.value.policy = tokenPolicyIdValue.value;
                        previewSetting.value.name = tokenNameValue.value;
                        previewSetting.value.opacity = parseInt(bgOpacity.value.value);
                    }
                    catch (err) {
                        $q.notify({
                            type: 'negative',
                            message: it('wallet.background.error.bexMode'),
                            position: 'top',
                            timeout: 10000
                        });
                    }
                }
                else {
                    $q.notify({
                        type: 'negative',
                        message: it('wallet.background.error.metadata'),
                        position: 'top',
                        timeout: 10000
                    });
                }
            }
            catch (error) {
                $q.notify({
                    type: 'negative',
                    message: it('wallet.background.error.metadata'),
                    position: 'top',
                    timeout: 10000
                });
            }
        };
        const onSubmit = async () => {
            const policy = tokenPolicyIdValue.value ?? '';
            const name = tokenNameValue.value ?? '';
            const opacity = parseInt(bgOpacity.value?.value ?? '80');
            if (policy == '' && name == '') {
                (0,ExtBackground/* removeBackground */.X1)();
                (0,ExtBackground/* setSiteOpacity */.Sp)(maxOpacity);
            }
            previewSetting.value.policy = '';
            previewSetting.value.name = '';
            previewSetting.value.opacity = 100;
            context.emit('submit', {
                policy: policy,
                name: name,
                opacity: opacity
            });
        };
        const onReset = () => {
            tokenPolicyIdValue.value = props.backgroundData.policy;
            tokenNameValue.value = props.backgroundData.name;
            let value = bgOpacity.value;
            value.value = props.backgroundData.opacity;
            if (previewSetting.value.policy != '') {
                previewSetting.value.policy = '';
                previewSetting.value.name = '';
                previewSetting.value.opacity = 100;
                (0,ExtBackground/* removeBackground */.X1)();
                (0,ExtBackground/* setWalletBackground */.li)(activeAccount.value.network, activeWalletBackground.value);
                (0,ExtBackground/* setSiteOpacity */.Sp)(maxOpacity);
            }
        };
        return {
            it,
            submitEnabled,
            onSubmit,
            onReset,
            isValidInput,
            setBackground: ExtBackground/* setBackground */.AY,
            removeCurrentBackground,
            testBackground,
            clearPreview,
            changeOpacity,
            randomMez,
            bgOpacity,
            opacitySteps,
            minOpacity,
            maxOpacity,
            tokenPolicyIdValue,
            tokenNameValue,
            showPreviewButton,
            showClearPreviewButton,
            showClearBackgroundButton,
            showRandomMezButton,
            isBexApp: ExtStorageLib/* isBexApp */.mo
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/forms/GridFormWalletBackground.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/forms/GridFormWalletBackground.vue




;
const GridFormWalletBackground_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(GridFormWalletBackgroundvue_type_script_lang_ts, [['render',GridFormWalletBackgroundvue_type_template_id_a7f8e8e4_ts_true_render]])

/* harmony default export */ const GridFormWalletBackground = (GridFormWalletBackground_exports_);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/forms/GridFormPasswordReset.vue + 3 modules
var GridFormPasswordReset = __webpack_require__(2252);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/forms/GridFormLockPasswordSetting.vue?vue&type=template&id=53550263&ts=true

function GridFormLockPasswordSettingvue_type_template_id_53550263_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_AccessPasswordInputModal = (0,runtime_core_esm_bundler/* resolveComponent */.up)("AccessPasswordInputModal");
    const _component_GFEPassword = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GFEPassword");
    const _component_GFERepeatPassword = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GFERepeatPassword");
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    const _component_GridButtonSecondary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonSecondary");
    const _component_GridForm = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridForm");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridForm, {
        onDoFormReset: _ctx.onReset,
        onDoFormSubmit: _ctx.onSubmit,
        "form-id": "GridFormLockPasswordSetting",
        "reset-button-label": _ctx.it('common.label.reset'),
        "submit-button-label": _ctx.it('common.label.save'),
        "submit-disabled": !_ctx.submitEnabled || _ctx.saving,
        "reset-disabled": _ctx.saving
    }, {
        content: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_AccessPasswordInputModal, {
                "show-modal": _ctx.showPasswordModal,
                textId: "wallet.settings.accessPassword",
                title: _ctx.it('wallet.settings.accessPassword.labelUnlock'),
                caption: _ctx.it('wallet.settings.accessPassword.captionDelete'),
                "submit-button-label": _ctx.it('wallet.settings.accessPassword.remove'),
                "show-info": false,
                autofocus: _ctx.showPasswordModal,
                onClose: _ctx.closeModal,
                onSubmit: _ctx.removeLockWallet
            }, null, 8, ["show-modal", "title", "caption", "submit-button-label", "autofocus", "onClose", "onSubmit"]),
            (_ctx.currentLockPassword)
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GFEPassword, {
                    key: 0,
                    class: "col-span-12",
                    onOnSubmittable: _ctx.onSetOldLockPassword,
                    autofocus: !_ctx.showPasswordModal,
                    "reset-counter": _ctx.resetCounter,
                    "input-id": "oldPassword",
                    "skip-validation": _ctx.skipValidation,
                    "text-id": _ctx.textId + '.current'
                }, null, 8, ["onOnSubmittable", "autofocus", "reset-counter", "skip-validation", "text-id"]))
                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GFEPassword, {
                "skip-validation": _ctx.skipValidation,
                class: "col-span-12 lg:col-span-6",
                onOnSubmittable: _ctx.onSetLockPassword,
                "reset-counter": _ctx.resetCounter,
                "text-id": _ctx.textId + '.enter'
            }, null, 8, ["skip-validation", "onOnSubmittable", "reset-counter", "text-id"]),
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GFERepeatPassword, {
                class: "col-span-12 lg:col-span-6",
                onOnSubmittable: _ctx.onSetRepeatPassword,
                "compare-password": _ctx.lockPassword,
                "reset-counter": _ctx.resetCounter,
                "text-id": _ctx.textId + '.repeat'
            }, null, 8, ["onOnSubmittable", "compare-password", "reset-counter", "text-id"]),
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, { dense: "" }),
            (_ctx.currentLockPassword)
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridButtonSecondary, {
                    key: 1,
                    class: "col-start-0 col-span-6 lg:col-start-0 lg:col-span-3",
                    label: _ctx.it('common.label.removeLock'),
                    onClick: _ctx.doShowPasswordModal,
                    type: 'button'
                }, null, 8, ["label", "onClick"]))
                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
            (_ctx.currentLockPassword)
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridButtonSecondary, {
                    key: 2,
                    class: "col-start-0 col-span-6 lg:col-start-0 lg:col-span-3",
                    label: _ctx.it('common.label.lock'),
                    onClick: _ctx.relockWallet,
                    disabled: _ctx.isActiveWalletPreparing || _ctx.isActiveWalletSyncing,
                    type: 'button'
                }, null, 8, ["label", "onClick", "disabled"]))
                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
        ]),
        btnBack: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
            (0,runtime_core_esm_bundler/* renderSlot */.WI)(_ctx.$slots, "btnBack")
        ]),
        _: 3
    }, 8, ["onDoFormReset", "onDoFormSubmit", "reset-button-label", "submit-button-label", "submit-disabled", "reset-disabled"]));
}

// EXTERNAL MODULE: ./src/components/ccw/grid/v2/forms/elements/GFEPassword.vue + 3 modules
var GFEPassword = __webpack_require__(84329);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/forms/elements/GFEOldPassword.vue + 3 modules
var GFEOldPassword = __webpack_require__(94622);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/forms/elements/GFERepeatPassword.vue + 3 modules
var GFERepeatPassword = __webpack_require__(21302);
// EXTERNAL MODULE: ./src/components/ccw/modal/AccessPasswordInputModal.vue + 8 modules
var AccessPasswordInputModal = __webpack_require__(94547);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/WalletLib.ts + 1 modules
var WalletLib = __webpack_require__(46805);
// EXTERNAL MODULE: ./src/lib/ExtAppWalletManagerLib.ts
var ExtAppWalletManagerLib = __webpack_require__(12736);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/forms/GridFormLockPasswordSetting.vue?vue&type=script&lang=ts

;











const doRelockWallet = ExtAppWalletManagerLib/* AWM.relockWallet */.b.relockWallet;
const removeWalletLock = ExtAppWalletManagerLib/* AWM.removeWalletLock */.b.removeWalletLock;
const updateLockPassword = ExtAppWalletManagerLib/* AWM.updateLockPassword */.b.updateLockPassword;
const checkPassword = ExtAppWalletManagerLib/* AWM.checkPassword */.b.checkPassword;
const updateSetting = ExtAppWalletManagerLib/* AWM.updateSetting */.b.updateSetting;
/* harmony default export */ const GridFormLockPasswordSettingvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'GridFormLockPasswordSetting',
    components: {
        GridSpace: GridSpace/* default */.Z,
        GridForm: GridForm/* default */.Z,
        AccessPasswordInputModal: AccessPasswordInputModal/* default */.Z,
        GFEPassword: GFEPassword/* default */.Z,
        GFEOldPassword: GFEOldPassword/* default */.Z,
        GFERepeatPassword: GFERepeatPassword/* default */.Z,
        GridButtonSecondary: GridButtonSecondary/* default */.Z
    },
    emits: ['submit'],
    props: {
        textId: { type: String, default: '' },
        saving: { type: Boolean, required: false, default: false },
        skipValidation: { type: Boolean, default: true }
    },
    setup(props, context) {
        const { it } = (0,useTranslation/* useTranslation */.$)();
        const { isActiveWalletLocked, activeWalletId, activeWalletData, isActiveWalletPreparing, isActiveWalletSyncing } = (0,useActiveWallet/* useActiveWallet */.r)();
        const $q = (0,use_quasar/* default */.Z)();
        const resetCounter = (0,reactivity_esm_bundler/* ref */.iH)(0);
        const submittable = (0,reactivity_esm_bundler/* reactive */.qj)({
            oldPassword: false,
            lockPassword: false,
            repeatPassword: false
        });
        const errors = (0,reactivity_esm_bundler/* reactive */.qj)({
            oldPassword: false,
            lockPassword: false,
            repeatPassword: false
        });
        const showPasswordModal = (0,reactivity_esm_bundler/* ref */.iH)(false);
        let savedValue = null;
        // Current encrypted wallet, used for checking encryption password
        // const currentEncryptedWallet              = ref(activeWallet.value!.dbEntry.encryptedWallet)
        // Currently stored lock password from settings
        const currentLockPassword = (0,reactivity_esm_bundler/* ref */.iH)(activeWalletData.value ? ((0,WalletLib/* getSetting */.$8)(activeWalletData.value, 'lockPassword')?.value.password ?? false) : false);
        (0,runtime_core_esm_bundler/* watchEffect */.m0)(() => {
            if (activeWalletId.value) {
                currentLockPassword.value = (activeWalletData.value ? ((0,WalletLib/* getSetting */.$8)(activeWalletData.value, 'lockPassword')?.value.password ?? false) : false);
            }
        });
        //The new lock password that a user can enter
        const lockPassword = (0,reactivity_esm_bundler/* ref */.iH)('');
        // Old password user can enter
        const oldLockPassword = (0,reactivity_esm_bundler/* ref */.iH)('');
        async function onSetOldLockPassword(payload) {
            submittable.oldPassword = payload.submittable;
            errors.oldPassword = payload.error;
            if (submittable.oldPassword) {
                oldLockPassword.value = payload.password;
            }
        }
        async function onSetRepeatPassword(payload) {
            submittable.repeatPassword = payload.submittable;
            errors.repeatPassword = payload.error;
        }
        function onSetLockPassword(payload) {
            submittable.lockPassword = payload.submittable;
            errors.lockPassword = payload.error;
            if (submittable.lockPassword) {
                lockPassword.value = payload.password;
            }
        }
        async function onSubmit() {
            if (activeWalletId.value && activeWalletData.value) {
                try {
                    //Save old password for temporary backup reasons
                    const oldPW = (await (0,WalletLib/* getSetting */.$8)(activeWalletData.value, 'lockPassword'))?.value.password ?? null;
                    if (oldPW !== null) {
                        // check if password is correct
                        const passwordIsCorrect = await checkPassword(activeWalletId.value, oldLockPassword.value);
                        if (!passwordIsCorrect) {
                            notifyUpdate(false, it('wallet.settings.accessPassword.pwCheckFailed'));
                            return;
                        }
                    }
                    const successSaveLockSetting = await saveSetting('lockPassword', true, { password: lockPassword.value });
                    if (!successSaveLockSetting) {
                        //Could not save password setting
                        await saveSetting('lockPassword', true, { password: oldPW });
                        notifyUpdate(false, it('wallet.settings.accessPassword.settingsNotSaved'));
                        return;
                    }
                    // const await check
                    const successUpdateLock = await updateLockPassword(activeWalletId.value, {
                        password: lockPassword.value
                    });
                    if (successUpdateLock) {
                        notifyUpdate(successSaveLockSetting, it('wallet.settings.accessPassword.updateSuccess'));
                        currentLockPassword.value = successSaveLockSetting;
                    }
                    else {
                        notifyUpdate(false, it('wallet.settings.accessPassword.noPwUpdate'));
                        return;
                    }
                    onReset();
                }
                catch (e) {
                    if (e.name === 'WrongUnlockPasswordError') {
                        notifyUpdate(false, e.message);
                    }
                    else {
                        notifyUpdate(false);
                    }
                }
            }
            else {
                notifyUpdate(false);
            }
        }
        /**
         * Save a setting to global setting store.
         *
         * @param setting
         * @param enabled
         * @param newValue
         */
        async function saveSetting(setting, enabled, newValue) {
            if (!activeWalletId.value || !activeWalletData.value) {
                return false;
            }
            const value = newValue ?? JSON.parse(JSON.stringify((0,WalletLib/* getSetting */.$8)(activeWalletData.value, setting)?.value ?? {}));
            return await updateSetting(activeWalletId.value, { setting, value: { enabled, value } });
        }
        function onReset() {
            resetCounter.value = resetCounter.value + 1;
        }
        const submitEnabled = (0,runtime_core_esm_bundler/* computed */.Fl)(() => ((!errors.lockPassword &&
            !errors.oldPassword &&
            !errors.repeatPassword)
            &&
                ((!currentLockPassword || (currentLockPassword && submittable.lockPassword)) &&
                    submittable.lockPassword &&
                    submittable.repeatPassword)));
        /**
         * Relocks the wallet with current set password.
         */
        async function relockWallet() {
            if (!activeWalletId.value) {
                return;
            }
            if (!isActiveWalletLocked.value) {
                if (currentLockPassword) {
                    const success = await doRelockWallet(activeWalletId.value);
                    if (!success) {
                        notifyUpdate(false, it('wallet.settings.accessPassword.unableToLock'));
                    }
                    else {
                        notifyUpdate(true, it('wallet.settings.accessPassword.locked'));
                    }
                }
                else {
                    notifyUpdate(false, it('wallet.settings.accessPassword.noLockSet'));
                }
            }
            else {
                notifyUpdate(true, it('wallet.settings.accessPassword.alreadyLocked'));
            }
        }
        const removeLockWallet = async (payload) => {
            if (!activeWalletId.value) {
                return;
            }
            if (!isActiveWalletLocked.value) {
                try {
                    if (!activeWalletId.value) {
                        throw new Error('No active wallet.');
                    }
                    let result = await removeWalletLock(activeWalletId.value, payload.password);
                    if (result)
                        showPasswordModal.value = false;
                }
                catch (e) {
                    if (e.name === 'WrongUnlockPasswordError') {
                        notifyUpdate(false, e.message);
                    }
                    else {
                        notifyUpdate(false, it('wallet.settings.accessPassword.removeFailed'));
                    }
                    return;
                }
                const savedSuccess = await saveSetting('lockPassword', false, { password: null });
                if (savedSuccess) {
                    notifyUpdate(true, it('wallet.settings.accessPassword.removeSuccess'));
                    currentLockPassword.value = false;
                }
                else {
                    notifyUpdate(false);
                }
            }
        };
        function notifyUpdate(success, message) {
            $q.notify({
                type: (success ? 'positive' : 'negative'),
                message: message ? message : it('wallet.settings.message.' + (success ? 'success' : 'failed')),
                position: 'top-left'
            });
        }
        const doShowPasswordModal = () => {
            showPasswordModal.value = true;
        };
        const closeModal = () => {
            showPasswordModal.value = false;
            const oldPwInput = document.getElementById('oldPassword');
            oldPwInput && oldPwInput.focus();
        };
        return {
            it,
            submittable,
            submitEnabled,
            resetCounter,
            // currentEncryptedWallet,
            lockPassword,
            currentLockPassword,
            isActiveWalletSyncing,
            isActiveWalletPreparing,
            onSetOldLockPassword,
            onSetLockPassword,
            onSetRepeatPassword,
            relockWallet,
            removeLockWallet,
            doShowPasswordModal,
            showPasswordModal,
            closeModal,
            onSubmit,
            onReset
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/forms/GridFormLockPasswordSetting.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/forms/GridFormLockPasswordSetting.vue




;
const GridFormLockPasswordSetting_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(GridFormLockPasswordSettingvue_type_script_lang_ts, [['render',GridFormLockPasswordSettingvue_type_template_id_53550263_ts_true_render]])

/* harmony default export */ const GridFormLockPasswordSetting = (GridFormLockPasswordSetting_exports_);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/icons/IconWarning.vue + 4 modules
var IconWarning = __webpack_require__(97515);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/settings/SettingsItem.vue + 4 modules
var SettingsItem = __webpack_require__(78150);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/settings/ForceWalletResync.vue?vue&type=template&id=a47cbb34&ts=true

function ForceWalletResyncvue_type_template_id_a47cbb34_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridText = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridText");
    const _component_GridButtonSecondary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonSecondary");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, [
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
            text: _ctx.t(_ctx.textId + '.info')
        }, null, 8, ["text"]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonSecondary, {
            class: "col-span-12 xs:col-span-8 sm:col-span-6 xl:col-span-4",
            link: _ctx.resyncWallet,
            label: _ctx.t(_ctx.textId + '.button.resync.label'),
            icon: _ctx.t(_ctx.textId + '.button.resync.icon')
        }, null, 8, ["link", "label", "icon"])
    ], 64));
}

;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/settings/ForceWalletResync.vue?vue&type=script&lang=ts








const resyncAppWallet = ExtAppWalletManagerLib/* AWM.resyncAppWallet */.b.resyncAppWallet;
/* harmony default export */ const ForceWalletResyncvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'ForceWalletResync',
    components: {
        GridText: GridText/* default */.Z,
        GridSpace: GridSpace/* default */.Z,
        GridButtonSecondary: GridButtonSecondary/* default */.Z,
        GridHeadline: GridHeadline/* default */.Z
    },
    props: {
        textId: { type: String, required: false, default: 'wallet.settings.resync' }
    },
    setup() {
        const { t } = (0,useTranslation/* useTranslation */.$)();
        const { activeWalletId } = (0,useActiveWallet/* useActiveWallet */.r)();
        function resyncWallet() {
            if (activeWalletId.value) {
                resyncAppWallet(activeWalletId.value);
            }
        }
        return {
            t,
            resyncWallet
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/settings/ForceWalletResync.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/settings/ForceWalletResync.vue




;
const ForceWalletResync_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(ForceWalletResyncvue_type_script_lang_ts, [['render',ForceWalletResyncvue_type_template_id_a47cbb34_ts_true_render]])

/* harmony default export */ const ForceWalletResync = (ForceWalletResync_exports_);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/settings/UnlockWallet.vue?vue&type=template&id=32868b07&ts=true

const UnlockWalletvue_type_template_id_32868b07_ts_true_hoisted_1 = { class: "w-full col-span-12 grid grid-cols-12 cc-gap" };
const UnlockWalletvue_type_template_id_32868b07_ts_true_hoisted_2 = { class: "col-span-12 lg:col-span-6 grid grid-cols-12 cc-gap" };
function UnlockWalletvue_type_template_id_32868b07_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_AccessPasswordInputModal = (0,runtime_core_esm_bundler/* resolveComponent */.up)("AccessPasswordInputModal");
    const _component_GridHeadline = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridHeadline");
    const _component_GridText = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridText");
    const _component_GridButtonSecondary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonSecondary");
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, [
        (_ctx.showPasswordModal)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_AccessPasswordInputModal, {
                key: 0,
                "show-modal": _ctx.showPasswordModal,
                title: _ctx.it('wallet.settings.accessPassword.labelUnlock'),
                caption: _ctx.it('wallet.settings.accessPassword.captionUnlock'),
                "submit-button-label": _ctx.it('common.label.unlock'),
                autofocus: true,
                onClose: _cache[0] || (_cache[0] = ($event) => (_ctx.showPasswordModal = false)),
                onSubmit: _ctx.onPasswordSubmit
            }, null, 8, ["show-modal", "title", "caption", "submit-button-label", "onSubmit"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", UnlockWalletvue_type_template_id_32868b07_ts_true_hoisted_1, [
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                label: _ctx.t(_ctx.textId + '.headline')
            }, null, 8, ["label"]),
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                text: _ctx.t(_ctx.textId + '.caption')
            }, null, 8, ["text"]),
            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", UnlockWalletvue_type_template_id_32868b07_ts_true_hoisted_2, [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonSecondary, {
                    class: "col-span-12 xs:col-span-8 lg:col-span-9",
                    link: _ctx.showUnlockWallet,
                    label: _ctx.t(_ctx.textId + '.button.unlock.label'),
                    icon: _ctx.t(_ctx.textId + '.button.unlock.icon')
                }, null, 8, ["link", "label", "icon"])
            ]),
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, {
                hr: "",
                class: "my-0.5 sm:my-2"
            })
        ])
    ], 64));
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/settings/UnlockWallet.vue?vue&type=template&id=32868b07&ts=true

;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/settings/UnlockWallet.vue?vue&type=script&lang=ts

;









const toggleLockWallet = ExtAppWalletManagerLib/* AWM.toggleLockWallet */.b.toggleLockWallet;
/* harmony default export */ const UnlockWalletvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'UnlockWallet',
    components: {
        GridText: GridText/* default */.Z,
        GridSpace: GridSpace/* default */.Z,
        GridButtonSecondary: GridButtonSecondary/* default */.Z,
        GridHeadline: GridHeadline/* default */.Z,
        AccessPasswordInputModal: AccessPasswordInputModal/* default */.Z
    },
    props: {
        textId: { type: String, required: false, default: 'wallet.settings.unlock' }
    },
    setup() {
        const { t, it } = (0,useTranslation/* useTranslation */.$)();
        const { openWallet } = (0,useNavigation/* useNavigation */.HJ)();
        const { isActiveWalletLocked, activeWalletId } = (0,useActiveWallet/* useActiveWallet */.r)();
        const $q = (0,use_quasar/* default */.Z)();
        const showPasswordModal = (0,reactivity_esm_bundler/* ref */.iH)(false);
        function showUnlockWallet() {
            showPasswordModal.value = true;
        }
        async function onPasswordSubmit(payload) {
            if (activeWalletId.value) {
                if (isActiveWalletLocked.value) {
                    const success = activeWalletId.value ? await toggleLockWallet(activeWalletId.value, payload.password) : false;
                    if (!success) {
                        $q.notify({
                            type: 'negative',
                            message: t('wallet.settings.accessPassword.wrongPassword'),
                            position: 'top-left',
                            timeout: 2000
                        });
                    }
                    else {
                        const stop = (0,runtime_core_esm_bundler/* watch */.YP)(isActiveWalletLocked, (locked, oldLocked) => {
                            if (oldLocked && !locked) {
                                stop();
                                if (activeWalletId.value) {
                                    openWallet(activeWalletId.value);
                                }
                            }
                        });
                        $q.notify({
                            type: 'positive',
                            message: t('wallet.settings.accessPassword.unlocked'),
                            position: 'top-left',
                            timeout: 2000
                        });
                    }
                }
            }
        }
        return {
            t,
            it,
            showUnlockWallet,
            onPasswordSubmit,
            showPasswordModal,
            activeWalletId
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/settings/UnlockWallet.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/settings/UnlockWallet.vue




;
const UnlockWallet_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(UnlockWalletvue_type_script_lang_ts, [['render',UnlockWalletvue_type_template_id_32868b07_ts_true_render]])

/* harmony default export */ const UnlockWallet = (UnlockWallet_exports_);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/settings/ExportWalletJson.vue?vue&type=template&id=189424e8&ts=true

const ExportWalletJsonvue_type_template_id_189424e8_ts_true_hoisted_1 = { class: "w-full col-span-12 sm:col-span-6" };
const ExportWalletJsonvue_type_template_id_189424e8_ts_true_hoisted_2 = { class: "inline grid grid-cols-12 cc-gap" };
function ExportWalletJsonvue_type_template_id_189424e8_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridHeadline = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridHeadline");
    const _component_GridText = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridText");
    const _component_GridButtonSecondary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonSecondary");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", ExportWalletJsonvue_type_template_id_189424e8_ts_true_hoisted_1, [
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", ExportWalletJsonvue_type_template_id_189424e8_ts_true_hoisted_2, [
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                label: _ctx.t(_ctx.textId + '.json.headline')
            }, null, 8, ["label"]),
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                text: _ctx.t(_ctx.textId + '.json.caption')
            }, null, 8, ["text"]),
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonSecondary, {
                class: "col-span-12 xs:col-span-8 lg:col-span-9 h-10",
                link: _ctx.exportWallet,
                label: _ctx.t(_ctx.textId + '.json.button.label'),
                icon: _ctx.t(_ctx.textId + '.json.button.icon')
            }, null, 8, ["link", "label", "icon"])
        ])
    ]));
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/settings/ExportWalletJson.vue?vue&type=template&id=189424e8&ts=true

// EXTERNAL MODULE: ./src/composables/ccw/useDownload.ts
var useDownload = __webpack_require__(22510);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/settings/ExportWalletJson.vue?vue&type=script&lang=ts









const ExportWalletJsonvue_type_script_lang_ts_toggleLockWallet = ExtAppWalletManagerLib/* AWM.toggleLockWallet */.b.toggleLockWallet;
/* harmony default export */ const ExportWalletJsonvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'ExportWalletJson',
    components: {
        GridText: GridText/* default */.Z,
        GridSpace: GridSpace/* default */.Z,
        GridButtonSecondary: GridButtonSecondary/* default */.Z,
        GridHeadline: GridHeadline/* default */.Z
    },
    props: {
        textId: { type: String, required: false, default: 'wallet.settings.exports' }
    },
    setup() {
        const { t } = (0,useTranslation/* useTranslation */.$)();
        const { downloadJSON } = (0,useDownload/* useDownload */.i)();
        const { activeWalletId } = (0,useActiveWallet/* useActiveWallet */.r)();
        async function exportWallet() {
            if (activeWalletId.value) {
                downloadJSON(activeWalletId.value);
            }
        }
        return {
            t,
            exportWallet
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/settings/ExportWalletJson.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/settings/ExportWalletJson.vue




;
const ExportWalletJson_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(ExportWalletJsonvue_type_script_lang_ts, [['render',ExportWalletJsonvue_type_template_id_189424e8_ts_true_render]])

/* harmony default export */ const ExportWalletJson = (ExportWalletJson_exports_);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/settings/ExportAccountPubKey.vue?vue&type=template&id=35ff0668&ts=true

const ExportAccountPubKeyvue_type_template_id_35ff0668_ts_true_hoisted_1 = { class: "w-full col-span-12 sm:col-span-6 grid grid-cols-12 cc-gap" };
const ExportAccountPubKeyvue_type_template_id_35ff0668_ts_true_hoisted_2 = { class: "grow-0 shrink-0 w-full flex flex-row flex-nowrap items-start justify-between border-b cc-p" };
const ExportAccountPubKeyvue_type_template_id_35ff0668_ts_true_hoisted_3 = { class: "flex flex-col cc-text-sz" };
const ExportAccountPubKeyvue_type_template_id_35ff0668_ts_true_hoisted_4 = { class: "flex flex-col content-center items-center justify-center p-4" };
const ExportAccountPubKeyvue_type_template_id_35ff0668_ts_true_hoisted_5 = {
    ref: "canvasRef",
    width: "212",
    height: "212",
    class: "shadow cc-rounded mb-4"
};
function ExportAccountPubKeyvue_type_template_id_35ff0668_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridHeadline = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridHeadline");
    const _component_GridText = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridText");
    const _component_GridButtonSecondary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonSecondary");
    const _component_GridTabs = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridTabs");
    const _component_CopyToClipboard = (0,runtime_core_esm_bundler/* resolveComponent */.up)("CopyToClipboard");
    const _component_Modal = (0,runtime_core_esm_bundler/* resolveComponent */.up)("Modal");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", ExportAccountPubKeyvue_type_template_id_35ff0668_ts_true_hoisted_1, [
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
            label: _ctx.t(_ctx.textId + '.accountPub.headline')
        }, null, 8, ["label"]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
            text: _ctx.t(_ctx.textId + '.accountPub.caption'),
            class: "items-start"
        }, null, 8, ["text"]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonSecondary, {
            class: "col-span-12 xs:col-span-8 lg:col-span-9 h-10",
            link: _ctx.exportAccountPubKey,
            label: _ctx.isActiveWalletLocked ? _ctx.t(_ctx.textId + '.accountPub.button.unlock.label') : _ctx.t(_ctx.textId + '.accountPub.button.doexport.label'),
            icon: _ctx.isActiveWalletLocked ? _ctx.t(_ctx.textId + '.accountPub.button.unlock.icon') : _ctx.t(_ctx.textId + '.accountPub.button.doexport.icon')
        }, null, 8, ["link", "label", "icon"]),
        (_ctx.open)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_Modal, {
                key: 0,
                narrow: "",
                "full-width-on-mobile": "",
                onClose: _ctx.onClose
            }, {
                header: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", ExportAccountPubKeyvue_type_template_id_35ff0668_ts_true_hoisted_2, [
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", ExportAccountPubKeyvue_type_template_id_35ff0668_ts_true_hoisted_3, [
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                                label: _ctx.t(_ctx.textId + '.accountPub.hover')
                            }, null, 8, ["label"])
                        ])
                    ])
                ]),
                content: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", ExportAccountPubKeyvue_type_template_id_35ff0668_ts_true_hoisted_4, [
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("canvas", ExportAccountPubKeyvue_type_template_id_35ff0668_ts_true_hoisted_5, null, 512),
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridTabs, {
                            tabs: _ctx.optionsPubFormat,
                            divider: false,
                            onSelection: _ctx.onPubFormatChange,
                            index: _ctx.pubFormat,
                            class: "mt-2"
                        }, {
                            tab0: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => []),
                            tab1: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => []),
                            tab2: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => []),
                            _: 1
                        }, 8, ["tabs", "onSelection", "index"]),
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_CopyToClipboard, {
                            label: _ctx.acctPubKey,
                            "label-hover": _ctx.t(_ctx.textId + '.accountPub.button.copy.hover'),
                            "notification-text": _ctx.t(_ctx.textId + '.accountPub.button.copy.notify'),
                            "copy-text": _ctx.acctPubKey,
                            class: "break-all text-center mt-1 mb-4"
                        }, null, 8, ["label", "label-hover", "notification-text", "copy-text"])
                    ])
                ]),
                _: 1
            }, 8, ["onClose"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
    ]));
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/settings/ExportAccountPubKey.vue?vue&type=template&id=35ff0668&ts=true

// EXTERNAL MODULE: ./node_modules/qrcode/lib/browser.js
var browser = __webpack_require__(25549);
// EXTERNAL MODULE: ./src/components/ccw/modal/Modal.vue + 4 modules
var Modal = __webpack_require__(61017);
// EXTERNAL MODULE: ./src/components/ccw/common/CopyToClipboard.vue + 3 modules
var CopyToClipboard = __webpack_require__(85243);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridTabs.vue + 4 modules
var GridTabs = __webpack_require__(49510);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/CSLUtils.ts
var CSLUtils = __webpack_require__(58173);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/settings/ExportAccountPubKey.vue?vue&type=script&lang=ts

;







const ExportAccountPubKeyvue_type_script_lang_ts_toggleLockWallet = ExtAppWalletManagerLib/* AWM.toggleLockWallet */.b.toggleLockWallet;
//@ts-ignore





/* harmony default export */ const ExportAccountPubKeyvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'ExportAccountPubKey',
    components: {
        GridText: GridText/* default */.Z,
        GridSpace: GridSpace/* default */.Z,
        GridButtonSecondary: GridButtonSecondary/* default */.Z,
        GridHeadline: GridHeadline/* default */.Z,
        CopyToClipboard: CopyToClipboard/* default */.Z,
        Modal: Modal/* default */.Z,
        GridTabs: GridTabs/* default */.Z
    },
    props: {
        textId: { type: String, required: false, default: 'wallet.settings.exports' }
    },
    setup() {
        const { t } = (0,useTranslation/* useTranslation */.$)();
        const $q = (0,use_quasar/* default */.Z)();
        const { isActiveWalletLocked, activeWalletId, activeAccount } = (0,useActiveWallet/* useActiveWallet */.r)();
        const open = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const acctPubKey = (0,reactivity_esm_bundler/* ref */.iH)('');
        const canvasRef = (0,reactivity_esm_bundler/* ref */.iH)(null);
        const optionsPubFormat = (0,reactivity_esm_bundler/* reactive */.qj)([
            { id: 'acct_xvk', label: 'acct_xvk', hover: 'Ed25519-bip32 extended public key', index: 0 },
            { id: 'xpub', label: 'xpub', hover: 'Ed25519-bip32 extended public key', index: 1 },
            { id: 'acct_vk', label: 'acct_vk', hover: 'Ed25519 public key', index: 2 }
        ]);
        const pubFormat = (0,reactivity_esm_bundler/* ref */.iH)(1);
        function onPubFormatChange(index) {
            pubFormat.value = index;
            exportAccountPubKey();
        }
        const generateMarker = (addr) => {
            browser.toCanvas(canvasRef.value, addr, function (error) {
                if (error)
                    console.error(error);
            });
        };
        async function exportAccountPubKey() {
            if (activeWalletId.value) {
                if (!isActiveWalletLocked.value) {
                    if (activeAccount.value) {
                        const index = open.value ? pubFormat.value : 0;
                        switch (index) {
                            case 0:
                                acctPubKey.value = (0,CSLUtils/* getXvkFromXpub */.qT)(activeAccount.value.pub);
                                break;
                            case 1:
                                acctPubKey.value = activeAccount.value.pub;
                                break;
                            case 2:
                                acctPubKey.value = (0,CSLUtils/* getVkFromXpub */.XF)(activeAccount.value.pub);
                                break;
                        }
                        open.value = true;
                        (0,runtime_core_esm_bundler/* nextTick */.Y3)(() => {
                            generateMarker(acctPubKey.value);
                            pubFormat.value = index;
                        });
                    }
                }
            }
        }
        const onClose = () => {
            open.value = false;
        };
        return {
            t,
            optionsPubFormat,
            pubFormat,
            onPubFormatChange,
            isActiveWalletLocked,
            exportAccountPubKey,
            open,
            onClose,
            canvasRef,
            generateMarker,
            acctPubKey
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/settings/ExportAccountPubKey.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/settings/ExportAccountPubKey.vue




;
const ExportAccountPubKey_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(ExportAccountPubKeyvue_type_script_lang_ts, [['render',ExportAccountPubKeyvue_type_template_id_35ff0668_ts_true_render]])

/* harmony default export */ const ExportAccountPubKey = (ExportAccountPubKey_exports_);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/settings/ExportCSV.vue + 6 modules
var ExportCSV = __webpack_require__(6653);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/settings/DeleteWallet.vue?vue&type=template&id=3d955a9a&ts=true

function DeleteWalletvue_type_template_id_3d955a9a_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridHeadline = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridHeadline");
    const _component_GridText = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridText");
    const _component_GridToggle = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridToggle");
    const _component_IconPencil = (0,runtime_core_esm_bundler/* resolveComponent */.up)("IconPencil");
    const _component_GridInput = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridInput");
    const _component_GridButtonWarning = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonWarning");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", {
        class: (0,shared_esm_bundler/* normalizeClass */.C_)(["w-full col-span-12 grid grid-cols-12 cc-gap", _ctx.fullWidth ? '' : 'lg:col-span-6'])
    }, [
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
            label: _ctx.t(_ctx.textId + '.headline')
        }, null, 8, ["label"]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
            text: _ctx.t(_ctx.textId + '.caption')
        }, null, 8, ["text"]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridToggle, {
            label: _ctx.t(_ctx.textId + '.toggle.acknowledged.label'),
            text: _ctx.t(_ctx.textId + '.toggle.acknowledged.text'),
            icon: _ctx.t(_ctx.textId + '.toggle.acknowledged.icon'),
            toggled: _ctx.toggled,
            toggleError: _ctx.toggleError,
            "onUpdate:toggled": _cache[0] || (_cache[0] = ($event) => (_ctx.toggled = $event)),
            class: "col-span-12"
        }, null, 8, ["label", "text", "icon", "toggled", "toggleError"]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridInput, {
            class: "col-span-12 mb-1",
            "input-text": _ctx.searchInput,
            "onUpdate:input-text": _cache[1] || (_cache[1] = ($event) => ((_ctx.searchInput) = $event)),
            "input-error": _ctx.searchInputError,
            "onUpdate:input-error": _cache[2] || (_cache[2] = ($event) => ((_ctx.searchInputError) = $event)),
            onLostFocus: _ctx.validateSearchInput,
            onEnter: _cache[3] || (_cache[3] = ($event) => { _ctx.validateSearchInput(); _ctx.onDeleteWallet(); }),
            onReset: _cache[4] || (_cache[4] = ($event) => (_ctx.onReset())),
            label: _ctx.t(_ctx.textId + '.name.label'),
            "input-hint": _ctx.t(_ctx.textId + '.name.hint'),
            "input-info": _ctx.t(_ctx.textId + '.name.info'),
            alwaysShowInfo: false,
            "input-id": "searchInput",
            "input-type": "text",
            autocomplete: "name",
            inputDisabled: _ctx.searchDisabled,
            "show-reset": true,
            "dense-input": ""
        }, {
            "icon-prepend": (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_IconPencil, { class: "h-5 w-5" })
            ]),
            _: 1
        }, 8, ["input-text", "input-error", "onLostFocus", "label", "input-hint", "input-info", "inputDisabled"]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonWarning, {
            class: "col-span-12 xs:col-span-8 lg:col-span-9",
            link: _ctx.onDeleteWallet,
            disabled: !_ctx.toggled || !_ctx.isCorrectName,
            label: _ctx.t(_ctx.textId + '.button.delete.label'),
            icon: _ctx.t(_ctx.textId + '.button.delete.icon')
        }, null, 8, ["link", "disabled", "label", "icon"])
    ], 2));
}

// EXTERNAL MODULE: ./src/composables/ccw/store/useWalletList.ts
var useWalletList = __webpack_require__(4905);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridToggle.vue + 3 modules
var GridToggle = __webpack_require__(68805);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/settings/DeleteWallet.vue?vue&type=script&lang=ts



;











const deleteWallet = ExtAppWalletManagerLib/* AWM.deleteWallet */.b.deleteWallet;
const DeleteWalletvue_type_script_lang_ts_toggleLockWallet = ExtAppWalletManagerLib/* AWM.toggleLockWallet */.b.toggleLockWallet;

/* harmony default export */ const DeleteWalletvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'DeleteWallet',
    components: {
        IconPencil: IconPencil/* default */.Z,
        GridText: GridText/* default */.Z,
        GridSpace: GridSpace/* default */.Z,
        GridToggle: GridToggle/* default */.Z,
        GridButtonWarning: GridButtonWarning/* default */.Z,
        GridHeadline: GridHeadline/* default */.Z,
        GridInput: GridInput/* default */.Z
    },
    props: {
        textId: { type: String, required: false, default: 'wallet.settings.deldereg.deletewallet' },
        fullWidth: { type: Boolean, required: false, default: false }
    },
    setup(props) {
        const { t } = (0,useTranslation/* useTranslation */.$)();
        const { gotoWalletList } = (0,useNavigation/* useNavigation */.HJ)();
        const { reloadWalletList } = (0,useWalletList/* useWalletList */.M)();
        const { isActiveWalletLocked, activeWalletName, activeWalletId } = (0,useActiveWallet/* useActiveWallet */.r)();
        const $q = (0,use_quasar/* default */.Z)();
        const toggled = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const isCorrectName = (0,reactivity_esm_bundler/* ref */.iH)(false);
        async function onDeleteWallet() {
            const isCorrectName = activeWalletName.value && searchInput.value === activeWalletName.value;
            if (activeWalletId.value && isCorrectName && toggled.value) {
                // if(isActiveWalletLocked.value) {
                //
                //   $q.dialog({
                //
                //     title: 'Prompt',
                //     message: 'Enter the wallet login password to delete the wallet.',
                //     prompt: {
                //       model: '',
                //       isValid: (val: any) => { return true },
                //       type: 'password' // optional
                //     },
                //     cancel: true,
                //     persistent: false
                //
                //   }).onOk(async (data: string) => {
                //
                //     const success = activeWalletId.value ? await toggleLockWallet(activeWalletId.value, (data?.length ?? 0) > 0 ? data : null) : false
                //
                //     if(!success) {
                //
                //       $q.notify({
                //
                //         type:               'negative',
                //         message:            'You entered a wrong wallet login password.',
                //         position:           'top-left',
                //         timeout:            2000
                //       })
                //
                //     } else {
                //
                //       activeWalletId.value ? await deleteWallet(activeWalletId.value) : false
                //
                //       gotoWalletList()
                //
                //       reloadWalletList()
                //
                //       $q.notify({
                //
                //         type:               'positive',
                //         message:            'Wallet deleted.',
                //         position:           'top-left',
                //         timeout:            2000
                //       })
                //     }
                //   })
                //
                // } else {
                activeWalletId.value ? await deleteWallet(activeWalletId.value) : false;
                gotoWalletList();
                reloadWalletList();
                // }
            }
            if (!isCorrectName) {
                searchInputError.value = t(props.textId + '.name.error');
            }
            toggleError.value = !toggled.value;
        }
        const searchInput = (0,reactivity_esm_bundler/* ref */.iH)('');
        const searchInputError = (0,reactivity_esm_bundler/* ref */.iH)('');
        const searchInputInfo = (0,reactivity_esm_bundler/* ref */.iH)('info');
        const searchDisabled = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const toggleError = (0,reactivity_esm_bundler/* ref */.iH)(false);
        function validateSearchInput(external) {
            if (activeWalletName.value) {
                isCorrectName.value = searchInput.value.trim() === activeWalletName.value.trim();
                if (!isCorrectName.value && searchInput.value !== '') {
                    searchInputError.value = t(props.textId + '.name.error');
                }
                else {
                    searchInputError.value = '';
                }
            }
            else {
                searchInputError.value = '';
            }
            return searchInputError.value;
        }
        function onReset() {
            searchInput.value = '';
            searchInputError.value = '';
        }
        (0,runtime_core_esm_bundler/* watchEffect */.m0)(() => {
            if (toggled.value) {
                toggleError.value = false;
            }
            else {
                searchInputError.value = '';
            }
            searchDisabled.value = !toggled.value;
        });
        let tosp = -1;
        // watch(searchInput,        () => { clearTimeout(tosp); tosp = setTimeout(() => validateSearchInput(false), 250) })
        (0,runtime_core_esm_bundler/* watch */.YP)(searchInput, () => { validateSearchInput(false); });
        return {
            t,
            toggled,
            onDeleteWallet,
            onReset,
            searchInput,
            searchInputError,
            searchInputInfo,
            searchDisabled,
            validateSearchInput,
            toggleError,
            isCorrectName
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/settings/DeleteWallet.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/settings/DeleteWallet.vue




;
const DeleteWallet_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(DeleteWalletvue_type_script_lang_ts, [['render',DeleteWalletvue_type_template_id_3d955a9a_ts_true_render]])

/* harmony default export */ const DeleteWallet = (DeleteWallet_exports_);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/settings/DeregisterWallet.vue?vue&type=template&id=35242a8e&ts=true

const DeregisterWalletvue_type_template_id_35242a8e_ts_true_hoisted_1 = {
    key: 0,
    class: "w-full col-span-12 lg:col-span-6 grid grid-cols-12 auto-rows-min cc-gap"
};
function DeregisterWalletvue_type_template_id_35242a8e_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridHeadline = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridHeadline");
    const _component_GridText = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridText");
    const _component_GridToggle = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridToggle");
    const _component_GridButtonWarning = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonWarning");
    return (_ctx.isRegistered)
        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", DeregisterWalletvue_type_template_id_35242a8e_ts_true_hoisted_1, [
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                label: _ctx.t(_ctx.textId + '.headline')
            }, null, 8, ["label"]),
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                text: _ctx.t(_ctx.textId + '.caption')
            }, null, 8, ["text"]),
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridToggle, {
                label: _ctx.t(_ctx.textId + '.toggle.acknowledged.label'),
                text: _ctx.toggleError ? _ctx.t(_ctx.textId + '.toggle.acknowledged.noutxo')
                    : _ctx.t(_ctx.textId + '.toggle.acknowledged.text'),
                icon: _ctx.t(_ctx.textId + '.toggle.acknowledged.icon'),
                toggled: _ctx.toggled,
                toggleError: _ctx.toggleError,
                "onUpdate:toggled": _cache[0] || (_cache[0] = ($event) => (_ctx.toggled = $event)),
                class: "col-span-12"
            }, null, 8, ["label", "text", "icon", "toggled", "toggleError"]),
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonWarning, {
                class: "col-span-12 xs:col-span-8 lg:col-span-9 mt-1",
                link: _ctx.onDeregisterWallet,
                disabled: !_ctx.toggled || !_ctx.hasUTxOs,
                label: _ctx.t(_ctx.textId + '.button.dereg.label'),
                icon: _ctx.t(_ctx.textId + '.button.dereg.icon')
            }, null, 8, ["link", "disabled", "label", "icon"])
        ]))
        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true);
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/settings/DeregisterWallet.vue?vue&type=template&id=35242a8e&ts=true

// EXTERNAL MODULE: ./src/composables/ccw/store/useBuildTx_v3.ts + 1 modules
var useBuildTx_v3 = __webpack_require__(72107);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/AccountLib.ts
var AccountLib = __webpack_require__(19276);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/settings/DeregisterWallet.vue?vue&type=script&lang=ts



;








/* harmony default export */ const DeregisterWalletvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'DeregisterWallet',
    components: {
        GridText: GridText/* default */.Z,
        GridSpace: GridSpace/* default */.Z,
        GridToggle: GridToggle/* default */.Z,
        GridButtonWarning: GridButtonWarning/* default */.Z,
        GridHeadline: GridHeadline/* default */.Z
    },
    props: {
        textId: { type: String, required: false, default: 'wallet.settings.deldereg.deregwallet' }
    },
    setup() {
        const { t } = (0,useTranslation/* useTranslation */.$)();
        const { gotoWalletPage } = (0,useNavigation/* useNavigation */.HJ)();
        const $q = (0,use_quasar/* default */.Z)();
        const { activeWalletData, activeAccount } = (0,useActiveWallet/* useActiveWallet */.r)();
        const { buildDeregistrationTx } = (0,useBuildTx_v3/* useBuildTxV3 */.b)();
        const toggled = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const hasUTxOs = activeAccount.value ? (0,AccountLib/* getAccountUtxoList */.ub)(activeAccount.value).length > 0 : false;
        const isRegistered = activeAccount.value ? activeAccount.value.base.stake.length > 0 && activeAccount.value.base.stake[0].registered : false;
        const toggleError = (0,runtime_core_esm_bundler/* computed */.Fl)(() => toggled.value && !hasUTxOs);
        async function onDeregisterWallet() {
            if (!activeWalletData.value || !activeAccount.value)
                return;
            const res = await buildDeregistrationTx(activeWalletData.value, activeAccount.value);
            if (res.error) {
                $q.notify({
                    type: 'negative',
                    message: res.error,
                    position: 'top-left',
                    timeout: 8000
                });
            }
            else {
                gotoWalletPage('Deregistration');
            }
        }
        return {
            t,
            toggled,
            toggleError,
            onDeregisterWallet,
            isRegistered,
            hasUTxOs
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/settings/DeregisterWallet.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/settings/DeregisterWallet.vue




;
const DeregisterWallet_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(DeregisterWalletvue_type_script_lang_ts, [['render',DeregisterWalletvue_type_template_id_35242a8e_ts_true_render]])

/* harmony default export */ const DeregisterWallet = (DeregisterWallet_exports_);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/settings/AddressBook.vue + 4 modules
var AddressBook = __webpack_require__(23906);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/settings/Collateral.vue?vue&type=template&id=3a9231a8&ts=true

const Collateralvue_type_template_id_3a9231a8_ts_true_hoisted_1 = { class: "col-span-full" };
const Collateralvue_type_template_id_3a9231a8_ts_true_hoisted_2 = {
    key: 0,
    class: "col-span-12 grid grid-cols-12"
};
const Collateralvue_type_template_id_3a9231a8_ts_true_hoisted_3 = { class: "col-span-12 mb-2" };
const Collateralvue_type_template_id_3a9231a8_ts_true_hoisted_4 = { class: "col-span-6 grid grid grid-cols-12" };
const Collateralvue_type_template_id_3a9231a8_ts_true_hoisted_5 = {
    key: 1,
    class: "col-span-12"
};
const Collateralvue_type_template_id_3a9231a8_ts_true_hoisted_6 = {
    key: 2,
    class: "col-span-12 mt-3"
};
const Collateralvue_type_template_id_3a9231a8_ts_true_hoisted_7 = { class: "col-span-12 p-2 grid grid-cols-12 cc-gap ring-2 ring-yellow-500 cc-rounded mb-2 mt-3" };
const Collateralvue_type_template_id_3a9231a8_ts_true_hoisted_8 = { class: "col-span-12 flex flex-row flex-nowrap whitespace-pre-wrap text-yellow-500 cc-text-bold" };
const Collateralvue_type_template_id_3a9231a8_ts_true_hoisted_9 = { class: "col-span-12" };
const Collateralvue_type_template_id_3a9231a8_ts_true_hoisted_10 = { key: 0 };
const Collateralvue_type_template_id_3a9231a8_ts_true_hoisted_11 = { class: "italic underline" };
const Collateralvue_type_template_id_3a9231a8_ts_true_hoisted_12 = { class: "mt-3" };
const Collateralvue_type_template_id_3a9231a8_ts_true_hoisted_13 = { class: "mt-3" };
const _hoisted_14 = { class: "mt-3" };
function Collateralvue_type_template_id_3a9231a8_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridButtonSecondary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonSecondary");
    const _component_GridAccountUtxoItem = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridAccountUtxoItem");
    const _component_GridTextArea = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridTextArea");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", Collateralvue_type_template_id_3a9231a8_ts_true_hoisted_1, [
        (!_ctx.collateralUtxo)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", Collateralvue_type_template_id_3a9231a8_ts_true_hoisted_2, [
                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", Collateralvue_type_template_id_3a9231a8_ts_true_hoisted_3, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.settings.collateral.noCollateral')), 1),
                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", Collateralvue_type_template_id_3a9231a8_ts_true_hoisted_4, [
                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonSecondary, {
                        label: _ctx.t('wallet.settings.collateral.button'),
                        link: _ctx.setCollateral,
                        class: "col-span-9"
                    }, null, 8, ["label", "link"])
                ])
            ]))
            : ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", Collateralvue_type_template_id_3a9231a8_ts_true_hoisted_5, [
                (0,runtime_core_esm_bundler/* createTextVNode */.Uk)((0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.settings.collateral.foundCollateral')) + " ", 1),
                (_ctx.collateralItem)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridAccountUtxoItem, {
                        key: 0,
                        class: "col-span-12 cc-text-sz mt-2",
                        "utxo-item": _ctx.collateralItem,
                        "is-collateral": true
                    }, null, 8, ["utxo-item"]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
            ])),
        (_ctx.hasBuildError)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", Collateralvue_type_template_id_3a9231a8_ts_true_hoisted_6, [
                (_ctx.hasBuildError)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridTextArea, {
                        key: 0,
                        label: _ctx.t('wallet.settings.collateral.error.label'),
                        text: _ctx.buildErrorMsg,
                        icon: _ctx.t('wallet.settings.collateral.error.icon'),
                        class: "col-span-12 mt-2 sm:mt-4",
                        "text-c-s-s": "cc-text-normal text-justify flex justify-start items-center",
                        css: "cc-rounded cc-banner-warning"
                    }, null, 8, ["label", "text", "icon"]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
            ]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", Collateralvue_type_template_id_3a9231a8_ts_true_hoisted_7, [
            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", Collateralvue_type_template_id_3a9231a8_ts_true_hoisted_8, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.settings.collateral.multiAccount.warning.note')), 1),
            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", Collateralvue_type_template_id_3a9231a8_ts_true_hoisted_9, [
                (_ctx.isMultiAccountWallet)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", Collateralvue_type_template_id_3a9231a8_ts_true_hoisted_10, [
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", Collateralvue_type_template_id_3a9231a8_ts_true_hoisted_11, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.settings.collateral.multiAccount.warning.headline')), 1),
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", Collateralvue_type_template_id_3a9231a8_ts_true_hoisted_12, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.settings.collateral.multiAccount.warning.text')), 1)
                    ]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", null, [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", {
                        class: (0,shared_esm_bundler/* normalizeClass */.C_)(_ctx.isMultiAccountWallet ? 'mt-3' : '')
                    }, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.settings.collateral.multiAccount.info.line1')
                        .replace('####minimumCollateral####', _ctx.minimumCollateral)
                        .replace('####maximumCollateral####', _ctx.maximumCollateral)), 3),
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", Collateralvue_type_template_id_3a9231a8_ts_true_hoisted_13, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.settings.collateral.multiAccount.info.line2')
                        .replace('####minimumCollateral####', _ctx.minimumCollateral)), 1),
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_14, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.settings.collateral.multiAccount.info.line3')), 1)
                ])
            ])
        ])
    ]));
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/settings/Collateral.vue?vue&type=template&id=3a9231a8&ts=true

// EXTERNAL MODULE: ./src/composables/ccw/store/useFormatter.ts
var useFormatter = __webpack_require__(16938);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridTextArea.vue + 4 modules
var GridTextArea = __webpack_require__(15660);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/summary/GridAccountUtxoItem.vue + 4 modules
var GridAccountUtxoItem = __webpack_require__(96157);
// EXTERNAL MODULE: ./src/components/ccw/common/Tooltip.vue + 3 modules
var Tooltip = __webpack_require__(30105);
// EXTERNAL MODULE: ./src/components/ccw/common/ExplorerLink.vue + 3 modules
var ExplorerLink = __webpack_require__(61413);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/settings/Collateral.vue?vue&type=script&lang=ts


















/* harmony default export */ const Collateralvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'Collateral',
    components: {
        GridHeadline: GridHeadline/* default */.Z,
        GridText: GridText/* default */.Z,
        GridTextArea: GridTextArea/* default */.Z,
        GridSpace: GridSpace/* default */.Z,
        GridInput: GridInput/* default */.Z,
        GridButtonPrimary: GridButtonPrimary/* default */.Z,
        GridButtonSecondary: GridButtonSecondary/* default */.Z,
        GridAccountUtxoItem: GridAccountUtxoItem/* default */.Z,
        ExplorerLink: ExplorerLink/* default */.Z,
        CopyToClipboard: CopyToClipboard/* default */.Z,
        Tooltip: Tooltip/* default */.Z
    },
    props: {
        label: { type: Boolean, required: false, default: false },
        textId: { type: String, required: false, default: 'wallet.settings.addrbook' },
        readonly: { type: Boolean, required: false, default: false },
        send: { type: Boolean, required: false, default: true },
        globalMode: { type: Boolean, required: false, default: false },
        combined: { type: Boolean, required: false, default: false },
        enableCollateral: { type: Boolean, required: false, default: false },
    },
    setup(props) {
        const { t } = (0,useTranslation/* useTranslation */.$)();
        const { activeWalletData, activeAccount, isMultiAccountWallet, } = (0,useActiveWallet/* useActiveWallet */.r)();
        const { gotoWalletPage } = (0,useNavigation/* useNavigation */.HJ)();
        const { formatADAString } = (0,useFormatter/* useFormatter */.G)();
        const { resetBuildTx, buildCollateralTx } = (0,useBuildTx_v3/* useBuildTxV3 */.b)();
        const minimumCollateral = formatADAString((0,AccountLib/* minCollateral */._0)(activeAccount.value?.network ?? null), true, 0);
        const maximumCollateral = formatADAString((0,AccountLib/* maxCollateral */.Fz)(activeAccount.value?.network ?? null), true, 0);
        const hasBuildError = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const buildErrorMsg = (0,reactivity_esm_bundler/* ref */.iH)('');
        const collateralUtxo = (0,reactivity_esm_bundler/* ref */.iH)(null);
        (0,runtime_core_esm_bundler/* watchEffect */.m0)(async () => {
            const account = activeAccount.value;
            if (account) {
                const accCollateral = (0,AccountLib/* getAccountCollateralListFilteredByPending */.$3)(account, [], props.enableCollateral);
                collateralUtxo.value = accCollateral.length > 0 ? accCollateral[0] : null;
            }
            else {
                collateralUtxo.value = null;
            }
        });
        const setCollateral = async () => {
            if (!activeWalletData.value || !activeAccount.value)
                return;
            resetBuildTx(activeAccount.value.pub);
            let buildError = (await buildCollateralTx(activeWalletData.value, activeAccount.value)).error;
            if (buildError != '') {
                if (buildError.includes('less than the minimum UTXO value')) {
                    const msgAr = buildError.split(' ');
                    if (msgAr.length > 0) {
                        buildError = t('wallet.settings.collateral.error.buildOutput')
                            .replace('####amount####', formatADAString(msgAr[msgAr.length - 1], true))
                            + " " + t('wallet.settings.collateral.error.lowFunds');
                    }
                }
                else if (buildError.includes('insufficient funds.')) {
                    buildError = t('wallet.settings.collateral.error.insufficient');
                }
                hasBuildError.value = true;
                buildErrorMsg.value = buildError;
            }
            else {
                gotoWalletPage('Collateral');
            }
        };
        const collateralItem = (0,runtime_core_esm_bundler/* computed */.Fl)(() => {
            if (collateralUtxo.value) {
                return {
                    bech32: collateralUtxo.value.paymentAddr.bech32,
                    list: [collateralUtxo.value],
                    owned: false
                };
            }
            return null;
        });
        return {
            t,
            setCollateral,
            collateralUtxo,
            collateralItem,
            hasBuildError,
            buildErrorMsg,
            minimumCollateral,
            maximumCollateral,
            isMultiAccountWallet
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/settings/Collateral.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/settings/Collateral.vue




;
const Collateral_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(Collateralvue_type_script_lang_ts, [['render',Collateralvue_type_template_id_3a9231a8_ts_true_render]])

/* harmony default export */ const Collateral = (Collateral_exports_);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/settings/TokenFragmentation.vue?vue&type=template&id=5ed9b688&ts=true

const TokenFragmentationvue_type_template_id_5ed9b688_ts_true_hoisted_1 = { class: "col-span-12 grid grid-cols-12 auto-rows-max cc-gap" };
function TokenFragmentationvue_type_template_id_5ed9b688_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_IconPencil = (0,runtime_core_esm_bundler/* resolveComponent */.up)("IconPencil");
    const _component_GridInput = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridInput");
    const _component_GridText = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridText");
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    const _component_GridForm = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridForm");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridForm, {
        class: "col-span-12 grid grid-cols-12 cc-gap",
        onDoFormReset: _ctx.onReset,
        onDoFormSubmit: _ctx.onSetFragmentation,
        "form-id": "TokenFragmentation",
        "reset-button-label": _ctx.t(_ctx.textId + '.button.default'),
        "submit-button-label": _ctx.t(_ctx.textId + '.button.save'),
        "submit-disabled": !_ctx.validateFragInput || _ctx.saving
    }, {
        content: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", TokenFragmentationvue_type_template_id_5ed9b688_ts_true_hoisted_1, [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridInput, {
                    class: "col-span-12 mt-2 sm:mt-0",
                    "input-text": _ctx.fragInput,
                    "onUpdate:inputText": _ctx.validateFragInput,
                    "input-error": _ctx.fragInputError,
                    "onUpdate:input-error": _cache[0] || (_cache[0] = ($event) => ((_ctx.fragInputError) = $event)),
                    onOnEnter: _ctx.onSetFragmentation,
                    label: _ctx.t(_ctx.textId + '.fragment.label'),
                    alwaysShowInfo: false,
                    "input-id": "fragmentInput",
                    autocomplete: "off"
                }, {
                    "icon-prepend": (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_IconPencil, { class: "h-5 w-5" })
                    ]),
                    _: 1
                }, 8, ["input-text", "onUpdate:inputText", "input-error", "onOnEnter", "label"]),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                    text: _ctx.t(_ctx.textId + '.fragment.info'),
                    class: "p-2 cc-shadow cc-rounded"
                }, null, 8, ["text"])
            ]),
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, { dense: "" })
        ]),
        btnBack: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
            (0,runtime_core_esm_bundler/* renderSlot */.WI)(_ctx.$slots, "btnBack")
        ]),
        _: 3
    }, 8, ["onDoFormReset", "onDoFormSubmit", "reset-button-label", "submit-button-label", "submit-disabled"]));
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/settings/TokenFragmentation.vue?vue&type=template&id=5ed9b688&ts=true

// EXTERNAL MODULE: ../ccw-lib2/core/IWalletSettings.ts
var IWalletSettings = __webpack_require__(11451);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/BigMathLib.ts + 1 modules
var BigMathLib = __webpack_require__(99149);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/settings/TokenFragmentation.vue?vue&type=script&lang=ts













/* harmony default export */ const TokenFragmentationvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'TokenFragmentation',
    components: {
        GridText: GridText/* default */.Z,
        GridSpace: GridSpace/* default */.Z,
        GridButtonSecondary: GridButtonSecondary/* default */.Z,
        GridHeadline: GridHeadline/* default */.Z,
        GridInput: GridInput/* default */.Z,
        GridForm: GridForm/* default */.Z,
        IconPencil: IconPencil/* default */.Z
    },
    props: {
        textId: { type: String, required: false, default: 'wallet.settings.tokenfrag' }
    },
    emits: ['saveSetting'],
    setup(props, { emit }) {
        const { t } = (0,useTranslation/* useTranslation */.$)();
        const { activeWalletData } = (0,useActiveWallet/* useActiveWallet */.r)();
        let tokenFragmentation = (0,IWalletSettings/* createITokenFragmentationSetting */.QZ)();
        let savedValue = null;
        if (activeWalletData.value) {
            const tmpValue = (0,WalletLib/* getSetting */.$8)(activeWalletData.value, 'tokenFragmentation');
            if (tmpValue) {
                tmpValue.value ? savedValue = tmpValue
                    : savedValue = { enabled: false, value: tokenFragmentation };
                if (savedValue?.value.fragment && savedValue.value.fragment > 0) {
                    tokenFragmentation.fragment = savedValue.value.fragment;
                }
            }
        }
        const saving = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const fragInput = (0,reactivity_esm_bundler/* ref */.iH)(tokenFragmentation.fragment.toString());
        const fragInputError = (0,reactivity_esm_bundler/* ref */.iH)('');
        const validFragValue = (0,runtime_core_esm_bundler/* computed */.Fl)(() => !fragInputError.value);
        function validateFragInput(value) {
            fragInputError.value = '';
            if (value) {
                value = value.replace(/[^0-9]/g, '');
                fragInput.value = BigMathLib.compare(value, '==', 0) ? '0' :
                    fragInput.value === '0' ? value.replace(/0/g, '') : value;
                if (value.length === 0 || BigMathLib.compare(value, '<=', 0) || BigMathLib.compare(fragInput.value, '>', 200)) {
                    fragInputError.value = t(props.textId + '.fragment.error');
                }
            }
            else {
                fragInput.value = '0';
                fragInputError.value = t(props.textId + '.fragment.error');
            }
        }
        async function onSetFragmentation() {
            emit('saveSetting', {
                fragment: Number(fragInput.value)
            });
            tokenFragmentation.fragment = Number(fragInput.value);
        }
        function onReset() {
            const defaultValues = (0,IWalletSettings/* createITokenFragmentationSetting */.QZ)();
            fragInput.value = defaultValues.fragment.toString();
            fragInputError.value = '';
        }
        // Start by saving if there was no setting found in wallet storage, component is only rendered if enabled
        if (!savedValue?.enabled) {
            onSetFragmentation();
        }
        return {
            t,
            fragInput,
            fragInputError,
            validFragValue,
            validateFragInput,
            saving,
            onSetFragmentation,
            onReset
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/settings/TokenFragmentation.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/settings/TokenFragmentation.vue




;
const TokenFragmentation_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(TokenFragmentationvue_type_script_lang_ts, [['render',TokenFragmentationvue_type_template_id_5ed9b688_ts_true_render]])

/* harmony default export */ const TokenFragmentation = (TokenFragmentation_exports_);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/settings/LedgerTransport.vue + 4 modules
var LedgerTransport = __webpack_require__(44844);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/settings/ChangeAddress.vue?vue&type=template&id=5e559318&ts=true

const ChangeAddressvue_type_template_id_5e559318_ts_true_hoisted_1 = { class: "col-span-12 grid grid-cols-12 cc-gap" };
const ChangeAddressvue_type_template_id_5e559318_ts_true_hoisted_2 = { class: "col-span-12 flex flex-col items-baseline" };
const ChangeAddressvue_type_template_id_5e559318_ts_true_hoisted_3 = { class: "cc-text-semi-bold" };
const ChangeAddressvue_type_template_id_5e559318_ts_true_hoisted_4 = {
    key: 0,
    class: "break-all font-mono"
};
const ChangeAddressvue_type_template_id_5e559318_ts_true_hoisted_5 = {
    key: 1,
    class: "break-all font-mono"
};
function ChangeAddressvue_type_template_id_5e559318_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridTextArea = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridTextArea");
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    const _component_SendAddrInput = (0,runtime_core_esm_bundler/* resolveComponent */.up)("SendAddrInput");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, [
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", ChangeAddressvue_type_template_id_5e559318_ts_true_hoisted_1, [
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridTextArea, {
                class: "col-span-12",
                css: "cc-rounded cc-banner-warning",
                dense: "",
                label: _ctx.t(_ctx.textId + '.notice.label'),
                text: _ctx.t(_ctx.textId + '.notice.text'),
                icon: _ctx.t(_ctx.textId + '.notice.icon')
            }, null, 8, ["label", "text", "icon"]),
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, { hr: "" }),
            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", ChangeAddressvue_type_template_id_5e559318_ts_true_hoisted_2, [
                (0,runtime_core_esm_bundler/* createElementVNode */._)("span", ChangeAddressvue_type_template_id_5e559318_ts_true_hoisted_3, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t(_ctx.textId + '.current')) + " ", 1),
                (_ctx.changeAddr)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("span", ChangeAddressvue_type_template_id_5e559318_ts_true_hoisted_4, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.changeAddr), 1))
                    : ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("span", ChangeAddressvue_type_template_id_5e559318_ts_true_hoisted_5, "not set (default)"))
            ]),
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, { hr: "" })
        ]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_SendAddrInput, {
            "text-id": _ctx.textId,
            "prefilled-address": _ctx.changeAddr,
            "show-header": false,
            "handle-address-book": false,
            "allow-message": false,
            "next-label": _ctx.t('common.label.save'),
            "can-be-empty": "",
            onSubmit: _ctx.onSetChangeAddress
        }, null, 8, ["text-id", "prefilled-address", "next-label", "onSubmit"])
    ], 64));
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/settings/ChangeAddress.vue?vue&type=template&id=5e559318&ts=true

// EXTERNAL MODULE: ./src/components/ccw/grid/v2/send/SendAddrInput.vue + 29 modules
var SendAddrInput = __webpack_require__(99677);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/settings/ChangeAddress.vue?vue&type=script&lang=ts

;









/* harmony default export */ const ChangeAddressvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'ChangeAddress',
    components: {
        GridText: GridText/* default */.Z,
        GridTextArea: GridTextArea/* default */.Z,
        GridSpace: GridSpace/* default */.Z,
        GridButtonSecondary: GridButtonSecondary/* default */.Z,
        SendAddrInput: SendAddrInput/* default */.Z
    },
    props: {
        textId: { type: String, required: false, default: 'wallet.settings.changeaddr' }
    },
    emits: ['saveSetting'],
    setup(props, { emit }) {
        const { t } = (0,useTranslation/* useTranslation */.$)();
        const $q = (0,use_quasar/* default */.Z)();
        const { activeWalletData } = (0,useActiveWallet/* useActiveWallet */.r)();
        const changeAddr = (0,reactivity_esm_bundler/* ref */.iH)('');
        let savedValue = null;
        const wallet = activeWalletData.value;
        if (wallet) {
            const tmpValue = (0,WalletLib/* getSetting */.$8)(wallet, 'changeAddress');
            if (tmpValue?.value) {
                if (tmpValue.value.address === wallet.accounts[0].base.payment[0][0].bech32) {
                    tmpValue.value.address = ''; // Overwrite default address to null.
                }
                savedValue = tmpValue;
            }
            else {
                savedValue = { enabled: false, value: { address: '' } };
            }
            if (savedValue.value.address) {
                changeAddr.value = savedValue.value.address;
            }
        }
        function onSetChangeAddress(address) {
            if (address && activeWalletData.value) {
                let type = (0,AccountLib/* getAddressType */.hZ)(address, activeWalletData.value.accounts);
                if (type === null) {
                    $q.notify({
                        type: 'negative',
                        message: t('wallet.settings.namiMessages.notOwned'),
                        position: 'top-left'
                    });
                    return;
                }
                else if (type === "external") {
                    $q.notify({
                        type: 'warning',
                        message: t('wallet.settings.namiMessages.nonStaking'),
                        position: 'top-left'
                    });
                }
            }
            emit('saveSetting', { address });
            changeAddr.value = address;
        }
        // Start by saving if there was no setting found in wallet storage, component is only rendered if enabled
        if (!savedValue?.enabled && changeAddr.value) {
            onSetChangeAddress(changeAddr.value);
        }
        return {
            t,
            changeAddr,
            onSetChangeAddress,
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/settings/ChangeAddress.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/settings/ChangeAddress.vue




;
const ChangeAddress_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(ChangeAddressvue_type_script_lang_ts, [['render',ChangeAddressvue_type_template_id_5e559318_ts_true_render]])

/* harmony default export */ const ChangeAddress = (ChangeAddress_exports_);
// EXTERNAL MODULE: ./src/ext/AppWalletManager.ts + 1 modules
var AppWalletManager = __webpack_require__(33931);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/Settings.vue?vue&type=script&lang=ts

;





























const resetWalletName = ExtAppWalletManagerLib/* AWM.resetWalletName */.b.resetWalletName;
const Settingsvue_type_script_lang_ts_toggleLockWallet = ExtAppWalletManagerLib/* AWM.toggleLockWallet */.b.toggleLockWallet;
const Settingsvue_type_script_lang_ts_updateSetting = ExtAppWalletManagerLib/* AWM.updateSetting */.b.updateSetting;
const updateSpendingPassword = ExtAppWalletManagerLib/* AWM.updateSpendingPassword */.b.updateSpendingPassword;



/* harmony default export */ const Settingsvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'Settings',
    components: {
        GridFormWalletName: GridFormWalletName/* default */.Z,
        GridFormPasswordReset: GridFormPasswordReset/* default */.Z,
        GridFormLockPasswordSetting: GridFormLockPasswordSetting,
        GridFormWalletIcon: GridFormWalletIcon,
        GridFormWalletBackground: GridFormWalletBackground,
        GridButtonSecondary: GridButtonSecondary/* default */.Z,
        SettingsItem: SettingsItem/* default */.Z,
        ForceWalletResync: ForceWalletResync,
        UnlockWallet: UnlockWallet,
        ExportWalletJson: ExportWalletJson,
        ExportAccountPubKey: ExportAccountPubKey,
        ExportCSV: ExportCSV/* default */.Z,
        DeleteWallet: DeleteWallet,
        DeregisterWallet: DeregisterWallet,
        AddressBook: AddressBook/* default */.Z,
        TokenFragmentation: TokenFragmentation,
        LedgerTransport: LedgerTransport/* default */.Z,
        ChangeAddress: ChangeAddress,
        Collateral: Collateral,
        IconWarning: IconWarning/* default */.Z,
        GridButtonWarning: GridButtonWarning/* default */.Z,
        GridSpace: GridSpace/* default */.Z,
        GridHeadline: GridHeadline/* default */.Z,
        GridText: GridText/* default */.Z,
    },
    setup() {
        const route = (0,vue_router/* useRoute */.yj)();
        const { t } = (0,useTranslation/* useTranslation */.$)();
        const { isActiveWalletLocked, activeWalletId, activeWalletName, activeWalletGroupName, activeWalletSignType, activeWalletData, activeWalletBackground, activeWalletTokenFragmentation, activeWalletAutoWithdrawal, defaultToAdvancedUTxOManagement, activeWalletChangeAddressEnabled, activeWalletLockPassword, activeWalletEnabledSendAll, activeWalletEnabledManualSync, activeAccount, } = (0,useActiveWallet/* useActiveWallet */.r)();
        const $q = (0,use_quasar/* default */.Z)();
        const { openWalletPage, gotoWalletPage } = (0,useNavigation/* useNavigation */.HJ)();
        const saving = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const isMnemonicWallet = (0,runtime_core_esm_bundler/* computed */.Fl)(() => activeWalletSignType.value === 'mnemonic');
        const isLedgerWallet = (0,runtime_core_esm_bundler/* computed */.Fl)(() => activeWalletSignType.value === 'ledger');
        const prefilledWalletName = (0,runtime_core_esm_bundler/* computed */.Fl)(() => activeWalletName.value ?? '');
        const prefilledGroupName = (0,runtime_core_esm_bundler/* computed */.Fl)(() => activeWalletGroupName.value ?? '');
        const tfEnabled = (0,runtime_core_esm_bundler/* computed */.Fl)(() => activeWalletTokenFragmentation.value);
        const awEnabled = (0,runtime_core_esm_bundler/* computed */.Fl)(() => activeWalletAutoWithdrawal.value);
        const caEnabled = (0,runtime_core_esm_bundler/* computed */.Fl)(() => activeWalletChangeAddressEnabled.value);
        const advancedUTxO = (0,runtime_core_esm_bundler/* computed */.Fl)(() => defaultToAdvancedUTxOManagement.value);
        const lockEnabled = (0,runtime_core_esm_bundler/* computed */.Fl)(() => activeWalletLockPassword.value);
        const enableSendAll = activeWalletEnabledSendAll;
        //const transportType       = computed(() => getSetting(activeWalletData.value, 'ledgerTransport')?.value)
        const enableManualSync = activeWalletEnabledManualSync;
        const reloading = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const enableCollateral = (0,runtime_core_esm_bundler/* computed */.Fl)(() => {
            const setting = (0,WalletLib/* getSetting */.$8)(activeWalletData.value, "enableCollateral", false);
            if (setting != null) {
                return setting.enabled;
            }
            return false;
        });
        const isLocked = isActiveWalletLocked.value;
        const updated = (0,reactivity_esm_bundler/* ref */.iH)(false);
        //If expand=lock was in url query, expand the lock view. ToDo: Should be generalized!
        const expandedLock = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const expandedCollateral = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const expandedVerification = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const expandedRecovery = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const expandedVoterData = (0,reactivity_esm_bundler/* ref */.iH)(false);
        (0,runtime_core_esm_bundler/* watchEffect */.m0)(() => {
            expandedLock.value = (route.params?.tabid?.toString() ?? '') === 'lock';
            expandedCollateral.value = (route.params?.tabid?.toString() ?? '') === 'collateral';
            expandedVerification.value = (route.params?.tabid?.toString() ?? '') === 'verification';
        });
        (0,runtime_core_esm_bundler/* watch */.YP)(activeWalletId, () => {
            reloading.value = true;
            (0,runtime_core_esm_bundler/* nextTick */.Y3)(() => {
                reloading.value = false;
            });
        });
        async function onSubmitWalletNameReset(payload) {
            if (activeWalletId.value) {
                saving.value = true;
                const success = await resetWalletName(activeWalletId.value, payload);
                saving.value = false;
                notifyUpdate(success);
            }
        }
        async function onSubmitWalletIconReset(iconData) {
            if (activeWalletId.value) {
                saving.value = true;
                const success = await (0,AppWalletManager.resetWalletIcon)(activeWalletId.value, iconData.compressedImageData);
                saving.value = false;
                notifyUpdate(success);
            }
        }
        const onSubmitWalletBackground = async (infos) => {
            if (activeWalletId.value) {
                const success = await (0,AppWalletManager.resetWalletBackground)(activeWalletId.value, infos);
                await (0,ExtBackground/* setWalletBackground */.li)(activeWalletData.value.network, infos);
                notifyUpdate(success);
            }
        };
        async function onSubmitPasswordReset(payload) {
            if (activeWalletId.value) {
                saving.value = true;
                const success = await updateSpendingPassword(activeWalletId.value, payload);
                saving.value = false;
                notifyUpdate(success);
            }
        }
        function onTokenFragmentationToggle(enabled) {
            if (!enabled) {
                saveSetting('tokenFragmentation', false);
            }
        }
        function onTokenFragmentationSave(event) {
            saveSetting('tokenFragmentation', true, event);
        }
        function onEnableSendAllToggle(enabled) {
            saveSetting('enableSendAll', enabled);
        }
        function onEnableManualSyncToggle(enabled) {
            saveSetting('enableManualSync', enabled);
        }
        function onEnableCollateral(enabled) {
            saveSetting('enableCollateral', enabled);
        }
        function onChangeAddressToggle(enabled) {
            saveSetting('changeAddress', enabled);
        }
        function onChangeAddressSave(event) {
            saveSetting('changeAddress', true, event);
        }
        // function onLedgerTransportSave(event: ISettingLedgerTransport) {
        //
        //   saveSetting('ledgerTransport', true, event)
        // }
        function onAutoWithdrawalToggle(enabled) {
            saveSetting('autoWithdrawal', enabled);
        }
        function onAdvancedUTxOManagementToggle(enabled) {
            saveSetting('advancedUTxOManagement', enabled);
        }
        async function saveSetting(setting, enabled, newValue) {
            if (!activeWalletId.value || !activeWalletData.value) {
                notifyUpdate(false);
                return false;
            }
            saving.value = true;
            let setting1 = (0,WalletLib/* getSetting */.$8)(activeWalletData.value, setting);
            const value = newValue ?? JSON.parse(JSON.stringify(setting1?.value ?? {}));
            const success = await Settingsvue_type_script_lang_ts_updateSetting(activeWalletId.value, { setting, value: { enabled, value } });
            saving.value = false;
            notifyUpdate(success);
            return success;
        }
        function notifyUpdate(success, message) {
            $q.notify({
                type: (success ? 'positive' : 'negative'),
                message: message ? message : t('wallet.settings.message.' + (success ? 'success' : 'failed')),
                position: 'top-left'
            });
        }
        const setVerification = () => {
            openWalletPage('WalletVerification', activeWalletId.value);
        };
        const gotoStakingVault = () => {
            gotoWalletPage('StakingVault');
        };
        const goToRecovery = () => {
            openWalletPage('WalletRestore', activeWalletId.value);
        };
        const lockedText = (0,runtime_core_esm_bundler/* computed */.Fl)(() => {
            const text = t('wallet.settings.deldereg.label1') ?? '';
            return isLocked ?
                text.replace('###label2###', '') :
                text.replace('###label2###', t('wallet.settings.deldereg.label2'));
        });
        return {
            t,
            isMnemonicWallet,
            isLedgerWallet,
            prefilledWalletName,
            prefilledGroupName,
            onSubmitPasswordReset,
            onSubmitWalletNameReset,
            onSubmitWalletIconReset,
            onSubmitWalletBackground,
            tfEnabled,
            onTokenFragmentationToggle,
            onTokenFragmentationSave,
            lockEnabled,
            onEnableSendAllToggle,
            enableSendAll,
            onEnableManualSyncToggle,
            enableManualSync,
            caEnabled,
            onChangeAddressToggle,
            onChangeAddressSave,
            enableCollateral,
            onEnableCollateral,
            updated,
            // transportType,
            // onLedgerTransportSave,
            awEnabled,
            onAutoWithdrawalToggle,
            advancedUTxO,
            onAdvancedUTxOManagementToggle,
            saving,
            isLocked,
            lockedText,
            expandedLock,
            expandedCollateral,
            expandedVerification,
            expandedRecovery,
            activeWalletId,
            activeWalletBackground,
            reloading,
            gotoStakingVault,
            setVerification,
            goToRecovery
        };
    }
}));

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/Settings.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/Settings.vue




;
const Settings_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(Settingsvue_type_script_lang_ts, [['render',render]])

/* harmony default export */ const Settings = (Settings_exports_);

/***/ })

}]);
//# sourceMappingURL=900.js.map