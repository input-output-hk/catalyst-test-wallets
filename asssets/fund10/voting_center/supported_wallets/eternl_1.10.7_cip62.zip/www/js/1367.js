"use strict";
(this["webpackChunkccw_frontend"] = this["webpackChunkccw_frontend"] || []).push([[1367],{

/***/ 89734:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Receive)
});

// EXTERNAL MODULE: ./node_modules/@vue/runtime-core/dist/runtime-core.esm-bundler.js
var runtime_core_esm_bundler = __webpack_require__(83673);
// EXTERNAL MODULE: ./node_modules/@vue/shared/dist/shared.esm-bundler.js
var shared_esm_bundler = __webpack_require__(62323);
// EXTERNAL MODULE: ./node_modules/@vue/runtime-dom/dist/runtime-dom.esm-bundler.js
var runtime_dom_esm_bundler = __webpack_require__(98880);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/Receive.vue?vue&type=template&id=58ac3818&ts=true

const _hoisted_1 = { class: "cc-page-wallet cc-text-sz" };
const _hoisted_2 = {
    key: 0,
    class: "col-span-12 grid grid-cols-12 cc-gap"
};
const _hoisted_3 = { class: "col-span-12 cc-flex cc-area-light align-middle p-2" };
const _hoisted_4 = { class: "col-span-12 flex flex-col xs:flex-row flex-nowrap items-end" };
const _hoisted_5 = {
    key: 1,
    class: "relative col-span-12"
};
const _hoisted_6 = { class: "cc-text-semi-bold" };
const _hoisted_7 = {
    key: 2,
    class: "relative col-span-12 grid grid-cols-12 cc-page-gap"
};
function render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridHeadline = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridHeadline");
    const _component_GridText = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridText");
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    const _component_GridReceiveAddr = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridReceiveAddr");
    const _component_IconPencil = (0,runtime_core_esm_bundler/* resolveComponent */.up)("IconPencil");
    const _component_q_spinner_dots = (0,runtime_core_esm_bundler/* resolveComponent */.up)("q-spinner-dots");
    const _component_q_spinner_tail = (0,runtime_core_esm_bundler/* resolveComponent */.up)("q-spinner-tail");
    const _component_GridInput = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridInput");
    const _component_GridTabs = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridTabs");
    const _component_GridReceiveAddrResults = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridReceiveAddrResults");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_1, [
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
            label: _ctx.caEnabled ? _ctx.t('wallet.receive.current.static') : _ctx.t('wallet.receive.current.headline')
        }, null, 8, ["label"]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
            text: _ctx.t('wallet.receive.current.caption')
        }, null, 8, ["text"]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, { hr: "" }),
        ((0,runtime_core_esm_bundler/* openBlock */.wg)(true), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, (0,runtime_core_esm_bundler/* renderList */.Ko)(_ctx.currentAddrList, (item) => {
            return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridReceiveAddr, {
                key: item.bech32,
                text: item.bech32,
                info: item.info,
                used: item.used
            }, null, 8, ["text", "info", "used"]));
        }), 128)),
        (!_ctx.caEnabled)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_2, [
                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_3, [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("i", {
                        class: "mdi mdi-information-outline cursor-pointer pointer-events-auto mr-1",
                        onClick: _cache[0] || (_cache[0] =
                            //@ts-ignore
                            (...args) => (_ctx.togglePrivacyNotice && _ctx.togglePrivacyNotice(...args)))
                    }),
                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                        class: "cc-text-semi-bold inline-block",
                        text: _ctx.t('wallet.receive.current.notice.label')
                    }, null, 8, ["text"]),
                    (_ctx.showPrivacyNotice)
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridText, {
                            key: 0,
                            text: _ctx.t('wallet.receive.current.notice.text')
                        }, null, 8, ["text"]))
                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                ]),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, {
                    hr: "",
                    class: "mt-1 mb-3"
                }),
                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_4, [
                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridInput, {
                        class: "col-span-12 mb-2",
                        "input-text": _ctx.searchInput,
                        "onUpdate:input-text": _cache[1] || (_cache[1] = ($event) => ((_ctx.searchInput) = $event)),
                        "input-error": _ctx.searchInputError,
                        "onUpdate:input-error": _cache[2] || (_cache[2] = ($event) => ((_ctx.searchInputError) = $event)),
                        onLostFocus: _ctx.validateSearchInput,
                        onReset: _ctx.resetFilter,
                        label: _ctx.t('wallet.receive.filter.label'),
                        "input-info": _ctx.t('wallet.receive.filter.caption'),
                        "input-hint": _ctx.t('wallet.receive.filter.hint'),
                        "capitalize-label": false,
                        showReset: "",
                        autocomplete: "off",
                        "input-id": "searchToken",
                        "input-type": "text"
                    }, {
                        "icon-prepend": (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_IconPencil, { class: "h-5 w-5" })
                        ]),
                        "icon-append": (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                            (_ctx.searchRunning)
                                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_q_spinner_dots, {
                                    key: 0,
                                    color: "grey"
                                }))
                                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                            (_ctx.fetchingMetadata)
                                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_q_spinner_tail, {
                                    key: 1,
                                    color: "gray"
                                }))
                                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                        ]),
                        _: 1
                    }, 8, ["input-text", "input-error", "onLostFocus", "onReset", "label", "input-info", "input-hint"]),
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", {
                        class: (0,shared_esm_bundler/* normalizeClass */.C_)(["ml-8 mb-0.5 mt-2 xs:mt-0 xs:pr-3", _ctx.searchInputError ? 'pb-7' : ''])
                    }, [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridTabs, {
                            tabs: _ctx.optionsType,
                            divider: false,
                            onSelection: _ctx.onTypeFilter,
                            index: _ctx.filterType
                        }, {
                            tab0: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => []),
                            tab1: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => []),
                            tab2: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => []),
                            _: 1
                        }, 8, ["tabs", "onSelection", "index"])
                    ], 2)
                ]),
                (_ctx.isFilteredResult && !_ctx.noResultsWarning)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridText, {
                        key: 0,
                        class: "break-words",
                        text: _ctx.t('wallet.receive.filter.results')
                            .replace('####count####', _ctx.resultSize)
                    }, null, 8, ["text"]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                (_ctx.noResultsWarning)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_5, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.receive.filter.error.empty')), 1))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, { hr: "" }),
                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", {
                    onClick: _cache[3] || (_cache[3] = (0,runtime_dom_esm_bundler/* withModifiers */.iM)(($event) => { _ctx.showAllKeys = !_ctx.showAllKeys; _ctx.getAdditionalAddresses(); }, ["stop"])),
                    class: "col-span-12 cursor-pointer"
                }, [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("i", {
                        class: (0,shared_esm_bundler/* normalizeClass */.C_)(["mr-2", _ctx.showAllKeys ? 'mdi mdi-chevron-down' : 'mdi mdi-chevron-right'])
                    }, null, 2),
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_6, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.receive.advanced.' + (!_ctx.showAllKeys ? 'show' : 'hide'))), 1)
                ]),
                (_ctx.showAllKeys)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_7, [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridReceiveAddrResults, {
                            headline: _ctx.t('wallet.receive.external.delegated.headline'),
                            text: _ctx.t('wallet.receive.external.delegated.caption'),
                            "result-list": _ctx.filteredExternalAddrList,
                            "is-filtered-result": _ctx.isFilteredResult,
                            "hide-on-empty-results": _ctx.hideListsOnEmptyResult,
                            highlight: true
                        }, null, 8, ["headline", "text", "result-list", "is-filtered-result", "hide-on-empty-results"]),
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridReceiveAddrResults, {
                            headline: _ctx.t('wallet.receive.internal.delegated.headline'),
                            text: _ctx.t('wallet.receive.internal.delegated.caption'),
                            "result-list": _ctx.filteredInternalAddrList,
                            "is-filtered-result": _ctx.isFilteredResult,
                            "hide-on-empty-results": _ctx.hideListsOnEmptyResult,
                            highlight: true
                        }, null, 8, ["headline", "text", "result-list", "is-filtered-result", "hide-on-empty-results"]),
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridReceiveAddrResults, {
                            headline: _ctx.t('wallet.receive.external.enterprise.headline'),
                            text: _ctx.t('wallet.receive.external.enterprise.caption'),
                            "result-list": _ctx.filteredEnterpriseExternalAddrList,
                            "is-filtered-result": _ctx.isFilteredResult,
                            "hide-on-empty-results": _ctx.hideListsOnEmptyResult,
                            highlight: true
                        }, null, 8, ["headline", "text", "result-list", "is-filtered-result", "hide-on-empty-results"]),
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridReceiveAddrResults, {
                            headline: _ctx.t('wallet.receive.internal.enterprise.headline'),
                            text: _ctx.t('wallet.receive.internal.enterprise.caption'),
                            "result-list": _ctx.filteredEnterpriseInternalAddrList,
                            "is-filtered-result": _ctx.isFilteredResult,
                            "hide-on-empty-results": _ctx.hideListsOnEmptyResult,
                            highlight: true
                        }, null, 8, ["headline", "text", "result-list", "is-filtered-result", "hide-on-empty-results"])
                    ]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
            ]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
    ]));
}

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/Receive.vue?vue&type=template&id=58ac3818&ts=true

// EXTERNAL MODULE: ./node_modules/@vue/reactivity/dist/reactivity.esm-bundler.js
var reactivity_esm_bundler = __webpack_require__(61959);
// EXTERNAL MODULE: ./src/composables/ccw/useTranslation.ts
var useTranslation = __webpack_require__(19376);
// EXTERNAL MODULE: ./src/composables/ccw/state/useBalanceVisible.ts
var useBalanceVisible = __webpack_require__(31611);
// EXTERNAL MODULE: ./src/composables/ccw/store/useActiveWallet.ts
var useActiveWallet = __webpack_require__(52144);
// EXTERNAL MODULE: ./node_modules/quasar/src/composables/use-quasar.js
var use_quasar = __webpack_require__(48825);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridHeadline.vue + 3 modules
var GridHeadline = __webpack_require__(63593);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridSpace.vue + 4 modules
var GridSpace = __webpack_require__(14740);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridText.vue + 4 modules
var GridText = __webpack_require__(96834);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/receive/GridReceiveAddr.vue + 4 modules
var GridReceiveAddr = __webpack_require__(68881);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/receive/GridReceiveAddrResults.vue?vue&type=template&id=02edb2b0&ts=true

const GridReceiveAddrResultsvue_type_template_id_02edb2b0_ts_true_hoisted_1 = {
    key: 0,
    class: "relative col-span-12 grid grid-cols-12 cc-page-gap"
};
const GridReceiveAddrResultsvue_type_template_id_02edb2b0_ts_true_hoisted_2 = { class: "col-span-12 flex justify-center" };
function GridReceiveAddrResultsvue_type_template_id_02edb2b0_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridHeadline = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridHeadline");
    const _component_GridText = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridText");
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    const _component_GridReceiveAddr = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridReceiveAddr");
    const _component_q_pagination = (0,runtime_core_esm_bundler/* resolveComponent */.up)("q-pagination");
    return (!_ctx.hideContent)
        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", GridReceiveAddrResultsvue_type_template_id_02edb2b0_ts_true_hoisted_1, [
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                label: _ctx.$props.headline,
                class: "mt-4"
            }, null, 8, ["label"]),
            (!_ctx.isFilteredResult)
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridText, {
                    key: 0,
                    text: _ctx.$props.text,
                    class: "mb-4"
                }, null, 8, ["text"]))
                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
            (_ctx.isFilteredResult && _ctx.$props.resultList.length === 0)
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridText, {
                    key: 1,
                    text: _ctx.t('wallet.receive.filter.error.empty'),
                    class: "mb-4"
                }, null, 8, ["text"]))
                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, { hr: "" }),
            ((0,runtime_core_esm_bundler/* openBlock */.wg)(true), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, (0,runtime_core_esm_bundler/* renderList */.Ko)(_ctx.pagedResults, (item) => {
                return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridReceiveAddr, {
                    key: item.bech32,
                    text: item.bech32,
                    info: item.info,
                    used: item.used,
                    highlight: _ctx.highlight
                }, null, 8, ["text", "info", "used", "highlight"]));
            }), 128)),
            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", GridReceiveAddrResultsvue_type_template_id_02edb2b0_ts_true_hoisted_2, [
                (_ctx.showPagination)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_q_pagination, {
                        key: 0,
                        modelValue: _ctx.currentPage,
                        "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => ((_ctx.currentPage) = $event)),
                        "model-value": _ctx.currentPage,
                        max: _ctx.maxPages,
                        "max-pages": 6,
                        "boundary-numbers": "",
                        flat: "",
                        color: "teal-90",
                        "text-color": "teal-90",
                        "active-color": "teal-90",
                        "active-text-color": "teal-90",
                        "active-design": "unelevated"
                    }, null, 8, ["modelValue", "model-value", "max"]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
            ])
        ]))
        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true);
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/receive/GridReceiveAddrResults.vue?vue&type=template&id=02edb2b0&ts=true

// EXTERNAL MODULE: ./src/components/ccw/common/CopyToClipboard.vue + 3 modules
var CopyToClipboard = __webpack_require__(85243);
// EXTERNAL MODULE: ./src/components/ccw/common/Tooltip.vue + 3 modules
var Tooltip = __webpack_require__(30105);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/receive/GridReceiveAddrResults.vue?vue&type=script&lang=ts








/* harmony default export */ const GridReceiveAddrResultsvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'GridReceiveAddrResults',
    components: {
        GridSpace: GridSpace/* default */.Z,
        CopyToClipboard: CopyToClipboard/* default */.Z,
        Tooltip: Tooltip/* default */.Z,
        GridHeadline: GridHeadline/* default */.Z,
        GridText: GridText/* default */.Z,
        GridReceiveAddr: GridReceiveAddr/* default */.Z,
    },
    props: {
        headline: { type: String, default: '', required: true },
        text: { type: String, default: '', required: true },
        itemsOnPage: { type: Number, default: 10, required: false },
        isFilteredResult: { type: Boolean, default: false, required: false },
        hideOnEmptyResults: { type: Boolean, default: false, required: false },
        highlight: { type: Boolean, default: false, required: false },
        // TODO: Not too sure about Refs as props here.
        resultList: { type: Object, default: [], required: true },
    },
    setup(props) {
        const { t } = (0,useTranslation/* useTranslation */.$)();
        const { resultList, isFilteredResult, hideOnEmptyResults } = (0,reactivity_esm_bundler/* toRefs */.BK)(props);
        const currentPage = (0,reactivity_esm_bundler/* ref */.iH)(1);
        const showPagination = (0,runtime_core_esm_bundler/* computed */.Fl)(() => resultList.value.length > props.itemsOnPage);
        const currentPageStart = (0,runtime_core_esm_bundler/* computed */.Fl)(() => (currentPage.value - 1) * props.itemsOnPage);
        const maxPages = (0,runtime_core_esm_bundler/* computed */.Fl)(() => Math.ceil(resultList.value.length / props.itemsOnPage));
        const pagedResults = (0,runtime_core_esm_bundler/* computed */.Fl)(() => resultList.value.slice(currentPageStart.value, currentPageStart.value + props.itemsOnPage));
        const hideContent = (0,runtime_core_esm_bundler/* computed */.Fl)(() => hideOnEmptyResults.value && resultList.value.length === 0);
        return {
            t,
            currentPage,
            showPagination,
            currentPageStart,
            maxPages,
            pagedResults,
            isFilteredResult,
            hideContent,
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/receive/GridReceiveAddrResults.vue?vue&type=script&lang=ts
 
// EXTERNAL MODULE: ./node_modules/vue-loader/dist/exportHelper.js
var exportHelper = __webpack_require__(74260);
// EXTERNAL MODULE: ./node_modules/quasar/src/components/pagination/QPagination.js
var QPagination = __webpack_require__(87300);
// EXTERNAL MODULE: ./node_modules/@quasar/app/lib/webpack/runtime.auto-import.js
var runtime_auto_import = __webpack_require__(7518);
var runtime_auto_import_default = /*#__PURE__*/__webpack_require__.n(runtime_auto_import);
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/receive/GridReceiveAddrResults.vue




;
const __exports__ = /*#__PURE__*/(0,exportHelper/* default */.Z)(GridReceiveAddrResultsvue_type_script_lang_ts, [['render',GridReceiveAddrResultsvue_type_template_id_02edb2b0_ts_true_render]])

/* harmony default export */ const GridReceiveAddrResults = (__exports__);
;

runtime_auto_import_default()(GridReceiveAddrResultsvue_type_script_lang_ts, 'components', {QPagination: QPagination/* default */.Z});

// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridInput.vue + 4 modules
var GridInput = __webpack_require__(27209);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/icons/IconPencil.vue + 4 modules
var IconPencil = __webpack_require__(44814);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridTabs.vue + 4 modules
var GridTabs = __webpack_require__(49510);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/CSLDerivation.ts
var CSLDerivation = __webpack_require__(18247);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/AccountLib.ts
var AccountLib = __webpack_require__(19276);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/OwnedKeyLib.ts
var OwnedKeyLib = __webpack_require__(38562);
// EXTERNAL MODULE: ../ccw-lib2/core/IReceiveAddress.ts
var IReceiveAddress = __webpack_require__(33745);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/Receive.vue?vue&type=script&lang=ts




;












/* harmony default export */ const Receivevue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'Receive',
    components: {
        GridInput: GridInput/* default */.Z,
        GridText: GridText/* default */.Z,
        GridReceiveAddr: GridReceiveAddr/* default */.Z,
        GridReceiveAddrResults: GridReceiveAddrResults,
        GridSpace: GridSpace/* default */.Z,
        GridHeadline: GridHeadline/* default */.Z,
        GridTabs: GridTabs/* default */.Z,
        IconPencil: IconPencil/* default */.Z,
    },
    setup() {
        const { t } = (0,useTranslation/* useTranslation */.$)();
        const $q = (0,use_quasar/* default */.Z)();
        const { activeWalletData, activeWalletChangeAddress, activeAccount } = (0,useActiveWallet/* useActiveWallet */.r)();
        const { isBalanceVisible, setBalanceVisible } = (0,useBalanceVisible/* useBalanceVisible */.c)();
        const showAllKeys = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const caSaved = activeWalletChangeAddress.value ?? { enabled: false, value: { address: '' } };
        const caEnabled = (0,reactivity_esm_bundler/* ref */.iH)(caSaved.enabled ?? false);
        const searchInputError = (0,reactivity_esm_bundler/* ref */.iH)('');
        const searchInput = (0,reactivity_esm_bundler/* ref */.iH)('');
        const fetchingMetadata = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const searchRunning = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const minInputLength = (0,reactivity_esm_bundler/* ref */.iH)(1);
        const filterTextId = (0,reactivity_esm_bundler/* ref */.iH)('wallet.receive.filter.toggle');
        const filterType = (0,reactivity_esm_bundler/* ref */.iH)(0); // 0=all | 1=used | 2=unused
        const showPrivacyNotice = (0,reactivity_esm_bundler/* ref */.iH)(true);
        (0,runtime_core_esm_bundler/* provide */.JJ)('searchTerm', searchInput);
        const optionsType = (0,reactivity_esm_bundler/* reactive */.qj)([
            { id: "all", label: t(filterTextId.value + '.all.label').toLowerCase(), hover: t(filterTextId.value + '.all.info'), index: 0 },
            { id: "used", label: t(filterTextId.value + '.used.label'), hover: t(filterTextId.value + '.used.info'), index: 1 },
            { id: "unused", label: t(filterTextId.value + '.unused.label'), hover: t(filterTextId.value + '.unused.info'), index: 2 },
        ]);
        const validateSearchInput = (event) => {
            if (searchInput.value.length > 0 && searchInput.value.length < minInputLength.value) {
                searchInputError.value = t('wallet.receive.filter.error.minLength');
            }
            else {
                searchInputError.value = '';
            }
        };
        /**
         * Called when switching filter types. (0=all | 1=used | 2=unused)
         * @param index
         */
        function onTypeFilter(index) {
            filterType.value = index;
            clearSearchTimeout();
            startSearchTimeout();
        }
        /**
         * Remove the input from the input field and reset values to indicate no search is running
         * @param event
         */
        const resetFilter = (event) => {
            searchInput.value = '';
            searchInputError.value = '';
            fetchingMetadata.value = false;
            searchRunning.value = false;
            clearSearchTimeout();
        };
        /**
         * Show the panels incl. headline when there are no results ?
         */
        const hideListsOnEmptyResult = (0,reactivity_esm_bundler/* ref */.iH)(true);
        /**
         * Is the list that is currently displayed, result of a filter action ?
         */
        const isFilteredResult = (0,reactivity_esm_bundler/* ref */.iH)(false);
        /**
         * Show a single warning (in this component) when no results are found ?
         */
        const noResultsWarning = (0,reactivity_esm_bundler/* ref */.iH)(false);
        /**
         * timeout id where for current running search that will be cleared in new search
         */
        let searchingTimeout = -1;
        /**
         * Helper for checking if search field is empty
         */
        const searchInputEmpty = (0,runtime_core_esm_bundler/* computed */.Fl)(() => searchInput.value.length === 0);
        /**
         * In 'filtered...' we store the results when using the filter.
         */
        const filteredExternalAddrList = (0,reactivity_esm_bundler/* ref */.iH)([]);
        const filteredInternalAddrList = (0,reactivity_esm_bundler/* ref */.iH)([]);
        const filteredEnterpriseExternalAddrList = (0,reactivity_esm_bundler/* ref */.iH)([]);
        const filteredEnterpriseInternalAddrList = (0,reactivity_esm_bundler/* ref */.iH)([]);
        /**
         * In 'initial...' we store the results after initialization for fast reload on cancel filter.
         */
        const initialBaseExternalAddrList = (0,reactivity_esm_bundler/* ref */.iH)([]);
        const initialBaseInternalAddrList = (0,reactivity_esm_bundler/* ref */.iH)([]);
        const initialEnterpriseExternalAddrList = (0,reactivity_esm_bundler/* ref */.iH)([]);
        const initialEnterpriseInternalAddrList = (0,reactivity_esm_bundler/* ref */.iH)([]);
        /**
         * Container for all filtered search results.
         */
        const listsOnPage = (0,reactivity_esm_bundler/* ref */.iH)([
            filteredExternalAddrList,
            filteredInternalAddrList,
            filteredEnterpriseExternalAddrList,
            filteredEnterpriseInternalAddrList
        ]);
        /**
         * Counter for how many results were found in search
         */
        const resultSize = (0,reactivity_esm_bundler/* ref */.iH)(0);
        /**
         * Look for changes in the input field and start new search & cancel old search
         */
        (0,runtime_core_esm_bundler/* watch */.YP)(searchInput, () => {
            validateSearchInput();
            clearSearchTimeout();
            if (searchInputEmpty.value) {
                isFilteredResult.value = false;
            }
            startSearchTimeout();
        });
        (0,runtime_core_esm_bundler/* onMounted */.bv)(() => {
            getAdditionalAddresses();
            initialBaseExternalAddrList.value = filteredExternalAddrList.value;
            initialBaseInternalAddrList.value = filteredInternalAddrList.value;
            initialEnterpriseExternalAddrList.value = filteredEnterpriseExternalAddrList.value;
            initialEnterpriseInternalAddrList.value = filteredEnterpriseInternalAddrList.value;
        });
        /**
         * When filtering, we modify lists. In here the initial list will be restored.
         */
        const restoreAddressLists = () => {
            filteredExternalAddrList.value = initialBaseExternalAddrList.value;
            filteredInternalAddrList.value = initialBaseInternalAddrList.value;
            filteredEnterpriseExternalAddrList.value = initialEnterpriseExternalAddrList.value;
            filteredEnterpriseInternalAddrList.value = initialEnterpriseInternalAddrList.value;
        };
        /**
         * Clear last search timeout / cancel last search.
         */
        const clearSearchTimeout = () => {
            searchRunning.value = false;
            clearTimeout(searchingTimeout);
        };
        /**
         * Start new search with input values.
         */
        const startSearchTimeout = () => {
            searchingTimeout = setTimeout(() => {
                restoreAddressLists();
                searchRunning.value = true;
                filterAddressesOnSearch();
            }, searchInput.value.length === 0 ? 0 : 300);
        };
        /**
         * The actual search function when filtering.
         */
        const filterAddressesOnSearch = () => {
            if ((searchInput.value.length === 4 && Number(searchInput.value)) || searchInput.value.includes("/") || searchInput.value.includes(" ") || searchInput.value.includes("'")) { // filter path
                filteredExternalAddrList.value = filteredExternalAddrList.value.filter(filterByPath);
                filteredInternalAddrList.value = filteredInternalAddrList.value.filter(filterByPath);
                filteredEnterpriseExternalAddrList.value = filteredEnterpriseExternalAddrList.value.filter(filterByPath);
                filteredEnterpriseInternalAddrList.value = filteredEnterpriseInternalAddrList.value.filter(filterByPath);
            }
            else { // filter address itself
                filteredExternalAddrList.value = filteredExternalAddrList.value.filter(filterByString);
                filteredInternalAddrList.value = filteredInternalAddrList.value.filter(filterByString);
                filteredEnterpriseExternalAddrList.value = filteredEnterpriseExternalAddrList.value.filter(filterByString);
                filteredEnterpriseInternalAddrList.value = filteredEnterpriseInternalAddrList.value.filter(filterByString);
            }
            isFilteredResult.value = true;
            // if we filter for all and no input is set -> there is no filter used
            if (filterType.value === 0 && searchInputEmpty.value) {
                isFilteredResult.value = false;
            }
            showAllKeys.value = true;
            searchRunning.value = false;
            resultSize.value = listsOnPage.value
                .map((list) => list.value.length)
                .reduce((last, current) => last + current, 0);
            noResultsWarning.value = resultSize.value === 0;
        };
        /**
         * Filter function: Filters all receive addresses by path.
         *
         * Try to parse user input into a path we can read.
         * 'searchablePath' looks like this '1852 1815 0 1 88'
         */
        const filterByPath = (address) => {
            let searchValue = searchInput.value ?? '';
            // Normalize search string so we can search more easy
            searchValue = searchValue.replace(/m\//gi, '');
            searchValue = searchValue.replace(/m /gi, '');
            searchValue = searchValue.replace(/m/gi, '');
            // replace / with " "
            if (searchValue.includes('/')) {
                searchValue = searchValue.replace(/\//g, ' ');
            }
            // replace ' with " "
            if (searchValue.includes('\'')) {
                searchValue = searchValue.replace(/\'/g, '');
            }
            // implode multiple whitespaces into one
            searchValue = searchValue.replace(/\s\s+/g, ' ');
            if (filterType.value === 0) {
                return address.searchablePath.includes(searchValue);
            }
            if (filterType.value === 1 && address.used === true) {
                return searchInputEmpty.value || (!searchInputEmpty.value && address.searchablePath.includes(searchValue));
            }
            if (filterType.value === 2 && address.used === false) {
                return searchInputEmpty.value || (!searchInputEmpty.value && address.searchablePath.includes(searchValue));
            }
            return false;
        };
        /**
         * Filter function: Filters all receive addresses by tx hash
         */
        const filterByString = (address) => {
            if (filterType.value === 0) {
                return address.bech32.includes(searchInput.value);
            }
            if (filterType.value === 1 && address.used === true) {
                return searchInputEmpty.value || (!searchInputEmpty.value && address.bech32.includes(searchInput.value));
            }
            if (filterType.value === 2 && address.used === false) {
                return searchInputEmpty.value || (!searchInputEmpty.value && address.bech32.includes(searchInput.value));
            }
            return false;
        };
        function getStaticAddr(addr) {
            if (!addr)
                addr = '';
            const wallet = activeWalletData.value;
            const account = activeAccount.value;
            if (wallet && account) {
                if (addr.length === 0 && account.base.payment.length > 0 && account.base.payment[0].length > 0) { // Single address mode with no custom address
                    addr = account.base.payment[0][0].bech32;
                }
                const { paymentKey, changeKey, stakeKey } = (0,AccountLib/* getAddressDetails */.IL)(addr, wallet.accounts);
                if (paymentKey) {
                    if (!stakeKey) {
                        $q.notify({
                            type: 'warning',
                            message: t('wallet.receive.warning.nonStaking'),
                            position: 'top-left'
                        });
                    }
                    return (0,IReceiveAddress/* createIReceiveAddress */.F)(addr, paymentKey.used, paymentKey.path, (0,CSLDerivation/* getStringDerivationPath */.Ad)(paymentKey.path));
                }
                if (changeKey) {
                    if (!stakeKey) {
                        $q.notify({
                            type: 'warning',
                            message: t('wallet.receive.warning.nonStaking'),
                            position: 'top-left'
                        });
                    }
                    return (0,IReceiveAddress/* createIReceiveAddress */.F)(addr, changeKey.used, changeKey.path, (0,CSLDerivation/* getStringDerivationPath */.Ad)(changeKey.path));
                }
                $q.notify({
                    type: 'negative',
                    message: t('wallet.receive.error.setting'),
                    position: 'top-left'
                });
            }
            else {
                console.error('Error: getStaticAddr: active account not set');
            }
            return null;
        }
        function getCurrentAddr() {
            const list = [];
            if (activeAccount.value) {
                const account = activeAccount.value;
                if (account) {
                    const addr = account.base.payment[0];
                    for (let i = 0; i < addr.length; i++) {
                        if (!addr[i].used) {
                            const key = (0,OwnedKeyLib/* getOwnedKeyFromCred */.tY)(account.keys, addr[i].cred, 'payment');
                            if (key) {
                                list.push((0,IReceiveAddress/* createIReceiveAddress */.F)(addr[i].bech32, addr[i].used, key.path, (0,CSLDerivation/* getStringDerivationPath */.Ad)(key.path)));
                                break;
                            }
                        }
                    }
                }
            }
            return list;
        }
        const currentAddrList = (0,reactivity_esm_bundler/* ref */.iH)([]);
        if (caEnabled.value) {
            const addr = getStaticAddr(caSaved.value.address);
            if (addr) {
                currentAddrList.value.push(addr);
            }
            else {
                caEnabled.value = false;
            }
        }
        if (!caEnabled.value) {
            setTimeout(() => { currentAddrList.value.push(...getCurrentAddr()); }, 0);
        }
        function getAdditionalAddresses() {
            if (activeAccount.value) {
                if (showAllKeys.value) {
                    startSearchTimeout();
                }
                if (searchInputEmpty.value) {
                    updateBaseExternalAddrList(activeAccount.value);
                    updateBaseInternalAddrList(activeAccount.value);
                    updateEnterpriseExternalAddrList(activeAccount.value);
                    updateEnterpriseInternalAddrList(activeAccount.value);
                }
            }
        }
        const transformInfo = (addr) => {
            addr.info = addr.info + ' (' + (addr.used ? t('wallet.receive.used') : t('wallet.receive.unused')) + ')';
            return addr;
        };
        function updateBaseExternalAddrList(account) {
            if (filteredExternalAddrList.value.length !== 0) {
                return;
            }
            filteredExternalAddrList.value = (0,AccountLib/* getBaseExternalAddrList */.om)(account).map(transformInfo);
        }
        function updateBaseInternalAddrList(account) {
            if (filteredInternalAddrList.value.length !== 0) {
                return;
            }
            filteredInternalAddrList.value = (0,AccountLib/* getBaseInternalAddrList */.eq)(account).map(transformInfo);
        }
        function updateEnterpriseExternalAddrList(account) {
            if (filteredEnterpriseExternalAddrList.value.length !== 0) {
                return;
            }
            filteredEnterpriseExternalAddrList.value = (0,AccountLib/* getEnterpriseExternalAddrList */.xU)(account).map(transformInfo);
        }
        function updateEnterpriseInternalAddrList(account) {
            if (filteredEnterpriseInternalAddrList.value.length !== 0) {
                return;
            }
            filteredEnterpriseInternalAddrList.value = (0,AccountLib/* getEnterpriseInternalAddrList */.cM)(account).map(transformInfo);
        }
        const togglePrivacyNotice = () => {
            showPrivacyNotice.value = !showPrivacyNotice.value;
        };
        const itemsOnPage = 10;
        return {
            t,
            currentAddrList,
            getAdditionalAddresses,
            isBalanceVisible,
            setBalanceVisible,
            caEnabled,
            showAllKeys,
            showPrivacyNotice,
            togglePrivacyNotice,
            getStringDerivationPath: CSLDerivation/* getStringDerivationPath */.Ad,
            validateSearchInput,
            resetFilter,
            onTypeFilter,
            startSearchTimeout,
            optionsType,
            filterType,
            searchInputError,
            searchInput,
            searchRunning,
            fetchingMetadata,
            filteredExternalAddrList,
            filteredInternalAddrList,
            filteredEnterpriseExternalAddrList,
            filteredEnterpriseInternalAddrList,
            resultSize,
            itemsOnPage,
            isFilteredResult,
            noResultsWarning,
            hideListsOnEmptyResult,
        };
    }
}));

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/Receive.vue?vue&type=script&lang=ts
 
// EXTERNAL MODULE: ./node_modules/quasar/src/components/spinner/QSpinnerDots.js
var QSpinnerDots = __webpack_require__(34765);
// EXTERNAL MODULE: ./node_modules/quasar/src/components/spinner/QSpinnerTail.js
var QSpinnerTail = __webpack_require__(90682);
;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/Receive.vue




;
const Receive_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(Receivevue_type_script_lang_ts, [['render',render]])

/* harmony default export */ const Receive = (Receive_exports_);
;


runtime_auto_import_default()(Receivevue_type_script_lang_ts, 'components', {QSpinnerDots: QSpinnerDots/* default */.Z,QSpinnerTail: QSpinnerTail/* default */.Z});


/***/ })

}]);
//# sourceMappingURL=1367.js.map