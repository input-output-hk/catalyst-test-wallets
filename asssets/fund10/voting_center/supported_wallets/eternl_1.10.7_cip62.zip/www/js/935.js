"use strict";
(this["webpackChunkccw_frontend"] = this["webpackChunkccw_frontend"] || []).push([[935,5134],{

/***/ 24521:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ CIP62Delegation)
});

// EXTERNAL MODULE: ./node_modules/@vue/runtime-core/dist/runtime-core.esm-bundler.js
var runtime_core_esm_bundler = __webpack_require__(83673);
// EXTERNAL MODULE: ./node_modules/@vue/shared/dist/shared.esm-bundler.js
var shared_esm_bundler = __webpack_require__(62323);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/CIP62Delegation.vue?vue&type=template&id=093b7b06&ts=true

const _hoisted_1 = { class: "cc-page-wallet cc-text-sz dark:text-cc-gray-dark" };
const _hoisted_2 = { class: "col-span-12 flex flex-row mb-2" };
const _hoisted_3 = { class: "cc-text-bold capitalize" };
const _hoisted_4 = { class: "ml-2" };
const _hoisted_5 = {
    key: 0,
    class: "col-span-12 grid grid-cols-12 cc-gap"
};
const _hoisted_6 = { class: "col-span-12 flex flex-row flex-nowrap items-center" };
const _hoisted_7 = {
    key: 2,
    class: "col-span-12 space-y-2 mb-1"
};
function render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridHeadline = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridHeadline");
    const _component_GridText = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridText");
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    const _component_IconError = (0,runtime_core_esm_bundler/* resolveComponent */.up)("IconError");
    const _component_GridButtonSecondary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonSecondary");
    const _component_GridTxListEntry = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridTxListEntry");
    const _component_GridTextArea = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridTextArea");
    const _component_VoteDelegationRatio = (0,runtime_core_esm_bundler/* resolveComponent */.up)("VoteDelegationRatio");
    const _component_SendConfirm = (0,runtime_core_esm_bundler/* resolveComponent */.up)("SendConfirm");
    const _component_SendSubmit = (0,runtime_core_esm_bundler/* resolveComponent */.up)("SendSubmit");
    const _component_GridSteps = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSteps");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_1, [
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
            label: _ctx.it('dapps.voting.delegation.headline'),
            class: "col-span-12"
        }, null, 8, ["label"]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
            text: _ctx.it('dapps.voting.delegation.caption'),
            class: "col-span-12 cc-text-sz"
        }, null, 8, ["text"]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, {
            hr: "",
            class: "col-span-12 my-0.5 sm:mt-2 sm:mb-1"
        }),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSteps, {
            onBack: _ctx.goBack,
            "show-stepper": false,
            steps: _ctx.optionsSteps,
            currentStep: _ctx.currentStep,
            "small-c-s-s": "pr-20 xs:pr-20 lg:pr-24"
        }, {
            step0: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_2, [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_3, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('dapps.voting.delegation.purpose')) + ":", 1),
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_4, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.purpose), 1)
                ]),
                (_ctx.error.length > 0)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_5, [
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_6, [
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_IconError, { class: "w-7 flex-none mr-2" }),
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                                text: _ctx.error,
                                class: "cc-text-sz"
                            }, null, 8, ["text"])
                        ]),
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, { class: "col-span-12" }),
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonSecondary, {
                            label: _ctx.it('common.label.cancel'),
                            link: _ctx.onCancel,
                            class: "col-start-0 col-span-6 sm:col-span-3"
                        }, null, 8, ["label", "link"]),
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, {
                            hr: "",
                            class: "col-span-12 my-0.5 sm:my-2"
                        }),
                        (_ctx.tx && _ctx.dappWalletData?.network)
                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridTxListEntry, {
                                key: 0,
                                tx: _ctx.tx,
                                wallet: _ctx.dappWalletData,
                                "network-id": _ctx.dappWalletData.network,
                                "always-open": "",
                                "staging-tx": ""
                            }, null, 8, ["tx", "wallet", "network-id"]))
                            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                    ]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                (_ctx.error.length === 0 && _ctx.isDeregistration)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridTextArea, {
                        key: 1,
                        class: "cc-flex-fixed col-span-12 w-full",
                        css: "cc-text-semi-bold cc-rounded cc-banner-warning",
                        "text-c-s-s": "",
                        text: _ctx.it('wallet.bex.activateAccount'),
                        icon: _ctx.it('dapps.enable.access.info.icon')
                    }, null, 8, ["text", "icon"]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                (_ctx.error.length === 0)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_7, [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                            label: _ctx.it('dapps.voting.delegation.ratio.headline'),
                            class: "w-full"
                        }, null, 8, ["label"]),
                        ((0,runtime_core_esm_bundler/* openBlock */.wg)(true), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, (0,runtime_core_esm_bundler/* renderList */.Ko)(_ctx.sortedDelegations, (delegation, index) => {
                            return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", {
                                class: "w-full",
                                key: index
                            }, [
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_VoteDelegationRatio, {
                                    "network-id": _ctx.dappWalletData?.network,
                                    "vote-key": _ctx.byteaToHex(delegation.voteKey),
                                    weight: delegation.weight,
                                    "total-weight": _ctx.totalWeight,
                                    "is-own": _ctx.byteaToHex(delegation.voteKey) === _ctx.ownVotePubKey
                                }, null, 8, ["network-id", "vote-key", "weight", "total-weight", "is-own"])
                            ]));
                        }), 128)),
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, {
                            hr: "",
                            class: "w-full pt-2"
                        })
                    ]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                (_ctx.tx && _ctx.error.length === 0 && _ctx.dappAccount)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_SendConfirm, {
                        key: 3,
                        onSubmit: _ctx.gotoNext,
                        type: "voting",
                        account: _ctx.dappAccount,
                        wallet: _ctx.dappWalletData,
                        "unsigned-tx": _ctx.tx,
                        "text-id": "wallet.send.step.confirm"
                    }, {
                        btnBack: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonSecondary, {
                                label: _ctx.it('common.label.cancel'),
                                link: _ctx.onCancel,
                                class: "col-start-0 col-span-6 sm:col-span-3 lg:col-start-0 lg:col-span-3"
                            }, null, 8, ["label", "link"])
                        ]),
                        _: 1
                    }, 8, ["onSubmit", "account", "wallet", "unsigned-tx"]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
            ]),
            step1: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_SendSubmit, {
                    onError: _ctx.onSubmitError,
                    onSending: _ctx.onTxSending,
                    onPending: _ctx.onTxPending,
                    onConfirmed: _ctx.onTxConfirmed,
                    "text-id": "wallet.send.step.submit"
                }, {
                    btnBack: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                        (_ctx.hasSubmitError)
                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridButtonSecondary, {
                                key: 0,
                                label: _ctx.it('common.label.retry'),
                                link: _ctx.goBack,
                                class: "col-start-0 col-span-6 lg:col-start-0 lg:col-span-3 mt-4"
                            }, null, 8, ["label", "link"]))
                            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                    ]),
                    _: 1
                }, 8, ["onError", "onSending", "onPending", "onConfirmed"])
            ]),
            _: 1
        }, 8, ["onBack", "steps", "currentStep"])
    ]));
}

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/CIP62Delegation.vue?vue&type=template&id=093b7b06&ts=true

// EXTERNAL MODULE: ./node_modules/@vue/reactivity/dist/reactivity.esm-bundler.js
var reactivity_esm_bundler = __webpack_require__(61959);
// EXTERNAL MODULE: ./node_modules/quasar/src/composables/use-quasar.js
var use_quasar = __webpack_require__(48825);
// EXTERNAL MODULE: ./src/composables/ccw/useTranslation.ts
var useTranslation = __webpack_require__(19376);
// EXTERNAL MODULE: ./src/composables/ccw/store/useBuildTx_v3.ts + 1 modules
var useBuildTx_v3 = __webpack_require__(72107);
// EXTERNAL MODULE: ./src/composables/ccw/store/useDAppWallet.ts
var useDAppWallet = __webpack_require__(35053);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/send/SendConfirm.vue + 4 modules
var SendConfirm = __webpack_require__(12662);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/send/SendSubmit.vue + 3 modules
var SendSubmit = __webpack_require__(65778);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/icons/IconWarning.vue + 4 modules
var IconWarning = __webpack_require__(97515);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/icons/IconError.vue + 4 modules
var IconError = __webpack_require__(66934);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridHeadline.vue + 3 modules
var GridHeadline = __webpack_require__(63593);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridText.vue + 4 modules
var GridText = __webpack_require__(96834);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridTextArea.vue + 4 modules
var GridTextArea = __webpack_require__(15660);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridSpace.vue + 4 modules
var GridSpace = __webpack_require__(14740);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridSteps.vue + 14 modules
var GridSteps = __webpack_require__(58217);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridButtonPrimary.vue + 3 modules
var GridButtonPrimary = __webpack_require__(12559);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridButtonSecondary.vue + 3 modules
var GridButtonSecondary = __webpack_require__(72713);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/txlist/GridTxListEntry.vue + 79 modules
var GridTxListEntry = __webpack_require__(55075);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/voting/VoteDelegationRatio.vue + 4 modules
var VoteDelegationRatio = __webpack_require__(36009);
// EXTERNAL MODULE: ./src/lib/utils/useLocalStorage.ts
var useLocalStorage = __webpack_require__(34787);
// EXTERNAL MODULE: ./src/lib/utils/useBexStorage.ts
var useBexStorage = __webpack_require__(6296);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/LibUtils.ts
var LibUtils = __webpack_require__(10751);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/CSLUtils.ts
var CSLUtils = __webpack_require__(58173);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/VoteLib.ts
var VoteLib = __webpack_require__(77263);
// EXTERNAL MODULE: ../ccw-lib2/Print.ts
var ccw_lib2_Print = __webpack_require__(72302);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/CSLConstants.ts
var CSLConstants = __webpack_require__(22798);
// EXTERNAL MODULE: ../ccw-lib2/core/ICatalyst.ts
var ICatalyst = __webpack_require__(36594);
;// CONCATENATED MODULE: ./src/dapp-connector/cip62.ts





// null       = valid purpose array
// undefined  = invalid format
// number[]   = unsupported purpose list
const cip62_enable = (arg) => {
    if (Print.cip62.all)
        console.warn(`cip62_enable: arg=${arg}`);
    const unsupportedPurposeList = [];
    if (!arg || !Array.isArray(arg)) {
        return undefined;
    }
    for (const purpose of arg) {
        if (Number.isNaN(purpose)) {
            return undefined;
        }
        if (!Object.values(ICIP62VotingPurpose).includes(purpose)) {
            if (unsupportedPurposeList.includes(purpose)) {
                return undefined;
            } // duplicate purpose
            unsupportedPurposeList.push(purpose);
        }
    }
    return unsupportedPurposeList.length === 0 ? null : unsupportedPurposeList;
};
const cip62_getVotingCredentials = (wallet, accountIdx) => {
    if (ccw_lib2_Print/* default.cip62.all */.Z.cip62.all)
        console.warn(`cip62_getVotingCredentials: walletId=${wallet.id}, accountIdx=${accountIdx}`);
    const additionalKeys = (0,useLocalStorage/* getAdditionalKeyList */.Ju)();
    let voteKey = null;
    if (additionalKeys) {
        voteKey = additionalKeys[wallet.id]?.find(k => (0,LibUtils/* isSameArray */.EZ)(k.path, [CSLConstants/* purpose.voting */.Gr.voting, CSLConstants/* coin.ada */.e2.ada, accountIdx])) ?? null;
    }
    return voteKey ?? null;
};
const cip62_getDelegation = (arg) => {
    if (Print.cip62.all)
        console.warn(`cip62_getDelegation: arg=${arg}`);
    if (arg.hasOwnProperty('delegations') &&
        arg.hasOwnProperty('purpose') &&
        Array.isArray(arg.delegations) &&
        arg.delegations.length > 0 &&
        typeof arg['purpose'] === 'number') {
        for (const vd of arg.delegations) {
            if (!vd.hasOwnProperty('voteKey') ||
                !vd.hasOwnProperty('weight') ||
                typeof vd['voteKey'] !== 'string' ||
                typeof vd['weight'] !== 'number') {
                return null;
            }
        }
        return arg;
    }
    return null;
};
const cip62_getVotes = (arg) => {
    if (Print.cip62.all)
        console.warn(`cip62_getVotes: arg=${JSON.stringify(arg)}`);
    if (!Array.isArray(arg)) {
        return null;
    }
    for (const vote of arg) {
        if (!vote.hasOwnProperty('proposal') ||
            !vote.hasOwnProperty('choice') ||
            !vote.hasOwnProperty('purpose') ||
            !vote.proposal.hasOwnProperty('votePublic') ||
            !vote.proposal.hasOwnProperty('votePlanId') ||
            !vote.proposal.hasOwnProperty('proposalIndex') ||
            typeof vote.proposal['votePublic'] !== 'boolean' ||
            typeof vote.proposal['votePlanId'] !== 'string' ||
            Number.isNaN(vote.proposal.proposalIndex) ||
            Number.isNaN(vote.choice) ||
            Number.isNaN(vote.purpose)) {
            return null;
        }
        // if private vote, verify additional fields
        if (!vote.proposal.votePublic && (!vote.proposal.hasOwnProperty('voteOptions') ||
            !vote.proposal.hasOwnProperty('voteEncKey') ||
            Number.isNaN(vote.proposal.voteOptions) ||
            typeof vote.proposal['voteEncKey'] !== 'string')) {
            return null;
        }
    }
    return arg;
};
// null               = invalid vote settings format
// undefined          = no vote settings, this is fine
// ICIP62VoteSettings = valid json parsed vote settings object
const cip62_getVoteSettings = (arg) => {
    if (Print.cip62.all)
        console.warn(`cip62_getVoteSettings: arg=${arg}`);
    if (!arg) {
        return undefined;
    }
    const settings = JSON.parse(arg);
    if (!settings.hasOwnProperty('purpose') ||
        !settings.hasOwnProperty('ver') ||
        Number.isNaN(settings.purpose) ||
        Number.isNaN(settings.ver)) {
        return null;
    }
    return settings;
};

;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/CIP62Delegation.vue?vue&type=script&lang=ts

;






















/* harmony default export */ const CIP62Delegationvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'CIP62Delegation',
    components: {
        GridTxListEntry: GridTxListEntry/* default */.Z,
        VoteDelegationRatio: VoteDelegationRatio/* default */.Z,
        SendConfirm: SendConfirm/* default */.Z,
        SendSubmit: SendSubmit/* default */.Z,
        IconWarning: IconWarning/* default */.Z,
        IconError: IconError/* default */.Z,
        GridHeadline: GridHeadline/* default */.Z,
        GridText: GridText/* default */.Z,
        GridTextArea: GridTextArea/* default */.Z,
        GridSpace: GridSpace/* default */.Z,
        GridSteps: GridSteps/* default */.Z,
        GridButtonPrimary: GridButtonPrimary/* default */.Z,
        GridButtonSecondary: GridButtonSecondary/* default */.Z
    },
    setup() {
        const { it } = (0,useTranslation/* useTranslation */.$)();
        const { dappWalletData, dappAccount } = (0,useDAppWallet/* useDAppWallet */.I)();
        const { resetBuildTx, buildVotingTx, getBuiltTx } = (0,useBuildTx_v3/* useBuildTxV3 */.b)();
        const $q = (0,use_quasar/* default */.Z)();
        resetBuildTx(dappAccount.value?.pub ?? null);
        const tx = (0,runtime_core_esm_bundler/* computed */.Fl)(() => {
            if (!dappAccount.value) {
                return null;
            }
            return getBuiltTx(dappAccount.value?.pub);
        });
        const accountVoteKey = dappWalletData.value && dappAccount.value ? cip62_getVotingCredentials(dappWalletData.value, dappAccount.value.index) : null;
        const ownVoteKey = accountVoteKey ? (0,VoteLib/* createVoteKey */.KB)(accountVoteKey.pub, dappAccount.value.index, 0) : null;
        const ownVotePubKey = ownVoteKey ? (0,CSLUtils/* getEd25519PubKeyHex */.ZG)(ownVoteKey.pub) : '';
        const delegation = (0,useLocalStorage/* getCIP62Delegation */.mL)();
        const purpose = (0,useBexStorage/* getCIP62PurposeName */.IA)(delegation.purpose);
        const isDeregistration = delegation.delegations.length === 0;
        const totalWeight = delegation.delegations.reduce((total, amount) => total + amount.weight, 0);
        const sortedDelegations = delegation.delegations.sort((a, b) => {
            if ((0,LibUtils/* byteaToHex */.rQ)(a.voteKey) === ownVotePubKey) {
                return -1;
            }
            return b.weight - a.weight;
        });
        const currentStep = (0,reactivity_esm_bundler/* ref */.iH)(0);
        const error = (0,reactivity_esm_bundler/* ref */.iH)('');
        const hasSubmitError = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const certificate = (0,reactivity_esm_bundler/* ref */.iH)(null);
        const signature = (0,reactivity_esm_bundler/* ref */.iH)('');
        const optionsSteps = (0,reactivity_esm_bundler/* reactive */.qj)([
            { id: 'tx', label: it('dapps.voting.delegation.step.stepper.tx') },
            { id: 'submit', label: it('dapps.voting.delegation.step.stepper.submit') }
        ]);
        function goBack() {
            error.value = '';
            currentStep.value = 0;
        }
        function gotoNext() {
            const m61285 = tx.value?.metadataList.find(m => m.key === '61285');
            if (m61285 && m61285.json['1'] !== (0,LibUtils/* prefix0x */.Cd)('0'.repeat(64 * 2))) {
                signature.value = m61285?.json['1'].slice(2);
                currentStep.value = 1;
            }
            else {
                error.value = it('dapps.voting.delegation.error.sign'); // shouldn't fail, but extra security
            }
        }
        function onErrorProofs() {
            //@ts-ignore
            if ($q.bex) {
                const eventFail = {
                    eventResponseKey: '',
                    data: {
                        api: 'onCIP62SubmitDelegation',
                        payload: {
                            origin: useBexStorage/* bexOrigin.value */.g0.value ?? ''
                        },
                        response: {
                            success: false,
                            error: {
                                code: useBexStorage/* CIP62ErrorCode.ProofGeneration */.AV.ProofGeneration,
                                info: 'wallet does not hold all keys'
                            }
                        }
                    }
                };
                //@ts-ignore
                $q.bex.send('eternl.to.bg', eventFail.data);
            }
        }
        function onCancel() {
            //@ts-ignore
            if ($q.bex) {
                const eventFail = {
                    eventResponseKey: '',
                    data: {
                        api: 'onCIP62SubmitDelegation',
                        payload: {
                            origin: useBexStorage/* bexOrigin.value */.g0.value ?? ''
                        },
                        response: {
                            success: false,
                            error: {
                                code: useBexStorage/* CIP62ErrorCode.UserDeclined */.AV.UserDeclined,
                                info: 'User declined to sign & submit voting delegation'
                            }
                        }
                    }
                };
                //@ts-ignore
                $q.bex.send('eternl.to.bg', eventFail.data);
            }
        }
        function onTxPending() {
            if (tx.value && tx.value.txHash && certificate.value && signature.value.length > 0) {
                //@ts-ignore
                if ($q.bex) {
                    const eventSuccess = {
                        eventResponseKey: '',
                        data: {
                            api: 'onCIP62SubmitDelegation',
                            payload: {
                                origin: useBexStorage/* bexOrigin.value */.g0.value ?? ''
                            },
                            response: {
                                cip62SignedDelegation: {
                                    certificate: certificate.value,
                                    signature: signature.value,
                                    txHash: tx.value.txHash
                                },
                                success: true
                            }
                        }
                    };
                    //@ts-ignore
                    $q.bex.send('eternl.to.bg', eventSuccess.data);
                }
            }
        }
        function onSubmitError() {
            hasSubmitError.value = true;
        }
        function onTxSending() { }
        function onTxConfirmed() { }
        (0,runtime_core_esm_bundler/* onErrorCaptured */.d1)((e, instance, info) => {
            $q.notify({
                type: 'negative',
                message: 'error: ' + (e?.message ?? 'no error message') + ' info: ' + info,
                position: 'top-left',
                timeout: 225000
            });
            console.error('CIP62Delegation: onErrorCaptured', e);
            setTimeout(() => {
                onErrorProofs();
            }, 225000);
            return true;
        });
        async function buildDelegationTx() {
            const wallet = dappWalletData.value;
            const account = dappAccount.value;
            if (!wallet || !account) {
                error.value = it('common.error.account');
                return;
            }
            try {
                const res = await buildVotingTx(wallet, account, delegation);
                certificate.value = res.certificate;
            }
            catch (err) {
                error.value = err.message;
            }
        }
        function onRetry() {
            error.value = '';
            resetBuildTx(dappAccount.value?.pub ?? null);
            buildDelegationTx();
        }
        (0,runtime_core_esm_bundler/* onMounted */.bv)(() => {
            buildDelegationTx();
        });
        return {
            it,
            delegation,
            sortedDelegations,
            isDeregistration,
            totalWeight,
            ownVotePubKey,
            purpose,
            byteaToHex: LibUtils/* byteaToHex */.rQ,
            dappWalletData,
            dappAccount,
            tx,
            hasSubmitError,
            error,
            currentStep,
            optionsSteps,
            goBack,
            gotoNext,
            onCancel,
            onRetry,
            onTxPending,
            onSubmitError,
            onTxSending,
            onTxConfirmed
        };
    }
}));

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/CIP62Delegation.vue?vue&type=script&lang=ts
 
// EXTERNAL MODULE: ./node_modules/vue-loader/dist/exportHelper.js
var exportHelper = __webpack_require__(74260);
;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/CIP62Delegation.vue




;
const __exports__ = /*#__PURE__*/(0,exportHelper/* default */.Z)(CIP62Delegationvue_type_script_lang_ts, [['render',render]])

/* harmony default export */ const CIP62Delegation = (__exports__);

/***/ })

}]);
//# sourceMappingURL=935.js.map