"use strict";
(this["webpackChunkccw_frontend"] = this["webpackChunkccw_frontend"] || []).push([[3052,5134],{

/***/ 96845:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ SignTx)
});

// EXTERNAL MODULE: ./node_modules/@vue/runtime-core/dist/runtime-core.esm-bundler.js
var runtime_core_esm_bundler = __webpack_require__(83673);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/SignTx.vue?vue&type=template&id=4a87be89&ts=true

const _hoisted_1 = { class: "cc-page-wallet cc-text-sz dark:text-cc-gray-dark" };
function render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridButtonSecondary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonSecondary");
    const _component_SignTxConfirm = (0,runtime_core_esm_bundler/* resolveComponent */.up)("SignTxConfirm");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_1, [
        (_ctx.activeAccount && _ctx.tx && _ctx.partialSign !== null)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_SignTxConfirm, {
                key: 0,
                onSubmit: _ctx.onSigned,
                account: _ctx.activeAccount,
                wallet: _ctx.activeWalletData,
                tx: _ctx.tx,
                "partial-sign": _ctx.partialSign,
                mappings: _ctx.contractPropMapping,
                "text-id": "wallet.send.step.confirm"
            }, {
                btnBack: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonSecondary, {
                        label: _ctx.it('common.label.cancel'),
                        link: _ctx.onCancel,
                        type: "button",
                        class: "col-start-0 col-span-6 sm:col-start-0 sm:col-span-3"
                    }, null, 8, ["label", "link"])
                ]),
                _: 1
            }, 8, ["onSubmit", "account", "wallet", "tx", "partial-sign", "mappings"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
    ]));
}

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/SignTx.vue?vue&type=template&id=4a87be89&ts=true

// EXTERNAL MODULE: ./node_modules/@vue/reactivity/dist/reactivity.esm-bundler.js
var reactivity_esm_bundler = __webpack_require__(61959);
// EXTERNAL MODULE: ./node_modules/quasar/src/composables/use-quasar.js
var use_quasar = __webpack_require__(48825);
// EXTERNAL MODULE: ./src/composables/ccw/useTranslation.ts
var useTranslation = __webpack_require__(19376);
// EXTERNAL MODULE: ./src/composables/ccw/store/useActiveWallet.ts
var useActiveWallet = __webpack_require__(52144);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/signtx/SignTxConfirm.vue + 4 modules
var SignTxConfirm = __webpack_require__(58608);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridButtonSecondary.vue + 3 modules
var GridButtonSecondary = __webpack_require__(72713);
// EXTERNAL MODULE: ./src/lib/utils/useLocalStorage.ts
var useLocalStorage = __webpack_require__(34787);
// EXTERNAL MODULE: ./src/lib/utils/useBexStorage.ts
var useBexStorage = __webpack_require__(6296);
// EXTERNAL MODULE: ./src/lib/ExtContractLib.ts
var ExtContractLib = __webpack_require__(68671);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/SignTx.vue?vue&type=script&lang=ts

;







/* harmony default export */ const SignTxvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'SignTx',
    components: {
        GridButtonSecondary: GridButtonSecondary/* default */.Z,
        SignTxConfirm: SignTxConfirm/* default */.Z
    },
    setup() {
        const { it } = (0,useTranslation/* useTranslation */.$)();
        const { activeWalletData, activeAccount } = (0,useActiveWallet/* useActiveWallet */.r)();
        const $q = (0,use_quasar/* default */.Z)();
        const tx = (0,reactivity_esm_bundler/* ref */.iH)(null);
        const partialSign = (0,reactivity_esm_bundler/* ref */.iH)(null);
        function initSignTx(account) {
            partialSign.value = (0,useLocalStorage/* getPartialSign */.nc)();
            tx.value = (0,useLocalStorage/* getSignTx */.y2)();
            console.log(tx.value);
        }
        const contractPropMapping = (0,reactivity_esm_bundler/* ref */.iH)(null);
        (0,runtime_core_esm_bundler/* watchEffect */.m0)(() => {
            if (activeAccount.value) {
                initSignTx(activeAccount.value);
            }
        });
        (0,runtime_core_esm_bundler/* onBeforeMount */.wF)(async () => {
            contractPropMapping.value = await (0,ExtContractLib/* getContractMappings */.L)();
        });
        function onErrorProofs() {
            //@ts-ignore
            if ($q.bex) {
                const eventFail = {
                    eventResponseKey: '',
                    data: {
                        api: 'onSignTx',
                        payload: {
                            origin: useBexStorage/* bexOrigin.value */.g0.value ?? ''
                        },
                        response: {
                            success: false,
                            error: {
                                code: useBexStorage/* TxSignErrorCode.ProofGeneration */.Ix.ProofGeneration,
                                info: 'wallet does not hold all keys'
                            }
                        }
                    }
                };
                //@ts-ignore
                $q.bex.send('eternl.to.bg', eventFail.data);
            }
        }
        function onCancel() {
            //@ts-ignore
            if ($q.bex) {
                const eventFail = {
                    eventResponseKey: '',
                    data: {
                        api: 'onSignTx',
                        payload: {
                            origin: useBexStorage/* bexOrigin.value */.g0.value ?? ''
                        },
                        response: {
                            success: false,
                            error: {
                                code: useBexStorage/* TxSignErrorCode.UserDeclined */.Ix.UserDeclined,
                                info: 'user declined to sign tx'
                            }
                        }
                    }
                };
                //@ts-ignore
                $q.bex.send('eternl.to.bg', eventFail.data);
            }
        }
        function onSigned(payload) {
            if (payload && payload.witnesses) {
                //@ts-ignore
                if ($q.bex) {
                    const eventSuccess = {
                        eventResponseKey: '',
                        data: {
                            api: 'onSignTx',
                            payload: {
                                origin: useBexStorage/* bexOrigin.value */.g0.value ?? ''
                            },
                            response: {
                                witnesses: payload.witnesses,
                                success: true
                            }
                        }
                    };
                    //@ts-ignore
                    $q.bex.send('eternl.to.bg', eventSuccess.data);
                }
            }
        }
        (0,runtime_core_esm_bundler/* onErrorCaptured */.d1)((e, instance, info) => {
            $q.notify({
                type: 'negative',
                message: 'error: ' + (e?.message ?? 'no error message') + ' info: ' + info,
                position: 'top-left',
                timeout: 225000
            });
            console.error('SignTx: onErrorCaptured', e);
            setTimeout(() => {
                onErrorProofs();
            }, 225000);
            return true;
        });
        return {
            it,
            activeWalletData,
            activeAccount,
            tx,
            partialSign,
            onCancel,
            onSigned,
            contractPropMapping
        };
    }
}));

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/SignTx.vue?vue&type=script&lang=ts
 
// EXTERNAL MODULE: ./node_modules/vue-loader/dist/exportHelper.js
var exportHelper = __webpack_require__(74260);
;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/SignTx.vue




;
const __exports__ = /*#__PURE__*/(0,exportHelper/* default */.Z)(SignTxvue_type_script_lang_ts, [['render',render]])

/* harmony default export */ const SignTx = (__exports__);

/***/ })

}]);
//# sourceMappingURL=3052.js.map