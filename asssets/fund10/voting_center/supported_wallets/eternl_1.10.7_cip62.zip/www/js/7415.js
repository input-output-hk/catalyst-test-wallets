"use strict";
(this["webpackChunkccw_frontend"] = this["webpackChunkccw_frontend"] || []).push([[7415,5134],{

/***/ 33913:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Transactions)
});

// EXTERNAL MODULE: ./node_modules/@vue/runtime-core/dist/runtime-core.esm-bundler.js
var runtime_core_esm_bundler = __webpack_require__(83673);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/Transactions.vue?vue&type=template&id=1428b25d&ts=true

const _hoisted_1 = { class: "cc-page-wallet cc-text-sz" };
function render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_ExportCSV = (0,runtime_core_esm_bundler/* resolveComponent */.up)("ExportCSV");
    const _component_base_modal = (0,runtime_core_esm_bundler/* resolveComponent */.up)("base-modal");
    const _component_TransactionHistory = (0,runtime_core_esm_bundler/* resolveComponent */.up)("TransactionHistory");
    const _component_PendingTransactions = (0,runtime_core_esm_bundler/* resolveComponent */.up)("PendingTransactions");
    const _component_GridTabs = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridTabs");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, [
        (_ctx.showModal)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_base_modal, {
                key: 0,
                "show-modal": _ctx.showModal,
                title: _ctx.it('preferences.exports.transactions.modalHeader'),
                caption: _ctx.it('preferences.exports.transactions.modalSubHeader'),
                persistent: false,
                "modal-c-s-s": "m-1 sm:max-w-xl cc-bg-light-1 h-5/6 flex flex-col flex-nowrap pb-2 relative",
                "header-c-s-s": "grow-0 flex items-start justify-between cc-bg-light-0 border-b cc-p",
                "content-c-s-s": "grow bg-transparent relative flex flex-col flex-nowrap relative h-full m-1 cc-p",
                onClose: _ctx.onClose
            }, {
                content: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_ExportCSV)
                ]),
                _: 1
            }, 8, ["show-modal", "title", "caption", "onClose"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_1, [
            (_ctx.activeAccount && _ctx.activeWalletData)
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridTabs, {
                    key: 0,
                    tabs: _ctx.optionsTabs,
                    "abs-header-tabs": [0]
                }, {
                    absHeader: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("span", {
                            class: "material-icons material-icons-outlined cursor-pointer absolute right-0 -top-2 lg:-top-3 button z-50 cc-none md:block cc-rounded items-center px-2 sm:px-3 sm:px-4 py-1.5 sm:py-2 focus:z-10 text-xs sm:text-sm cc-tabs-button text-center no-underline w-10",
                            onClick: _cache[0] || (_cache[0] =
                                //@ts-ignore
                                (...args) => (_ctx.openExport && _ctx.openExport(...args)))
                        }, "download")
                    ]),
                    tab0: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_TransactionHistory, {
                            account: _ctx.activeAccount,
                            wallet: _ctx.activeWalletData,
                            mappings: _ctx.contractPropMapping
                        }, null, 8, ["account", "wallet", "mappings"])
                    ]),
                    tab1: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_PendingTransactions, {
                            account: _ctx.activeAccount,
                            wallet: _ctx.activeWalletData,
                            mappings: _ctx.contractPropMapping
                        }, null, 8, ["account", "wallet", "mappings"])
                    ]),
                    _: 1
                }, 8, ["tabs"]))
                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
        ])
    ], 64));
}

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/Transactions.vue?vue&type=template&id=1428b25d&ts=true

// EXTERNAL MODULE: ./node_modules/@vue/reactivity/dist/reactivity.esm-bundler.js
var reactivity_esm_bundler = __webpack_require__(61959);
// EXTERNAL MODULE: ./src/composables/ccw/useTranslation.ts
var useTranslation = __webpack_require__(19376);
// EXTERNAL MODULE: ./src/composables/ccw/store/useActiveWallet.ts
var useActiveWallet = __webpack_require__(52144);
;// CONCATENATED MODULE: ./src/composables/ccw/state/useExportMenuOpen.ts

const exportMenuOpen = (0,reactivity_esm_bundler/* ref */.iH)(false);
const useExportMenuOpen = () => {
    const openExportMenu = () => { exportMenuOpen.value = true; };
    const closeExportMenu = () => { exportMenuOpen.value = false; };
    const toggleExportMenu = () => { exportMenuOpen.value = !exportMenuOpen.value; };
    const isExportMenuOpen = (0,runtime_core_esm_bundler/* computed */.Fl)(() => exportMenuOpen.value);
    return {
        openExportMenu,
        closeExportMenu,
        toggleExportMenu,
        isExportMenuOpen
    };
};

// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridTabs.vue + 4 modules
var GridTabs = __webpack_require__(49510);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/common/IconButton.vue?vue&type=template&id=2e05d5cc&ts=true

const IconButtonvue_type_template_id_2e05d5cc_ts_true_hoisted_1 = { class: "group flex flex-col flex-nowrap justify-center items-center cc-rounded cc-btn-focus" };
function IconButtonvue_type_template_id_2e05d5cc_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("button", IconButtonvue_type_template_id_2e05d5cc_ts_true_hoisted_1, [
        (0,runtime_core_esm_bundler/* renderSlot */.WI)(_ctx.$slots, "default")
    ]));
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/common/IconButton.vue?vue&type=template&id=2e05d5cc&ts=true

;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/common/IconButton.vue?vue&type=script&lang=ts

/* harmony default export */ const IconButtonvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'IconButton',
    props: {
        icon: { type: String, default: null }
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/common/IconButton.vue?vue&type=script&lang=ts
 
// EXTERNAL MODULE: ./node_modules/vue-loader/dist/exportHelper.js
var exportHelper = __webpack_require__(74260);
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/common/IconButton.vue




;
const __exports__ = /*#__PURE__*/(0,exportHelper/* default */.Z)(IconButtonvue_type_script_lang_ts, [['render',IconButtonvue_type_template_id_2e05d5cc_ts_true_render]])

/* harmony default export */ const IconButton = (__exports__);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/settings/ExportCSV.vue + 6 modules
var ExportCSV = __webpack_require__(6653);
// EXTERNAL MODULE: ./node_modules/@vue/shared/dist/shared.esm-bundler.js
var shared_esm_bundler = __webpack_require__(62323);
// EXTERNAL MODULE: ./node_modules/@vue/runtime-dom/dist/runtime-dom.esm-bundler.js
var runtime_dom_esm_bundler = __webpack_require__(98880);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/transactions/TransactionHistory.vue?vue&type=template&id=8ff2be22&ts=true

const TransactionHistoryvue_type_template_id_8ff2be22_ts_true_hoisted_1 = { class: "col-span-12 grid grid-cols-12" };
const _hoisted_2 = { class: "col-span-12 grid grid-cols-12 cc-gap" };
const _hoisted_3 = { class: "col-span-12 flex justify-center" };
function TransactionHistoryvue_type_template_id_8ff2be22_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridHeadline = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridHeadline");
    const _component_GridText = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridText");
    const _component_GridButtonSecondary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonSecondary");
    const _component_TxFilters = (0,runtime_core_esm_bundler/* resolveComponent */.up)("TxFilters");
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    const _component_GridTxListEntry = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridTxListEntry");
    const _component_q_pagination = (0,runtime_core_esm_bundler/* resolveComponent */.up)("q-pagination");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, [
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", {
            class: (0,shared_esm_bundler/* normalizeClass */.C_)(["col-span-12 grid grid-flow-col cc-gap", _ctx.isFiltered ? 'grid-rows-3' : 'grid-rows-2'])
        }, [
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                label: _ctx.it('wallet.transactions.history.headline')
            }, null, 8, ["label"]),
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                text: _ctx.totalTx + ' ' + _ctx.it('wallet.transactions.history.caption'),
                class: "truncate"
            }, null, 8, ["text"]),
            (_ctx.isFiltered)
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridText, {
                    key: 0,
                    text: _ctx.fTxCnt + ' ' + _ctx.it('wallet.transactions.filtered'),
                    class: "truncate"
                }, null, 8, ["text"]))
                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", {
                class: (0,shared_esm_bundler/* normalizeClass */.C_)([_ctx.isFiltered ? 'row-span-3' : 'row-span-2', "flex justify-end items-end"])
            }, [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonSecondary, {
                    class: "px-4",
                    label: _ctx.it('wallet.transactions.filter.label'),
                    onClick: _cache[0] || (_cache[0] = (0,runtime_dom_esm_bundler/* withModifiers */.iM)(($event) => (_ctx.showFilters = !_ctx.showFilters), ["stop"]))
                }, null, 8, ["label"])
            ], 2)
        ], 2),
        (0,runtime_core_esm_bundler/* withDirectives */.wy)((0,runtime_core_esm_bundler/* createElementVNode */._)("div", TransactionHistoryvue_type_template_id_8ff2be22_ts_true_hoisted_1, [
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_TxFilters, {
                "text-id": "wallet.transactions.filter",
                "tx-list": _ctx.originalTxList,
                onSubmit: _ctx.onTxFilterUpdate,
                onReset: _ctx.onTxFilterReset
            }, null, 8, ["tx-list", "onSubmit", "onReset"])
        ], 512), [
            [runtime_dom_esm_bundler/* vShow */.F8, _ctx.showFilters]
        ]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, { hr: "" }),
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_2, [
            ((0,runtime_core_esm_bundler/* openBlock */.wg)(true), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, (0,runtime_core_esm_bundler/* renderList */.Ko)(_ctx.txListPaged, (item) => {
                return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridTxListEntry, {
                    "hide-divider": false,
                    key: item.txHash,
                    ref_for: true,
                    ref: "listEntries",
                    tx: item,
                    wallet: _ctx.wallet,
                    "network-id": _ctx.wallet.network,
                    "tx-property-map": _ctx.txPropertyMap,
                    "tx-out-property-map": _ctx.txOutPropertyMap
                }, null, 8, ["tx", "wallet", "network-id", "tx-property-map", "tx-out-property-map"]));
            }), 128))
        ]),
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_3, [
            (_ctx.showPagination)
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_q_pagination, {
                    key: 0,
                    modelValue: _ctx.currentPage,
                    "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => ((_ctx.currentPage) = $event)),
                    "model-value": _ctx.currentPage,
                    max: _ctx.maxPages,
                    "max-pages": 6,
                    "boundary-numbers": "",
                    flat: "",
                    color: "teal-90",
                    "text-color": "teal-90",
                    "active-color": "teal-90",
                    "active-text-color": "teal-90",
                    "active-design": "unelevated"
                }, null, 8, ["modelValue", "model-value", "max"]))
                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
        ])
    ], 64));
}

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/transactions/TransactionHistory.vue?vue&type=template&id=8ff2be22&ts=true

// EXTERNAL MODULE: ./node_modules/quasar/src/composables/use-quasar.js
var use_quasar = __webpack_require__(48825);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridHeadline.vue + 3 modules
var GridHeadline = __webpack_require__(63593);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridSpace.vue + 4 modules
var GridSpace = __webpack_require__(14740);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridText.vue + 4 modules
var GridText = __webpack_require__(96834);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridButtonSecondary.vue + 3 modules
var GridButtonSecondary = __webpack_require__(72713);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/txlist/GridTxListEntry.vue + 79 modules
var GridTxListEntry = __webpack_require__(55075);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/txlist/TxFilters.vue?vue&type=template&id=100e4333&ts=true

const TxFiltersvue_type_template_id_100e4333_ts_true_hoisted_1 = { class: "col-span-4 sm:col-span-2 flex flex-col flex-nowrap justify-start items-center" };
const TxFiltersvue_type_template_id_100e4333_ts_true_hoisted_2 = { class: "capitalize cc-text-bold mb-8 sm:mb-9" };
const TxFiltersvue_type_template_id_100e4333_ts_true_hoisted_3 = { class: "flex flex-col flex-nowrap items-center mb-2" };
const _hoisted_4 = { class: "q-gutter-sm row" };
const _hoisted_5 = { class: "row items-center justify-end q-gutter-sm" };
const _hoisted_6 = {
    key: 0,
    class: "mt-2 cc-addr cc-text-sm break-normal max-w-min text-center md:text-left"
};
const _hoisted_7 = { class: "md:whitespace-nowrap" };
const _hoisted_8 = { class: "cc-text-semi-bold whitespace-nowrap" };
const _hoisted_9 = { key: 0 };
const _hoisted_10 = {
    key: 0,
    class: ""
};
const _hoisted_11 = {
    key: 0,
    class: "cc-text-semi-bold whitespace-nowrap"
};
const _hoisted_12 = { key: 0 };
const _hoisted_13 = { class: "col-span-8 sm:col-span-10 grid grid-cols-12 cc-gap" };
const _hoisted_14 = { class: "col-span-12 capitalize cc-text-bold text-center" };
const _hoisted_15 = { class: "text-md ml-1.5" };
const _hoisted_16 = { class: "text-md ml-1.5" };
const _hoisted_17 = {
    key: 0,
    class: "col-span-12 flex flex-row flex-nowrap whitespace-pre-wrap"
};
function TxFiltersvue_type_template_id_100e4333_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    const _component_q_btn = (0,runtime_core_esm_bundler/* resolveComponent */.up)("q-btn");
    const _component_q_date = (0,runtime_core_esm_bundler/* resolveComponent */.up)("q-date");
    const _component_q_time = (0,runtime_core_esm_bundler/* resolveComponent */.up)("q-time");
    const _component_q_popup_proxy = (0,runtime_core_esm_bundler/* resolveComponent */.up)("q-popup-proxy");
    const _component_GridInput = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridInput");
    const _component_IconPencil = (0,runtime_core_esm_bundler/* resolveComponent */.up)("IconPencil");
    const _component_IconError = (0,runtime_core_esm_bundler/* resolveComponent */.up)("IconError");
    const _component_GridText = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridText");
    const _component_GridForm = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridForm");
    const _directive_close_popup = (0,runtime_core_esm_bundler/* resolveDirective */.Q2)("close-popup");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, [
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, {
            hr: "",
            class: "col-span-12 mb-2"
        }),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridForm, {
            onDoFormReset: _ctx.onFilterReset,
            onDoFormSubmit: _ctx.onFilterSubmit,
            "form-id": "'txFilters'",
            "reset-button-label": _ctx.t('common.label.reset'),
            "submit-button-label": _ctx.t('common.label.apply'),
            class: "col-span-12 mb-2"
        }, {
            content: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", TxFiltersvue_type_template_id_100e4333_ts_true_hoisted_1, [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("span", TxFiltersvue_type_template_id_100e4333_ts_true_hoisted_2, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t(_ctx.textId + '.period.label')), 1),
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", TxFiltersvue_type_template_id_100e4333_ts_true_hoisted_3, [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_q_btn, {
                            icon: "event",
                            round: "",
                            color: "primary"
                        }, {
                            default: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_q_popup_proxy, {
                                    onBeforeShow: _ctx.updateDateRangeFilter,
                                    cover: "",
                                    "transition-show": "scale",
                                    "transition-hide": "scale",
                                    class: "bg-transparent"
                                }, {
                                    default: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_4, [
                                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_q_date, {
                                                range: "",
                                                modelValue: _ctx.fDateRangeProxy,
                                                "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => ((_ctx.fDateRangeProxy) = $event)),
                                                "model-value": _ctx.fDateRangeProxy,
                                                mask: "YYYY-MM-DD HH:mm",
                                                onRangeEnd: _ctx.setRangeEnd,
                                                onRangeStart: _ctx.setRangeStart,
                                                onClose: _ctx.closeDateSelect,
                                                dark: _ctx.getDarkMode()
                                            }, {
                                                default: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                                                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_5, [
                                                        (0,runtime_core_esm_bundler/* withDirectives */.wy)((0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_q_btn, {
                                                            label: "Cancel",
                                                            color: "primary",
                                                            flat: ""
                                                        }, null, 512), [
                                                            [_directive_close_popup]
                                                        ]),
                                                        (0,runtime_core_esm_bundler/* withDirectives */.wy)((0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_q_btn, {
                                                            label: "OK",
                                                            color: "primary",
                                                            flat: "",
                                                            onClick: (0,runtime_dom_esm_bundler/* withModifiers */.iM)(_ctx.saveDateRangeFilter, ["stop"])
                                                        }, null, 8, ["onClick"]), [
                                                            [_directive_close_popup]
                                                        ])
                                                    ])
                                                ]),
                                                _: 1
                                            }, 8, ["modelValue", "model-value", "onRangeEnd", "onRangeStart", "onClose", "dark"]),
                                            (_ctx.startDateSet && !_ctx.endDateSet)
                                                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_q_time, {
                                                    key: 0,
                                                    range: "",
                                                    modelValue: _ctx.fTimeStartProxy,
                                                    "onUpdate:modelValue": [
                                                        _cache[1] || (_cache[1] = ($event) => ((_ctx.fTimeStartProxy) = $event)),
                                                        _ctx.updateStartTime
                                                    ],
                                                    mask: "YYYY-MM-DD HH:mm",
                                                    dark: _ctx.getDarkMode(),
                                                    format24h: true
                                                }, {
                                                    default: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                                                        (0,runtime_core_esm_bundler/* createTextVNode */.Uk)(" Set start time ")
                                                    ]),
                                                    _: 1
                                                }, 8, ["modelValue", "onUpdate:modelValue", "dark"]))
                                                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                                            (_ctx.endDateSet)
                                                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_q_time, {
                                                    key: 1,
                                                    range: "",
                                                    modelValue: _ctx.fTimeEndProxy,
                                                    "onUpdate:modelValue": [
                                                        _cache[2] || (_cache[2] = ($event) => ((_ctx.fTimeEndProxy) = $event)),
                                                        _ctx.updateEndTime
                                                    ],
                                                    mask: "YYYY-MM-DD HH:mm",
                                                    dark: _ctx.getDarkMode(),
                                                    format24h: true
                                                }, {
                                                    default: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                                                        (0,runtime_core_esm_bundler/* createTextVNode */.Uk)(" Set end time ")
                                                    ]),
                                                    _: 1
                                                }, 8, ["modelValue", "onUpdate:modelValue", "dark"]))
                                                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                                        ])
                                    ]),
                                    _: 1
                                }, 8, ["onBeforeShow"])
                            ]),
                            _: 1
                        }),
                        (_ctx.fDateRange)
                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_6, [
                                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_7, [
                                    (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_8, [
                                        (0,runtime_core_esm_bundler/* createTextVNode */.Uk)((0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.isSingleDay ? _ctx.formatDatetime(_ctx.fDateRange, true, false) : _ctx.formatDatetime(_ctx.fDateRange.from, true, false)) + " ", 1),
                                        (_ctx.filterTimeStart)
                                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("span", _hoisted_9, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.formatDatetime(_ctx.vTimeStartProxy, false, true, false, _ctx.timezoneUTC)), 1))
                                            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                                    ]),
                                    (!_ctx.isSingleDay)
                                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("span", _hoisted_10, " to "))
                                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                                ]),
                                (!_ctx.isSingleDay)
                                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_11, [
                                        (0,runtime_core_esm_bundler/* createTextVNode */.Uk)((0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.formatDatetime(_ctx.fDateRange.to, true, false)) + " ", 1),
                                        (_ctx.filterTimeEnd)
                                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("span", _hoisted_12, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.formatDatetime(_ctx.vTimeEndProxy, false, true, false, _ctx.timezoneUTC)), 1))
                                            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                                    ]))
                                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                            ]))
                            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                    ])
                ]),
                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_13, [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_14, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t(_ctx.textId + '.amount.label')), 1),
                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridInput, {
                        "input-text": _ctx.fInputMin,
                        "onUpdate:input-text": _cache[3] || (_cache[3] = ($event) => ((_ctx.fInputMin) = $event)),
                        class: "col-span-12 sm:col-span-6 cc-text-sm",
                        "onUpdate:inputText": _ctx.validateAdaMinInput,
                        label: _ctx.t(_ctx.textId + '.amount.from'),
                        "input-hint": "0",
                        autocomplete: "off",
                        "input-id": "inputAdaMin",
                        "input-type": "text",
                        currency: "",
                        "decimal-separator": _ctx.decimalSeparator,
                        "group-separator": _ctx.groupSeparator
                    }, {
                        "icon-prepend": (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_15, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.adaSymbol), 1)
                        ]),
                        _: 1
                    }, 8, ["input-text", "onUpdate:inputText", "label", "decimal-separator", "group-separator"]),
                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridInput, {
                        "input-text": _ctx.fInputMax,
                        "onUpdate:input-text": _cache[4] || (_cache[4] = ($event) => ((_ctx.fInputMax) = $event)),
                        class: "col-span-12 sm:col-span-6 cc-text-sm mb-2",
                        "onUpdate:inputText": _ctx.validateAdaMaxInput,
                        label: _ctx.t(_ctx.textId + '.amount.to'),
                        "input-hint": "0",
                        autocomplete: "off",
                        "input-id": "inputAdaMax",
                        "input-type": "text",
                        currency: "",
                        "decimal-separator": _ctx.decimalSeparator,
                        "group-separator": _ctx.groupSeparator
                    }, {
                        "icon-prepend": (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_16, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.adaSymbol), 1)
                        ]),
                        _: 1
                    }, 8, ["input-text", "onUpdate:inputText", "label", "decimal-separator", "group-separator"])
                ]),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridInput, {
                    "input-text": _ctx.fSearchInput,
                    "onUpdate:input-text": _cache[5] || (_cache[5] = ($event) => ((_ctx.fSearchInput) = $event)),
                    class: "col-span-12 mb-2",
                    "onUpdate:inputText": _cache[6] || (_cache[6] = ($event) => (_ctx.fSearchInput = $event)),
                    label: _ctx.t(_ctx.textId + '.search.label'),
                    "input-info": _ctx.t(_ctx.textId + '.search.info'),
                    "input-hint": _ctx.t(_ctx.textId + '.search.hint'),
                    autofocus: "",
                    autocomplete: "off",
                    "input-id": "searchTx",
                    "input-type": "text"
                }, {
                    "icon-prepend": (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_IconPencil, { class: "h-5 w-5" })
                    ]),
                    _: 1
                }, 8, ["input-text", "label", "input-info", "input-hint"]),
                (_ctx.filterError)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_17, [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_IconError, { class: "w-7 flex-none mr-2" }),
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, { text: _ctx.filterError }, null, 8, ["text"])
                    ]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
            ]),
            _: 1
        }, 8, ["onDoFormReset", "onDoFormSubmit", "reset-button-label", "submit-button-label"])
    ], 64));
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/txlist/TxFilters.vue?vue&type=template&id=100e4333&ts=true

// EXTERNAL MODULE: ./src/composables/ccw/useAdaSymbol.ts
var useAdaSymbol = __webpack_require__(88138);
// EXTERNAL MODULE: ./src/composables/ccw/store/useFormatter.ts
var useFormatter = __webpack_require__(16938);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/forms/GridForm.vue + 3 modules
var GridForm = __webpack_require__(76798);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/icons/IconPencil.vue + 4 modules
var IconPencil = __webpack_require__(44814);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/icons/IconError.vue + 4 modules
var IconError = __webpack_require__(66934);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridInput.vue + 4 modules
var GridInput = __webpack_require__(27209);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/BigMathLib.ts + 1 modules
var BigMathLib = __webpack_require__(99149);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/CSLUtils.ts
var CSLUtils = __webpack_require__(58173);
// EXTERNAL MODULE: ./src/lib/utils/useLocalStorage.ts
var useLocalStorage = __webpack_require__(34787);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/txlist/TxFilters.vue?vue&type=script&lang=ts
/* provided dependency */ var Buffer = __webpack_require__(14244)["Buffer"];














/* harmony default export */ const TxFiltersvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'TxFilters',
    components: {
        GridForm: GridForm/* default */.Z,
        GridInput: GridInput/* default */.Z,
        GridText: GridText/* default */.Z,
        GridSpace: GridSpace/* default */.Z,
        IconPencil: IconPencil/* default */.Z,
        IconError: IconError/* default */.Z
    },
    props: {
        textId: { type: String, required: true, default: '' },
        txList: { type: Object, required: true }
    },
    emits: ['submit', 'reset'],
    setup(props, { emit }) {
        const { t } = (0,useTranslation/* useTranslation */.$)();
        const { adaSymbol } = (0,useAdaSymbol/* useAdaSymbol */.Z)();
        const { languageTag, formatDatetime, formatADAString, formatAmountString, getDecimalNumber, valueFromFormattedString, getNumberFormatSeparators } = (0,useFormatter/* useFormatter */.G)();
        const { activeAccount } = (0,useActiveWallet/* useActiveWallet */.r)();
        const decimalNumber = getDecimalNumber();
        let formatSeparators = getNumberFormatSeparators();
        const decimalSeparator = (0,reactivity_esm_bundler/* ref */.iH)(formatSeparators.decimal);
        const groupSeparator = (0,reactivity_esm_bundler/* ref */.iH)(formatSeparators.group);
        const minusSign = (0,reactivity_esm_bundler/* ref */.iH)(formatSeparators.minusSign);
        (0,runtime_core_esm_bundler/* watch */.YP)(() => languageTag.value, () => {
            formatSeparators = getNumberFormatSeparators();
            decimalSeparator.value = formatSeparators.decimal;
            groupSeparator.value = formatSeparators.group;
            minusSign.value = formatSeparators.minusSign;
            onFilterReset();
        }, { deep: true });
        const decodeHex = (str) => Buffer.from(str, 'hex').toString();
        const filterError = (0,reactivity_esm_bundler/* ref */.iH)('');
        const fDateRangeProxy = (0,reactivity_esm_bundler/* ref */.iH)(null);
        const fDateRange = (0,reactivity_esm_bundler/* ref */.iH)(null);
        const isSingleDay = (0,runtime_core_esm_bundler/* computed */.Fl)(() => !fDateRange.value?.from);
        const filterTimeStart = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const filterTimeEnd = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const fTimeStartProxy = (0,reactivity_esm_bundler/* ref */.iH)(null);
        const fTimeEndProxy = (0,reactivity_esm_bundler/* ref */.iH)(null);
        const vTimeStartProxy = (0,reactivity_esm_bundler/* ref */.iH)(null);
        const vTimeEndProxy = (0,reactivity_esm_bundler/* ref */.iH)(null);
        const startDateSet = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const endDateSet = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const timezoneUTC = (0,reactivity_esm_bundler/* ref */.iH)((0,useLocalStorage/* getAppUseUTC */.jY)());
        const fInputMin = (0,reactivity_esm_bundler/* ref */.iH)(''); // input
        const fInputMinLovelace = (0,reactivity_esm_bundler/* ref */.iH)('0');
        const fInputMax = (0,reactivity_esm_bundler/* ref */.iH)(''); // input
        const fInputMaxLovelace = (0,reactivity_esm_bundler/* ref */.iH)('0');
        const fSearchInput = (0,reactivity_esm_bundler/* ref */.iH)('');
        const allNotes = (0,reactivity_esm_bundler/* ref */.iH)([]);
        let filteredTxList = [];
        function setAbsMinMaxAda(txList) {
            filterError.value = '';
            let acc = ['0', '0'];
            for (const tx of txList) {
                if (!tx.balance) { } // do nothing
                else if (BigMathLib.compare(tx.balance.ownTotal, '<', acc[0])) {
                    acc[0] = tx.balance.ownTotal;
                }
                else if (BigMathLib.compare(tx.balance.ownTotal, '>', acc[1])) {
                    acc[1] = tx.balance.ownTotal;
                }
            }
            fInputMin.value = formatADAString(BigMathLib.subtract(acc[0], decimalNumber), true, 0, false, false, false);
            fInputMax.value = formatADAString(BigMathLib.add(acc[1], decimalNumber), true, 0, false, false, false);
        }
        function validateAdaMinInput(value) {
            if (value) {
                filterError.value = '';
                if (value.startsWith(minusSign.value) || value.startsWith('-')) {
                    value = minusSign.value + value?.replace(minusSign.value, '')?.replace(/-/g, '') ?? value;
                    if (value.replace(/[^0-9]/g, '').length === 0) { // only minus sign entered so far
                        fInputMin.value = minusSign.value;
                        return;
                    }
                }
                const ada = valueFromFormattedString(value, 0);
                if (ada.whole.length === 0 || BigMathLib.isZero(ada.whole)) {
                    fInputMin.value = '';
                    return;
                }
                fInputMin.value = formatAmountString(ada.whole, true, true);
            }
            else {
                fInputMin.value = '';
            }
        }
        function validateAdaMaxInput(value) {
            if (value) {
                filterError.value = '';
                if (value.startsWith(minusSign.value) || value.startsWith('-')) {
                    value = minusSign.value + value?.replace(minusSign.value, '')?.replace(/-/g, '') ?? value;
                    if (value.replace(/[^0-9]/g, '').length === 0) { // only minus sign entered so far
                        fInputMax.value = minusSign.value;
                        return;
                    }
                }
                const ada = valueFromFormattedString(value, 0);
                if (ada.whole.length === 0 || BigMathLib.isZero(ada.whole)) {
                    fInputMax.value = '';
                    return;
                }
                fInputMax.value = formatAmountString(ada.whole, true, true);
            }
            else {
                fInputMax.value = '';
            }
        }
        function txListFilter(tx) {
            if (fDateRange.value) {
                let fromDateFilter;
                let toDateFilter;
                if (fDateRange.value.from) { // a date range filter is set
                    fromDateFilter = Date.parse(fDateRange.value.from);
                    toDateFilter = Date.parse(fDateRange.value.to);
                }
                else { // a single date is set
                    fromDateFilter = Date.parse(fDateRange.value + 'T00:00:00.000Z');
                    toDateFilter = Date.parse(fDateRange.value + 'T23:59:59.999Z');
                }
                if (Date.parse(tx.blockTime) >= fromDateFilter &&
                    Date.parse(tx.blockTime) <= toDateFilter) {
                }
                else {
                    return false;
                }
            }
            if (BigMathLib.compare(tx.balance.ownTotal, '>=', fInputMinLovelace.value) &&
                BigMathLib.compare(tx.balance.ownTotal, '<=', fInputMaxLovelace.value)) {
            }
            else {
                return false;
            }
            if (fSearchInput.value) {
                const searchStr = fSearchInput.value.toLowerCase();
                const msg = tx.metadataList.find(item => item.key === '674')?.json.msg ?? null;
                if (msg?.some(line => line.toLowerCase().includes(searchStr)) ||
                    tx.txHash.includes(searchStr) ||
                    tx.blockHash.includes(searchStr) ||
                    tx.inputList.some(i => i.paymentAddr.bech32.includes(searchStr)) ||
                    tx.collateralInputList.some(i => i.paymentAddr.bech32.includes(searchStr)) ||
                    tx.outputList.some(o => o.paymentAddr.bech32.includes(searchStr)) ||
                    (tx.balance && (tx.balance.ownDiffTokens.some(t => (t.fingerprint ?? (0,CSLUtils/* getAssetIdBech32 */.Pn)(t.policy, t.name)).includes(searchStr) && !isZero(t)) || // search by asset fingerprint
                        tx.balance.ownDiffTokens.some(t => decodeHex(t.name).toLowerCase().includes(searchStr) && !isZero(t)) || // search token name
                        tx.balance.ownDiffTokens.some(t => t.name.includes(searchStr) && !isZero(t)) // search by token name hex
                    ))) {
                }
                else {
                    const note = allNotes.value.find(item => item.txHash === tx.txHash);
                    if (note && note.note.note.toLowerCase().includes(searchStr)) {
                    }
                    else {
                        return false;
                    }
                }
            }
            return true;
        }
        function isZero(token) { return BigMathLib.compare(token.quantity, '==', 0); }
        function updateFilteredTxList(txList, resetMinimums = true, firstCall = false) {
            if (!txList || txList.length === 0) {
                if (!firstCall)
                    onFilterReset();
                return;
            }
            resetMinimums && setAbsMinMaxAda(txList);
            filterError.value = '';
            filteredTxList.splice(0);
            if (!fDateRange.value && fInputMinLovelace.value === '0' && fInputMaxLovelace.value === '0' && !fSearchInput.value) { // no filters set
                filteredTxList = [...txList];
            }
            else {
                filteredTxList = txList.filter(tx => txListFilter(tx));
            }
            !filterError.value ? emit('submit', filteredTxList) : emit('submit', txList);
        }
        function updateMinMaxFilter() {
            if (fInputMin.value.length === 0 || fInputMin.value === minusSign.value ||
                fInputMax.value.length === 0 || fInputMax.value === minusSign.value) {
                filterError.value = t(props.textId + '.error.adarange');
                return;
            }
            const minAda = valueFromFormattedString(fInputMin.value, 0);
            const maxAda = valueFromFormattedString(fInputMax.value, 0);
            fInputMinLovelace.value = BigMathLib.multiply(minAda.whole, decimalNumber);
            if (BigMathLib.compare(maxAda.whole, '<=', minAda.whole)) {
                const newValue = BigMathLib.add(minAda.whole, 1);
                fInputMaxLovelace.value = BigMathLib.multiply(newValue, decimalNumber);
                fInputMax.value = formatAmountString(newValue, true, true);
            }
            else {
                fInputMaxLovelace.value = BigMathLib.multiply(maxAda.whole, decimalNumber);
            }
        }
        function updateDateRangeFilter() {
            startDateSet.value = false;
            endDateSet.value = false;
            fTimeStartProxy.value = null;
            vTimeStartProxy.value = null;
            fTimeEndProxy.value = null;
            vTimeEndProxy.value = null;
            filterTimeStart.value = false;
            filterTimeEnd.value = false;
            if (fDateRange.value) {
                fDateRangeProxy.value = fDateRange.value;
            }
            else {
                const date = new Date();
                fDateRangeProxy.value = { from: date.getFullYear() + '/' + date.getMonth() + '/' + date.getDay(), to: date.getFullYear() + '/' + date.getMonth() + '/' + date.getDay() };
            }
        }
        function saveDateRangeFilter() {
            if (fDateRangeProxy.value) {
                const startTime = fTimeStartProxy.value;
                const endTime = fTimeEndProxy.value;
                // if we select a single day we have to check times
                if (!fDateRangeProxy.value?.from) {
                    fDateRange.value = { from: null, to: null };
                    //if a start time has been set, set the time + date as start range filter
                    if (fTimeStartProxy.value !== null) {
                        filterTimeStart.value = true;
                        let fromDate = new Date(fDateRangeProxy.value);
                        if (startTime) {
                            fromDate.setHours(startTime.getHours());
                            fromDate.setMinutes(startTime.getMinutes());
                        }
                        fDateRange.value.from = fromDate;
                    }
                    else {
                        filterTimeStart.value = false;
                        const fromDate = new Date(fDateRangeProxy.value);
                        fromDate.setHours(0);
                        fromDate.setMinutes(0);
                        fromDate.setSeconds(0);
                        fDateRange.value.from = fromDate;
                    }
                    if (fTimeEndProxy.value !== null) {
                        filterTimeEnd.value = true;
                        let toDate = new Date(fDateRangeProxy.value);
                        if (endTime) {
                            toDate.setHours(endTime.getHours());
                            toDate.setMinutes(endTime.getMinutes());
                        }
                        fDateRange.value.to = toDate;
                    }
                    else {
                        filterTimeEnd.value = false;
                        const toDate = new Date(fDateRangeProxy.value);
                        toDate.setHours(23);
                        toDate.setMinutes(59);
                        toDate.setSeconds(59);
                        fDateRange.value.to = toDate;
                    }
                }
                else {
                    fDateRange.value = fDateRangeProxy.value;
                    if (fTimeStartProxy.value !== null) {
                        filterTimeStart.value = true;
                        const startDate = new Date(fDateRange.value.from);
                        startDate.setTime(new Date(fTimeStartProxy.value).getTime());
                        startDate.setDate(new Date(fDateRange.value.from).getDate());
                        fDateRange.value.from = startDate;
                    }
                    if (fTimeEndProxy.value !== null) {
                        filterTimeEnd.value = true;
                        const endDate = new Date(fDateRange.value.to);
                        endDate.setTime(new Date(fTimeEndProxy.value).getTime());
                        endDate.setDate(new Date(fDateRange.value.to).getDate());
                        fDateRange.value.to = endDate;
                    }
                    else {
                        const endDate = new Date(fDateRange.value.to);
                        endDate.setDate(new Date(fDateRange.value.to).getDate());
                        endDate.setHours(23);
                        endDate.setMinutes(59);
                        endDate.setSeconds(59);
                        fDateRange.value.to = endDate;
                    }
                }
            }
            else {
                fDateRange.value = null;
            }
        }
        function onFilterReset() {
            fDateRange.value = null;
            updateDateRangeFilter();
            fInputMin.value = '';
            fInputMax.value = '';
            fSearchInput.value = '';
            fSearchInput.value = '';
            setAbsMinMaxAda(props.txList);
            emit('reset');
        }
        function onFilterSubmit() {
            updateMinMaxFilter();
            updateFilteredTxList(props.txList, false);
        }
        (0,runtime_core_esm_bundler/* watch */.YP)(() => props.txList.length, (numTx, oldNumTx) => {
            if (numTx !== oldNumTx) {
                updateFilteredTxList(props.txList, true);
            }
        });
        (0,runtime_core_esm_bundler/* watch */.YP)(() => activeAccount.value?.txNoteList, (numTx, oldNumTx) => {
            if (numTx !== oldNumTx) {
                allNotes.value = activeAccount.value?.txNoteList || [];
                updateFilteredTxList(props.txList, true);
            }
        }, { deep: true });
        updateFilteredTxList(props.txList, true);
        const setRangeStart = (event) => {
            startDateSet.value = true;
            endDateSet.value = false;
        };
        const setRangeEnd = (event) => {
            endDateSet.value = true;
        };
        function convertDateToUTC(date) {
            return new Date(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate(), date.getUTCHours(), date.getUTCMinutes(), date.getUTCSeconds());
        }
        const updateStartTime = (event) => {
            fTimeStartProxy.value = new Date(event);
            vTimeStartProxy.value = new Date(event);
            if (!timezoneUTC.value) {
                fTimeStartProxy.value = convertDateToUTC(fTimeStartProxy.value);
            }
        };
        const updateEndTime = (event) => {
            fTimeEndProxy.value = new Date(event);
            vTimeEndProxy.value = new Date(event);
            if (!timezoneUTC.value) {
                fTimeEndProxy.value = convertDateToUTC(fTimeEndProxy.value);
            }
        };
        const closeDateSelect = () => {
            endDateSet.value = false;
        };
        return {
            t,
            adaSymbol,
            decimalSeparator,
            groupSeparator,
            formatDatetime,
            filterError,
            fDateRangeProxy,
            fDateRange,
            isSingleDay,
            updateDateRangeFilter,
            saveDateRangeFilter,
            fTimeStartProxy,
            fTimeEndProxy,
            startDateSet,
            endDateSet,
            filterTimeStart,
            filterTimeEnd,
            vTimeStartProxy,
            vTimeEndProxy,
            updateStartTime,
            updateEndTime,
            fInputMin,
            fInputMax,
            validateAdaMinInput,
            validateAdaMaxInput,
            fSearchInput,
            onFilterReset,
            onFilterSubmit,
            setRangeStart,
            setRangeEnd,
            closeDateSelect,
            getDarkMode: useLocalStorage/* getDarkMode */.TF,
            timezoneUTC
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/txlist/TxFilters.vue?vue&type=script&lang=ts
 
// EXTERNAL MODULE: ./node_modules/quasar/src/components/btn/QBtn.js
var QBtn = __webpack_require__(2165);
// EXTERNAL MODULE: ./node_modules/quasar/src/components/popup-proxy/QPopupProxy.js
var QPopupProxy = __webpack_require__(83944);
// EXTERNAL MODULE: ./node_modules/quasar/src/components/date/QDate.js + 1 modules
var QDate = __webpack_require__(32651);
// EXTERNAL MODULE: ./node_modules/quasar/src/components/time/QTime.js + 2 modules
var QTime = __webpack_require__(1534);
// EXTERNAL MODULE: ./node_modules/quasar/src/directives/ClosePopup.js
var ClosePopup = __webpack_require__(60677);
// EXTERNAL MODULE: ./node_modules/@quasar/app/lib/webpack/runtime.auto-import.js
var runtime_auto_import = __webpack_require__(7518);
var runtime_auto_import_default = /*#__PURE__*/__webpack_require__.n(runtime_auto_import);
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/txlist/TxFilters.vue




;
const TxFilters_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(TxFiltersvue_type_script_lang_ts, [['render',TxFiltersvue_type_template_id_100e4333_ts_true_render]])

/* harmony default export */ const TxFilters = (TxFilters_exports_);
;




runtime_auto_import_default()(TxFiltersvue_type_script_lang_ts, 'components', {QBtn: QBtn/* default */.Z,QPopupProxy: QPopupProxy/* default */.Z,QDate: QDate/* default */.Z,QTime: QTime/* default */.Z});runtime_auto_import_default()(TxFiltersvue_type_script_lang_ts, 'directives', {ClosePopup: ClosePopup/* default */.Z});

// EXTERNAL MODULE: ./src/components/ccw/grid/v2/send/SendSubmitStatus.vue + 4 modules
var SendSubmitStatus = __webpack_require__(56993);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/AccountLib.ts
var AccountLib = __webpack_require__(19276);
// EXTERNAL MODULE: ./src/lib/ExtContractLib.ts
var ExtContractLib = __webpack_require__(68671);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/transactions/TransactionHistory.vue?vue&type=script&lang=ts


;









/* harmony default export */ const TransactionHistoryvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'TransactionHistory',
    components: {
        GridTxListEntry: GridTxListEntry/* default */.Z,
        TxFilters: TxFilters,
        GridText: GridText/* default */.Z,
        GridSpace: GridSpace/* default */.Z,
        GridHeadline: GridHeadline/* default */.Z,
        GridButtonSecondary: GridButtonSecondary/* default */.Z,
        SendSubmitStatus: SendSubmitStatus/* default */.Z
    },
    props: {
        account: { type: Object, required: true },
        wallet: { type: Object, required: true },
        mappings: { type: Object, required: false }
    },
    setup(props) {
        const { it } = (0,useTranslation/* useTranslation */.$)();
        const $q = (0,use_quasar/* default */.Z)();
        const showFilters = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const totalTx = (0,reactivity_esm_bundler/* ref */.iH)(0);
        const fTxCnt = (0,reactivity_esm_bundler/* ref */.iH)(0);
        const originalTxList = (0,reactivity_esm_bundler/* reactive */.qj)([]);
        const filteredTxList = (0,reactivity_esm_bundler/* reactive */.qj)([]);
        let tooc = -1;
        const isFiltered = (0,runtime_core_esm_bundler/* computed */.Fl)(() => fTxCnt.value !== 0 && fTxCnt.value !== totalTx.value);
        const itemsOnPage = 20;
        const currentPage = (0,reactivity_esm_bundler/* ref */.iH)(1);
        const showPagination = (0,runtime_core_esm_bundler/* computed */.Fl)(() => filteredTxList.length > itemsOnPage);
        const currentPageStart = (0,runtime_core_esm_bundler/* computed */.Fl)(() => (currentPage.value - 1) * itemsOnPage);
        const maxPages = (0,runtime_core_esm_bundler/* computed */.Fl)(() => Math.ceil(filteredTxList.length / itemsOnPage));
        const txListPaged = (0,runtime_core_esm_bundler/* computed */.Fl)(() => filteredTxList.slice(currentPageStart.value, currentPageStart.value + itemsOnPage));
        const listEntries = (0,reactivity_esm_bundler/* ref */.iH)([]);
        function onTxFilterUpdate(fTxList) {
            filteredTxList.splice(0, filteredTxList.length, ...fTxList);
            fTxCnt.value = filteredTxList.length;
            currentPage.value = 0;
            currentPage.value = 1;
        }
        function onTxFilterReset() {
            clearTimeout(tooc);
            tooc = setTimeout(() => { resetTxList(); }, 250);
        }
        function resetTxList() {
            clearTimeout(tooc);
            originalTxList.splice(0, originalTxList.length, ...(0,AccountLib/* getAccountTxList */.hk)(props.account));
            totalTx.value = originalTxList.length;
            onTxFilterUpdate(originalTxList);
        }
        const txHashList = (0,runtime_core_esm_bundler/* computed */.Fl)(() => props.account.txHashList);
        (0,runtime_core_esm_bundler/* watch */.YP)(() => txHashList.value.length, (numTx) => {
            if (props.account.txHashList.length > totalTx.value) {
                $q.notify({
                    type: 'positive',
                    message: 'New transaction added to list.',
                    position: 'top-left',
                    timeout: 2000
                });
            }
            clearTimeout(tooc);
            tooc = setTimeout(() => { resetTxList(); }, 250);
        });
        resetTxList();
        /**
         * stores properties for tx
         */
        const txPropertyMap = (0,reactivity_esm_bundler/* reactive */.qj)(new Map());
        const txOutPropertyMap = (0,reactivity_esm_bundler/* reactive */.qj)(new Map());
        const checkITxProperties = (txHash, list, mapping) => {
            if (txPropertyMap.has(txHash)) { // we did process this tx already, exit early
                return txPropertyMap.get(txHash);
            }
            list.forEach((utxo) => {
                let contractProperty = (0,ExtContractLib/* getContractProperty */.Q)(utxo.paymentAddr.bech32, mapping);
                if (contractProperty) {
                    txPropertyMap.set(txHash, contractProperty);
                    txOutPropertyMap.set(utxo.paymentAddr.bech32, contractProperty);
                }
            });
        };
        const mapContractMappings = (mapping) => {
            if (!props.wallet) {
                return;
            }
            if (!mapping) {
                return;
            }
            txListPaged.value.forEach((tx) => {
                checkITxProperties(tx.txHash, tx.inputList, mapping);
                checkITxProperties(tx.txHash, tx.outputList, mapping);
            });
            listEntries.value.forEach((entry) => {
                entry.updateTxContractBadge();
            });
        };
        (0,runtime_core_esm_bundler/* onMounted */.bv)(() => {
            mapContractMappings(props.mappings);
        });
        (0,runtime_core_esm_bundler/* watch */.YP)(() => props.mappings, () => {
            mapContractMappings(props.mappings);
        }, { deep: true });
        (0,runtime_core_esm_bundler/* watch */.YP)(() => currentPage.value, () => {
            mapContractMappings(props.mappings);
        });
        return {
            it,
            showFilters,
            isFiltered,
            totalTx,
            fTxCnt,
            onTxFilterUpdate,
            onTxFilterReset,
            resetTxList,
            originalTxList,
            filteredTxList,
            currentPage,
            showPagination,
            maxPages,
            txListPaged,
            txPropertyMap,
            txOutPropertyMap,
            listEntries
        };
    }
}));

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/transactions/TransactionHistory.vue?vue&type=script&lang=ts
 
// EXTERNAL MODULE: ./node_modules/quasar/src/components/pagination/QPagination.js
var QPagination = __webpack_require__(87300);
;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/transactions/TransactionHistory.vue




;
const TransactionHistory_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(TransactionHistoryvue_type_script_lang_ts, [['render',TransactionHistoryvue_type_template_id_8ff2be22_ts_true_render]])

/* harmony default export */ const TransactionHistory = (TransactionHistory_exports_);
;

runtime_auto_import_default()(TransactionHistoryvue_type_script_lang_ts, 'components', {QPagination: QPagination/* default */.Z});

;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/transactions/PendingTransactions.vue?vue&type=template&id=10d89ef8&ts=true

const PendingTransactionsvue_type_template_id_10d89ef8_ts_true_hoisted_1 = { class: "cc-text-semi-bold mr-1" };
const PendingTransactionsvue_type_template_id_10d89ef8_ts_true_hoisted_2 = { class: "col-span-12 grid grid-cols-12" };
const PendingTransactionsvue_type_template_id_10d89ef8_ts_true_hoisted_3 = { class: "col-span-12 grid grid-cols-12 cc-gap" };
const PendingTransactionsvue_type_template_id_10d89ef8_ts_true_hoisted_4 = { class: "col-span-12 flex justify-center" };
function PendingTransactionsvue_type_template_id_10d89ef8_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridHeadline = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridHeadline");
    const _component_GridText = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridText");
    const _component_TxFilters = (0,runtime_core_esm_bundler/* resolveComponent */.up)("TxFilters");
    const _component_GridButtonPrimary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonPrimary");
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    const _component_GridTxListEntry = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridTxListEntry");
    const _component_q_pagination = (0,runtime_core_esm_bundler/* resolveComponent */.up)("q-pagination");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, [
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", {
            class: (0,shared_esm_bundler/* normalizeClass */.C_)(["col-span-12 grid grid-flow-col cc-gap", _ctx.isFiltered ? 'grid-rows-3' : 'grid-rows-2'])
        }, [
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                label: _ctx.it('wallet.transactions.pending.headline')
            }, null, 8, ["label"]),
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                text: _ctx.totalTx + ' ' + _ctx.it('wallet.transactions.pending.caption'),
                class: "truncate"
            }, null, 8, ["text"]),
            (_ctx.isFiltered)
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridText, {
                    key: 0,
                    text: _ctx.fTxCnt + ' ' + _ctx.it('wallet.transactions.filtered'),
                    class: "truncate"
                }, null, 8, ["text"]))
                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", {
                class: (0,shared_esm_bundler/* normalizeClass */.C_)(["relative self-end justify-self-end cursor-pointer whitespace-nowrap", _ctx.isFiltered ? 'row-span-3' : 'row-span-2']),
                onClick: _cache[0] || (_cache[0] = (0,runtime_dom_esm_bundler/* withModifiers */.iM)(($event) => (_ctx.showFilters = !_ctx.showFilters), ["stop"]))
            }, [
                (0,runtime_core_esm_bundler/* createElementVNode */._)("i", {
                    class: (0,shared_esm_bundler/* normalizeClass */.C_)(["relative mr-1 text-xl text-gray-400 top-0.5", _ctx.showFilters ? 'mdi mdi-chevron-down' : 'mdi mdi-chevron-right'])
                }, null, 2),
                (0,runtime_core_esm_bundler/* createElementVNode */._)("span", PendingTransactionsvue_type_template_id_10d89ef8_ts_true_hoisted_1, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('wallet.transactions.filter.label')), 1)
            ], 2)
        ], 2),
        (0,runtime_core_esm_bundler/* withDirectives */.wy)((0,runtime_core_esm_bundler/* createElementVNode */._)("div", PendingTransactionsvue_type_template_id_10d89ef8_ts_true_hoisted_2, [
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_TxFilters, {
                "text-id": "wallet.transactions.filter",
                "tx-list": _ctx.originalTxList,
                onSubmit: _ctx.onTxFilterUpdate,
                onReset: _ctx.onTxFilterReset
            }, null, 8, ["tx-list", "onSubmit", "onReset"])
        ], 512), [
            [runtime_dom_esm_bundler/* vShow */.F8, _ctx.showFilters]
        ]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonPrimary, {
            label: _ctx.it('common.label.removeAll'),
            link: _ctx.onRemoveAllTx,
            disabled: _ctx.originalTxList.length === 0,
            class: "col-start-7 col-span-6 sm:col-start-8 sm:col-span-5 lg:col-start-9 lg:col-span-4"
        }, null, 8, ["label", "link", "disabled"]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, { hr: "" }),
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", PendingTransactionsvue_type_template_id_10d89ef8_ts_true_hoisted_3, [
            ((0,runtime_core_esm_bundler/* openBlock */.wg)(true), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, (0,runtime_core_esm_bundler/* renderList */.Ko)(_ctx.txListPaged, (item) => {
                return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridTxListEntry, {
                    key: item.txHash,
                    tx: item,
                    wallet: _ctx.wallet,
                    "network-id": _ctx.wallet.network,
                    "tx-property-map": _ctx.txPropertyMap,
                    "tx-out-property-map": _ctx.txOutPropertyMap,
                    onRemove: _ctx.onRemoveExpiredTx,
                    "hide-divider": false,
                    "always-open": "",
                    "hide-account-balance": "",
                    "pending-tx": ""
                }, null, 8, ["tx", "wallet", "network-id", "tx-property-map", "tx-out-property-map", "onRemove"]));
            }), 128))
        ]),
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", PendingTransactionsvue_type_template_id_10d89ef8_ts_true_hoisted_4, [
            (_ctx.showPagination)
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_q_pagination, {
                    key: 0,
                    modelValue: _ctx.currentPage,
                    "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => ((_ctx.currentPage) = $event)),
                    "model-value": _ctx.currentPage,
                    max: _ctx.maxPages,
                    "max-pages": 6,
                    "boundary-numbers": "",
                    flat: "",
                    color: "teal-90",
                    "text-color": "teal-90",
                    "active-color": "teal-90",
                    "active-text-color": "teal-90",
                    "active-design": "unelevated"
                }, null, 8, ["modelValue", "model-value", "max"]))
                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
        ])
    ], 64));
}

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/transactions/PendingTransactions.vue?vue&type=template&id=10d89ef8&ts=true

// EXTERNAL MODULE: ./src/composables/ccw/store/useCheckTxOnChain.ts
var useCheckTxOnChain = __webpack_require__(82226);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridButtonPrimary.vue + 3 modules
var GridButtonPrimary = __webpack_require__(12559);
// EXTERNAL MODULE: ../ccw-lib2/core/ITx.ts
var ITx = __webpack_require__(62844);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/ChainLib.ts
var ChainLib = __webpack_require__(48011);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/BalanceLib.ts
var BalanceLib = __webpack_require__(29120);
// EXTERNAL MODULE: ./src/data/PendingTxDb.ts
var PendingTxDb = __webpack_require__(59025);
// EXTERNAL MODULE: ./src/data/OfflineDataDb.ts
var OfflineDataDb = __webpack_require__(79822);
// EXTERNAL MODULE: ./src/lib/ExtAppWalletManagerLib.ts
var ExtAppWalletManagerLib = __webpack_require__(12736);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/transactions/PendingTransactions.vue?vue&type=script&lang=ts

;


















const immediatelySyncAppWallet = ExtAppWalletManagerLib/* AWM.immediatelySyncAppWallet */.b.immediatelySyncAppWallet;
/* harmony default export */ const PendingTransactionsvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'PendingTransactions',
    components: {
        GridTxListEntry: GridTxListEntry/* default */.Z,
        TxFilters: TxFilters,
        GridText: GridText/* default */.Z,
        GridSpace: GridSpace/* default */.Z,
        GridHeadline: GridHeadline/* default */.Z,
        GridButtonPrimary: GridButtonPrimary/* default */.Z,
        SendSubmitStatus: SendSubmitStatus/* default */.Z
    },
    props: {
        account: { type: Object, required: true },
        wallet: { type: Object, required: true },
        mappings: { type: Object, required: false }
    },
    setup(props) {
        const { it } = (0,useTranslation/* useTranslation */.$)();
        const $q = (0,use_quasar/* default */.Z)();
        const { scanForPendingTx, onChainTxList } = (0,useCheckTxOnChain/* useCheckTxOnChain */.V)();
        const showFilters = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const totalTx = (0,reactivity_esm_bundler/* ref */.iH)(0);
        const fTxCnt = (0,reactivity_esm_bundler/* ref */.iH)(0);
        const originalTxList = (0,reactivity_esm_bundler/* reactive */.qj)([]);
        const filteredTxList = (0,reactivity_esm_bundler/* reactive */.qj)([]);
        const triggeredTxList = [];
        let firstReset = true;
        let tooc = -1;
        let tosc = -1;
        const isFiltered = (0,runtime_core_esm_bundler/* computed */.Fl)(() => fTxCnt.value !== 0 && fTxCnt.value !== totalTx.value);
        const itemsOnPage = 20;
        const currentPage = (0,reactivity_esm_bundler/* ref */.iH)(1);
        const showPagination = (0,runtime_core_esm_bundler/* computed */.Fl)(() => filteredTxList.length > itemsOnPage);
        const currentPageStart = (0,runtime_core_esm_bundler/* computed */.Fl)(() => (currentPage.value - 1) * itemsOnPage);
        const maxPages = (0,runtime_core_esm_bundler/* computed */.Fl)(() => Math.ceil(filteredTxList.length / itemsOnPage));
        const txListPaged = (0,runtime_core_esm_bundler/* computed */.Fl)(() => filteredTxList.sort((a, b) => {
            let slotA = a.invalidHereafter;
            let slotB = b.invalidHereafter;
            if (a.blockTime) {
                slotA = (0,ChainLib/* getCalculatedSlotFromBlockTime */.fY)(props.account.network, a.blockTime);
            }
            if (b.blockTime) {
                slotB = (0,ChainLib/* getCalculatedSlotFromBlockTime */.fY)(props.account.network, b.blockTime);
            }
            return slotB - slotA;
        }).slice(currentPageStart.value, currentPageStart.value + itemsOnPage));
        const delayedReset = () => {
            clearTimeout(tooc);
            tooc = setTimeout(() => { resetTxList(); }, 250);
        };
        function onTxConfirmed() {
            immediatelySyncAppWallet(props.wallet.id);
        }
        function onTxFilterUpdate(fTxList) {
            filteredTxList.splice(0, filteredTxList.length, ...fTxList);
            fTxCnt.value = filteredTxList.length;
            currentPage.value = 0;
            currentPage.value = 1;
        }
        function onTxFilterReset() { delayedReset(); }
        const onRemoveAllTx = async () => {
            const networkId = props.account.network;
            const pendingTxList = originalTxList;
            if (pendingTxList.length > 0) {
                const chainTip = (0,ChainLib/* getCalculatedChainTip */.YB)(networkId);
                // check old transactions up until 10 minutes after they are invalid. db-sync + rollbacks + forks etc.
                const removeTxHashList = pendingTxList.filter(item => {
                    // console.log('item', item)
                    const isOutOfTTL = (item.invalidHereafter - chainTip) < 0;
                    const isOnChain = item.blockNo > 0 && item.blockNo < Number.MAX_SAFE_INTEGER;
                    return isOutOfTTL || isOnChain;
                }).map(tx => tx.txHash);
                for (const txHash of removeTxHashList) {
                    await (0,PendingTxDb/* removePendingTx */.z6)(networkId, txHash);
                }
            }
            delayedReset();
        };
        async function resetTxList() {
            clearTimeout(tooc);
            if ((0,useLocalStorage/* getAutoCleanupTx */.Qi)()) {
                await onRemoveAllTx();
            }
            const networkId = props.account.network;
            const pendingTxList = (0,PendingTxDb/* getPendingTxList */.wL)(networkId);
            if (pendingTxList.length > 0) {
                const pendingTxHashList = pendingTxList.map(tx => tx.txHash);
                const tmpTxList = await (0,OfflineDataDb/* loadTxList */.kR)(networkId, pendingTxHashList);
                const tmpTxHashList = tmpTxList.map(tx => tx.txHash);
                let doSync = false;
                for (const txHash of tmpTxHashList) {
                    if (!triggeredTxList.includes(txHash)) {
                        doSync = true;
                        triggeredTxList.push(txHash);
                    }
                }
                if (doSync && !firstReset) {
                    immediatelySyncAppWallet(props.wallet.id);
                }
                firstReset = false;
                const txList = pendingTxList.map(pendingTx => (0,ITx/* createITx */.e)(tmpTxList.find(tx => tx.txHash === pendingTx.txHash) ?? pendingTx.tx));
                for (let i = txList.length - 1; i >= 0; i--) {
                    const tx = txList[i];
                    const hasAtLeastOneOwnedPaymentKey = (0,AccountLib/* updateTxKeyTypes */.dT)(props.account, tx);
                    if (!hasAtLeastOneOwnedPaymentKey) {
                        txList.splice(i, 1);
                    }
                    else {
                        if (tx.balance) {
                            (0,BalanceLib/* updateITxBalance */.Nf)(tx.balance, tx);
                        }
                    }
                }
                if (txList.length > 0) {
                    scanForPendingTx(networkId);
                }
                originalTxList.splice(0, originalTxList.length, ...txList);
            }
            else {
                originalTxList.splice(0, originalTxList.length);
            }
            totalTx.value = originalTxList.length;
            onTxFilterUpdate(originalTxList);
        }
        const txHashList = (0,runtime_core_esm_bundler/* computed */.Fl)(() => props.account.txHashList);
        (0,runtime_core_esm_bundler/* watch */.YP)(() => txHashList.value.length, (numTx) => {
            if (props.account.txHashList.length > totalTx.value) {
                $q.notify({
                    type: 'positive',
                    message: 'New transaction added to list.',
                    position: 'top-left',
                    timeout: 2000
                });
            }
            delayedReset();
        });
        (0,runtime_core_esm_bundler/* watch */.YP)(() => onChainTxList.length, (numTx) => {
            delayedReset();
        });
        const onRemoveExpiredTx = async (tx) => {
            await (0,PendingTxDb/* removePendingTx */.z6)(props.account.network, tx.txHash);
            delayedReset();
        };
        const scheduler = () => {
            delayedReset();
            clearTimeout(tosc);
            tosc = setTimeout(() => { scheduler(); }, 8000);
        };
        (0,runtime_core_esm_bundler/* onMounted */.bv)(() => {
            scheduler();
        });
        (0,runtime_core_esm_bundler/* onUnmounted */.Ah)(() => {
            clearTimeout(tosc);
            clearTimeout(tooc);
        });
        /**
         * stores properties for tx
         */
        const txPropertyMap = (0,reactivity_esm_bundler/* reactive */.qj)(new Map());
        const txOutPropertyMap = (0,reactivity_esm_bundler/* reactive */.qj)(new Map());
        const listEntries = (0,reactivity_esm_bundler/* ref */.iH)([]);
        const checkITxProperties = (txHash, list, mapping) => {
            if (txPropertyMap.has(txHash)) { // we did process this tx already, exit early
                return txPropertyMap.get(txHash);
            }
            list.forEach((utxo) => {
                let contractProperty = (0,ExtContractLib/* getContractProperty */.Q)(utxo.paymentAddr.bech32, mapping);
                if (contractProperty) {
                    txPropertyMap.set(txHash, contractProperty);
                    txOutPropertyMap.set(utxo.paymentAddr.bech32, contractProperty);
                }
            });
        };
        const mapContractMappings = (mapping) => {
            if (!props.wallet) {
                return;
            }
            if (!mapping) {
                return;
            }
            txListPaged.value.forEach((tx) => {
                checkITxProperties(tx.txHash, tx.inputList, mapping);
                checkITxProperties(tx.txHash, tx.outputList, mapping);
            });
            listEntries.value.forEach((entry) => {
                entry.updateTxContractBadge();
            });
        };
        (0,runtime_core_esm_bundler/* onMounted */.bv)(() => {
            mapContractMappings(props.mappings);
        });
        (0,runtime_core_esm_bundler/* watch */.YP)(() => props.mappings, () => {
            mapContractMappings(props.mappings);
        }, { deep: true });
        (0,runtime_core_esm_bundler/* watch */.YP)(() => currentPage.value, () => {
            mapContractMappings(props.mappings);
        });
        return {
            it,
            showFilters,
            isFiltered,
            totalTx,
            fTxCnt,
            onTxConfirmed,
            onTxFilterUpdate,
            onTxFilterReset,
            resetTxList,
            originalTxList,
            filteredTxList,
            currentPage,
            showPagination,
            maxPages,
            txListPaged,
            onRemoveExpiredTx,
            onRemoveAllTx,
            txPropertyMap,
            txOutPropertyMap
        };
    }
}));

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/transactions/PendingTransactions.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/transactions/PendingTransactions.vue




;
const PendingTransactions_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(PendingTransactionsvue_type_script_lang_ts, [['render',PendingTransactionsvue_type_template_id_10d89ef8_ts_true_render]])

/* harmony default export */ const PendingTransactions = (PendingTransactions_exports_);
;

runtime_auto_import_default()(PendingTransactionsvue_type_script_lang_ts, 'components', {QPagination: QPagination/* default */.Z});

// EXTERNAL MODULE: ./src/components/ccw/modal/BaseModal.vue + 4 modules
var BaseModal = __webpack_require__(57044);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/Transactions.vue?vue&type=script&lang=ts











/* harmony default export */ const Transactionsvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'Transactions',
    components: {
        IconButton: IconButton,
        BaseModal: BaseModal/* default */.Z,
        ExportCSV: ExportCSV/* default */.Z,
        GridTabs: GridTabs/* default */.Z,
        TransactionHistory: TransactionHistory,
        PendingTransactions: PendingTransactions
    },
    setup() {
        const { it } = (0,useTranslation/* useTranslation */.$)();
        const showModal = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const { activeWalletData, activeAccount } = (0,useActiveWallet/* useActiveWallet */.r)();
        const { toggleExportMenu, isExportMenuOpen } = useExportMenuOpen();
        const onClose = () => {
            showModal.value = false;
        };
        const openExport = () => {
            showModal.value = true;
            toggleExportMenu();
        };
        const contractPropMapping = (0,reactivity_esm_bundler/* ref */.iH)({
            properties: [],
            list: []
        });
        (0,runtime_core_esm_bundler/* onErrorCaptured */.d1)((e) => { console.error('Summary: onErrorCaptured', e); return true; });
        const optionsTabs = (0,reactivity_esm_bundler/* reactive */.qj)([
            { id: 'history', label: it('menu.wallet.transactions.submenu.history'), index: 0 },
            { id: 'pending', label: it('menu.wallet.transactions.submenu.pending'), index: 1 }
        ]);
        (0,runtime_core_esm_bundler/* onMounted */.bv)(async () => {
            contractPropMapping.value = await (0,ExtContractLib/* getContractMappings */.L)();
        });
        return {
            it,
            optionsTabs,
            onErrorCaptured: runtime_core_esm_bundler/* onErrorCaptured */.d1,
            toggleExportMenu,
            isExportMenuOpen,
            onClose,
            showModal,
            openExport,
            activeWalletData,
            activeAccount,
            contractPropMapping
        };
    }
}));

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/Transactions.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/Transactions.vue




;
const Transactions_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(Transactionsvue_type_script_lang_ts, [['render',render]])

/* harmony default export */ const Transactions = (Transactions_exports_);

/***/ })

}]);
//# sourceMappingURL=7415.js.map