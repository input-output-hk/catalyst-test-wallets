"use strict";
(this["webpackChunkccw_frontend"] = this["webpackChunkccw_frontend"] || []).push([[8260],{

/***/ 57161:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Verification)
});

// EXTERNAL MODULE: ./node_modules/@vue/runtime-core/dist/runtime-core.esm-bundler.js
var runtime_core_esm_bundler = __webpack_require__(83673);
// EXTERNAL MODULE: ./node_modules/@vue/shared/dist/shared.esm-bundler.js
var shared_esm_bundler = __webpack_require__(62323);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/Verification.vue?vue&type=template&id=192d8f53&ts=true

const _hoisted_1 = { class: "cc-page-wallet cc-text-sz" };
const _hoisted_2 = { class: "cc-grid" };
const _hoisted_3 = { class: "cc-grid" };
const _hoisted_4 = {
    key: 2,
    class: "col-span-12 grid grid-cols-12 cc-gap"
};
const _hoisted_5 = {
    key: 0,
    class: "cc-grid"
};
const _hoisted_6 = { class: "cc-grid" };
const _hoisted_7 = { class: "grid grid-cols-12 col-span-12" };
const _hoisted_8 = { class: "cc-grid" };
const _hoisted_9 = {
    key: 0,
    class: "col-span-12"
};
const _hoisted_10 = { class: "cc-text-semi-bold" };
const _hoisted_11 = { class: "cc-grid" };
const _hoisted_12 = { class: "cc-text-semi-bold" };
const _hoisted_13 = { class: "col-span-12 grid grid-cols-12" };
function render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridButtonSecondary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonSecondary");
    const _component_GridFormMnemonicVerify = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridFormMnemonicVerify");
    const _component_GridTextArea = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridTextArea");
    const _component_GridFormPasswordReset = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridFormPasswordReset");
    const _component_GridSteps = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSteps");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_1, [
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_2, [
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSteps, {
                onBack: _ctx.goBack,
                steps: _ctx.optionsSteps,
                currentStep: _ctx.currentStep,
                "small-c-s-s": "pr-20 xs:pr-20 lg:pr-24"
            }, {
                step0: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_3, [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridFormMnemonicVerify, {
                            onSubmit: _ctx.verifyMnemonic,
                            onInputChange: _ctx.resetValidity,
                            class: "col-span-12"
                        }, {
                            btnBack: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonSecondary, {
                                    label: _ctx.it('common.label.back'),
                                    link: _ctx.goBack,
                                    class: "col-start-0 col-span-6 lg:col-start-7 lg:col-span-3"
                                }, null, 8, ["label", "link"])
                            ]),
                            _: 1
                        }, 8, ["onSubmit", "onInputChange"]),
                        (_ctx.showIsValid)
                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridTextArea, {
                                key: 0,
                                text: _ctx.it('wallet.settings.verification.match.label'),
                                icon: _ctx.it('wallet.settings.verification.match.icon'),
                                class: "col-span-12 mt-2 sm:mt-4",
                                "text-c-s-s": "cc-text-normal text-justify flex justify-start items-center",
                                css: "cc-rounded cc-banner-green"
                            }, null, 8, ["text", "icon"]))
                            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                        (_ctx.showIsInvalid)
                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridTextArea, {
                                key: 1,
                                text: _ctx.it('wallet.settings.verification.invalid.label'),
                                icon: _ctx.it('wallet.settings.verification.invalid.icon'),
                                class: "col-span-12 mt-2 sm:mt-4",
                                "text-c-s-s": "cc-text-normal text-justify flex justify-start items-center",
                                css: "cc-rounded cc-banner-warning"
                            }, null, 8, ["text", "icon"]))
                            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                        (!_ctx.isActiveWalletLocked)
                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_4, [
                                (_ctx.showIsValid)
                                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridButtonSecondary, {
                                        key: 0,
                                        label: _ctx.it('wallet.settings.verification.match.spending'),
                                        link: _ctx.goToPasswordRestore,
                                        class: "col-start-7 col-span-6 lg:col-start-10 lg:col-span-3"
                                    }, null, 8, ["label", "link"]))
                                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                            ]))
                            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                    ]),
                    (_ctx.isActiveWalletLocked)
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_5, [
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_6, [
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridTextArea, {
                                    text: _ctx.it('wallet.settings.verification.recovery.caption'),
                                    icon: _ctx.it('wallet.settings.verification.recovery.icon'),
                                    class: "col-span-12 mt-2 sm:mt-4",
                                    "text-c-s-s": "cc-text-normal text-justify flex justify-start items-center",
                                    css: "cc-rounded cc-banner-blue"
                                }, null, 8, ["text", "icon"]),
                                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_7, [
                                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonSecondary, {
                                        label: _ctx.it('wallet.settings.verification.recovery.recover'),
                                        link: _ctx.goToRestore,
                                        class: "col-start-7 col-span-6 lg:col-start-10 lg:col-span-3 mt-3"
                                    }, null, 8, ["label", "link"])
                                ])
                            ])
                        ]))
                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                ]),
                step1: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_8, [
                        (!_ctx.isActiveWalletLocked)
                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_9, [
                                (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_10, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('wallet.settings.verification.spendingRecovery.label')), 1),
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridTextArea, {
                                    text: _ctx.it('wallet.settings.verification.spendingRecovery.caption'),
                                    icon: _ctx.it('wallet.settings.verification.spendingRecovery.icon'),
                                    class: "col-span-12 mt-2 sm:mt-4",
                                    "text-c-s-s": "cc-text-normal text-justify flex justify-start items-center",
                                    css: "cc-rounded cc-banner-blue"
                                }, null, 8, ["text", "icon"])
                            ]))
                            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_11, [
                            (_ctx.isMnemonicWallet && !_ctx.isLocked)
                                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridFormPasswordReset, {
                                    key: 0,
                                    "text-id": "form.password.spending",
                                    class: "col-span-12",
                                    saving: _ctx.saving,
                                    "require-old-password": false,
                                    onSubmit: _ctx.onSubmitPasswordReset
                                }, null, 8, ["saving", "onSubmit"]))
                                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                        ]),
                        (_ctx.isActiveWalletLocked)
                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", {
                                key: 1,
                                class: "cc-grid cursor-pointer",
                                onClick: _cache[0] || (_cache[0] = ($event) => (_ctx.expandDescription = !_ctx.expandDescription))
                            }, [
                                (0,runtime_core_esm_bundler/* createElementVNode */._)("i", {
                                    class: (0,shared_esm_bundler/* normalizeClass */.C_)(["mr-2", _ctx.expandDescription ? 'mdi mdi-chevron-down' : 'mdi mdi-chevron-right'])
                                }, null, 2),
                                (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_12, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('wallet.settings.verification.spendingRecovery.label')), 1),
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridTextArea, {
                                    text: _ctx.it('wallet.settings.verification.recovery.caption'),
                                    icon: _ctx.it('wallet.settings.verification.recovery.icon'),
                                    class: "col-span-12 mt-2 sm:mt-4",
                                    "text-c-s-s": "cc-text-normal text-justify flex justify-start items-center",
                                    css: "cc-rounded cc-banner-blue"
                                }, null, 8, ["text", "icon"])
                            ]))
                            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_13, [
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonSecondary, {
                                label: _ctx.it('common.label.back'),
                                link: _ctx.gotToLastStep,
                                class: "ml-1.5 col-start-7 col-span-6 lg:col-start-10 lg:col-span-3"
                            }, null, 8, ["label", "link"])
                        ])
                    ])
                ]),
                _: 1
            }, 8, ["onBack", "steps", "currentStep"])
        ])
    ]));
}

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/Verification.vue?vue&type=template&id=192d8f53&ts=true

// EXTERNAL MODULE: ./node_modules/@vue/reactivity/dist/reactivity.esm-bundler.js
var reactivity_esm_bundler = __webpack_require__(61959);
// EXTERNAL MODULE: ./node_modules/quasar/src/composables/use-quasar.js
var use_quasar = __webpack_require__(48825);
// EXTERNAL MODULE: ./src/composables/ccw/useNetworkId.ts
var useNetworkId = __webpack_require__(36648);
// EXTERNAL MODULE: ./src/composables/ccw/useTranslation.ts
var useTranslation = __webpack_require__(19376);
// EXTERNAL MODULE: ./src/composables/ccw/useNavigation.ts
var useNavigation = __webpack_require__(52439);
// EXTERNAL MODULE: ./src/composables/ccw/store/useWalletCreation.ts
var useWalletCreation = __webpack_require__(68139);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridButtonPrimary.vue + 3 modules
var GridButtonPrimary = __webpack_require__(12559);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridButtonSecondary.vue + 3 modules
var GridButtonSecondary = __webpack_require__(72713);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridHeadline.vue + 3 modules
var GridHeadline = __webpack_require__(63593);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridText.vue + 4 modules
var GridText = __webpack_require__(96834);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridTextArea.vue + 4 modules
var GridTextArea = __webpack_require__(15660);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridSpace.vue + 4 modules
var GridSpace = __webpack_require__(14740);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridInput.vue + 4 modules
var GridInput = __webpack_require__(27209);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/forms/GridFormPasswordReset.vue + 3 modules
var GridFormPasswordReset = __webpack_require__(2252);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridSteps.vue + 14 modules
var GridSteps = __webpack_require__(58217);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/icons/IconPencil.vue + 4 modules
var IconPencil = __webpack_require__(44814);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/mnemonic/GridFormMnemonicVerify.vue?vue&type=template&id=4e011fa0&ts=true

const GridFormMnemonicVerifyvue_type_template_id_4e011fa0_ts_true_hoisted_1 = { class: "w-full grid grid-cols-12 cc-gap" };
const GridFormMnemonicVerifyvue_type_template_id_4e011fa0_ts_true_hoisted_2 = {
    key: 2,
    class: "w-full col-span-12 grid grid-cols-12 cc-gap"
};
function GridFormMnemonicVerifyvue_type_template_id_4e011fa0_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridTextArea = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridTextArea");
    const _component_GridFormMnemonicList = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridFormMnemonicList");
    const _component_IconPencil = (0,runtime_core_esm_bundler/* resolveComponent */.up)("IconPencil");
    const _component_GridInput = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridInput");
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    const _component_GridButtonSecondary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonSecondary");
    const _component_GridButtonPrimary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonPrimary");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", GridFormMnemonicVerifyvue_type_template_id_4e011fa0_ts_true_hoisted_1, [
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridTextArea, {
            label: _ctx.it('form.mnemonicinput.instructions.label'),
            text: _ctx.it('form.mnemonicinput.instructions.text'),
            icon: _ctx.it('form.mnemonicinput.instructions.icon'),
            class: "col-span-12",
            css: "cc-area-highlight",
            "text-c-s-s": "cc-text-normal text-justify"
        }, null, 8, ["label", "text", "icon"]),
        (_ctx.inputMnemonic.length)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridFormMnemonicList, {
                key: 0,
                label: _ctx.it('form.mnemonicinput.label'),
                mnemonic: _ctx.inputMnemonic,
                "onUpdate:mnemonic": _cache[0] || (_cache[0] = ($event) => ((_ctx.inputMnemonic) = $event)),
                editable: true,
                onRemoveWord: _ctx.removeWord,
                class: "col-span-12"
            }, null, 8, ["label", "mnemonic", "onRemoveWord"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (_ctx.inputMnemonic.length < 24)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridInput, {
                key: 1,
                "input-text": _ctx.wordInput,
                "onUpdate:input-text": _cache[1] || (_cache[1] = ($event) => ((_ctx.wordInput) = $event)),
                "input-error": _ctx.wordInputError,
                "onUpdate:input-error": _cache[2] || (_cache[2] = ($event) => ((_ctx.wordInputError) = $event)),
                onEnter: _ctx.onEnter,
                label: _ctx.it('form.mnemonicinput.input.label'),
                "input-hint": _ctx.it('form.mnemonicinput.input.hint'),
                "input-info": _ctx.wordInputInfo,
                alwaysShowInfo: true,
                "input-id": "wordInput",
                "input-type": "text",
                autofocus: "",
                class: "col-span-12"
            }, {
                "icon-prepend": (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_IconPencil, { class: "h-5 w-5" })
                ]),
                _: 1
            }, 8, ["input-text", "input-error", "onEnter", "label", "input-hint", "input-info"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, { hr: "" }),
        ( true)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", GridFormMnemonicVerifyvue_type_template_id_4e011fa0_ts_true_hoisted_2, [
                (_ctx.wordInput.length > 1)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(true), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, { key: 0 }, (0,runtime_core_esm_bundler/* renderList */.Ko)(_ctx.filterOptions, (item) => {
                        return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridButtonSecondary, {
                            key: item + 'filter',
                            label: item,
                            capitalize: false,
                            link: () => _ctx.onClickedWord(item),
                            class: "col-span-6 sm:col-span-4 lg:col-span-2 lowercase"
                        }, null, 8, ["label", "link"]));
                    }), 128))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
            ]))
            : 0,
        (0,runtime_core_esm_bundler/* renderSlot */.WI)(_ctx.$slots, "btnBack"),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonPrimary, {
            label: _ctx.it('wallet.settings.verification.start'),
            disabled: _ctx.disableSubmit,
            link: _ctx.onSubmit,
            class: "col-start-7 col-span-6 lg:col-start-10 lg:col-span-3"
        }, null, 8, ["label", "disabled", "link"])
    ]));
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/mnemonic/GridFormMnemonicVerify.vue?vue&type=template&id=4e011fa0&ts=true

// EXTERNAL MODULE: ./src/lib/ExtLib.ts
var ExtLib = __webpack_require__(23211);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/mnemonic/GridFormMnemonicList.vue + 4 modules
var GridFormMnemonicList = __webpack_require__(64756);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/mnemonic/GridFormMnemonicVerify.vue?vue&type=script&lang=ts











/* harmony default export */ const GridFormMnemonicVerifyvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'GridFormMnemonicVerify',
    components: {
        IconPencil: IconPencil/* default */.Z,
        GridFormMnemonicList: GridFormMnemonicList/* default */.Z,
        GridInput: GridInput/* default */.Z,
        GridSpace: GridSpace/* default */.Z,
        GridTextArea: GridTextArea/* default */.Z,
        GridButtonPrimary: GridButtonPrimary/* default */.Z,
        GridButtonSecondary: GridButtonSecondary/* default */.Z
    },
    emits: ['submit', 'inputChange'],
    props: {
        mnemonic: { type: Array, required: false, default: () => [] },
        textId: { type: String, default: '' }
    },
    setup(props, context) {
        const { it } = (0,useTranslation/* useTranslation */.$)();
        const wordlist = ExtLib.wordlists.english.concat();
        const inputMnemonic = (0,reactivity_esm_bundler/* ref */.iH)([]);
        const info = it('form.mnemonicinput.input.info');
        const wordInput = (0,reactivity_esm_bundler/* ref */.iH)('');
        const wordInputError = (0,reactivity_esm_bundler/* ref */.iH)('');
        const wordInputInfo = (0,reactivity_esm_bundler/* ref */.iH)(info);
        const filterOptions = (0,reactivity_esm_bundler/* ref */.iH)([]);
        const disableSubmit = (0,runtime_core_esm_bundler/* computed */.Fl)(() => {
            return inputMnemonic.value.length !== 24 && inputMnemonic.value.length !== 15 && inputMnemonic.value.length !== 12;
        });
        function onEnter() {
            wordInput.value = wordInput.value + ' ';
        }
        const showWordLimitError = () => {
            wordInputError.value = it('wallet.settings.verification.wordLimit');
        };
        (0,runtime_core_esm_bundler/* watch */.YP)(wordInput, (newValue, oldValue) => {
            if (inputMnemonic.value.length > 24) {
                showWordLimitError();
                return;
            }
            context.emit('inputChange');
            if (newValue.length === 0) {
                wordInputInfo.value = info;
                wordInputError.value = '';
            }
            else {
                const input = newValue.toLowerCase();
                const needle = input.trim();
                if (needle.includes(' ')) {
                    const words = needle.split(' ');
                    const filteredWords = [];
                    for (const word of words) {
                        if (word && word.length > 0) {
                            const filtered = (wordlist.filter(v => v.toLowerCase().startsWith(word)));
                            if (filtered.some(e => e === word)) {
                                filteredWords.push(word);
                            }
                            else {
                                filteredWords.length = 0;
                            }
                        }
                    }
                    wordInput.value = '';
                    for (let i = 0; i < filteredWords.length; i++) {
                        if (filteredWords[i] && filteredWords[i].length && inputMnemonic.value.length < 24) {
                            inputMnemonic.value[inputMnemonic.value.length] = filteredWords[i];
                        }
                    }
                    validateWordInput();
                    return;
                }
                filterOptions.value = (wordlist.filter(v => v.toLowerCase().startsWith(needle)));
                if (input.length > needle.length && filterOptions.value.some(e => e === needle)) {
                    filterOptions.value = [needle];
                }
                let info = filterOptions.value.join(', ');
                if (info.length > 64) {
                    info = info.substr(0, 64) + ' ...';
                }
                wordInputInfo.value = info;
                if (input.endsWith(' ')) {
                    validateWordInput();
                }
            }
        });
        function validateWordInput() {
            let index = inputMnemonic.value.length;
            if (filterOptions.value.length === 0) {
                wordInputError.value = it('form.mnemonicinput.input.error');
            }
            else {
                if (filterOptions.value[0]) {
                    if (inputMnemonic.value.length < 24) {
                        inputMnemonic.value.push('');
                        inputMnemonic.value[index] = filterOptions.value[0];
                        wordInput.value = '';
                    }
                }
            }
            return wordInputError.value;
        }
        function onSubmit() {
            try {
                context.emit('submit', { mnemonic: inputMnemonic.value.filter((element) => element.length > 0).join(' ') });
            }
            catch (e) {
                wordInputError.value = it('form.mnemonicinput.input.error');
            }
        }
        function onClickedWord(word) {
            if (inputMnemonic.value.length === 24) {
                showWordLimitError();
                return;
            }
            wordInput.value = word + ' ';
            document.getElementById('wordInput')?.focus();
        }
        const removeWord = (payload) => {
            context.emit('inputChange');
            inputMnemonic.value.splice(payload.index, 1);
            wordInputError.value = '';
        };
        return {
            it,
            onClickedWord,
            onEnter,
            onSubmit,
            removeWord,
            validateWordInput,
            disableSubmit,
            filterOptions,
            inputMnemonic,
            wordInput,
            wordInputError,
            wordInputInfo,
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/mnemonic/GridFormMnemonicVerify.vue?vue&type=script&lang=ts
 
// EXTERNAL MODULE: ./node_modules/vue-loader/dist/exportHelper.js
var exportHelper = __webpack_require__(74260);
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/mnemonic/GridFormMnemonicVerify.vue




;
const __exports__ = /*#__PURE__*/(0,exportHelper/* default */.Z)(GridFormMnemonicVerifyvue_type_script_lang_ts, [['render',GridFormMnemonicVerifyvue_type_template_id_4e011fa0_ts_true_render]])

/* harmony default export */ const GridFormMnemonicVerify = (__exports__);
// EXTERNAL MODULE: ./src/composables/ccw/store/useActiveWallet.ts
var useActiveWallet = __webpack_require__(52144);
// EXTERNAL MODULE: ./src/lib/ExtAppWalletManagerLib.ts
var ExtAppWalletManagerLib = __webpack_require__(12736);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/Verification.vue?vue&type=script&lang=ts

;

















/* harmony default export */ const Verificationvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'Verification',
    components: {
        GridSpace: GridSpace/* default */.Z,
        GridHeadline: GridHeadline/* default */.Z,
        GridText: GridText/* default */.Z,
        GridInput: GridInput/* default */.Z,
        GridButtonPrimary: GridButtonPrimary/* default */.Z,
        GridButtonSecondary: GridButtonSecondary/* default */.Z,
        GridTextArea: GridTextArea/* default */.Z,
        GridFormMnemonicVerify: GridFormMnemonicVerify,
        GridSteps: GridSteps/* default */.Z,
        GridFormPasswordReset: GridFormPasswordReset/* default */.Z,
        IconPencil: IconPencil/* default */.Z
    },
    setup() {
        const currentStep = (0,reactivity_esm_bundler/* ref */.iH)(0);
        const { setMnemonic, generateWalletIdFromMnemonic } = (0,useWalletCreation/* useWalletCreation */.c)();
        const { it } = (0,useTranslation/* useTranslation */.$)();
        const { networkId } = (0,useNetworkId/* useNetworkId */.h)();
        const { openWalletPage, gotoPage } = (0,useNavigation/* useNavigation */.HJ)();
        const { activeWalletId, isActiveWalletLocked, activeWalletSignType, } = (0,useActiveWallet/* useActiveWallet */.r)();
        const isLocked = isActiveWalletLocked.value;
        const isMnemonicWallet = (0,runtime_core_esm_bundler/* computed */.Fl)(() => activeWalletSignType.value === 'mnemonic');
        const optionsSteps = (0,runtime_core_esm_bundler/* computed */.Fl)(() => {
            if (isActiveWalletLocked.value) {
                return [
                    { id: 'phrase', label: it('wallet.settings.verification.spendingRecovery.step0') },
                ];
            }
            else {
                return [
                    { id: 'phrase', label: it('wallet.settings.verification.spendingRecovery.step0') },
                    { id: 'password', label: it('wallet.settings.verification.spendingRecovery.step1') },
                ];
            }
        });
        const expandDescription = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const showIsValid = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const showIsInvalid = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const saving = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const $q = (0,use_quasar/* default */.Z)();
        function resetInputs() {
            setMnemonic('');
        }
        resetInputs();
        const gotToLastStep = () => {
            currentStep.value = currentStep.value > 0 ? currentStep.value - 1 : 0;
        };
        const goToPasswordRestore = () => {
            currentStep.value = 1;
        };
        const goBack = () => {
            openWalletPage('WalletSettings', activeWalletId.value, 'verification');
        };
        const goToRestore = () => {
            openWalletPage('WalletRestore', activeWalletId.value);
        };
        const resetValidity = () => {
            showIsValid.value = false;
            showIsInvalid.value = false;
        };
        const mnemonic = (0,reactivity_esm_bundler/* ref */.iH)();
        const verifyMnemonic = (payload) => {
            resetValidity();
            if (payload.mnemonic) {
                setMnemonic(payload.mnemonic ?? '');
                mnemonic.value = payload.mnemonic;
                try {
                    const walletId = generateWalletIdFromMnemonic(networkId.value);
                    if (activeWalletId.value === walletId) {
                        showIsValid.value = true;
                    }
                    else {
                        showIsInvalid.value = true;
                    }
                }
                catch (error) {
                    showIsInvalid.value = true;
                }
            }
        };
        async function onSubmitPasswordReset(payload) {
            if (activeWalletId.value) {
                saving.value = true;
                await ExtAppWalletManagerLib/* AWM.updateSpendingFromMnemonic */.b.updateSpendingFromMnemonic(activeWalletId.value, { password: payload.password, mnemonic: mnemonic.value });
                saving.value = false;
                $q.notify({
                    type: 'positive',
                    message: it('wallet.settings.message.success'),
                    position: 'top-left'
                });
            }
        }
        return {
            it,
            showIsValid,
            showIsInvalid,
            gotToLastStep,
            resetValidity,
            verifyMnemonic,
            goBack,
            isActiveWalletLocked,
            expandDescription,
            goToRestore,
            gotoPage,
            optionsSteps,
            currentStep,
            goToPasswordRestore,
            isMnemonicWallet,
            onSubmitPasswordReset,
            isLocked,
            saving
        };
    }
}));

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/Verification.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/Verification.vue




;
const Verification_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(Verificationvue_type_script_lang_ts, [['render',render]])

/* harmony default export */ const Verification = (Verification_exports_);

/***/ })

}]);
//# sourceMappingURL=8260.js.map