"use strict";
(this["webpackChunkccw_frontend"] = this["webpackChunkccw_frontend"] || []).push([[6266],{

/***/ 41038:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ BexEnableLayout)
});

// EXTERNAL MODULE: ./node_modules/@vue/runtime-core/dist/runtime-core.esm-bundler.js
var runtime_core_esm_bundler = __webpack_require__(83673);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/layouts/ccw/BexEnableLayout.vue?vue&type=template&id=5163c43e&scoped=true&ts=true

const _withScopeId = n => ((0,runtime_core_esm_bundler/* pushScopeId */.dD)("data-v-5163c43e"), n = n(), (0,runtime_core_esm_bundler/* popScopeId */.Cn)(), n);
const _hoisted_1 = {
    class: "relative w-full h-full cc-layout-px cc-layout-py cc-text-color flex flex-col flex-nowrap",
    id: "cc-layout-container"
};
const _hoisted_2 = /*#__PURE__*/ _withScopeId(() => /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("div", {
    class: "fixed inset-0 bg-gradient-to-r from-slate-200 to-stone-200 dark:from-slate-900 dark:to-stone-900",
    id: "cc-background-iframe-container"
}, null, -1));
const _hoisted_3 = {
    class: "relative flex-grow w-full flex-1 cc-site-max-width mx-auto flex flex-col flex-nowrap",
    id: "cc-main-container"
};
const _hoisted_4 = {
    class: "relative flex-1 flex-grow-1 h-full overflow-hidden cc-rounded-la cc-shadow flex flex-row flex-nowrap",
    style: { "min-height": "222px" }
};
const _hoisted_5 = { class: "relative flex-1 w-full h-full" };
const _hoisted_6 = { class: "relative w-full h-full cc-rounded-la flex flex-row flex-nowrap cc-bg-light-1" };
const _hoisted_7 = { class: "relative h-full flex-1 overflow-hidden focus:outline-none flex flex-col flex-nowrap" };
function render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_Header = (0,runtime_core_esm_bundler/* resolveComponent */.up)("Header");
    const _component_EpochProgress = (0,runtime_core_esm_bundler/* resolveComponent */.up)("EpochProgress");
    const _component_router_view = (0,runtime_core_esm_bundler/* resolveComponent */.up)("router-view");
    const _component_NavSidebarEnable = (0,runtime_core_esm_bundler/* resolveComponent */.up)("NavSidebarEnable");
    const _component_Footer = (0,runtime_core_esm_bundler/* resolveComponent */.up)("Footer");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_1, [
        _hoisted_2,
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_Header),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_EpochProgress),
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_3, [
            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_4, [
                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_5, [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_6, [
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("main", _hoisted_7, [
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_router_view)
                        ])
                    ])
                ]),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_NavSidebarEnable, { api: _ctx.api }, null, 8, ["api"])
            ])
        ]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_Footer)
    ]));
}

;// CONCATENATED MODULE: ./src/layouts/ccw/BexEnableLayout.vue?vue&type=template&id=5163c43e&scoped=true&ts=true

// EXTERNAL MODULE: ./node_modules/quasar/src/composables/use-quasar.js
var use_quasar = __webpack_require__(48825);
// EXTERNAL MODULE: ./src/composables/ccw/useTranslation.ts
var useTranslation = __webpack_require__(19376);
// EXTERNAL MODULE: ./src/composables/ccw/state/useMainMenuOpen.ts
var useMainMenuOpen = __webpack_require__(33008);
// EXTERNAL MODULE: ./src/components/ccw/Header.vue + 28 modules
var Header = __webpack_require__(34928);
// EXTERNAL MODULE: ./src/components/ccw/header/EpochProgress.vue + 5 modules
var EpochProgress = __webpack_require__(81780);
// EXTERNAL MODULE: ./src/components/ccw/Footer.vue + 14 modules
var Footer = __webpack_require__(78542);
// EXTERNAL MODULE: ./node_modules/@vue/shared/dist/shared.esm-bundler.js
var shared_esm_bundler = __webpack_require__(62323);
// EXTERNAL MODULE: ./node_modules/@vue/runtime-dom/dist/runtime-dom.esm-bundler.js
var runtime_dom_esm_bundler = __webpack_require__(98880);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/bex/NavSidebarEnable.vue?vue&type=template&id=8178c1a2&ts=true

const NavSidebarEnablevue_type_template_id_8178c1a2_ts_true_hoisted_1 = {
    key: 0,
    class: "w-full h-full inline-block px-1.5 mt-1.5 pt-1.5 pb-1.5"
};
const NavSidebarEnablevue_type_template_id_8178c1a2_ts_true_hoisted_2 = { class: "w-full h-full flex flex-col flex-nowrap justify-between" };
const NavSidebarEnablevue_type_template_id_8178c1a2_ts_true_hoisted_3 = { class: "w-full h-full flex flex-col flex-nowrap space-y-4" };
const NavSidebarEnablevue_type_template_id_8178c1a2_ts_true_hoisted_4 = { class: "space-y-2" };
const NavSidebarEnablevue_type_template_id_8178c1a2_ts_true_hoisted_5 = { class: "w-full cc-flex-fixed grid grid-cols-12 cc-gap" };
function NavSidebarEnablevue_type_template_id_8178c1a2_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridTextArea = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridTextArea");
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    const _component_GridButtonSecondary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonSecondary");
    const _component_GridButtonPrimary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonPrimary");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, [
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", {
            class: (0,shared_esm_bundler/* normalizeClass */.C_)(["absolute z-40 inset-0 w-full h-full cursor-pointer cc-rounded-la overflow-hidden cc-none lg:hidden", _ctx.isMainMenuOpen ? 'flex' : '']),
            onClick: _cache[0] || (_cache[0] = (0,runtime_dom_esm_bundler/* withModifiers */.iM)(
            //@ts-ignore
            (...args) => (_ctx.toggleMainMenu && _ctx.toggleMainMenu(...args)), ["stop"]))
        }, null, 2),
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", {
            class: (0,shared_esm_bundler/* normalizeClass */.C_)(["absolute order-first z-50 w-full xs:w-72 cc-rounded-la-l inset-0 cc-shadow cc-none lg:flex lg:relative cc-flex-fixed flex-col flex-nowrap cc-nav-bg", _ctx.isMainMenuOpen ? 'flex' : ''])
        }, [
            (_ctx.appMode === 'enable')
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", NavSidebarEnablevue_type_template_id_8178c1a2_ts_true_hoisted_1, [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", NavSidebarEnablevue_type_template_id_8178c1a2_ts_true_hoisted_2, [
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", NavSidebarEnablevue_type_template_id_8178c1a2_ts_true_hoisted_3, [
                            (!_ctx.dAppAccountSet)
                                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridTextArea, {
                                    key: 0,
                                    class: "cc-flex-fixed col-span-12 w-full",
                                    css: "cc-text-semi-bold cc-rounded cc-banner-warning",
                                    "text-c-s-s": "",
                                    text: _ctx.it('wallet.bex.activateAccount'),
                                    icon: _ctx.it('dapps.enable.access.info.icon')
                                }, null, 8, ["text", "icon"]))
                                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                            (_ctx.dAppAccountSet)
                                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridTextArea, {
                                    key: 1,
                                    class: "cc-flex-fixed col-span-12 w-full",
                                    css: "cc-text-semi-bold cc-rounded cc-banner-blue",
                                    "text-c-s-s": "",
                                    html: true,
                                    text: _ctx.it('dapps.enable.access.info.text'),
                                    icon: _ctx.it('dapps.enable.access.info.icon') + ' relative -top-1'
                                }, null, 8, ["text", "icon"]))
                                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                            (_ctx.dAppAccountSet)
                                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridSpace, {
                                    key: 2,
                                    hr: "",
                                    label: _ctx.it('dapps.enable.access.access.url'),
                                    "label-c-s-s": "cc-text-bold cc-text-sz",
                                    class: "w-full mb-4"
                                }, null, 8, ["label"]))
                                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                            (_ctx.dAppAccountSet)
                                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridTextArea, {
                                    key: 3,
                                    class: "cc-flex-fixed col-span-12 w-full",
                                    css: 'cc-rounded ' + (_ctx.isHTTPS ? 'cc-banner-green' : 'cc-banner-warning'),
                                    "text-c-s-s": "cc-text-bold",
                                    text: _ctx.bexOrigin + (!_ctx.isHTTPS ? ' (not secure)' : ''),
                                    icon: _ctx.it('dapps.enable.access.url.icon')
                                }, null, 8, ["css", "text", "icon"]))
                                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", null, [
                                (_ctx.dAppAccountSet)
                                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridSpace, {
                                        key: 0,
                                        hr: "",
                                        label: _ctx.it('dapps.enable.access.access.label'),
                                        "label-c-s-s": "cc-text-bold cc-text-sz mb-0",
                                        class: "w-full mb-4"
                                    }, null, 8, ["label"]))
                                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", NavSidebarEnablevue_type_template_id_8178c1a2_ts_true_hoisted_4, [
                                    (_ctx.dAppAccountSet && _ctx.cip30req)
                                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridTextArea, {
                                            key: 0,
                                            class: "cc-flex-fixed col-span-12 w-full",
                                            css: "cc-text-semi-bold cc-rounded cc-banner-gray",
                                            "text-c-s-s": "",
                                            html: true,
                                            text: '<b>' + _ctx.it('dapps.enable.access.cip30.label') + '</b>' + _ctx.it('dapps.enable.access.cip30.description'),
                                            icon: _ctx.it('dapps.enable.access.cip30.icon') + ' relative -top-1'
                                        }, null, 8, ["text", "icon"]))
                                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                                    (_ctx.dAppAccountSet && _ctx.cip62purposeStr.length > 0)
                                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridTextArea, {
                                            key: 1,
                                            class: "cc-flex-fixed col-span-12 w-full",
                                            css: "cc-text-semi-bold cc-rounded cc-banner-gray",
                                            "text-c-s-s": "",
                                            html: true,
                                            text: '<b>' + _ctx.it('dapps.enable.access.cip62.label') + '</b>' + _ctx.it('dapps.enable.access.cip62.description') + ' ' + _ctx.cip62purposeStr,
                                            icon: _ctx.it('dapps.enable.access.cip62.icon') + ' relative -top-1'
                                        }, null, 8, ["text", "icon"]))
                                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                                ])
                            ])
                        ]),
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", NavSidebarEnablevue_type_template_id_8178c1a2_ts_true_hoisted_5, [
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonSecondary, {
                                label: 'Cancel',
                                link: _ctx.onCancel,
                                class: "col-span-6"
                            }, null, 8, ["link"]),
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonPrimary, {
                                label: 'Connect to Site',
                                link: _ctx.onConnect,
                                disabled: !_ctx.dAppAccountSet,
                                class: "col-span-6"
                            }, null, 8, ["link", "disabled"])
                        ])
                    ])
                ]))
                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
        ], 2)
    ], 64));
}

;// CONCATENATED MODULE: ./src/components/bex/NavSidebarEnable.vue?vue&type=template&id=8178c1a2&ts=true

// EXTERNAL MODULE: ./node_modules/@vue/reactivity/dist/reactivity.esm-bundler.js
var reactivity_esm_bundler = __webpack_require__(61959);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridSpace.vue + 4 modules
var GridSpace = __webpack_require__(14740);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridTextArea.vue + 4 modules
var GridTextArea = __webpack_require__(15660);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridButtonPrimary.vue + 3 modules
var GridButtonPrimary = __webpack_require__(12559);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridButtonSecondary.vue + 3 modules
var GridButtonSecondary = __webpack_require__(72713);
// EXTERNAL MODULE: ./src/lib/ExtStorageLib.ts + 1 modules
var ExtStorageLib = __webpack_require__(40736);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/bex/NavSidebarEnable.vue?vue&type=script&lang=ts

;







/* harmony default export */ const NavSidebarEnablevue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'NavSidebarEnable',
    components: {
        GridSpace: GridSpace/* default */.Z,
        GridTextArea: GridTextArea/* default */.Z,
        GridButtonPrimary: GridButtonPrimary/* default */.Z,
        GridButtonSecondary: GridButtonSecondary/* default */.Z,
    },
    props: {
        api: { type: String, required: true }
    },
    setup(props) {
        const { it } = (0,useTranslation/* useTranslation */.$)();
        const { toggleMainMenu, openMainMenu, isMainMenuOpen } = (0,useMainMenuOpen/* useMainMenuOpen */.T)();
        const cip30req = [ExtStorageLib/* RESPONSE.onEnabled */.YC.onEnabled, ExtStorageLib/* RESPONSE.onCIP62Enabled */.YC.onCIP62Enabled].includes(props.api) && !(0,ExtStorageLib/* getConnectedOriginList */.Cs)().includes(ExtStorageLib/* bexOrigin.value */.g0.value ?? '');
        const cip62req = props.api === ExtStorageLib/* RESPONSE.onCIP62Enabled */.YC.onCIP62Enabled;
        const getcip62purposeStr = () => {
            const cip62purpose = cip62req ? (0,ExtStorageLib/* getCIP62PurposeList */.Ce)() : [];
            let purposeArr = [];
            for (const purpose of cip62purpose) {
                const name = (0,ExtStorageLib/* getCIP62PurposeName */.IA)(purpose);
                name.length > 0 ? purposeArr.push(name) : false;
            }
            return purposeArr.join(', ');
        };
        const cip62purposeStr = getcip62purposeStr();
        const isHTTPS = ExtStorageLib/* bexOrigin.value */.g0.value?.startsWith('https');
        const $q = (0,use_quasar/* default */.Z)();
        console.warn('setup: func NavSidebarEnable');
        const toWalletId = (0,reactivity_esm_bundler/* ref */.iH)((0,ExtStorageLib/* getDAppWalletId */.ix)());
        const toAccountId = (0,reactivity_esm_bundler/* ref */.iH)((0,ExtStorageLib/* getDAppAccountId */.KB)());
        const updateDAppIds = () => {
            toWalletId.value = (0,ExtStorageLib/* getDAppWalletId */.ix)();
            toAccountId.value = (0,ExtStorageLib/* getDAppAccountId */.KB)();
        };
        window.removeEventListener('focus', updateDAppIds);
        window.removeEventListener('blur', updateDAppIds);
        window.addEventListener('focus', updateDAppIds);
        window.addEventListener('blur', updateDAppIds);
        const dAppAccountSet = (0,runtime_core_esm_bundler/* computed */.Fl)(() => !!toAccountId.value);
        openMainMenu();
        function onConnect() {
            //@ts-ignore
            console.warn('NavSidebarEnable: onConnect', $q.bex);
            //@ts-ignore
            if ($q.bex) {
                //@ts-ignore
                $q.bex.send('eternl.to.bg', {
                    api: props.api,
                    payload: {
                        origin: ExtStorageLib/* bexOrigin.value */.g0.value
                    },
                    response: {
                        isEnabled: true
                    }
                });
            }
        }
        function onCancel() {
            console.warn('NavSidebarEnable: onCancel');
            //@ts-ignore
            if ($q.bex) {
                //@ts-ignore
                $q.bex.send('eternl.to.bg', {
                    api: props.api,
                    payload: {
                        origin: ExtStorageLib/* bexOrigin.value */.g0.value
                    },
                    response: {
                        isEnabled: false
                    }
                });
            }
        }
        return {
            it,
            cip30req,
            cip62req,
            cip62purposeStr,
            isHTTPS,
            appMode: ExtStorageLib/* appMode */.pd,
            bexMode: ExtStorageLib/* bexMode */.I6,
            bexOrigin: ExtStorageLib/* bexOrigin */.g0,
            onConnect,
            onCancel,
            toggleMainMenu,
            isMainMenuOpen,
            dAppAccountSet
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/bex/NavSidebarEnable.vue?vue&type=script&lang=ts
 
// EXTERNAL MODULE: ./node_modules/vue-loader/dist/exportHelper.js
var exportHelper = __webpack_require__(74260);
;// CONCATENATED MODULE: ./src/components/bex/NavSidebarEnable.vue




;
const __exports__ = /*#__PURE__*/(0,exportHelper/* default */.Z)(NavSidebarEnablevue_type_script_lang_ts, [['render',NavSidebarEnablevue_type_template_id_8178c1a2_ts_true_render]])

/* harmony default export */ const NavSidebarEnable = (__exports__);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/layouts/ccw/BexEnableLayout.vue?vue&type=script&lang=ts

;






/* harmony default export */ const BexEnableLayoutvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'BexEnableLayout',
    components: {
        Header: Header/* default */.Z,
        EpochProgress: EpochProgress/* default */.Z,
        Footer: Footer/* default */.Z,
        NavSidebarEnable: NavSidebarEnable
    },
    props: {
        api: { type: String, required: true }
    },
    setup(props) {
        const { t } = (0,useTranslation/* useTranslation */.$)();
        const { isMainMenuOpen } = (0,useMainMenuOpen/* useMainMenuOpen */.T)();
        const $q = (0,use_quasar/* default */.Z)();
        console.log('BexEnableLayout: api:', props.api);
        (0,runtime_core_esm_bundler/* onErrorCaptured */.d1)((e, instance, info) => {
            $q.notify({
                type: 'negative',
                message: 'error: ' + (e?.message ?? 'no error message') + ' info: ' + info,
                position: 'top-left',
                timeout: 20000,
                closeBtn: true
            });
            console.error('Layout: onErrorCaptured', e);
            return true;
        });
        return {
            t,
            isMainMenuOpen
        };
    }
}));

;// CONCATENATED MODULE: ./src/layouts/ccw/BexEnableLayout.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/layouts/ccw/BexEnableLayout.vue




;


const BexEnableLayout_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(BexEnableLayoutvue_type_script_lang_ts, [['render',render],['__scopeId',"data-v-5163c43e"]])

/* harmony default export */ const BexEnableLayout = (BexEnableLayout_exports_);

/***/ })

}]);
//# sourceMappingURL=6266.js.map