"use strict";
(this["webpackChunkccw_frontend"] = this["webpackChunkccw_frontend"] || []).push([[3543],{

/***/ 81226:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Restore)
});

// EXTERNAL MODULE: ./node_modules/@vue/runtime-core/dist/runtime-core.esm-bundler.js
var runtime_core_esm_bundler = __webpack_require__(83673);
// EXTERNAL MODULE: ./node_modules/@vue/shared/dist/shared.esm-bundler.js
var shared_esm_bundler = __webpack_require__(62323);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/Restore.vue?vue&type=template&id=65c6ff2c&ts=true

const _hoisted_1 = { class: "min-h-16 sm:min-h-20 w-full max-w-full p-3 text-center flex flex-col flex-nowrap justify-center items-center border-t border-b mb-px cc-text-sz cc-bg-white-0" };
const _hoisted_2 = { class: "cc-text-semi-bold" };
const _hoisted_3 = { class: "" };
const _hoisted_4 = { class: "cc-page-wallet cc-text-sz" };
function render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_InfoModal = (0,runtime_core_esm_bundler/* resolveComponent */.up)("InfoModal");
    const _component_AccountCreationOverlay = (0,runtime_core_esm_bundler/* resolveComponent */.up)("AccountCreationOverlay");
    const _component_ConfirmationModal = (0,runtime_core_esm_bundler/* resolveComponent */.up)("ConfirmationModal");
    const _component_GridHeadline = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridHeadline");
    const _component_GridText = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridText");
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    const _component_GridRadioGroup = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridRadioGroup");
    const _component_GridButtonPrimary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonPrimary");
    const _component_GridButtonSecondary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonSecondary");
    const _component_GridFormMnemonicInput = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridFormMnemonicInput");
    const _component_GridFormWalletNamePassword = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridFormWalletNamePassword");
    const _component_GridFormAccountSelection = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridFormAccountSelection");
    const _component_GridSteps = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSteps");
    const _component_Page = (0,runtime_core_esm_bundler/* resolveComponent */.up)("Page");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_Page, {
        containerCSS: '',
        "align-top": ""
    }, {
        header: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_1, [
                (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_2, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('wallet.restore.headline')), 1),
                (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_3, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('wallet.restore.caption')), 1)
            ])
        ]),
        content: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
            (_ctx.showInfoModal)
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_InfoModal, {
                    key: 0,
                    caption: _ctx.it('common.walletCreation.restart'),
                    title: _ctx.it('common.label.notice'),
                    onClose: _ctx.onHideModal,
                    onConfirm: _ctx.onHideModal
                }, null, 8, ["caption", "title", "onClose", "onConfirm"]))
                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
            (_ctx.walletCreateInProgress)
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_AccountCreationOverlay, {
                    key: 1,
                    status: _ctx.walletCreationStatus
                }, null, 8, ["status"]))
                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
            (_ctx.isMounted)
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_ConfirmationModal, {
                    key: 2,
                    "show-modal": _ctx.showRestoreModal,
                    onConfirm: _ctx.confirmGotoNextStepWalletName,
                    onCancel: _ctx.openExistingWalletOnSettings,
                    onClose: _ctx.openExistingWalletOnSettings,
                    title: _ctx.it('wallet.settings.verification.recovery.confirmModal.label'),
                    caption: _ctx.it('wallet.settings.verification.recovery.confirmModal.text')
                }, null, 8, ["show-modal", "onConfirm", "onCancel", "onClose", "title", "caption"]))
                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_4, [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSteps, {
                    onBack: _ctx.goBack,
                    steps: _ctx.optionsSteps,
                    currentStep: _ctx.currentStep,
                    "small-c-s-s": "pr-20 xs:pr-20 lg:pr-24"
                }, {
                    step0: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                            label: _ctx.it('wallet.restore.step.type.headline'),
                            doCapitalize: false
                        }, null, 8, ["label"]),
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                            text: _ctx.it('wallet.restore.step.type.caption'),
                            class: "cc-text-sz"
                        }, null, 8, ["text"]),
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, {
                            hr: "",
                            class: "my-0.5 sm:my-2"
                        }),
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridRadioGroup, {
                            id: "number_of_words",
                            name: "number_of_words",
                            options: _ctx.optionsNumberOfWords,
                            onSelected: _ctx.onSelectedNumberOfWords
                        }, null, 8, ["options", "onSelected"]),
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonPrimary, {
                            class: "col-start-7 col-span-6 lg:col-start-10 lg:col-span-3",
                            label: _ctx.it('common.label.next'),
                            link: _ctx.gotoNextStepRecoveryPhrase,
                            disabled: _ctx.selectedOptionNumberOfWords === null
                        }, null, 8, ["label", "link", "disabled"])
                    ]),
                    step1: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridFormMnemonicInput, {
                            onSubmit: _ctx.gotoNextStepWalletName,
                            "mnemonic-length": _ctx.selectedOptionNumberOfWords?.no ?? 0,
                            class: "col-span-12"
                        }, {
                            btnBack: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonSecondary, {
                                    label: _ctx.it('common.label.back'),
                                    link: _ctx.goBackToNumberOfWords,
                                    class: "col-start-0 col-span-6 lg:col-start-7 lg:col-span-3"
                                }, null, 8, ["label", "link"])
                            ]),
                            _: 1
                        }, 8, ["onSubmit", "mnemonic-length"])
                    ]),
                    step2: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridFormWalletNamePassword, {
                            onSubmit: _ctx.gotoNextStepAccountSelection,
                            class: "col-span-12",
                            "prefilled-wallet-name": _ctx.oldWalletName,
                            "text-id": "wallet.restore.step.password"
                        }, {
                            btnBack: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonSecondary, {
                                    label: 'Back',
                                    link: _ctx.goBackToNumberOfWords,
                                    class: "col-start-0 col-span-12 lg:col-start-0 lg:col-span-3"
                                }, null, 8, ["link"])
                            ]),
                            _: 1
                        }, 8, ["onSubmit", "prefilled-wallet-name"])
                    ]),
                    step3: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridFormAccountSelection, {
                            onSubmit: _ctx.gotoNextStepWalletCreation,
                            class: "col-span-12",
                            "text-id": "wallet.restore.step.password"
                        }, {
                            btnBack: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonSecondary, {
                                    label: 'Back',
                                    link: _ctx.goBackToNumberOfWords,
                                    class: "col-start-0 col-span-12 lg:col-start-0 lg:col-span-3"
                                }, null, 8, ["link"])
                            ]),
                            _: 1
                        }, 8, ["onSubmit"])
                    ]),
                    _: 1
                }, 8, ["onBack", "steps", "currentStep"])
            ])
        ]),
        _: 1
    }));
}

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/Restore.vue?vue&type=template&id=65c6ff2c&ts=true

// EXTERNAL MODULE: ./node_modules/@vue/reactivity/dist/reactivity.esm-bundler.js
var reactivity_esm_bundler = __webpack_require__(61959);
// EXTERNAL MODULE: ./node_modules/quasar/src/composables/use-quasar.js
var use_quasar = __webpack_require__(48825);
// EXTERNAL MODULE: ./src/composables/ccw/useNetworkId.ts
var useNetworkId = __webpack_require__(36648);
// EXTERNAL MODULE: ./src/composables/ccw/useTranslation.ts
var useTranslation = __webpack_require__(19376);
// EXTERNAL MODULE: ./src/composables/ccw/useNavigation.ts
var useNavigation = __webpack_require__(52439);
// EXTERNAL MODULE: ./src/composables/ccw/store/useWalletList.ts
var useWalletList = __webpack_require__(4905);
// EXTERNAL MODULE: ./src/composables/ccw/store/useWalletCreation.ts
var useWalletCreation = __webpack_require__(68139);
// EXTERNAL MODULE: ./src/components/ccw/Page.vue + 21 modules
var Page = __webpack_require__(53707);
// EXTERNAL MODULE: ./src/components/ccw/modal/InfoModal.vue + 4 modules
var InfoModal = __webpack_require__(82172);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridHeadline.vue + 3 modules
var GridHeadline = __webpack_require__(63593);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridText.vue + 4 modules
var GridText = __webpack_require__(96834);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridSpace.vue + 4 modules
var GridSpace = __webpack_require__(14740);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridSteps.vue + 14 modules
var GridSteps = __webpack_require__(58217);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridRadioGroup.vue + 4 modules
var GridRadioGroup = __webpack_require__(46837);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridButtonPrimary.vue + 3 modules
var GridButtonPrimary = __webpack_require__(12559);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridButtonSecondary.vue + 3 modules
var GridButtonSecondary = __webpack_require__(72713);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/forms/GridFormWalletNamePassword.vue + 3 modules
var GridFormWalletNamePassword = __webpack_require__(30374);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/forms/GridFormAccountSelection.vue + 4 modules
var GridFormAccountSelection = __webpack_require__(28566);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/mnemonic/GridFormMnemonicInput.vue?vue&type=template&id=139d7eae&ts=true

const GridFormMnemonicInputvue_type_template_id_139d7eae_ts_true_hoisted_1 = { class: "w-full grid grid-cols-12 cc-gap cc-text-sz" };
const GridFormMnemonicInputvue_type_template_id_139d7eae_ts_true_hoisted_2 = {
    key: 2,
    class: "w-full col-span-12 grid grid-cols-12 cc-gap"
};
function GridFormMnemonicInputvue_type_template_id_139d7eae_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridTextArea = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridTextArea");
    const _component_GridFormMnemonicList = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridFormMnemonicList");
    const _component_IconPencil = (0,runtime_core_esm_bundler/* resolveComponent */.up)("IconPencil");
    const _component_GridInput = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridInput");
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    const _component_GridButtonSecondary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonSecondary");
    const _component_GridButtonPrimary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonPrimary");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", GridFormMnemonicInputvue_type_template_id_139d7eae_ts_true_hoisted_1, [
        (!_ctx.inputCorrect)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridTextArea, {
                key: 0,
                label: _ctx.it('form.mnemonicinput.instructions.label'),
                text: _ctx.it('form.mnemonicinput.instructions.text'),
                icon: _ctx.it('form.mnemonicinput.instructions.icon'),
                class: "col-span-12",
                css: "cc-area-highlight",
                "text-c-s-s": "cc-text-normal text-justify"
            }, null, 8, ["label", "text", "icon"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridFormMnemonicList, {
            label: _ctx.it('form.mnemonicinput.label'),
            mnemonic: _ctx.inputMnemonic,
            "onUpdate:mnemonic": _cache[0] || (_cache[0] = ($event) => ((_ctx.inputMnemonic) = $event)),
            editable: !_ctx.inputCorrect,
            class: "col-span-12"
        }, null, 8, ["label", "mnemonic", "editable"]),
        (!_ctx.inputCorrect)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridInput, {
                key: 1,
                "input-text": _ctx.wordInput,
                "onUpdate:input-text": _cache[1] || (_cache[1] = ($event) => ((_ctx.wordInput) = $event)),
                "input-error": _ctx.wordInputError,
                "onUpdate:input-error": _cache[2] || (_cache[2] = ($event) => ((_ctx.wordInputError) = $event)),
                onEnter: _ctx.onEnter,
                label: _ctx.it('form.mnemonicinput.input.label'),
                "input-hint": _ctx.it('form.mnemonicinput.input.hint'),
                "input-info": _ctx.wordInputInfo,
                alwaysShowInfo: true,
                "input-id": "wordInput",
                "input-type": "text",
                autofocus: "",
                autocomplete: "name",
                class: "col-span-12"
            }, {
                "icon-prepend": (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_IconPencil, { class: "h-5 w-5" })
                ]),
                _: 1
            }, 8, ["input-text", "input-error", "onEnter", "label", "input-hint", "input-info"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, { hr: "" }),
        (!_ctx.inputCorrect)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", GridFormMnemonicInputvue_type_template_id_139d7eae_ts_true_hoisted_2, [
                (_ctx.wordInput.length > 1)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(true), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, { key: 0 }, (0,runtime_core_esm_bundler/* renderList */.Ko)(_ctx.filterOptions, (item) => {
                        return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridButtonSecondary, {
                            key: item + 'filter',
                            label: item,
                            capitalize: false,
                            link: () => _ctx.onClickedWord(item),
                            class: "col-span-6 sm:col-span-4 lg:col-span-2 lowercase"
                        }, null, 8, ["label", "link"]));
                    }), 128))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
            ]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (_ctx.inputCorrect)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridTextArea, {
                key: 3,
                label: _ctx.it('form.mnemonicinput.input.correct.label'),
                text: _ctx.it('form.mnemonicinput.input.correct.text'),
                icon: _ctx.it('form.mnemonicinput.input.correct.icon'),
                class: "col-span-12",
                css: "cc-rounded cc-banner-warning ",
                "text-c-s-s": "text-justify"
            }, null, 8, ["label", "text", "icon"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (0,runtime_core_esm_bundler/* renderSlot */.WI)(_ctx.$slots, "btnBack"),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonPrimary, {
            label: _ctx.it('common.label.continue'),
            link: _ctx.onSubmit,
            disabled: !_ctx.inputCorrect,
            class: "col-start-7 col-span-6 lg:col-start-10 lg:col-span-3"
        }, null, 8, ["label", "link", "disabled"])
    ]));
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/mnemonic/GridFormMnemonicInput.vue?vue&type=template&id=139d7eae&ts=true

// EXTERNAL MODULE: ./src/lib/ExtLib.ts
var ExtLib = __webpack_require__(23211);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/icons/IconPencil.vue + 4 modules
var IconPencil = __webpack_require__(44814);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridInput.vue + 4 modules
var GridInput = __webpack_require__(27209);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridTextArea.vue + 4 modules
var GridTextArea = __webpack_require__(15660);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/mnemonic/GridFormMnemonicList.vue + 4 modules
var GridFormMnemonicList = __webpack_require__(64756);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/CSLKeys.ts
var CSLKeys = __webpack_require__(7572);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/mnemonic/GridFormMnemonicInput.vue?vue&type=script&lang=ts



;









/* harmony default export */ const GridFormMnemonicInputvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'GridFormMnemonicInput',
    components: {
        IconPencil: IconPencil/* default */.Z,
        GridFormMnemonicList: GridFormMnemonicList/* default */.Z,
        GridInput: GridInput/* default */.Z,
        GridSpace: GridSpace/* default */.Z,
        GridTextArea: GridTextArea/* default */.Z,
        GridButtonPrimary: GridButtonPrimary/* default */.Z,
        GridButtonSecondary: GridButtonSecondary/* default */.Z
    },
    emits: ['submit'],
    props: {
        mnemonicLength: { type: Number, required: true },
        mnemonic: { type: Array, required: false, default: () => [] },
        textId: { type: String, default: '' }
    },
    setup(props, context) {
        const { it } = (0,useTranslation/* useTranslation */.$)();
        const $q = (0,use_quasar/* default */.Z)();
        const wordlist = ExtLib.wordlists.english.concat();
        const arr = [];
        let i = 0;
        for (; i < props.mnemonic.length; i++) {
            if (i < props.mnemonic.length - 2) {
                arr.push(props.mnemonic[i]);
            }
            else {
                arr.push('');
            }
        }
        for (; i < props.mnemonicLength; i++) {
            arr.push('');
        }
        const inputCorrect = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const inputMnemonic = (0,reactivity_esm_bundler/* ref */.iH)(arr);
        const info = it('form.mnemonicinput.input.info');
        const wordInput = (0,reactivity_esm_bundler/* ref */.iH)('');
        const wordInputError = (0,reactivity_esm_bundler/* ref */.iH)('');
        const wordInputInfo = (0,reactivity_esm_bundler/* ref */.iH)(info);
        const filterOptions = (0,reactivity_esm_bundler/* ref */.iH)([]);
        function onEnter() {
            wordInput.value = wordInput.value + ' ';
        }
        (0,runtime_core_esm_bundler/* watch */.YP)(wordInput, (newValue, oldValue) => {
            if (newValue.length === 0) {
                wordInputInfo.value = info;
                wordInputError.value = '';
            }
            else {
                const input = newValue.toLowerCase();
                const needle = input.trim();
                if (needle.includes(' ')) {
                    const words = needle.split(' ');
                    const filteredWords = [];
                    for (const word of words) {
                        if (word && word.length > 0) {
                            const filtered = (wordlist.filter(v => v.toLowerCase().startsWith(word)));
                            if (filtered.some(e => e === word)) {
                                filteredWords.push(word);
                            }
                            else {
                                // failed
                                filteredWords.length = 0;
                            }
                        }
                    }
                    if (filteredWords.length === props.mnemonicLength) {
                        for (let i = 0; i < filteredWords.length; i++) {
                            inputMnemonic.value[i] = filteredWords[i];
                        }
                        validateWordInput(false);
                        return;
                    }
                }
                filterOptions.value = (wordlist.filter(v => v.toLowerCase().startsWith(needle)));
                if (input.length > needle.length && filterOptions.value.some(e => e === needle)) {
                    filterOptions.value = [needle];
                }
                let info = filterOptions.value.join(', ');
                if (info.length > 64) {
                    info = info.substr(0, 64) + ' ...';
                }
                wordInputInfo.value = info;
                if (input.endsWith(' ')) {
                    validateWordInput(false);
                }
            }
        });
        function testMnemonic() {
            let index = inputMnemonic.value.indexOf('');
            if (index < 0) {
                try {
                    (0,CSLKeys/* createPrvRoot */.op)(inputMnemonic.value.join(' '));
                    wordInputError.value = '';
                    inputCorrect.value = true;
                }
                catch (e) {
                    inputCorrect.value = false;
                    wordInputError.value = it('form.mnemonicinput.input.errorKey');
                    $q.notify({
                        type: 'negative',
                        message: it('form.mnemonicinput.input.errorKey'),
                        position: 'top-left'
                    });
                }
            }
        }
        function validateWordInput(external) {
            let index = inputMnemonic.value.indexOf('');
            if (index < 0) {
                testMnemonic();
            }
            else if (index >= props.mnemonicLength) {
                // wordInputError.value = ''
            }
            else {
                if (filterOptions.value.length === 1) {
                    inputMnemonic.value[index] = filterOptions.value[0];
                    wordInput.value = '';
                    index = inputMnemonic.value.indexOf('');
                    testMnemonic();
                }
                else {
                    wordInputError.value = it('form.mnemonicinput.input.error');
                }
            }
            return wordInputError.value;
        }
        function onSubmit() {
            try {
                (0,CSLKeys/* createPrvRoot */.op)(inputMnemonic.value.join(' '));
                context.emit('submit', { mnemonic: inputMnemonic.value.join(' ') });
            }
            catch (e) {
                inputCorrect.value = false;
                wordInputError.value = it('form.mnemonicinput.input.error');
            }
        }
        function onClickedWord(word) {
            wordInput.value = word + ' ';
            document.getElementById('wordInput')?.focus();
        }
        return {
            it,
            wordInput,
            wordInputError,
            wordInputInfo,
            validateWordInput,
            onEnter,
            filterOptions,
            inputCorrect,
            inputMnemonic,
            onSubmit,
            onClickedWord
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/mnemonic/GridFormMnemonicInput.vue?vue&type=script&lang=ts
 
// EXTERNAL MODULE: ./node_modules/vue-loader/dist/exportHelper.js
var exportHelper = __webpack_require__(74260);
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/mnemonic/GridFormMnemonicInput.vue




;
const __exports__ = /*#__PURE__*/(0,exportHelper/* default */.Z)(GridFormMnemonicInputvue_type_script_lang_ts, [['render',GridFormMnemonicInputvue_type_template_id_139d7eae_ts_true_render]])

/* harmony default export */ const GridFormMnemonicInput = (__exports__);
// EXTERNAL MODULE: ./src/components/ccw/overlay/AccountCreationOverlay.vue + 4 modules
var AccountCreationOverlay = __webpack_require__(21928);
// EXTERNAL MODULE: ./src/components/ccw/modal/ConfirmationModal.vue + 4 modules
var ConfirmationModal = __webpack_require__(65455);
// EXTERNAL MODULE: ./src/lib/utils/WalletCreationStatusMapper.ts
var WalletCreationStatusMapper = __webpack_require__(7387);
// EXTERNAL MODULE: ./src/ext/AppWalletManager.ts + 1 modules
var AppWalletManager = __webpack_require__(33931);
// EXTERNAL MODULE: ./src/ext/WalletEvent.ts
var WalletEvent = __webpack_require__(65467);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/Restore.vue?vue&type=script&lang=ts

;
























/* harmony default export */ const Restorevue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'RestoreWallet',
    components: {
        Page: Page/* default */.Z,
        InfoModal: InfoModal/* default */.Z,
        GridSpace: GridSpace/* default */.Z,
        GridHeadline: GridHeadline/* default */.Z,
        GridText: GridText/* default */.Z,
        GridInput: GridInput/* default */.Z,
        GridSteps: GridSteps/* default */.Z,
        GridRadioGroup: GridRadioGroup/* default */.Z,
        GridButtonPrimary: GridButtonPrimary/* default */.Z,
        GridButtonSecondary: GridButtonSecondary/* default */.Z,
        GridFormWalletNamePassword: GridFormWalletNamePassword/* default */.Z,
        GridFormMnemonicInput: GridFormMnemonicInput,
        GridFormAccountSelection: GridFormAccountSelection/* default */.Z,
        AccountCreationOverlay: AccountCreationOverlay/* default */.Z,
        ConfirmationModal: ConfirmationModal/* default */.Z,
        IconPencil: IconPencil/* default */.Z
    },
    setup() {
        const { setWalletName, setSpendingPassword, setMnemonic, setNumberOfAccounts, setWalletCreationHook, generateWalletIdFromMnemonic, createWallet } = (0,useWalletCreation/* useWalletCreation */.c)();
        const { reloadWalletList, hasWalletWithId, getWalletById } = (0,useWalletList/* useWalletList */.M)();
        const { networkId } = (0,useNetworkId/* useNetworkId */.h)();
        const { gotoHome, openWallet, openWalletPage } = (0,useNavigation/* useNavigation */.HJ)();
        const { it } = (0,useTranslation/* useTranslation */.$)();
        const $q = (0,use_quasar/* default */.Z)();
        const currentStep = (0,reactivity_esm_bundler/* ref */.iH)(0);
        const selectedOptionNumberOfWords = (0,reactivity_esm_bundler/* ref */.iH)(null);
        const walletCreateInProgress = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const walletCreationStatus = (0,reactivity_esm_bundler/* ref */.iH)('');
        const restoreError = (0,reactivity_esm_bundler/* ref */.iH)('');
        const showInfoModal = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const showRestoreModal = (0,reactivity_esm_bundler/* ref */.iH)({ display: false });
        const oldWalletName = (0,reactivity_esm_bundler/* ref */.iH)('');
        // indicated if restoring a locked wallet
        const recreateWallet = (0,reactivity_esm_bundler/* ref */.iH)(false);
        function resetInputs() {
            selectedOptionNumberOfWords.value = null;
            setWalletName('');
            setSpendingPassword('');
            setMnemonic('');
        }
        resetInputs();
        function goBackToNumberOfWords() {
            currentStep.value = 0;
            resetInputs();
        }
        function goBackToRecoveryPhrase() { goBackToNumberOfWords(); }
        function goBack() {
            if (currentStep.value === 1) {
                goBackToNumberOfWords();
            }
            if (currentStep.value === 2) {
                goBackToRecoveryPhrase();
            }
        }
        function gotoNextStepRecoveryPhrase() {
            if (selectedOptionNumberOfWords.value !== null) {
                currentStep.value = 1;
            }
        }
        function gotoNextStepAccountSelection(payload) {
            setWalletName(payload.walletName);
            setSpendingPassword(payload.password);
            oldWalletName.value = payload.walletName;
            currentStep.value = 3;
        }
        function gotoNextStepWalletName(payload) {
            if (payload.mnemonic) {
                setWalletName('');
                setSpendingPassword('');
                setMnemonic(payload.mnemonic ?? '');
                if (!networkId.value) {
                    $q.notify({
                        type: 'negative',
                        message: 'Error: No active network.',
                        position: 'top-left'
                    });
                    gotoHome();
                    return;
                }
                const walletId = generateWalletIdFromMnemonic(networkId.value);
                if (hasWalletWithId(walletId)) {
                    const wallet = getWalletById(walletId);
                    // show modal for restoring only if wallet is locked.
                    if (wallet?.locked) {
                        showRestoreModal.value.display = true;
                    }
                    else {
                        $q.notify({
                            type: 'warning',
                            message: it('wallet.restore.message.duplicate'),
                            position: 'top-left'
                        });
                        openWallet(walletId);
                    }
                }
                else {
                    currentStep.value = 2;
                    recreateWallet.value = false;
                }
            }
        }
        const openExistingWallet = () => {
            const walletId = generateWalletIdFromMnemonic(networkId.value);
            $q.notify({
                type: 'warning',
                message: it('wallet.restore.message.duplicate'),
                position: 'top-left'
            });
            openWallet(walletId);
        };
        const openExistingWalletOnSettings = () => {
            const walletId = generateWalletIdFromMnemonic(networkId.value);
            $q.notify({
                type: 'warning',
                message: it('wallet.restore.message.duplicate'),
                position: 'top-left'
            });
            openWalletPage('WalletSettings', walletId);
        };
        /**
         * Called when modal asking for restoring locked wallet was confirmed.
         */
        const confirmGotoNextStepWalletName = () => {
            const walletId = generateWalletIdFromMnemonic(networkId.value);
            const wallet = getWalletById(walletId);
            oldWalletName.value = wallet?.dbEntry.name ?? '';
            showRestoreModal.value.display = false;
            recreateWallet.value = true;
            currentStep.value = 2;
        };
        async function gotoNextStepWalletCreation(payload) {
            setNumberOfAccounts(payload.accountNumber);
            setWalletCreationHook(async (status) => {
                walletCreationStatus.value = (0,WalletCreationStatusMapper/* getStatusInfo */.I)(status, it);
            });
            walletCreateInProgress.value = true;
            try {
                if (!networkId.value) {
                    throw new Error('Error: No active network.');
                }
                if (recreateWallet.value) {
                    const walletId = generateWalletIdFromMnemonic(networkId.value);
                    const wallet = getWalletById(walletId);
                    const groupName = wallet?.dbEntry.groupName;
                    const plate = wallet?.dbEntry.data.plate;
                    const background = wallet?.dbEntry.data?.background;
                    const successDelete = await (0,AppWalletManager.deleteWallet)(walletId);
                    if (!successDelete) {
                        $q.notify({
                            type: 'negative',
                            message: it('wallet.settings.verification.recovery.unableToDelete'),
                            position: 'top-left'
                        });
                        walletCreateInProgress.value = false;
                        // go to old wallet
                        openWallet(walletId);
                        return;
                    }
                    let observer = {
                        event: WalletEvent/* WalletEvent.syncStarted */._.syncStarted,
                        callback: async (event, walletId) => { }
                    };
                    observer.callback = async (event, walletId) => {
                        // this will be the id of newly created wallet as it will be called on sync start after wallet was created
                        const newWalletId = generateWalletIdFromMnemonic(networkId.value);
                        if (walletId !== newWalletId) {
                            return;
                        }
                        try {
                            await (0,AppWalletManager.resetWalletName)(newWalletId, { walletName: oldWalletName.value, groupName: groupName });
                            await (0,AppWalletManager.resetWalletPlate)(newWalletId, { ...plate });
                            await (0,AppWalletManager.resetWalletBackground)(newWalletId, { ...background });
                        }
                        catch (err) {
                            console.error(err);
                        }
                        await reloadWalletList(true);
                        openWallet(newWalletId);
                        (0,AppWalletManager.removeObserver)(observer);
                    };
                    (0,AppWalletManager.addObserver)(observer);
                    await createWallet(networkId.value, 'mnemonic');
                    await reloadWalletList();
                    $q.notify({
                        type: 'positive',
                        message: it('wallet.restore.message.success'),
                        position: 'top-left'
                    });
                }
                else {
                    const walletId = await createWallet(networkId.value, 'mnemonic');
                    await reloadWalletList();
                    $q.notify({
                        type: 'positive',
                        message: it('wallet.restore.message.success'),
                        position: 'top-left'
                    });
                    openWallet(walletId);
                }
            }
            catch (err) {
                let errorMessage = it('wallet.restore.message.faildb');
                if (err.message && err.message.toLowerCase().includes('invalid mnemonic checksum')) {
                    errorMessage = it('wallet.restore.message.failmnemonic');
                    $q.notify({
                        type: 'negative',
                        message: errorMessage,
                        position: 'top-left'
                    });
                    gotoHome();
                }
                else {
                    walletCreateInProgress.value = false;
                    showInfoModal.value = true;
                }
                console.error('CreateWallet: Error:', err.message);
            }
        }
        function onSelectedNumberOfWords(option) {
            selectedOptionNumberOfWords.value = option;
        }
        const optionsSteps = (0,reactivity_esm_bundler/* reactive */.qj)([
            { id: 'type', label: it('wallet.restore.step.type.label') },
            { id: 'phrase', label: it('wallet.restore.step.recoveryphrase.label') },
            { id: 'password', label: it('wallet.restore.step.password.label') },
            { id: 'account', label: it('wallet.restore.step.account.label') }
        ]);
        const optionsNumberOfWords = (0,reactivity_esm_bundler/* reactive */.qj)([
            { no: 24, id: '24words', label: it('wallet.restore.step.type.options.length24.label'), caption: it('wallet.restore.step.type.options.length24.caption') },
            { no: 15, id: '15words', label: it('wallet.restore.step.type.options.length15.label'), caption: it('wallet.restore.step.type.options.length15.caption') },
            { no: 12, id: '12words', label: it('wallet.restore.step.type.options.length12.label'), caption: it('wallet.restore.step.type.options.length12.caption') }
        ]);
        function onHideModal() {
            showInfoModal.value = false;
        }
        const isMounted = (0,reactivity_esm_bundler/* ref */.iH)(false);
        (0,runtime_core_esm_bundler/* onMounted */.bv)(() => { (0,runtime_core_esm_bundler/* nextTick */.Y3)(() => { isMounted.value = true; }); });
        return {
            it,
            optionsSteps,
            currentStep,
            restoreError,
            walletCreateInProgress,
            walletCreationStatus,
            optionsNumberOfWords,
            selectedOptionNumberOfWords,
            isMounted,
            showRestoreModal,
            oldWalletName,
            onSelectedNumberOfWords,
            gotoNextStepRecoveryPhrase,
            confirmGotoNextStepWalletName,
            gotoNextStepWalletName,
            gotoNextStepAccountSelection,
            gotoNextStepWalletCreation,
            openExistingWallet,
            openExistingWalletOnSettings,
            goBackToNumberOfWords,
            goBackToRecoveryPhrase,
            goBack,
            showInfoModal,
            onHideModal
        };
    }
}));

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/Restore.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/pages/ccw/wallet/Restore.vue




;
const Restore_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(Restorevue_type_script_lang_ts, [['render',render]])

/* harmony default export */ const Restore = (Restore_exports_);

/***/ })

}]);
//# sourceMappingURL=3543.js.map