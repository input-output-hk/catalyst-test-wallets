"use strict";
(this["webpackChunkccw_frontend"] = this["webpackChunkccw_frontend"] || []).push([[7949],{

/***/ 5536:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ BexSignLayout)
});

// EXTERNAL MODULE: ./node_modules/@vue/runtime-core/dist/runtime-core.esm-bundler.js
var runtime_core_esm_bundler = __webpack_require__(83673);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/layouts/ccw/BexSignLayout.vue?vue&type=template&id=4bf9840d&scoped=true&ts=true

const _withScopeId = n => ((0,runtime_core_esm_bundler/* pushScopeId */.dD)("data-v-4bf9840d"), n = n(), (0,runtime_core_esm_bundler/* popScopeId */.Cn)(), n);
const _hoisted_1 = {
    class: "relative w-full h-full cc-layout-px cc-layout-py cc-text-color flex flex-col flex-nowrap",
    id: "cc-layout-container"
};
const _hoisted_2 = /*#__PURE__*/ _withScopeId(() => /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("div", {
    class: "fixed inset-0 bg-gradient-to-r from-slate-200 to-stone-200 dark:from-slate-900 dark:to-stone-900",
    id: "cc-background-iframe-container"
}, null, -1));
const _hoisted_3 = {
    class: "relative flex-grow w-full flex-1 cc-site-max-width mx-auto flex flex-col flex-nowrap",
    id: "cc-main-container"
};
const _hoisted_4 = {
    class: "relative flex-1 flex-grow-1 h-full overflow-hidden cc-rounded-la cc-shadow flex flex-row flex-nowrap",
    style: { "min-height": "222px" }
};
const _hoisted_5 = { class: "relative flex-1 w-full h-full" };
const _hoisted_6 = { class: "relative w-full h-full cc-rounded-la flex flex-row flex-nowrap cc-bg-light-1" };
const _hoisted_7 = { class: "relative h-full flex-1 overflow-hidden focus:outline-none flex flex-col flex-nowrap" };
const _hoisted_8 = /*#__PURE__*/ _withScopeId(() => /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("div", {
    class: "absolute top-0 left-0 cc-text-color cc-text-sz z-50",
    id: "ccvaultio-modal"
}, null, -1));
function render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_Header = (0,runtime_core_esm_bundler/* resolveComponent */.up)("Header");
    const _component_EpochProgress = (0,runtime_core_esm_bundler/* resolveComponent */.up)("EpochProgress");
    const _component_router_view = (0,runtime_core_esm_bundler/* resolveComponent */.up)("router-view");
    const _component_Footer = (0,runtime_core_esm_bundler/* resolveComponent */.up)("Footer");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, [
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_1, [
            _hoisted_2,
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_Header),
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_EpochProgress),
            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_3, [
                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_4, [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_5, [
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_6, [
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("main", _hoisted_7, [
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_router_view)
                            ])
                        ])
                    ])
                ])
            ]),
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_Footer)
        ]),
        _hoisted_8
    ], 64));
}

;// CONCATENATED MODULE: ./src/layouts/ccw/BexSignLayout.vue?vue&type=template&id=4bf9840d&scoped=true&ts=true

// EXTERNAL MODULE: ./node_modules/quasar/src/composables/use-quasar.js
var use_quasar = __webpack_require__(48825);
// EXTERNAL MODULE: ./src/composables/ccw/useTranslation.ts
var useTranslation = __webpack_require__(19376);
// EXTERNAL MODULE: ./src/composables/ccw/state/useMainMenuOpen.ts
var useMainMenuOpen = __webpack_require__(33008);
// EXTERNAL MODULE: ./src/composables/ccw/store/useWalletList.ts
var useWalletList = __webpack_require__(4905);
// EXTERNAL MODULE: ./src/components/ccw/Header.vue + 28 modules
var Header = __webpack_require__(34928);
// EXTERNAL MODULE: ./src/components/ccw/header/EpochProgress.vue + 5 modules
var EpochProgress = __webpack_require__(81780);
// EXTERNAL MODULE: ./src/components/ccw/Footer.vue + 14 modules
var Footer = __webpack_require__(78542);
// EXTERNAL MODULE: ./src/components/ccw/common/IconButton.vue + 3 modules
var IconButton = __webpack_require__(45995);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/layouts/ccw/BexSignLayout.vue?vue&type=script&lang=ts

;







/* harmony default export */ const BexSignLayoutvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'BexEnableLayout',
    components: {
        Header: Header/* default */.Z,
        EpochProgress: EpochProgress/* default */.Z,
        Footer: Footer/* default */.Z,
        IconButton: IconButton/* default */.Z
    },
    setup() {
        const { t } = (0,useTranslation/* useTranslation */.$)();
        const { isMainMenuOpen } = (0,useMainMenuOpen/* useMainMenuOpen */.T)();
        const { walletList } = (0,useWalletList/* useWalletList */.M)();
        const $q = (0,use_quasar/* default */.Z)();
        (0,runtime_core_esm_bundler/* onErrorCaptured */.d1)((e, instance, info) => {
            $q.notify({
                type: 'negative',
                message: 'error: ' + (e?.message ?? 'no error message') + ' info: ' + info,
                position: 'top-left',
                timeout: 20000,
                closeBtn: true
            });
            console.error('Layout: onErrorCaptured', e);
            return true;
        });
        return {
            t,
            isMainMenuOpen,
            walletList
        };
    }
}));

;// CONCATENATED MODULE: ./src/layouts/ccw/BexSignLayout.vue?vue&type=script&lang=ts
 
// EXTERNAL MODULE: ./node_modules/vue-loader/dist/exportHelper.js
var exportHelper = __webpack_require__(74260);
;// CONCATENATED MODULE: ./src/layouts/ccw/BexSignLayout.vue




;


const __exports__ = /*#__PURE__*/(0,exportHelper/* default */.Z)(BexSignLayoutvue_type_script_lang_ts, [['render',render],['__scopeId',"data-v-4bf9840d"]])

/* harmony default export */ const BexSignLayout = (__exports__);

/***/ })

}]);
//# sourceMappingURL=7949.js.map