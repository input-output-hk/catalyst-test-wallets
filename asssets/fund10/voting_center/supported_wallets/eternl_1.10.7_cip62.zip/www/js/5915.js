"use strict";
(this["webpackChunkccw_frontend"] = this["webpackChunkccw_frontend"] || []).push([[5915],{

/***/ 16206:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Create)
});

// EXTERNAL MODULE: ./node_modules/@vue/runtime-core/dist/runtime-core.esm-bundler.js
var runtime_core_esm_bundler = __webpack_require__(83673);
// EXTERNAL MODULE: ./node_modules/@vue/shared/dist/shared.esm-bundler.js
var shared_esm_bundler = __webpack_require__(62323);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/Create.vue?vue&type=template&id=2c7e8a51&ts=true

const _hoisted_1 = { class: "min-h-16 sm:min-h-20 w-full max-w-full p-3 text-center flex flex-col flex-nowrap justify-center items-center border-t border-b mb-px cc-bg-white-0" };
const _hoisted_2 = { class: "cc-text-semi-bold" };
const _hoisted_3 = { class: "" };
const _hoisted_4 = { class: "cc-page-wallet cc-text-sz" };
function render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_InfoModal = (0,runtime_core_esm_bundler/* resolveComponent */.up)("InfoModal");
    const _component_AccountCreationOverlay = (0,runtime_core_esm_bundler/* resolveComponent */.up)("AccountCreationOverlay");
    const _component_GridFormWalletNamePassword = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridFormWalletNamePassword");
    const _component_GridButtonSecondary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonSecondary");
    const _component_GridFormAccountSelection = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridFormAccountSelection");
    const _component_GridFormMnemonicHint = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridFormMnemonicHint");
    const _component_GridFormMnemonic = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridFormMnemonic");
    const _component_GridFormMnemonicInputConfirm = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridFormMnemonicInputConfirm");
    const _component_GridSteps = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSteps");
    const _component_Page = (0,runtime_core_esm_bundler/* resolveComponent */.up)("Page");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_Page, {
        containerCSS: '',
        "align-top": ""
    }, {
        header: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_1, [
                (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_2, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('wallet.create.headline')), 1),
                (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_3, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('wallet.create.caption')), 1)
            ])
        ]),
        content: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
            (_ctx.showInfoModal)
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_InfoModal, {
                    key: 0,
                    caption: _ctx.it('common.walletCreation.restart'),
                    title: _ctx.it('common.label.notice'),
                    onClose: _ctx.onHideModal,
                    onConfirm: _ctx.onHideModal
                }, null, 8, ["caption", "title", "onClose", "onConfirm"]))
                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
            (_ctx.walletCreateInProgress)
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_AccountCreationOverlay, {
                    key: 1,
                    status: _ctx.walletCreationStatus
                }, null, 8, ["status"]))
                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_4, [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSteps, {
                    onBack: _ctx.goBack,
                    steps: _ctx.optionsSteps,
                    currentStep: _ctx.currentStep,
                    "small-c-s-s": "pr-11 xs:pr-20 lg:pr-24"
                }, {
                    step0: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridFormWalletNamePassword, {
                            onSubmit: _ctx.gotoNextStepAccountSelection,
                            "is-stepper": "",
                            class: "col-span-12"
                        }, null, 8, ["onSubmit"])
                    ]),
                    step1: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridFormAccountSelection, {
                            "disable-discover": true,
                            onSubmit: _ctx.gotoNextStepMnemonicHint,
                            class: "col-span-12",
                            "text-id": "wallet.restore.step.password"
                        }, {
                            btnBack: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonSecondary, {
                                    label: 'Back',
                                    link: _ctx.goBack,
                                    class: "col-start-0 col-span-12 lg:col-start-0 lg:col-span-3"
                                }, null, 8, ["link"])
                            ]),
                            _: 1
                        }, 8, ["onSubmit"])
                    ]),
                    step2: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridFormMnemonicHint, {
                            onSubmit: _ctx.gotoNextStepMnemonic,
                            class: "col-span-12"
                        }, {
                            btnBack: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonSecondary, {
                                    label: _ctx.it('common.label.back'),
                                    link: _ctx.goBack,
                                    class: "col-start-0 col-span-6 lg:col-start-7 lg:col-span-3"
                                }, null, 8, ["label", "link"])
                            ]),
                            _: 1
                        }, 8, ["onSubmit"])
                    ]),
                    step3: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridFormMnemonic, {
                            onSubmit: _ctx.gotoNextStepMnemonicCompare,
                            mnemonic: _ctx.tmpMnemonic,
                            class: "col-span-12"
                        }, {
                            btnBack: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonSecondary, {
                                    label: _ctx.it('common.label.back'),
                                    link: _ctx.goBack,
                                    class: "col-start-0 col-span-6 lg:col-start-7 lg:col-span-3"
                                }, null, 8, ["label", "link"])
                            ]),
                            _: 1
                        }, 8, ["onSubmit", "mnemonic"])
                    ]),
                    step4: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridFormMnemonicInputConfirm, {
                            onSubmit: _ctx.gotoNextStepWalletCreation,
                            mnemonic: _ctx.tmpMnemonic.split(' '),
                            class: "col-span-12"
                        }, {
                            btnBack: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonSecondary, {
                                    label: _ctx.it('common.label.back'),
                                    link: _ctx.goBack,
                                    class: "col-start-0 col-span-6 lg:col-start-7 lg:col-span-3"
                                }, null, 8, ["label", "link"])
                            ]),
                            _: 1
                        }, 8, ["onSubmit", "mnemonic"])
                    ]),
                    _: 1
                }, 8, ["onBack", "steps", "currentStep"])
            ])
        ]),
        _: 1
    }));
}

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/Create.vue?vue&type=template&id=2c7e8a51&ts=true

// EXTERNAL MODULE: ./node_modules/@vue/reactivity/dist/reactivity.esm-bundler.js
var reactivity_esm_bundler = __webpack_require__(61959);
// EXTERNAL MODULE: ./node_modules/quasar/src/composables/use-quasar.js
var use_quasar = __webpack_require__(48825);
// EXTERNAL MODULE: ./src/composables/ccw/useNetworkId.ts
var useNetworkId = __webpack_require__(36648);
// EXTERNAL MODULE: ./src/composables/ccw/useTranslation.ts
var useTranslation = __webpack_require__(19376);
// EXTERNAL MODULE: ./src/composables/ccw/useNavigation.ts
var useNavigation = __webpack_require__(52439);
// EXTERNAL MODULE: ./src/composables/ccw/store/useWalletList.ts
var useWalletList = __webpack_require__(4905);
// EXTERNAL MODULE: ./src/composables/ccw/store/useWalletCreation.ts
var useWalletCreation = __webpack_require__(68139);
// EXTERNAL MODULE: ./src/components/ccw/Page.vue + 21 modules
var Page = __webpack_require__(53707);
// EXTERNAL MODULE: ./src/components/ccw/modal/InfoModal.vue + 4 modules
var InfoModal = __webpack_require__(82172);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridHeadline.vue + 3 modules
var GridHeadline = __webpack_require__(63593);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridText.vue + 4 modules
var GridText = __webpack_require__(96834);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridSpace.vue + 4 modules
var GridSpace = __webpack_require__(14740);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridSteps.vue + 14 modules
var GridSteps = __webpack_require__(58217);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridTextArea.vue + 4 modules
var GridTextArea = __webpack_require__(15660);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridRadioGroup.vue + 4 modules
var GridRadioGroup = __webpack_require__(46837);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridButtonPrimary.vue + 3 modules
var GridButtonPrimary = __webpack_require__(12559);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridButtonSecondary.vue + 3 modules
var GridButtonSecondary = __webpack_require__(72713);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/forms/GridFormWalletNamePassword.vue + 3 modules
var GridFormWalletNamePassword = __webpack_require__(30374);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/forms/GridFormAccountSelection.vue + 4 modules
var GridFormAccountSelection = __webpack_require__(28566);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/mnemonic/GridFormMnemonicHint.vue?vue&type=template&id=f669579a&ts=true

const GridFormMnemonicHintvue_type_template_id_f669579a_ts_true_hoisted_1 = { class: "w-full grid grid-cols-12 cc-gap col-span-12 cc-text-sz" };
function GridFormMnemonicHintvue_type_template_id_f669579a_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridHeadline = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridHeadline");
    const _component_GridText = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridText");
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    const _component_GridTextArea = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridTextArea");
    const _component_GridToggle = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridToggle");
    const _component_GridButtonCountdown = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonCountdown");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", GridFormMnemonicHintvue_type_template_id_f669579a_ts_true_hoisted_1, [
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
            label: _ctx.it('form.mnemonichint.label')
        }, null, 8, ["label"]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
            text: _ctx.it('form.mnemonichint.text'),
            class: "cc-text-sz"
        }, null, 8, ["text"]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, {
            hr: "",
            class: "my-0.5 sm:my-2"
        }),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridTextArea, {
            label: null,
            text: _ctx.it('form.mnemonichint.hint'),
            icon: _ctx.it('form.mnemonichint.icon'),
            class: "col-span-12",
            "text-c-s-s": "cc-text-normal text-justify",
            css: "cc-rounded cc-banner-warning"
        }, null, 8, ["text", "icon"]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, {
            hr: "",
            class: "my-0.5 sm:my-2"
        }),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridToggle, {
            label: _ctx.it('form.mnemonichint.toggle.acknowledged.label'),
            text: _ctx.it('form.mnemonichint.toggle.acknowledged.text'),
            icon: _ctx.it('form.mnemonichint.toggle.acknowledged.icon'),
            toggled: _ctx.toggled,
            "onUpdate:toggled": _cache[0] || (_cache[0] = ($event) => (_ctx.toggled = $event)),
            class: "col-span-12"
        }, null, 8, ["label", "text", "icon", "toggled"]),
        (0,runtime_core_esm_bundler/* renderSlot */.WI)(_ctx.$slots, "btnBack"),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonCountdown, {
            label: _ctx.it('common.label.next'),
            link: _ctx.onSubmit,
            disabled: !_ctx.toggled,
            duration: 1,
            class: "col-start-7 col-span-6 lg:col-start-10 lg:col-span-3"
        }, null, 8, ["label", "link", "disabled"])
    ]));
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/mnemonic/GridFormMnemonicHint.vue?vue&type=template&id=f669579a&ts=true

// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridToggle.vue + 3 modules
var GridToggle = __webpack_require__(68805);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridButtonCountdown.vue + 3 modules
var GridButtonCountdown = __webpack_require__(66950);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/mnemonic/GridFormMnemonicHint.vue?vue&type=script&lang=ts









/* harmony default export */ const GridFormMnemonicHintvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'GridFormMnemonicHint',
    components: {
        GridHeadline: GridHeadline/* default */.Z,
        GridText: GridText/* default */.Z,
        GridSpace: GridSpace/* default */.Z,
        GridTextArea: GridTextArea/* default */.Z,
        GridToggle: GridToggle/* default */.Z,
        GridButtonCountdown: GridButtonCountdown/* default */.Z
    },
    emits: ['submit'],
    setup(props, context) {
        const { it } = (0,useTranslation/* useTranslation */.$)();
        const toggled = (0,reactivity_esm_bundler/* ref */.iH)(false);
        function onSubmit() {
            context.emit('submit');
        }
        return {
            it,
            toggled,
            onSubmit
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/mnemonic/GridFormMnemonicHint.vue?vue&type=script&lang=ts
 
// EXTERNAL MODULE: ./node_modules/vue-loader/dist/exportHelper.js
var exportHelper = __webpack_require__(74260);
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/mnemonic/GridFormMnemonicHint.vue




;
const __exports__ = /*#__PURE__*/(0,exportHelper/* default */.Z)(GridFormMnemonicHintvue_type_script_lang_ts, [['render',GridFormMnemonicHintvue_type_template_id_f669579a_ts_true_render]])

/* harmony default export */ const GridFormMnemonicHint = (__exports__);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/mnemonic/GridFormMnemonic.vue?vue&type=template&id=da0716c0&ts=true

const GridFormMnemonicvue_type_template_id_da0716c0_ts_true_hoisted_1 = { class: "w-full grid grid-cols-12 cc-gap col-span-12 cc-text-sz" };
function GridFormMnemonicvue_type_template_id_da0716c0_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridFormMnemonicList = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridFormMnemonicList");
    const _component_GridTextArea = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridTextArea");
    const _component_GridToggle = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridToggle");
    const _component_GridButtonCountdown = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonCountdown");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", GridFormMnemonicvue_type_template_id_da0716c0_ts_true_hoisted_1, [
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridFormMnemonicList, {
            label: _ctx.it('form.mnemonic.label'),
            mnemonic: _ctx.mnemonic,
            class: "col-span-12"
        }, null, 8, ["label", "mnemonic"]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridTextArea, {
            label: _ctx.it('form.mnemonic.hint.label'),
            text: _ctx.it('form.mnemonic.hint.text'),
            icon: _ctx.it('form.mnemonic.hint.icon'),
            class: "col-span-12",
            "text-c-s-s": "cc-text-normal text-justify",
            css: "cc-rounded cc-banner-warning"
        }, null, 8, ["label", "text", "icon"]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridToggle, {
            label: _ctx.it('form.mnemonic.toggle.acknowledged.label'),
            text: _ctx.it('form.mnemonic.toggle.acknowledged.text'),
            icon: _ctx.it('form.mnemonic.toggle.acknowledged.icon'),
            toggled: _ctx.toggled,
            toggleError: _ctx.toggleError,
            "onUpdate:toggled": _cache[0] || (_cache[0] = ($event) => (_ctx.toggled = $event)),
            "onUpdate:toggleError": _cache[1] || (_cache[1] = ($event) => (_ctx.toggleError = $event)),
            class: "col-span-12"
        }, null, 8, ["label", "text", "icon", "toggled", "toggleError"]),
        (0,runtime_core_esm_bundler/* renderSlot */.WI)(_ctx.$slots, "btnBack"),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonCountdown, {
            label: _ctx.it('common.label.next'),
            link: _ctx.onSubmit,
            disabled: !_ctx.toggled,
            class: "col-start-7 col-span-6 lg:col-start-10 lg:col-span-3"
        }, null, 8, ["label", "link", "disabled"])
    ]));
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/mnemonic/GridFormMnemonic.vue?vue&type=template&id=da0716c0&ts=true

// EXTERNAL MODULE: ./src/components/ccw/grid/v2/mnemonic/GridFormMnemonicList.vue + 4 modules
var GridFormMnemonicList = __webpack_require__(64756);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/CSLKeys.ts
var CSLKeys = __webpack_require__(7572);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/mnemonic/GridFormMnemonic.vue?vue&type=script&lang=ts








 // TODO: wrapper method
/* harmony default export */ const GridFormMnemonicvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'GridFormMnemonic',
    components: {
        GridTextArea: GridTextArea/* default */.Z,
        GridToggle: GridToggle/* default */.Z,
        GridButtonCountdown: GridButtonCountdown/* default */.Z,
        GridButtonSecondary: GridButtonSecondary/* default */.Z,
        GridFormMnemonicList: GridFormMnemonicList/* default */.Z,
    },
    emits: ['submit'],
    props: {
        mnemonic: { type: String, required: false, default: '' },
        textId: { type: String, default: '' }
    },
    setup(props, context) {
        const { it } = (0,useTranslation/* useTranslation */.$)();
        const toggled = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const toggleError = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const tmp = props.mnemonic.length === 0 ? (0,CSLKeys/* getMnemonic */.qy)(256).split(' ') : props.mnemonic.split(' ');
        const mnemonic = (0,reactivity_esm_bundler/* ref */.iH)(tmp);
        function onSubmit() {
            if (toggled.value) {
                context.emit('submit', { mnemonic: mnemonic.value.join(' ') });
            }
            else {
                toggleError.value = true;
            }
        }
        return {
            it,
            mnemonic,
            toggled,
            toggleError,
            onSubmit
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/mnemonic/GridFormMnemonic.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/mnemonic/GridFormMnemonic.vue




;
const GridFormMnemonic_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(GridFormMnemonicvue_type_script_lang_ts, [['render',GridFormMnemonicvue_type_template_id_da0716c0_ts_true_render]])

/* harmony default export */ const GridFormMnemonic = (GridFormMnemonic_exports_);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/mnemonic/GridFormMnemonicInputConfirm.vue?vue&type=template&id=2064d1b8&ts=true

const GridFormMnemonicInputConfirmvue_type_template_id_2064d1b8_ts_true_hoisted_1 = { class: "w-full grid grid-cols-12 cc-gap cc-text-sz" };
const GridFormMnemonicInputConfirmvue_type_template_id_2064d1b8_ts_true_hoisted_2 = { class: "w-full col-span-12 grid grid-cols-12 cc-gap" };
function GridFormMnemonicInputConfirmvue_type_template_id_2064d1b8_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridTextArea = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridTextArea");
    const _component_GridFormMnemonicList = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridFormMnemonicList");
    const _component_IconPencil = (0,runtime_core_esm_bundler/* resolveComponent */.up)("IconPencil");
    const _component_GridInput = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridInput");
    const _component_GridButtonSecondary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonSecondary");
    const _component_GridToggle = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridToggle");
    const _component_GridButtonCountdown = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonCountdown");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", GridFormMnemonicInputConfirmvue_type_template_id_2064d1b8_ts_true_hoisted_1, [
        (!_ctx.inputCorrect)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridTextArea, {
                key: 0,
                label: _ctx.it('form.mnemonicconfirm.instructions.label'),
                text: _ctx.it('form.mnemonicconfirm.instructions.text'),
                icon: _ctx.it('form.mnemonicconfirm.instructions.icon'),
                class: "col-span-12",
                css: "cc-area-highlight",
                "text-c-s-s": "cc-text-normal text-justify"
            }, null, 8, ["label", "text", "icon"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridFormMnemonicList, {
            label: _ctx.it('form.mnemonicconfirm.label'),
            mnemonic: _ctx.compareMnemonic,
            "onUpdate:mnemonic": _cache[0] || (_cache[0] = ($event) => ((_ctx.compareMnemonic) = $event)),
            editable: !_ctx.inputCorrect,
            class: "col-span-12"
        }, null, 8, ["label", "mnemonic", "editable"]),
        (!_ctx.inputCorrect)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridInput, {
                key: 1,
                "input-text": _ctx.wordInput,
                "onUpdate:input-text": _cache[1] || (_cache[1] = ($event) => ((_ctx.wordInput) = $event)),
                "input-error": _ctx.wordInputError,
                "onUpdate:input-error": _cache[2] || (_cache[2] = ($event) => ((_ctx.wordInputError) = $event)),
                onEnter: _ctx.onEnter,
                label: _ctx.it('form.mnemonicconfirm.input.label'),
                "input-hint": _ctx.it('form.mnemonicconfirm.input.hint'),
                "input-info": _ctx.wordInputInfo,
                alwaysShowInfo: true,
                "input-id": "wordInput",
                "input-type": "text",
                autofocus: "",
                autocomplete: "name",
                class: "col-span-12"
            }, {
                "icon-prepend": (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_IconPencil, { class: "h-5 w-5" })
                ]),
                _: 1
            }, 8, ["input-text", "input-error", "onEnter", "label", "input-hint", "input-info"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", GridFormMnemonicInputConfirmvue_type_template_id_2064d1b8_ts_true_hoisted_2, [
            (_ctx.wordInput.length > 1)
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(true), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, { key: 0 }, (0,runtime_core_esm_bundler/* renderList */.Ko)(_ctx.filterOptions, (item) => {
                    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridButtonSecondary, {
                        key: item + 'filter',
                        label: item,
                        capitalize: false,
                        link: () => _ctx.onClickedWord(item),
                        class: "col-span-6 sm:col-span-4 lg:col-span-2 lowercase"
                    }, null, 8, ["label", "link"]));
                }), 128))
                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
        ]),
        (_ctx.inputCorrect)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridTextArea, {
                key: 2,
                label: _ctx.it('form.mnemonicconfirm.input.correct.label'),
                text: _ctx.it('form.mnemonicconfirm.input.correct.text'),
                icon: _ctx.it('form.mnemonicconfirm.input.correct.icon'),
                class: "col-span-12",
                "text-c-s-s": "cc-text-normal text-justify",
                css: "cc-rounded cc-banner-warning"
            }, null, 8, ["label", "text", "icon"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (_ctx.inputCorrect)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridToggle, {
                key: 3,
                label: _ctx.it('form.mnemonicconfirm.toggle.label'),
                text: _ctx.it('form.mnemonicconfirm.toggle.text'),
                icon: _ctx.it('form.mnemonicconfirm.toggle.icon'),
                toggled: _ctx.toggled,
                toggleError: _ctx.toggleError,
                "onUpdate:toggled": _cache[3] || (_cache[3] = ($event) => (_ctx.toggled = $event)),
                "onUpdate:toggleError": _cache[4] || (_cache[4] = ($event) => (_ctx.toggleError = $event)),
                class: "col-span-12"
            }, null, 8, ["label", "text", "icon", "toggled", "toggleError"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (0,runtime_core_esm_bundler/* renderSlot */.WI)(_ctx.$slots, "btnBack"),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonCountdown, {
            label: _ctx.it('common.label.continue'),
            link: _ctx.onSubmit,
            disabled: !_ctx.toggled,
            duration: 1,
            class: "col-start-7 col-span-6 lg:col-start-10 lg:col-span-3"
        }, null, 8, ["label", "link", "disabled"])
    ]));
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/mnemonic/GridFormMnemonicInputConfirm.vue?vue&type=template&id=2064d1b8&ts=true

// EXTERNAL MODULE: ./src/lib/ExtLib.ts
var ExtLib = __webpack_require__(23211);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/icons/IconPencil.vue + 4 modules
var IconPencil = __webpack_require__(44814);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridInput.vue + 4 modules
var GridInput = __webpack_require__(27209);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/mnemonic/GridFormMnemonicInputConfirm.vue?vue&type=script&lang=ts











/* harmony default export */ const GridFormMnemonicInputConfirmvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'GridFormMnemonicInputConfirm',
    components: {
        IconPencil: IconPencil/* default */.Z,
        GridFormMnemonicList: GridFormMnemonicList/* default */.Z,
        GridInput: GridInput/* default */.Z,
        GridTextArea: GridTextArea/* default */.Z,
        GridToggle: GridToggle/* default */.Z,
        GridButtonSecondary: GridButtonSecondary/* default */.Z,
        GridButtonCountdown: GridButtonCountdown/* default */.Z
    },
    emits: ['submit'],
    props: {
        mnemonic: { type: Array, required: true },
        textId: { type: String, default: '' }
    },
    setup(props, context) {
        const { it } = (0,useTranslation/* useTranslation */.$)();
        const wordlist = ExtLib.wordlists.english.concat();
        const arr = [];
        for (let i = 0; i < props.mnemonic.length; i++) {
            // Keep here for testing.
            // if(i < props.mnemonic.length - 2) {
            //
            //   arr.push(props.mnemonic[i] as string)
            //
            // } else {
            arr.push('');
            // }
        }
        const inputCorrect = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const compareMnemonic = (0,reactivity_esm_bundler/* ref */.iH)(arr);
        const info = it('form.mnemonicconfirm.input.info');
        const wordInput = (0,reactivity_esm_bundler/* ref */.iH)('');
        const wordInputError = (0,reactivity_esm_bundler/* ref */.iH)('');
        const wordInputInfo = (0,reactivity_esm_bundler/* ref */.iH)(info);
        const filterOptions = (0,reactivity_esm_bundler/* ref */.iH)([]);
        function onEnter() {
            wordInput.value = wordInput.value + ' ';
        }
        (0,runtime_core_esm_bundler/* watch */.YP)(wordInput, (newValue, oldValue) => {
            // console.log('watch: wordInput:', newValue)
            if (newValue.length === 0) {
                wordInputInfo.value = info;
                wordInputError.value = '';
            }
            else {
                const input = newValue.toLowerCase();
                const needle = input.trim();
                filterOptions.value = (wordlist.filter(v => v.toLowerCase().startsWith(needle)));
                // console.log(filterOptions.value.toString())
                if (input.length > needle.length && filterOptions.value.some(e => e === needle)) {
                    filterOptions.value = [needle];
                }
                // console.log(filterOptions.value.toString())
                let info = filterOptions.value.join(', ');
                if (info.length > 64) {
                    info = info.substr(0, 64) + ' ...';
                }
                wordInputInfo.value = info;
                if (input.endsWith(' ')) {
                    validateWordInput(false);
                }
            }
        });
        function validateWordInput(external) {
            let index = compareMnemonic.value.indexOf('');
            if (index < 0) {
                console.log('validateWordInput: Error: 1: index:', index);
                wordInputError.value = '';
            }
            else if (index >= props.mnemonic.length) {
                console.log('validateWordInput: Error: 2: index:', index, props.mnemonic.length);
                wordInputError.value = '';
            }
            else {
                const compareWord = props.mnemonic[index];
                if (filterOptions.value.length === 1 && filterOptions.value[0] === compareWord) {
                    wordInput.value = compareWord;
                }
                if (wordInput.value === compareWord) {
                    wordInputError.value = '';
                    compareMnemonic.value[index] = wordInput.value;
                    wordInput.value = '';
                    if (compareMnemonic.value.join(',') === props.mnemonic.join(',')) {
                        inputCorrect.value = true;
                    }
                }
                else {
                    wordInputError.value = it('form.mnemonicconfirm.input.error');
                }
            }
            return wordInputError.value;
        }
        const toggled = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const toggleError = (0,reactivity_esm_bundler/* ref */.iH)(false);
        function onSubmit() {
            if (toggled.value) {
                context.emit('submit');
            }
            else {
                toggleError.value = true;
            }
        }
        function onClickedWord(word) {
            console.log(word);
            wordInput.value = word + ' ';
            document.getElementById('wordInput')?.focus();
        }
        return {
            it,
            wordInput,
            wordInputError,
            wordInputInfo,
            validateWordInput,
            onEnter,
            filterOptions,
            inputCorrect,
            compareMnemonic,
            toggled,
            toggleError,
            onSubmit,
            onClickedWord
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/mnemonic/GridFormMnemonicInputConfirm.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/mnemonic/GridFormMnemonicInputConfirm.vue




;
const GridFormMnemonicInputConfirm_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(GridFormMnemonicInputConfirmvue_type_script_lang_ts, [['render',GridFormMnemonicInputConfirmvue_type_template_id_2064d1b8_ts_true_render]])

/* harmony default export */ const GridFormMnemonicInputConfirm = (GridFormMnemonicInputConfirm_exports_);
// EXTERNAL MODULE: ./src/components/ccw/overlay/AccountCreationOverlay.vue + 4 modules
var AccountCreationOverlay = __webpack_require__(21928);
// EXTERNAL MODULE: ./src/lib/utils/WalletCreationStatusMapper.ts
var WalletCreationStatusMapper = __webpack_require__(7387);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/Create.vue?vue&type=script&lang=ts


;






















/* harmony default export */ const Createvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'CreateWallet',
    components: {
        Page: Page/* default */.Z,
        InfoModal: InfoModal/* default */.Z,
        GridSpace: GridSpace/* default */.Z,
        GridHeadline: GridHeadline/* default */.Z,
        GridText: GridText/* default */.Z,
        GridTextArea: GridTextArea/* default */.Z,
        GridSteps: GridSteps/* default */.Z,
        GridRadioGroup: GridRadioGroup/* default */.Z,
        GridButtonPrimary: GridButtonPrimary/* default */.Z,
        GridButtonSecondary: GridButtonSecondary/* default */.Z,
        GridFormWalletNamePassword: GridFormWalletNamePassword/* default */.Z,
        GridFormMnemonicHint: GridFormMnemonicHint,
        GridFormMnemonic: GridFormMnemonic,
        GridFormMnemonicInputConfirm: GridFormMnemonicInputConfirm,
        GridFormAccountSelection: GridFormAccountSelection/* default */.Z,
        AccountCreationOverlay: AccountCreationOverlay/* default */.Z,
    },
    setup() {
        const { setWalletName, setSpendingPassword, setMnemonic, createWallet, setNumberOfAccounts, setDiscoverAccounts, setWalletCreationHook, } = (0,useWalletCreation/* useWalletCreation */.c)();
        const { reloadWalletList } = (0,useWalletList/* useWalletList */.M)();
        const { networkId } = (0,useNetworkId/* useNetworkId */.h)();
        const { openWallet, gotoWalletList, } = (0,useNavigation/* useNavigation */.HJ)();
        const { it } = (0,useTranslation/* useTranslation */.$)();
        const $q = (0,use_quasar/* default */.Z)();
        const currentStep = (0,reactivity_esm_bundler/* ref */.iH)(0);
        const tmpMnemonic = (0,reactivity_esm_bundler/* ref */.iH)('');
        const walletCreateInProgress = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const walletCreationStatus = (0,reactivity_esm_bundler/* ref */.iH)('');
        const showInfoModal = (0,reactivity_esm_bundler/* ref */.iH)(false);
        function resetInputs() {
            setWalletName('');
            setSpendingPassword('');
            setMnemonic('');
        }
        resetInputs();
        function gotoNextStepAccountSelection(payload = null) {
            if (payload !== null) {
                setWalletName(payload.walletName);
                setSpendingPassword(payload.password);
            }
            currentStep.value = 1;
        }
        function gotoNextStepMnemonicHint(payload = null) {
            if (payload !== null) {
                setNumberOfAccounts(payload.accountNumber);
                setDiscoverAccounts(payload.discoverAccounts);
            }
            currentStep.value = 2;
        }
        function gotoNextStepMnemonic() {
            currentStep.value = 3;
        }
        function gotoNextStepMnemonicCompare(payload) {
            tmpMnemonic.value = payload.mnemonic;
            currentStep.value = 4;
        }
        async function gotoNextStepWalletCreation() {
            setMnemonic(tmpMnemonic.value);
            setWalletCreationHook(async (status) => {
                walletCreationStatus.value = (0,WalletCreationStatusMapper/* getStatusInfo */.I)(status, it);
            });
            walletCreateInProgress.value = true;
            try {
                if (!networkId.value) {
                    throw new Error('Error: No active network.');
                }
                const walletId = await createWallet(networkId.value, 'mnemonic');
                await reloadWalletList();
                $q.notify({
                    type: 'positive',
                    message: it('wallet.create.message.success'),
                    position: 'top-left'
                });
                openWallet(walletId);
            }
            catch (err) {
                let errorMessage = it('wallet.create.message.faildb');
                if (err.message && err.message.toLowerCase().includes('invalid mnemonic checksum')) {
                    errorMessage = it('wallet.create.message.failmnemonic');
                    $q.notify({
                        type: 'negative',
                        message: errorMessage,
                        position: 'top-left'
                    });
                    gotoWalletList();
                }
                else {
                    walletCreateInProgress.value = false;
                    showInfoModal.value = true;
                }
                console.error('CreateWallet: Error:', err.message);
            }
        }
        function goBackToWalletName() {
            currentStep.value = 0;
            resetInputs();
        }
        function goBackToMnemonic() {
            currentStep.value = 3;
        }
        function goBack() {
            if (currentStep.value === 1) {
                goBackToWalletName();
            }
            if (currentStep.value === 2) {
                gotoNextStepAccountSelection();
            }
            if (currentStep.value === 3) {
                gotoNextStepMnemonicHint();
            }
            if (currentStep.value === 4) {
                goBackToMnemonic();
            }
        }
        const optionsSteps = (0,reactivity_esm_bundler/* reactive */.qj)([
            { id: 'password', label: it('wallet.create.step.password') },
            { id: 'account', label: it('wallet.create.step.account') },
            { id: 'hint', label: it('wallet.create.step.hint') },
            { id: 'phrase', label: it('wallet.create.step.recoveryphrase') },
            { id: 'confirm', label: it('wallet.create.step.confirm') }
        ]);
        function onHideModal() {
            showInfoModal.value = false;
        }
        return {
            it,
            optionsSteps,
            currentStep,
            tmpMnemonic,
            gotoNextStepMnemonicHint,
            gotoNextStepMnemonic,
            gotoNextStepMnemonicCompare,
            gotoNextStepWalletCreation,
            gotoNextStepAccountSelection,
            walletCreateInProgress,
            walletCreationStatus,
            goBack,
            showInfoModal,
            onHideModal
        };
    }
}));

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/Create.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/pages/ccw/wallet/Create.vue




;
const Create_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(Createvue_type_script_lang_ts, [['render',render]])

/* harmony default export */ const Create = (Create_exports_);

/***/ })

}]);
//# sourceMappingURL=5915.js.map