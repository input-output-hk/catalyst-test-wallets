"use strict";
(this["webpackChunkccw_frontend"] = this["webpackChunkccw_frontend"] || []).push([[4437,5134],{

/***/ 2821:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ StakingVault)
});

// EXTERNAL MODULE: ./node_modules/@vue/runtime-core/dist/runtime-core.esm-bundler.js
var runtime_core_esm_bundler = __webpack_require__(83673);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/StakingVault.vue?vue&type=template&id=7c562dbc&ts=true

const _hoisted_1 = { class: "cc-page-wallet cc-text-sz dark:text-cc-gray" };
function render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_SVSummary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("SVSummary");
    const _component_SVFAQ = (0,runtime_core_esm_bundler/* resolveComponent */.up)("SVFAQ");
    const _component_GridTabs = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridTabs");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_1, [
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridTabs, { tabs: _ctx.optionsTabs }, {
            tab0: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_SVSummary, {
                    wallet: _ctx.activeWalletData,
                    account: _ctx.activeAccount
                }, null, 8, ["wallet", "account"])
            ]),
            tab1: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_SVFAQ)
            ]),
            _: 1
        }, 8, ["tabs"])
    ]));
}

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/StakingVault.vue?vue&type=template&id=7c562dbc&ts=true

// EXTERNAL MODULE: ./node_modules/@vue/reactivity/dist/reactivity.esm-bundler.js
var reactivity_esm_bundler = __webpack_require__(61959);
// EXTERNAL MODULE: ./src/composables/ccw/useTranslation.ts
var useTranslation = __webpack_require__(19376);
// EXTERNAL MODULE: ./src/composables/ccw/store/useActiveWallet.ts
var useActiveWallet = __webpack_require__(52144);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/stakingvault/SVSummary.vue?vue&type=template&id=b64c8938&ts=true

const SVSummaryvue_type_template_id_b64c8938_ts_true_hoisted_1 = {
    key: 1,
    class: "cc-grid"
};
const _hoisted_2 = { class: "col-span-12 sm:col-span-12 flex flex-col items-start justify-start space-y-1" };
function SVSummaryvue_type_template_id_b64c8938_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_SVCreateAccount = (0,runtime_core_esm_bundler/* resolveComponent */.up)("SVCreateAccount");
    const _component_GridHeadline = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridHeadline");
    const _component_GridText = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridText");
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    const _component_SVLockList = (0,runtime_core_esm_bundler/* resolveComponent */.up)("SVLockList");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, [
        (_ctx.wallet && !_ctx.svAccount)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_SVCreateAccount, {
                key: 0,
                wallet: _ctx.wallet
            }, null, 8, ["wallet"]))
            : ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", SVSummaryvue_type_template_id_b64c8938_ts_true_hoisted_1, [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                    label: _ctx.it('wallet.stakingvault.summary.headline')
                }, null, 8, ["label"]),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                    text: _ctx.it('wallet.stakingvault.summary.caption')
                }, null, 8, ["text"])
            ])),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, {
            hr: "",
            class: "mt-2 mb-2"
        }),
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_2, [
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                text: _ctx.it('wallet.stakingvault.faq.faq11.text'),
                class: "cc-banner-blue p-2"
            }, null, 8, ["text"])
        ]),
        (_ctx.svAccount && _ctx.account && _ctx.wallet)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_SVLockList, {
                key: 2,
                wallet: _ctx.wallet,
                account: _ctx.account,
                "sv-account": _ctx.svAccount
            }, null, 8, ["wallet", "account", "sv-account"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
    ], 64));
}

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/stakingvault/SVSummary.vue?vue&type=template&id=b64c8938&ts=true

// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridHeadline.vue + 3 modules
var GridHeadline = __webpack_require__(63593);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridText.vue + 4 modules
var GridText = __webpack_require__(96834);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridSpace.vue + 4 modules
var GridSpace = __webpack_require__(14740);
// EXTERNAL MODULE: ./node_modules/@vue/runtime-dom/dist/runtime-dom.esm-bundler.js
var runtime_dom_esm_bundler = __webpack_require__(98880);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/stakingvault/SVCreateAccount.vue?vue&type=template&id=1911b23e&ts=true

const SVCreateAccountvue_type_template_id_1911b23e_ts_true_hoisted_1 = { class: "cc-grid" };
const SVCreateAccountvue_type_template_id_1911b23e_ts_true_hoisted_2 = {
    key: 0,
    class: "col-span-12 grid grid-cols-12 cc-gap"
};
const _hoisted_3 = { class: "col-span-12 grid grid-cols-11 cc-gap p-2 ring-2 ring-yellow-500 cc-rounded" };
const _hoisted_4 = {
    key: 4,
    class: "cc-grid"
};
function SVCreateAccountvue_type_template_id_1911b23e_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridHeadline = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridHeadline");
    const _component_GridText = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridText");
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    const _component_GridTextArea = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridTextArea");
    const _component_GridToggle = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridToggle");
    const _component_SignAddStakeVaultAccount = (0,runtime_core_esm_bundler/* resolveComponent */.up)("SignAddStakeVaultAccount");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", SVCreateAccountvue_type_template_id_1911b23e_ts_true_hoisted_1, [
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
            label: _ctx.it('wallet.stakingvault.createAccount.headline')
        }, null, 8, ["label"]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
            text: _ctx.it('wallet.stakingvault.createAccount.caption')
        }, null, 8, ["text"]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, { hr: "" }),
        (!_ctx.isValidNetwork)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", SVCreateAccountvue_type_template_id_1911b23e_ts_true_hoisted_2, [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                    label: _ctx.it('wallet.stakingvault.network.label')
                }, null, 8, ["label"]),
                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_3, [
                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                        class: "col-span-11",
                        text: _ctx.it('wallet.stakingvault.network.text')
                    }, null, 8, ["text"])
                ])
            ]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (_ctx.isValidNetwork)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridTextArea, {
                key: 1,
                label: _ctx.it('wallet.stakingvault.createAccount.warning.readFAQ.label'),
                text: _ctx.it('wallet.stakingvault.createAccount.warning.readFAQ.text'),
                icon: _ctx.it('wallet.stakingvault.createAccount.warning.readFAQ.icon'),
                html: "",
                onClick: (0,runtime_dom_esm_bundler/* withModifiers */.iM)(_ctx.onClickedGotoFAQ, ["stop"]),
                class: "col-span-12 cursor-pointer",
                "text-c-s-s": "cc-text-normal text-justify",
                css: "cc-rounded cc-banner-warning"
            }, null, 8, ["label", "text", "icon", "onClick"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (_ctx.isValidNetwork)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridToggle, {
                key: 2,
                label: _ctx.it('wallet.stakingvault.createAccount.warning.toggleReadFAQ.label'),
                text: _ctx.it('wallet.stakingvault.createAccount.warning.toggleReadFAQ.text'),
                icon: _ctx.it('wallet.stakingvault.createAccount.warning.toggleReadFAQ.icon'),
                html: "",
                toggled: _ctx.faqAccepted,
                "onUpdate:toggled": _cache[0] || (_cache[0] = ($event) => (_ctx.faqAccepted = $event)),
                css: _ctx.faqAccepted ? 'cc-rounded cc-banner-green justify-center items-center' : 'cc-rounded cc-banner-blue justify-center items-center',
                class: "col-span-12"
            }, null, 8, ["label", "text", "icon", "toggled", "css"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (_ctx.isValidNetwork)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridSpace, {
                key: 3,
                hr: ""
            }))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (_ctx.isValidNetwork && _ctx.faqAccepted)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_4, [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridTextArea, {
                    label: _ctx.it('wallet.stakingvault.createAccount.warning.instructions.account.label'),
                    text: _ctx.it('wallet.stakingvault.createAccount.warning.instructions.account.text'),
                    icon: _ctx.it('wallet.stakingvault.createAccount.warning.instructions.account.icon'),
                    html: "",
                    class: "col-span-12",
                    "text-c-s-s": "cc-text-normal text-justify",
                    css: "cc-rounded cc-banner-blue"
                }, null, 8, ["label", "text", "icon"]),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, { hr: "" }),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_SignAddStakeVaultAccount, {
                    "text-id": "wallet.stakingvault.lock.addaccount",
                    class: "col-span-12 mb-0 sm:mb-1 lg:mb-2"
                })
            ]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
    ]));
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/stakingvault/SVCreateAccount.vue?vue&type=template&id=1911b23e&ts=true

// EXTERNAL MODULE: ./src/composables/ccw/useNavigation.ts
var useNavigation = __webpack_require__(52439);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridTextArea.vue + 4 modules
var GridTextArea = __webpack_require__(15660);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridToggle.vue + 3 modules
var GridToggle = __webpack_require__(68805);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/accounts/SignAddStakeVaultAccount.vue?vue&type=template&id=5dc69e48&ts=true

const SignAddStakeVaultAccountvue_type_template_id_5dc69e48_ts_true_hoisted_1 = { class: "grid grid-cols-12 cc-gap" };
const SignAddStakeVaultAccountvue_type_template_id_5dc69e48_ts_true_hoisted_2 = {
    key: 1,
    class: "col-span-12 grid grid-cols-12 cc-gap"
};
const SignAddStakeVaultAccountvue_type_template_id_5dc69e48_ts_true_hoisted_3 = {
    key: 2,
    class: "col-span-12 lg:col-span-8 grid grid-cols-12 cc-gap mb-2 lg:mb-0"
};
const SignAddStakeVaultAccountvue_type_template_id_5dc69e48_ts_true_hoisted_4 = { class: "col-span-12 flex flex-row flex-nowrap items-center whitespace-pre-wrap cc-text-sz" };
const _hoisted_5 = {
    key: 3,
    class: "col-span-12 lg:col-span-9 flex flex-row flex-nowrap items-center whitespace-pre-wrap cc-text-sz mb-4"
};
function SignAddStakeVaultAccountvue_type_template_id_5dc69e48_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridHeadline = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridHeadline");
    const _component_GridText = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridText");
    const _component_GridFormSignWithPassword = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridFormSignWithPassword");
    const _component_LedgerTransport = (0,runtime_core_esm_bundler/* resolveComponent */.up)("LedgerTransport");
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    const _component_IconInfo = (0,runtime_core_esm_bundler/* resolveComponent */.up)("IconInfo");
    const _component_IconError = (0,runtime_core_esm_bundler/* resolveComponent */.up)("IconError");
    const _component_IconCheck = (0,runtime_core_esm_bundler/* resolveComponent */.up)("IconCheck");
    const _component_GridButtonPrimary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonPrimary");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", SignAddStakeVaultAccountvue_type_template_id_5dc69e48_ts_true_hoisted_1, [
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
            label: _ctx.t(_ctx.textId + '.label'),
            class: "col-span-12"
        }, null, 8, ["label"]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
            text: _ctx.t(_ctx.textId + '.caption') +
                (_ctx.isMnemonic ? ' ' + _ctx.t(_ctx.textId + '.info.mnemonic') : '') +
                (_ctx.isReadOnly ? ' ' + _ctx.t(_ctx.textId + '.info.readonly') : ''),
            class: "col-span-12 cc-text-sz"
        }, null, 8, ["text"]),
        (!_ctx.isConfirmed && _ctx.isMnemonic)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridFormSignWithPassword, {
                key: 0,
                onSubmit: _ctx.onSubmitPassword,
                class: "col-span-12",
                "text-id": _ctx.textId,
                autocomplete: "off",
                "skip-validation": ""
            }, {
                btnBack: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                    (0,runtime_core_esm_bundler/* renderSlot */.WI)(_ctx.$slots, "btnBack")
                ]),
                _: 3
            }, 8, ["onSubmit", "text-id"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (_ctx.isLedger && !_ctx.isConfirmed)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", SignAddStakeVaultAccountvue_type_template_id_5dc69e48_ts_true_hoisted_2, [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_LedgerTransport),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, { hr: "" })
            ]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        ((_ctx.isLedger || _ctx.isTrezor || _ctx.signError.length > 0) && !_ctx.isConfirmed)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", SignAddStakeVaultAccountvue_type_template_id_5dc69e48_ts_true_hoisted_3, [
                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SignAddStakeVaultAccountvue_type_template_id_5dc69e48_ts_true_hoisted_4, [
                    (_ctx.signError.length === 0)
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_IconInfo, {
                            key: 0,
                            class: "w-7 flex-none mr-2"
                        }))
                        : ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_IconError, {
                            key: 1,
                            class: "w-7 flex-none mr-2"
                        })),
                    (_ctx.signError.length === 0)
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridText, {
                            key: 2,
                            text: _ctx.t(_ctx.textId + '.info' + (_ctx.isLedger ? '.ledger' : '.trezor'))
                        }, null, 8, ["text"]))
                        : ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridText, {
                            key: 3,
                            text: _ctx.signError
                        }, null, 8, ["text"]))
                ])
            ]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (_ctx.isConfirmed)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_5, [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_IconCheck, { class: "w-7 flex-none mr-2 text-green-600" }),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                    text: _ctx.t(_ctx.textId + '.info.submit')
                }, null, 8, ["text"])
            ]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (_ctx.isLedger || _ctx.isTrezor)
            ? (0,runtime_core_esm_bundler/* renderSlot */.WI)(_ctx.$slots, "btnBack", { key: 4 })
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (_ctx.isLedger || _ctx.isTrezor)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridButtonPrimary, {
                key: 5,
                label: _ctx.t(_ctx.textId + '.button.sign'),
                link: _ctx.onGenerateAccount,
                class: "col-start-7 col-span-6 sm:col-start-10 sm:col-span-3"
            }, null, 8, ["label", "link"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
    ]));
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/accounts/SignAddStakeVaultAccount.vue?vue&type=template&id=5dc69e48&ts=true

// EXTERNAL MODULE: ./node_modules/quasar/src/composables/use-quasar.js
var use_quasar = __webpack_require__(48825);
// EXTERNAL MODULE: ./src/composables/ccw/store/useTrezorDevice.ts
var useTrezorDevice = __webpack_require__(83368);
// EXTERNAL MODULE: ./src/composables/ccw/store/useLedgerDevice.ts
var useLedgerDevice = __webpack_require__(47617);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridButtonPrimary.vue + 3 modules
var GridButtonPrimary = __webpack_require__(12559);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/icons/IconInfo.vue + 4 modules
var IconInfo = __webpack_require__(31599);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/icons/IconCheck.vue + 4 modules
var IconCheck = __webpack_require__(59548);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/icons/IconError.vue + 4 modules
var IconError = __webpack_require__(66934);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/forms/GridFormSignWithPassword.vue + 3 modules
var GridFormSignWithPassword = __webpack_require__(58315);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/settings/LedgerTransport.vue + 4 modules
var LedgerTransport = __webpack_require__(44844);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/WalletLib.ts + 1 modules
var WalletLib = __webpack_require__(46805);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/AccountLib.ts
var AccountLib = __webpack_require__(19276);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/TimeLockConstants.ts
var TimeLockConstants = __webpack_require__(90976);
// EXTERNAL MODULE: ./src/lib/ExtAppWalletManagerLib.ts
var ExtAppWalletManagerLib = __webpack_require__(12736);
// EXTERNAL MODULE: ./node_modules/@cardano-foundation/ledgerjs-hw-app-cardano/dist/Ada.js
var Ada = __webpack_require__(35922);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/accounts/SignAddStakeVaultAccount.vue?vue&type=script&lang=ts

;


















const addSVAccount = ExtAppWalletManagerLib/* AWM.addSVAccount */.b.addSVAccount;
/* harmony default export */ const SignAddStakeVaultAccountvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'SignAddStakeVaultAccount',
    components: {
        GridFormSignWithPassword: GridFormSignWithPassword/* default */.Z,
        GridHeadline: GridHeadline/* default */.Z,
        GridText: GridText/* default */.Z,
        GridSpace: GridSpace/* default */.Z,
        GridButtonPrimary: GridButtonPrimary/* default */.Z,
        IconInfo: IconInfo/* default */.Z,
        IconCheck: IconCheck/* default */.Z,
        IconError: IconError/* default */.Z,
        LedgerTransport: LedgerTransport/* default */.Z
    },
    props: {
        textId: { type: String, required: true, default: '' }
    },
    emits: ['submit'],
    setup(props, { emit }) {
        const { t } = (0,useTranslation/* useTranslation */.$)();
        const { initiateTrezor, getTrezorPublicKey, getTrezorDerivationTypeFromWalletId } = (0,useTrezorDevice/* useTrezorDevice */.S)();
        const { initiateLedger, getLedgerPublicKey } = (0,useLedgerDevice/* useLedgerDevice */.t)();
        const $q = (0,use_quasar/* default */.Z)();
        const { activeWalletData, activeWalletId, activeAccount } = (0,useActiveWallet/* useActiveWallet */.r)();
        const spendingPassword = (0,reactivity_esm_bundler/* ref */.iH)('');
        const signError = (0,reactivity_esm_bundler/* ref */.iH)('');
        const isConfirmed = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const isReadOnly = (0,runtime_core_esm_bundler/* computed */.Fl)(() => (activeAccount.value?.signType ?? '') === 'readonly');
        const isMnemonic = (0,runtime_core_esm_bundler/* computed */.Fl)(() => (activeAccount.value?.signType ?? '') === 'mnemonic');
        const isLedger = (0,runtime_core_esm_bundler/* computed */.Fl)(() => (activeAccount.value?.signType ?? '') === 'ledger');
        const isTrezor = (0,runtime_core_esm_bundler/* computed */.Fl)(() => (activeAccount.value?.signType ?? '') === 'trezor');
        const onAccountAdded = () => setTimeout(() => { emit('submit'); }, 25);
        (0,runtime_core_esm_bundler/* watch */.YP)(spendingPassword, () => signError.value = '');
        async function onSubmitPassword(payload) {
            const wallet = activeWalletData.value;
            if (!wallet)
                return;
            if (wallet.signType === 'mnemonic' && (0,WalletLib/* verifyRootKeyPassword */.WM)(wallet, payload.password)) {
                spendingPassword.value = payload.password;
                if (!(await addSVAccount(wallet.id, {
                    password: payload.password,
                    accountPubBech32: null
                }))) {
                    signError.value = t(props.textId + '.error.general');
                }
                else {
                    $q.notify({
                        type: 'positive',
                        message: 'Account added.',
                        position: 'top',
                        timeout: 3000
                    });
                }
                onAccountAdded();
            }
            else {
                signError.value = t(props.textId + '.error.password');
            }
        }
        async function onGenerateAccount() {
            const wallet = activeWalletData.value;
            if (!wallet)
                return;
            if ((isLedger.value || isTrezor.value)) {
                signError.value = '';
                $q.loading.show({
                    message: t(props.textId + '.loading.' + activeAccount.value?.signType),
                    html: true
                });
                const pubKeyList = [];
                try {
                    //Check if account 0 exists, as it is needed for the process.
                    const accountZero = wallet.accounts.find((account) => account.index === 0);
                    if (!accountZero) {
                        throw new Error('Please create account 0 to use this feature.');
                    }
                    if (isLedger.value) {
                        await initiateLedger(Ada.TransactionSigningMode.MULTISIG_TRANSACTION, undefined, undefined, activeWalletId.value);
                        pubKeyList.push(...(await getLedgerPublicKey(TimeLockConstants/* svAccountPath.0 */.EA[0], TimeLockConstants/* svAccountPath.2 */.EA[2])));
                    }
                    else if (isTrezor.value) {
                        const features = await initiateTrezor(undefined, activeWalletId.value);
                        pubKeyList.push(...(await getTrezorPublicKey(TimeLockConstants/* svAccountPath.0 */.EA[0], TimeLockConstants/* svAccountPath.2 */.EA[2], 1, [], getTrezorDerivationTypeFromWalletId(activeWalletId.value ?? ''))));
                    }
                    if (pubKeyList.length === 0) {
                        signError.value = t(props.textId + '.error.nokey');
                    }
                    else if (accountZero.pub !== pubKeyList[0]) {
                        signError.value = t(props.textId + '.error.mismatch');
                    }
                    else {
                        if (!(await addSVAccount(wallet.id, {
                            password: null,
                            accountPubBech32: (0,AccountLib/* prepareAccountKey */.Cl)(pubKeyList[pubKeyList.length - 1])
                        }))) {
                            signError.value = t(props.textId + '.error.general');
                        }
                        else {
                            $q.notify({
                                type: 'positive',
                                message: 'Account added.',
                                position: 'top',
                                timeout: 3000
                            });
                        }
                    }
                }
                catch (err) {
                    signError.value = err.message;
                }
                $q.loading.hide();
                if (signError.value.length === 0) {
                    isConfirmed.value = true;
                    onAccountAdded();
                }
            }
            else {
                signError.value = t(props.textId + '.error.nohw');
            }
        }
        return {
            t,
            isReadOnly,
            isMnemonic,
            isLedger,
            isTrezor,
            isConfirmed,
            spendingPassword,
            signError,
            onGenerateAccount,
            onSubmitPassword
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/accounts/SignAddStakeVaultAccount.vue?vue&type=script&lang=ts
 
// EXTERNAL MODULE: ./node_modules/vue-loader/dist/exportHelper.js
var exportHelper = __webpack_require__(74260);
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/accounts/SignAddStakeVaultAccount.vue




;
const __exports__ = /*#__PURE__*/(0,exportHelper/* default */.Z)(SignAddStakeVaultAccountvue_type_script_lang_ts, [['render',SignAddStakeVaultAccountvue_type_template_id_5dc69e48_ts_true_render]])

/* harmony default export */ const SignAddStakeVaultAccount = (__exports__);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/stakingvault/SVCreateAccount.vue?vue&type=script&lang=ts









/* harmony default export */ const SVCreateAccountvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'SVCreateAccount',
    components: {
        GridHeadline: GridHeadline/* default */.Z,
        GridText: GridText/* default */.Z,
        GridTextArea: GridTextArea/* default */.Z,
        GridToggle: GridToggle/* default */.Z,
        GridSpace: GridSpace/* default */.Z,
        SignAddStakeVaultAccount: SignAddStakeVaultAccount
    },
    props: {
        wallet: { type: Object, required: true }
    },
    setup(props) {
        const { it } = (0,useTranslation/* useTranslation */.$)();
        const { gotoWalletPage } = (0,useNavigation/* useNavigation */.HJ)();
        const networkId = props.wallet.network;
        const isValidNetwork = networkId === 'mainnet' || networkId === 'guild';
        const faqAccepted = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const onClickedGotoFAQ = () => {
            gotoWalletPage('StakingVault', 'faq');
        };
        return {
            it,
            faqAccepted,
            isValidNetwork,
            onClickedGotoFAQ
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/stakingvault/SVCreateAccount.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/stakingvault/SVCreateAccount.vue




;
const SVCreateAccount_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(SVCreateAccountvue_type_script_lang_ts, [['render',SVCreateAccountvue_type_template_id_1911b23e_ts_true_render]])

/* harmony default export */ const SVCreateAccount = (SVCreateAccount_exports_);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/stakingvault/SVLockList.vue?vue&type=template&id=cd81344c&ts=true

const SVLockListvue_type_template_id_cd81344c_ts_true_hoisted_1 = {
    key: 0,
    class: "col-span-12 flex flex-col flex-nowrap justify-center items-center"
};
const SVLockListvue_type_template_id_cd81344c_ts_true_hoisted_2 = {
    key: 3,
    class: "cc-grid"
};
function SVLockListvue_type_template_id_cd81344c_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_q_spinner_dots = (0,runtime_core_esm_bundler/* resolveComponent */.up)("q-spinner-dots");
    const _component_GridTextArea = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridTextArea");
    const _component_SVRedeem = (0,runtime_core_esm_bundler/* resolveComponent */.up)("SVRedeem");
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    const _component_SVEntryList = (0,runtime_core_esm_bundler/* resolveComponent */.up)("SVEntryList");
    return (_ctx.isActiveWalletPreparing)
        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", SVLockListvue_type_template_id_cd81344c_ts_true_hoisted_1, [
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_q_spinner_dots, {
                color: "gray",
                size: "3em"
            })
        ]))
        : (_ctx.showNoEntries)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridTextArea, {
                key: 1,
                label: _ctx.it('wallet.stakingvault.summary.instructions.withoutLocks.label'),
                text: _ctx.it('wallet.stakingvault.summary.instructions.withoutLocks.text'),
                icon: _ctx.it('wallet.stakingvault.summary.instructions.withoutLocks.icon'),
                html: "",
                class: "col-span-12",
                "text-c-s-s": "cc-text-normal text-justify",
                css: "cc-rounded cc-banner-blue"
            }, null, 8, ["label", "text", "icon"]))
            : (_ctx.showRedeem && _ctx.svAccount && _ctx.account && _ctx.wallet)
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_SVRedeem, {
                    key: 2,
                    wallet: _ctx.wallet,
                    account: _ctx.account,
                    "sv-account": _ctx.svAccount
                }, null, 8, ["wallet", "account", "sv-account"]))
                : ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", SVLockListvue_type_template_id_cd81344c_ts_true_hoisted_2, [
                    (_ctx.svRedeemableList.length > 0)
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridSpace, {
                            key: 0,
                            hr: ""
                        }))
                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                    (_ctx.svRedeemableList.length > 0)
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_SVEntryList, {
                            key: 1,
                            "entry-list": _ctx.svRedeemableList,
                            label: _ctx.it('wallet.stakingvault.summary.label.redeemableFunds'),
                            onRedeem: _ctx.onRedeemAda
                        }, {
                            info: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridTextArea, {
                                    text: _ctx.it('wallet.stakingvault.summary.instructions.redeemable.text'),
                                    icon: _ctx.it('wallet.stakingvault.summary.instructions.redeemable.icon'),
                                    html: "",
                                    class: "col-span-12",
                                    "text-c-s-s": "cc-text-normal text-justify",
                                    css: "cc-rounded cc-banner-green"
                                }, null, 8, ["text", "icon"])
                            ]),
                            _: 1
                        }, 8, ["entry-list", "label", "onRedeem"]))
                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                    (_ctx.svLockedList.length > 0)
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridSpace, {
                            key: 2,
                            hr: ""
                        }))
                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                    (_ctx.svLockedList.length > 0)
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_SVEntryList, {
                            key: 3,
                            "entry-list": _ctx.svLockedList,
                            label: _ctx.it('wallet.stakingvault.summary.label.lockedFunds')
                        }, {
                            info: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridTextArea, {
                                    text: _ctx.it('wallet.stakingvault.summary.instructions.locked.text'),
                                    icon: _ctx.it('wallet.stakingvault.summary.instructions.locked.icon'),
                                    html: "",
                                    class: "col-span-12",
                                    "text-c-s-s": "cc-text-normal text-justify",
                                    css: "cc-rounded cc-banner-warning"
                                }, null, 8, ["text", "icon"])
                            ]),
                            _: 1
                        }, 8, ["entry-list", "label"]))
                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                    (_ctx.svRedeemedList.length > 0)
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridSpace, {
                            key: 4,
                            hr: ""
                        }))
                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                    (_ctx.svRedeemedList.length > 0)
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_SVEntryList, {
                            key: 5,
                            "entry-list": _ctx.svRedeemedList,
                            label: _ctx.it('wallet.stakingvault.summary.label.redeemedFunds')
                        }, {
                            info: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridTextArea, {
                                    text: _ctx.it('wallet.stakingvault.summary.instructions.redeemed.text'),
                                    icon: _ctx.it('wallet.stakingvault.summary.instructions.redeemed.icon'),
                                    html: "",
                                    class: "col-span-12",
                                    "text-c-s-s": "cc-text-normal text-justify",
                                    css: "cc-rounded cc-banner-blue"
                                }, null, 8, ["text", "icon"])
                            ]),
                            _: 1
                        }, 8, ["entry-list", "label"]))
                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                    (_ctx.svExternalList.length > 0)
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridSpace, {
                            key: 6,
                            hr: ""
                        }))
                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                    (_ctx.svExternalList.length > 0)
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_SVEntryList, {
                            key: 7,
                            "entry-list": _ctx.svExternalList,
                            label: _ctx.it('wallet.stakingvault.summary.label.externalFunds'),
                            onRedeem: _ctx.onRedeemAda
                        }, {
                            info: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridTextArea, {
                                    text: _ctx.it('wallet.stakingvault.summary.instructions.external.text'),
                                    icon: _ctx.it('wallet.stakingvault.summary.instructions.external.icon'),
                                    html: "",
                                    class: "col-span-12",
                                    "text-c-s-s": "cc-text-normal text-justify",
                                    css: "cc-rounded cc-banner-warning"
                                }, null, 8, ["text", "icon"])
                            ]),
                            _: 1
                        }, 8, ["entry-list", "label", "onRedeem"]))
                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                ]));
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/stakingvault/SVLockList.vue?vue&type=template&id=cd81344c&ts=true

// EXTERNAL MODULE: ./src/composables/ccw/store/useChainTip.ts + 2 modules
var useChainTip = __webpack_require__(42764);
// EXTERNAL MODULE: ./src/components/ccw/common/Tooltip.vue + 3 modules
var Tooltip = __webpack_require__(30105);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/txlist/GridTxListUtxoTokenList.vue + 4 modules
var GridTxListUtxoTokenList = __webpack_require__(39304);
// EXTERNAL MODULE: ./node_modules/@vue/shared/dist/shared.esm-bundler.js
var shared_esm_bundler = __webpack_require__(62323);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/stakingvault/SVEntryList.vue?vue&type=template&id=636aa54c&ts=true

const SVEntryListvue_type_template_id_636aa54c_ts_true_hoisted_1 = {
    key: 0,
    class: "col-span-12 flex flex-row flex-nowrap justify-between"
};
const SVEntryListvue_type_template_id_636aa54c_ts_true_hoisted_2 = { class: "text-right" };
const SVEntryListvue_type_template_id_636aa54c_ts_true_hoisted_3 = /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("br", null, null, -1);
const SVEntryListvue_type_template_id_636aa54c_ts_true_hoisted_4 = {
    key: 1,
    class: "col-span-12 flex flex-row flex-nowrap justify-between"
};
const SVEntryListvue_type_template_id_636aa54c_ts_true_hoisted_5 = { class: "text-right" };
const _hoisted_6 = {
    key: 3,
    class: "col-span-12 flex flex-row flex-nowrap justify-between"
};
const _hoisted_7 = { class: "text-right" };
const _hoisted_8 = /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("br", null, null, -1);
const _hoisted_9 = { class: "col-span-12 flex flex-row flex-nowrap justify-between" };
const _hoisted_10 = { class: "text-right" };
const _hoisted_11 = {
    key: 5,
    class: "col-span-12 flex flex-row flex-nowrap justify-between"
};
const _hoisted_12 = { class: "text-right" };
const _hoisted_13 = { class: "flex flex-row flex-nowrap" };
const _hoisted_14 = {
    key: 7,
    class: "col-span-12 flex flex-row flex-nowrap justify-between"
};
const _hoisted_15 = { class: "text-right cc-text-green" };
const _hoisted_16 = { class: "flex flex-col" };
const _hoisted_17 = { class: "flex flex-row flex-nowrap" };
const _hoisted_18 = { class: "col-span-12 flex flex-row flex-nowrap justify-between" };
const _hoisted_19 = { class: "text-right flex flex-row space-x-1" };
const _hoisted_20 = { key: 0 };
const _hoisted_21 = { key: 1 };
const _hoisted_22 = ["onClick"];
const _hoisted_23 = {
    key: 2,
    class: "col-span-12 flex justify-center"
};
function SVEntryListvue_type_template_id_636aa54c_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridHeadline = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridHeadline");
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    const _component_FormattedAmount = (0,runtime_core_esm_bundler/* resolveComponent */.up)("FormattedAmount");
    const _component_GridTxListUtxoTokenList = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridTxListUtxoTokenList");
    const _component_Tooltip = (0,runtime_core_esm_bundler/* resolveComponent */.up)("Tooltip");
    const _component_q_pagination = (0,runtime_core_esm_bundler/* resolveComponent */.up)("q-pagination");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, [
        (_ctx.currentPage.length > 0)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridHeadline, {
                key: 0,
                label: _ctx.label,
                class: "col-span-12"
            }, null, 8, ["label"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (0,runtime_core_esm_bundler/* renderSlot */.WI)(_ctx.$slots, "info"),
        (_ctx.currentPage.length > 0)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(true), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, { key: 1 }, (0,runtime_core_esm_bundler/* renderList */.Ko)(_ctx.currentPage, (item, index) => {
                return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", {
                    class: (0,shared_esm_bundler/* normalizeClass */.C_)(["col-span-12 grid grid-cols-12 cc-gap cc-area-light cc-p", _ctx.currentPage.length === 1 ? '' : 'md:col-span-6']),
                    key: index
                }, [
                    (item.meta?.lockEpochNo)
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", SVEntryListvue_type_template_id_636aa54c_ts_true_hoisted_1, [
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("span", null, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('wallet.stakingvault.summary.label.lockedAt')), 1),
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("span", SVEntryListvue_type_template_id_636aa54c_ts_true_hoisted_2, [
                                (0,runtime_core_esm_bundler/* createTextVNode */.Uk)((0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.formatDatetime(item.meta?.lockTimestamp ?? '')), 1),
                                SVEntryListvue_type_template_id_636aa54c_ts_true_hoisted_3,
                                (0,runtime_core_esm_bundler/* createTextVNode */.Uk)((0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('common.label.epoch') + ' ' + item.meta?.lockEpochNo), 1)
                            ])
                        ]))
                        : ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", SVEntryListvue_type_template_id_636aa54c_ts_true_hoisted_4, [
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("span", null, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('wallet.stakingvault.summary.label.transferredAt')), 1),
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("span", SVEntryListvue_type_template_id_636aa54c_ts_true_hoisted_5, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.formatDatetime(item.meta?.lockTimestamp ?? '')), 1)
                        ])),
                    (item.meta?.lockEpochNo)
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridSpace, {
                            key: 2,
                            hr: ""
                        }))
                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                    (item.meta?.lockEpochNo)
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_6, [
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("span", null, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('wallet.stakingvault.summary.label.unlocksAt')), 1),
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_7, [
                                (0,runtime_core_esm_bundler/* createTextVNode */.Uk)((0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.formatDatetime(item.meta?.unlockTimestamp ?? '')), 1),
                                _hoisted_8,
                                (0,runtime_core_esm_bundler/* createTextVNode */.Uk)((0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('common.label.epoch') + ' ' + item.meta?.unlockEpochNo), 1)
                            ])
                        ]))
                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, { hr: "" }),
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_9, [
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("span", null, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('wallet.stakingvault.summary.label.amount')), 1),
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_10, [
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_FormattedAmount, {
                                amount: item.meta?.lockAmount.toString() ?? '0',
                                "text-c-s-s": "justify-end mb-1",
                                "show-fraction": true
                            }, null, 8, ["amount"]),
                            (item.mezList.length > 0)
                                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridTxListUtxoTokenList, {
                                    key: 0,
                                    "token-list": item.mezList
                                }, null, 8, ["token-list"]))
                                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                        ])
                    ]),
                    (item.meta?.lockEpochNo)
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridSpace, {
                            key: 4,
                            hr: ""
                        }))
                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                    (item.meta?.lockEpochNo)
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_11, [
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("span", null, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('wallet.stakingvault.summary.label.refRewards')), 1),
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_12, [
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_FormattedAmount, {
                                    amount: item.meta?.rewards?.refPoolRewards ?? '0',
                                    "text-c-s-s": "justify-end"
                                }, null, 8, ["amount"]),
                                (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_13, [
                                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_FormattedAmount, {
                                        amount: item.meta?.rewards?.refPoolROS ?? '0',
                                        percent: true,
                                        "whole-c-s-s": "",
                                        "fraction-c-s-s": "",
                                        decimals: 2,
                                        "text-c-s-s": "mr-1"
                                    }, null, 8, ["amount"]),
                                    (0,runtime_core_esm_bundler/* createTextVNode */.Uk)(" ROS ")
                                ])
                            ])
                        ]))
                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                    (item.meta?.lockEpochNo)
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridSpace, {
                            key: 6,
                            hr: ""
                        }))
                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                    (item.meta?.lockEpochNo)
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_14, [
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("span", null, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('wallet.stakingvault.summary.label.svRewards')), 1),
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_15, [
                                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_16, [
                                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_FormattedAmount, {
                                        amount: item.meta?.rewards?.svPoolRewards ?? '0',
                                        "text-c-s-s": "justify-end"
                                    }, null, 8, ["amount"]),
                                    (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_17, [
                                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_FormattedAmount, {
                                            amount: item.meta?.rewards?.svPoolROS ?? '0',
                                            percent: true,
                                            "whole-c-s-s": "",
                                            "fraction-c-s-s": "",
                                            decimals: 2,
                                            "text-c-s-s": "mr-1"
                                        }, null, 8, ["amount"]),
                                        (0,runtime_core_esm_bundler/* createTextVNode */.Uk)(" ROS ")
                                    ])
                                ])
                            ])
                        ]))
                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, { hr: "" }),
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_18, [
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("span", null, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('wallet.stakingvault.summary.label.status')), 1),
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_19, [
                            ((item.status === 'locked' || item.status === 'external') && item.meta?.rewards?.paid)
                                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", {
                                    key: 0,
                                    class: (0,shared_esm_bundler/* normalizeClass */.C_)(["whitespace-nowrap text-center", _ctx.statusBadgeClass('redeemable')])
                                }, [
                                    (item.status === 'locked')
                                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("span", _hoisted_20, (0,shared_esm_bundler/* toDisplayString */.zw)('rewards paid')))
                                        : ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("span", _hoisted_21, (0,shared_esm_bundler/* toDisplayString */.zw)('rewards'))),
                                    (item.tooltip)
                                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_Tooltip, {
                                            key: 2,
                                            anchor: "top middle",
                                            offset: [0, 25],
                                            "transition-show": "scale",
                                            "transition-hide": "scale"
                                        }, {
                                            default: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                                                (0,runtime_core_esm_bundler/* createTextVNode */.Uk)((0,shared_esm_bundler/* toDisplayString */.zw)('Rewards were paid to lock address.'), 1)
                                            ]),
                                            _: 1
                                        }))
                                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                                ], 2))
                                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                            (item.status === 'locked' || item.status === 'redeemed')
                                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", {
                                    key: 1,
                                    class: (0,shared_esm_bundler/* normalizeClass */.C_)(["whitespace-nowrap text-center", _ctx.statusBadgeClass(item.status)])
                                }, [
                                    (0,runtime_core_esm_bundler/* createElementVNode */._)("span", null, (0,shared_esm_bundler/* toDisplayString */.zw)(item.status), 1),
                                    (item.tooltip)
                                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_Tooltip, {
                                            key: 0,
                                            anchor: "top middle",
                                            offset: [0, 25],
                                            "transition-show": "scale",
                                            "transition-hide": "scale"
                                        }, {
                                            default: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                                                (0,runtime_core_esm_bundler/* createTextVNode */.Uk)((0,shared_esm_bundler/* toDisplayString */.zw)(item.tooltip), 1)
                                            ]),
                                            _: 2
                                        }, 1024))
                                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                                ], 2))
                                : ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", {
                                    key: 2,
                                    class: (0,shared_esm_bundler/* normalizeClass */.C_)(["whitespace-nowrap text-center", _ctx.statusBadgeClass(item.status) + (item.status === 'redeemable' || item.status === 'external' ? ' cursor-pointer' : '')]),
                                    onClick: ($event) => (_ctx.onRedeemAda(item))
                                }, [
                                    (0,runtime_core_esm_bundler/* createTextVNode */.Uk)((0,shared_esm_bundler/* toDisplayString */.zw)(item.status) + " ", 1),
                                    (item.tooltip)
                                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_Tooltip, {
                                            key: 0,
                                            anchor: "top middle",
                                            offset: [0, 25],
                                            "transition-show": "scale",
                                            "transition-hide": "scale"
                                        }, {
                                            default: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                                                (0,runtime_core_esm_bundler/* createTextVNode */.Uk)((0,shared_esm_bundler/* toDisplayString */.zw)(item.tooltip), 1)
                                            ]),
                                            _: 2
                                        }, 1024))
                                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                                ], 10, _hoisted_22))
                        ])
                    ])
                ], 2));
            }), 128))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (_ctx.showPagination)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_23, [
                (_ctx.showPagination)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_q_pagination, {
                        key: 0,
                        modelValue: _ctx.currentPageNo,
                        "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => ((_ctx.currentPageNo) = $event)),
                        "model-value": _ctx.currentPageNo,
                        max: _ctx.maxPages,
                        "max-pages": 6,
                        "boundary-numbers": "",
                        flat: "",
                        color: "teal-90",
                        "text-color": "teal-90",
                        "active-color": "teal-90",
                        "active-text-color": "teal-90",
                        "active-design": "unelevated"
                    }, null, 8, ["modelValue", "model-value", "max"]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
            ]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
    ], 64));
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/stakingvault/SVEntryList.vue?vue&type=template&id=636aa54c&ts=true

// EXTERNAL MODULE: ./src/composables/ccw/store/useFormatter.ts
var useFormatter = __webpack_require__(16938);
// EXTERNAL MODULE: ./src/components/ccw/common/FormattedAmount.vue + 3 modules
var FormattedAmount = __webpack_require__(6200);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/stakingvault/SVEntryList.vue?vue&type=script&lang=ts








/* harmony default export */ const SVEntryListvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'SVEntryList',
    emits: [
        'redeem'
    ],
    components: {
        GridSpace: GridSpace/* default */.Z,
        GridHeadline: GridHeadline/* default */.Z,
        GridTxListUtxoTokenList: GridTxListUtxoTokenList/* default */.Z,
        Tooltip: Tooltip/* default */.Z,
        FormattedAmount: FormattedAmount/* default */.Z
    },
    props: {
        label: { type: String, required: true },
        entryList: { type: Array, required: true }
    },
    setup(props, { emit }) {
        const { it } = (0,useTranslation/* useTranslation */.$)();
        const { formatPercent, formatDatetime } = (0,useFormatter/* useFormatter */.G)();
        const svStatusLabel = {
            syncing: it('common.status.syncing'),
            invalid: it('common.status.invalid'),
            locked: it('common.status.locked'),
            claimable: it('common.status.claimable'),
            redeemed: it('common.status.redeemed')
        };
        const statusBadgeClass = (status) => {
            switch (status) {
                case 'external': return 'cc-badge-gray';
                case 'locked': return 'cc-badge-purple';
                case 'redeemable': return 'cc-badge-green';
                case 'redeemed': return 'cc-badge-blue';
                default: return '';
            }
        };
        function onRedeemAda(entry) {
            console.log('onRedeemAda', entry);
            emit('redeem');
        }
        const itemsOnPage = 4;
        const currentPageNo = (0,reactivity_esm_bundler/* ref */.iH)(1);
        const maxPages = (0,runtime_core_esm_bundler/* computed */.Fl)(() => Math.ceil(props.entryList.length / itemsOnPage));
        const showPagination = (0,runtime_core_esm_bundler/* computed */.Fl)(() => props.entryList.length > itemsOnPage);
        const currentPageStart = (0,runtime_core_esm_bundler/* computed */.Fl)(() => (currentPageNo.value - 1) * itemsOnPage);
        const currentPage = (0,runtime_core_esm_bundler/* computed */.Fl)(() => props.entryList.slice(currentPageStart.value, currentPageStart.value + itemsOnPage));
        return {
            it,
            formatPercent,
            formatDatetime,
            currentPageNo,
            showPagination,
            maxPages,
            currentPage,
            onRedeemAda,
            svStatusLabel,
            statusBadgeClass,
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/stakingvault/SVEntryList.vue?vue&type=script&lang=ts
 
// EXTERNAL MODULE: ./node_modules/quasar/src/components/pagination/QPagination.js
var QPagination = __webpack_require__(87300);
// EXTERNAL MODULE: ./node_modules/@quasar/app/lib/webpack/runtime.auto-import.js
var runtime_auto_import = __webpack_require__(7518);
var runtime_auto_import_default = /*#__PURE__*/__webpack_require__.n(runtime_auto_import);
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/stakingvault/SVEntryList.vue




;
const SVEntryList_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(SVEntryListvue_type_script_lang_ts, [['render',SVEntryListvue_type_template_id_636aa54c_ts_true_render]])

/* harmony default export */ const SVEntryList = (SVEntryList_exports_);
;

runtime_auto_import_default()(SVEntryListvue_type_script_lang_ts, 'components', {QPagination: QPagination/* default */.Z});

;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/stakingvault/SVRedeem.vue?vue&type=template&id=a0b5e3b8&ts=true

const SVRedeemvue_type_template_id_a0b5e3b8_ts_true_hoisted_1 = {
    key: 0,
    class: "col-span-12 flex flex-col flex-nowrap justify-center items-center"
};
function SVRedeemvue_type_template_id_a0b5e3b8_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_q_spinner_dots = (0,runtime_core_esm_bundler/* resolveComponent */.up)("q-spinner-dots");
    const _component_GridButtonSecondary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonSecondary");
    const _component_SendConfirm = (0,runtime_core_esm_bundler/* resolveComponent */.up)("SendConfirm");
    const _component_SendSubmit = (0,runtime_core_esm_bundler/* resolveComponent */.up)("SendSubmit");
    const _component_GridSteps = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSteps");
    return (!_ctx.tx)
        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", SVRedeemvue_type_template_id_a0b5e3b8_ts_true_hoisted_1, [
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_q_spinner_dots, {
                color: "gray",
                size: "3em"
            })
        ]))
        : ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridSteps, {
            key: 1,
            onBack: _ctx.goBack,
            steps: _ctx.optionsSteps,
            currentStep: _ctx.currentStep,
            "small-c-s-s": "pr-20 xs:pr-20 lg:pr-24"
        }, {
            step0: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_SendConfirm, {
                    onSubmit: _ctx.gotoNext,
                    wallet: _ctx.wallet,
                    account: _ctx.svAccount,
                    "unsigned-tx": _ctx.tx,
                    "text-id": "wallet.send.step.confirm"
                }, {
                    btnBack: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonSecondary, {
                            label: _ctx.it('common.label.cancel'),
                            link: _ctx.goBack,
                            class: "col-start-0 col-span-6 sm:col-span-3 lg:col-start-0 lg:col-span-3"
                        }, null, 8, ["label", "link"])
                    ]),
                    _: 1
                }, 8, ["onSubmit", "wallet", "account", "unsigned-tx"])
            ]),
            step1: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_SendSubmit, {
                    onError: _ctx.onSubmitError,
                    onSending: _ctx.onTxSending,
                    onPending: _ctx.onTxPending,
                    onConfirmed: _ctx.onTxConfirmed,
                    "text-id": "wallet.send.step.submit"
                }, {
                    btnBack: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                        (_ctx.hasSubmitError)
                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridButtonSecondary, {
                                key: 0,
                                label: _ctx.it('common.label.retry'),
                                link: _ctx.goBack,
                                class: "col-start-0 col-span-6 lg:col-start-0 lg:col-span-3 mt-4"
                            }, null, 8, ["label", "link"]))
                            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                    ]),
                    _: 1
                }, 8, ["onError", "onSending", "onPending", "onConfirmed"])
            ]),
            _: 1
        }, 8, ["onBack", "steps", "currentStep"]));
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/stakingvault/SVRedeem.vue?vue&type=template&id=a0b5e3b8&ts=true

// EXTERNAL MODULE: ./src/composables/ccw/store/useBuildTx_v3.ts + 1 modules
var useBuildTx_v3 = __webpack_require__(72107);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/send/SendConfirm.vue + 4 modules
var SendConfirm = __webpack_require__(12662);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/send/SendSubmit.vue + 3 modules
var SendSubmit = __webpack_require__(65778);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridSteps.vue + 14 modules
var GridSteps = __webpack_require__(58217);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridButtonSecondary.vue + 3 modules
var GridButtonSecondary = __webpack_require__(72713);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/AppWalletLib.ts + 1 modules
var AppWalletLib = __webpack_require__(86278);
// EXTERNAL MODULE: ./src/lib/CardanoSerializationLib.ts + 1 modules
var CardanoSerializationLib = __webpack_require__(50033);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/AddressLib.ts
var AddressLib = __webpack_require__(91845);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/TimeLockUtils.ts
var TimeLockUtils = __webpack_require__(4367);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/ChainLib.ts
var ChainLib = __webpack_require__(48011);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/CSLCredentials.ts
var CSLCredentials = __webpack_require__(84431);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/CSLUtils.ts
var CSLUtils = __webpack_require__(58173);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/TxLib_wip.ts + 2 modules
var TxLib_wip = __webpack_require__(16359);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/TimeLockSync.ts
var TimeLockSync = __webpack_require__(35270);
;// CONCATENATED MODULE: ../ccw-lib2/core/lib/TimeLockLib.ts










// Redeeming does not validate any data, when redeeming the rewards are already a utxo on a script address.
const generateTxSVRedeem = async (svAccount, accChangeHD) => {
    const start = Date.now();
    const networkId = svAccount.network;
    const epochParams = (0,ChainLib/* getEpochParams */.M4)(networkId);
    if (!epochParams)
        throw new Error('Error: generateTxSVRedeem: no epoch params available.');
    const currentSlot = (0,ChainLib/* getCalculatedChainTip */.YB)(networkId);
    // Expand svAccount, 1 payment key
    if (svAccount.keys.payment.length === 0) {
        (0,AccountLib/* expandPaymentKeys */.sY)(svAccount);
    }
    if (!svAccount.keys.script) {
        svAccount.keys.script = [];
    }
    await (0,TimeLockSync/* syncSVAccount */.Fu)(svAccount);
    const utxoList = (0,AccountLib/* getAccountUtxoList */.ub)(svAccount);
    const txList = (0,AccountLib/* getAccountTxList */.hk)(svAccount);
    const svKey = svAccount.keys.payment[0];
    // Witnesses
    // [1/2] : Tx needs to be signed by script + user_sv_key (m/1854'/1815'/0'/0/0)
    const witnesses = CardanoSerializationLib/* TransactionWitnessSet.new */.XgB["new"]();
    const witScripts = CardanoSerializationLib/* NativeScripts.new */.a5u["new"]();
    const includedUnlockSlots = [];
    const redeemableUtxos = [];
    let largestUnlockSlot = 0;
    // Loop through all known utxos
    for (const utxo of utxoList) {
        // All utxos on this account are on script addresses.
        if ((0,AddressLib/* isScriptAddress */.k)(utxo.paymentAddr.bech32)) {
            // Find the initial transaction that 'created' the script address.
            // utxo could either be the initial one or the rewards payout or a random utxo.
            const tx = txList.find(item => item.outputList.find(output => output.paymentAddr.bech32 === utxo.paymentAddr.bech32) &&
                item.metadataList.some(m => m.key === TimeLockConstants/* svMetadataKey.toString */.cE.toString()));
            if (!tx || (tx.metadataList.length === 0) || (!tx.metadataList[0].json)) {
                throw new Error('Redeem: no tx details for utxo:' + utxo.txHash + '#' + utxo.txIndex);
            }
            const meta = tx.metadataList[0].json;
            if (meta.unlockSlotNo > 0 && meta.unlockSlotNo < currentSlot) {
                if (meta.unlockSlotNo > largestUnlockSlot)
                    largestUnlockSlot = meta.unlockSlotNo;
                redeemableUtxos.push(utxo);
                if (!includedUnlockSlots.includes(meta.unlockSlotNo)) {
                    // check whether it's a script address
                    const timeLockScript = (0,TimeLockUtils/* createTimeLockScriptFromSlot */.C3)(meta.unlockSlotNo, svKey.pub);
                    witScripts.add(timeLockScript);
                    if (!svAccount.keys.script.some(key => key.cred === utxo.paymentAddr.cred)) {
                        svAccount.keys.script.push({
                            // IPubKey
                            pub: '',
                            // IDerivedKey
                            path: svKey.path,
                            index: 0,
                            // IEntity
                            bech32: svKey.bech32,
                            // ICredentials
                            cred: utxo.paymentAddr.cred,
                            used: true,
                            isScript: true,
                            scriptHash: (0,CSLCredentials/* getCredFromScript */.dc)(timeLockScript)
                        });
                    }
                    includedUnlockSlots.push(meta.unlockSlotNo);
                }
            }
        }
        else {
            throw new Error('Redeem: no script address:' + utxo.txHash + '#' + utxo.txIndex);
        }
    }
    witnesses.set_native_scripts(witScripts);
    const witnessSizeOffset = 1 + 96;
    const metadata = (0,CSLUtils/* getTxMetadataFromString */.nr)('Redeemed funds from Staking Vault.');
    const feeOffset = (witnesses.to_bytes().byteLength + witnessSizeOffset) * epochParams.txFeePerByte;
    const builtTx = await (0,TxLib_wip/* createUnsignedTxSVRedeem */.H9)(networkId, redeemableUtxos, svAccount.keys, accChangeHD, feeOffset, largestUnlockSlot, metadata, witnesses);
    console.log((Date.now() - start) + 'ms');
    return builtTx;
};

// EXTERNAL MODULE: ../ccw-lib2/core/lib/tx/TxParser.ts
var TxParser = __webpack_require__(90095);
// EXTERNAL MODULE: ./src/lib/ExtApiLib.ts
var ExtApiLib = __webpack_require__(1553);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/stakingvault/SVRedeem.vue?vue&type=script&lang=ts

;











/* harmony default export */ const SVRedeemvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'SVRedeem',
    components: {
        GridSteps: GridSteps/* default */.Z,
        GridButtonSecondary: GridButtonSecondary/* default */.Z,
        SendConfirm: SendConfirm/* default */.Z,
        SendSubmit: SendSubmit/* default */.Z
    },
    props: {
        account: { type: Object, required: true },
        svAccount: { type: Object, required: true },
        wallet: { type: Object, required: true }
    },
    setup(props) {
        const { it } = (0,useTranslation/* useTranslation */.$)();
        const { gotoWalletPage } = (0,useNavigation/* useNavigation */.HJ)();
        const { resetBuildTx, cloneBuildTx, setBuiltTx, setTxBody, setMetadata, setKeyList, setWitnessSet, getBuildStatus } = (0,useBuildTx_v3/* useBuildTxV3 */.b)();
        const $q = (0,use_quasar/* default */.Z)();
        const currentStep = (0,reactivity_esm_bundler/* ref */.iH)(0);
        const optionsSteps = (0,reactivity_esm_bundler/* reactive */.qj)([
            { id: 'confirm', label: it('wallet.stakingvault.steps.stepper.confirm') },
            { id: 'submit', label: it('wallet.stakingvault.steps.stepper.submit') }
        ]);
        const tx = (0,reactivity_esm_bundler/* ref */.iH)(null);
        const hasSubmitError = (0,runtime_core_esm_bundler/* computed */.Fl)(() => (getBuildStatus(props.svAccount.pub) === useBuildTx_v3/* IBuildStatus.error */.k.error));
        async function onRedeemAda() {
            const { changeAddrBech32 } = (0,AppWalletLib/* getWalletSettings */.Ml)(props.wallet, props.account);
            if (!changeAddrBech32) {
                console.error("Unable to get change address for account.");
                return;
            }
            try {
                const redeemTx = await generateTxSVRedeem(props.svAccount, changeAddrBech32);
                const cslTx = redeemTx.tx;
                const convertedTx = await (0,TxParser/* convertTxToITx */.F4)(props.svAccount, cslTx, null, ExtApiLib/* loadTxDetailsList */.LG);
                console.log(convertedTx);
                console.log('cslTx.auxiliary_data() ', cslTx.auxiliary_data(), cslTx.auxiliary_data()?.to_bytes().byteLength);
                const accountPubKey = props.svAccount.pub;
                resetBuildTx(accountPubKey);
                setBuiltTx(accountPubKey, convertedTx.tx);
                setTxBody(accountPubKey, cslTx.body());
                setMetadata(accountPubKey, cslTx.auxiliary_data() ?? null);
                setWitnessSet(accountPubKey, cslTx.witness_set());
                setKeyList(accountPubKey, [props.svAccount.keys.payment[0], ...props.svAccount.keys.script]); // need to add the actual key for the pub key
                tx.value = convertedTx.tx;
            }
            catch (e) {
                $q.notify({
                    type: 'negative',
                    message: 'error: ' + (e?.message ?? 'no error message'),
                    position: 'top',
                    timeout: 6000
                });
                console.error('onRedeemAda error:', e?.message ?? e);
            }
        }
        onRedeemAda();
        function goBack() {
            if (currentStep.value === 0) {
                tx.value = null;
            }
            if (currentStep.value === 1) {
                currentStep.value = 0;
            }
        }
        function gotoNext() {
            cloneBuildTx(props.svAccount.pub, props.account.pub);
            if (currentStep.value === 0) {
                currentStep.value = 1;
            }
        }
        function onSubmitError() { console.error('submit error!!'); }
        function onTxSending() { }
        function onTxPending() {
            gotoWalletPage('Transactions', 'pending');
        }
        function onTxConfirmed() { }
        return {
            it,
            tx,
            hasSubmitError,
            //
            optionsSteps,
            currentStep,
            onSubmitError,
            onTxSending,
            onTxPending,
            onTxConfirmed,
            goBack,
            gotoNext
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/stakingvault/SVRedeem.vue?vue&type=script&lang=ts
 
// EXTERNAL MODULE: ./node_modules/quasar/src/components/spinner/QSpinnerDots.js
var QSpinnerDots = __webpack_require__(34765);
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/stakingvault/SVRedeem.vue




;
const SVRedeem_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(SVRedeemvue_type_script_lang_ts, [['render',SVRedeemvue_type_template_id_a0b5e3b8_ts_true_render]])

/* harmony default export */ const SVRedeem = (SVRedeem_exports_);
;

runtime_auto_import_default()(SVRedeemvue_type_script_lang_ts, 'components', {QSpinnerDots: QSpinnerDots/* default */.Z});

;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/stakingvault/SVLockList.vue?vue&type=script&lang=ts


;









/* harmony default export */ const SVLockListvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'SVLockList',
    components: {
        GridSpace: GridSpace/* default */.Z,
        GridTextArea: GridTextArea/* default */.Z,
        GridTxListUtxoTokenList: GridTxListUtxoTokenList/* default */.Z,
        Tooltip: Tooltip/* default */.Z,
        SVEntryList: SVEntryList,
        SVRedeem: SVRedeem,
    },
    props: {
        account: { type: Object, required: true },
        svAccount: { type: Object, required: true },
        wallet: { type: Object, required: true }
    },
    setup(props) {
        const $q = (0,use_quasar/* default */.Z)();
        const { it } = (0,useTranslation/* useTranslation */.$)();
        const { chainTip } = (0,useChainTip/* useChainTip */.K)();
        const { isActiveWalletPreparing } = (0,useActiveWallet/* useActiveWallet */.r)();
        const svLockedList = (0,reactivity_esm_bundler/* ref */.iH)([]);
        const svRedeemableList = (0,reactivity_esm_bundler/* ref */.iH)([]);
        const svRedeemedList = (0,reactivity_esm_bundler/* ref */.iH)([]);
        const svExternalList = (0,reactivity_esm_bundler/* ref */.iH)([]);
        function updateSVLists() {
            try {
                const svLists = (0,TimeLockUtils/* updateSVMetaList */.ZL)(props.svAccount);
                for (const entry of svLists.lockedList) {
                    entry.tooltip = it('wallet.stakingvault.summary.tooltip.locked');
                }
                for (const entry of svLists.redeemableList) {
                    entry.tooltip = it('wallet.stakingvault.summary.tooltip.redeemable');
                }
                for (const entry of svLists.redeemedList) {
                    entry.tooltip = it('wallet.stakingvault.summary.tooltip.redeemed');
                }
                for (const entry of svLists.externalList) {
                    entry.tooltip = it('wallet.stakingvault.summary.tooltip.external');
                }
                svLockedList.value = svLists.lockedList;
                svRedeemableList.value = svLists.redeemableList;
                svRedeemedList.value = svLists.redeemedList;
                svExternalList.value = svLists.externalList;
            }
            catch (e) {
                $q.notify({
                    type: 'negative',
                    message: 'error: ' + (e?.message ?? 'no error message'),
                    position: 'top-left',
                    timeout: 5000
                });
            }
        }
        (0,runtime_core_esm_bundler/* watch */.YP)(() => chainTip.epochNo, () => updateSVLists());
        (0,runtime_core_esm_bundler/* watch */.YP)(() => props.svAccount, () => updateSVLists());
        (0,runtime_core_esm_bundler/* onMounted */.bv)(() => updateSVLists());
        const showNoEntries = (0,runtime_core_esm_bundler/* computed */.Fl)(() => svLockedList.value.length === 0 &&
            svRedeemableList.value.length === 0 &&
            svRedeemedList.value.length === 0 &&
            svExternalList.value.length === 0);
        const showRedeem = (0,reactivity_esm_bundler/* ref */.iH)(false);
        function onRedeemAda() {
            console.log('onRedeemAda');
            showRedeem.value = true;
        }
        return {
            it,
            isActiveWalletPreparing,
            showNoEntries,
            showRedeem,
            svLockedList,
            svRedeemableList,
            svRedeemedList,
            svExternalList,
            onRedeemAda
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/stakingvault/SVLockList.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/stakingvault/SVLockList.vue




;
const SVLockList_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(SVLockListvue_type_script_lang_ts, [['render',SVLockListvue_type_template_id_cd81344c_ts_true_render]])

/* harmony default export */ const SVLockList = (SVLockList_exports_);
;

runtime_auto_import_default()(SVLockListvue_type_script_lang_ts, 'components', {QSpinnerDots: QSpinnerDots/* default */.Z});

;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/stakingvault/SVCalc.vue?vue&type=template&id=9444241a&ts=true

const SVCalcvue_type_template_id_9444241a_ts_true_hoisted_1 = { class: "cc-grid" };
const SVCalcvue_type_template_id_9444241a_ts_true_hoisted_2 = { class: "col-span-12 grid grid-cols-12 cc-gap" };
const SVCalcvue_type_template_id_9444241a_ts_true_hoisted_3 = { class: "col-span-12 flex flex-col sm:flex-row cc-gap-lg" };
const SVCalcvue_type_template_id_9444241a_ts_true_hoisted_4 = { class: "flex flex-col" };
const SVCalcvue_type_template_id_9444241a_ts_true_hoisted_5 = { class: "cc-text-semi-bold whitespace-nowrap cc-text-sm mb-1 sm:mb-2" };
const SVCalcvue_type_template_id_9444241a_ts_true_hoisted_6 = { class: "w-full sm:w-auto" };
const SVCalcvue_type_template_id_9444241a_ts_true_hoisted_7 = ["selected", "value"];
const SVCalcvue_type_template_id_9444241a_ts_true_hoisted_8 = { class: "mt-1" };
const SVCalcvue_type_template_id_9444241a_ts_true_hoisted_9 = { class: "flex-grow flex flex-col" };
const SVCalcvue_type_template_id_9444241a_ts_true_hoisted_10 = { class: "cc-text-semi-bold whitespace-nowrap cc-text-sm mb-1 sm:mb-2" };
const SVCalcvue_type_template_id_9444241a_ts_true_hoisted_11 = {
    key: 2,
    class: "col-span-12 grid grid-cols-11 cc-gap p-2 ring-2 ring-green-700 cc-rounded"
};
const SVCalcvue_type_template_id_9444241a_ts_true_hoisted_12 = { class: "col-span-11 sm:col-span-5 cc-rounded cc-bg-light-0 p-1.5" };
const SVCalcvue_type_template_id_9444241a_ts_true_hoisted_13 = { class: "w-full flex flex-col flex-nowrap justify-center items-center cc-text-sm" };
const SVCalcvue_type_template_id_9444241a_ts_true_hoisted_14 = { class: "italic whitespace-nowrap" };
const SVCalcvue_type_template_id_9444241a_ts_true_hoisted_15 = { class: "flex flex-row flex-nowrap" };
const SVCalcvue_type_template_id_9444241a_ts_true_hoisted_16 = /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("div", { class: "col-span-11 sm:col-span-1 flex flex-row flex-nowrap justify-center items-center h-4 sm:h-full" }, [
    /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("i", { class: "mdi mdi-compare-horizontal text-2xl" })
], -1);
const SVCalcvue_type_template_id_9444241a_ts_true_hoisted_17 = { class: "col-span-11 sm:col-span-5 cc-rounded cc-bg-light-0 p-1.5" };
const SVCalcvue_type_template_id_9444241a_ts_true_hoisted_18 = { class: "w-full flex flex-col flex-nowrap justify-center items-center cc-text-sm" };
const SVCalcvue_type_template_id_9444241a_ts_true_hoisted_19 = { class: "italic whitespace-nowrap" };
const SVCalcvue_type_template_id_9444241a_ts_true_hoisted_20 = { class: "flex flex-row flex-nowrap" };
const SVCalcvue_type_template_id_9444241a_ts_true_hoisted_21 = { class: "flex flex-row flex-nowrap mr-1" };
const SVCalcvue_type_template_id_9444241a_ts_true_hoisted_22 = /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("i", { class: "text-green-600 mdi mdi-finance ml-1" }, null, -1);
const SVCalcvue_type_template_id_9444241a_ts_true_hoisted_23 = {
    key: 3,
    class: "col-span-12 mt-2 sm:mt-3 grid grid-cols-12 cc-gap"
};
function SVCalcvue_type_template_id_9444241a_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridTextArea = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridTextArea");
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    const _component_AdaInput = (0,runtime_core_esm_bundler/* resolveComponent */.up)("AdaInput");
    const _component_GridHeadline = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridHeadline");
    const _component_FormattedAmount = (0,runtime_core_esm_bundler/* resolveComponent */.up)("FormattedAmount");
    const _component_GridText = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridText");
    const _component_GridTokenList = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridTokenList");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", SVCalcvue_type_template_id_9444241a_ts_true_hoisted_1, [
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridTextArea, {
            label: _ctx.it('wallet.stakingvault.lock.warning.instructions.calc.label'),
            text: _ctx.it('wallet.stakingvault.lock.warning.instructions.calc.text'),
            icon: _ctx.it('wallet.stakingvault.lock.warning.instructions.calc.icon'),
            html: "",
            class: "col-span-12",
            "text-c-s-s": "cc-text-normal text-justify",
            css: "cc-rounded cc-banner-blue"
        }, null, 8, ["label", "text", "icon"]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, { hr: "" }),
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SVCalcvue_type_template_id_9444241a_ts_true_hoisted_2, [
            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SVCalcvue_type_template_id_9444241a_ts_true_hoisted_3, [
                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SVCalcvue_type_template_id_9444241a_ts_true_hoisted_4, [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("span", SVCalcvue_type_template_id_9444241a_ts_true_hoisted_5, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('wallet.stakingvault.lock.period')), 1),
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SVCalcvue_type_template_id_9444241a_ts_true_hoisted_6, [
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("select", {
                            class: "h-11 cc-rounded-xl cc-dropdown cc-text-sm w-full",
                            required: true,
                            onChange: _cache[0] || (_cache[0] = ($event) => (_ctx.onLockPeriodChange($event)))
                        }, [
                            ((0,runtime_core_esm_bundler/* openBlock */.wg)(true), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, (0,runtime_core_esm_bundler/* renderList */.Ko)(_ctx.validLockPeriods, (item) => {
                                return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("option", {
                                    key: item.label + '_option',
                                    selected: item.lockPeriod === _ctx.numEpochsToLock,
                                    value: item.lockPeriod
                                }, (0,shared_esm_bundler/* toDisplayString */.zw)(item.label), 9, SVCalcvue_type_template_id_9444241a_ts_true_hoisted_7));
                            }), 128))
                        ], 32)
                    ]),
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("span", SVCalcvue_type_template_id_9444241a_ts_true_hoisted_8, "Unlocks at: " + (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.unlockDate), 1)
                ]),
                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SVCalcvue_type_template_id_9444241a_ts_true_hoisted_9, [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("span", SVCalcvue_type_template_id_9444241a_ts_true_hoisted_10, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('wallet.stakingvault.lock.amount.label')), 1),
                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_AdaInput, {
                        "text-id": "wallet.stakingvault.lock.amount",
                        "default-value": _ctx.lockAmount,
                        "min-lovelace": _ctx.svMinLockAmount,
                        "max-lovelace": _ctx.svMaxLockAmount,
                        onUpdate: _ctx.onAdaInput
                    }, null, 8, ["default-value", "min-lovelace", "max-lovelace", "onUpdate"])
                ])
            ]),
            (_ctx.estRewards)
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridSpace, {
                    key: 0,
                    hr: ""
                }))
                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
            (_ctx.estRewards)
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridHeadline, {
                    key: 1,
                    label: _ctx.it('wallet.stakingvault.lock.rewards')
                }, null, 8, ["label"]))
                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
            (_ctx.estRewards)
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", SVCalcvue_type_template_id_9444241a_ts_true_hoisted_11, [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SVCalcvue_type_template_id_9444241a_ts_true_hoisted_12, [
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SVCalcvue_type_template_id_9444241a_ts_true_hoisted_13, [
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SVCalcvue_type_template_id_9444241a_ts_true_hoisted_14, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('wallet.stakingvault.lock.refpool.label')), 1),
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_FormattedAmount, {
                                amount: _ctx.estRewards?.refPoolRewards,
                                "balance-always-visible": "",
                                "text-c-s-s": "flex-nowrap inline"
                            }, null, 8, ["amount"]),
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SVCalcvue_type_template_id_9444241a_ts_true_hoisted_15, [
                                (0,runtime_core_esm_bundler/* createTextVNode */.Uk)(" ("),
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_FormattedAmount, {
                                    amount: _ctx.estRewards?.refPoolROS,
                                    percent: true,
                                    "whole-c-s-s": "",
                                    "fraction-c-s-s": "",
                                    decimals: 2,
                                    "text-c-s-s": "mr-1"
                                }, null, 8, ["amount"]),
                                (0,runtime_core_esm_bundler/* createTextVNode */.Uk)("ROS) ")
                            ])
                        ])
                    ]),
                    SVCalcvue_type_template_id_9444241a_ts_true_hoisted_16,
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SVCalcvue_type_template_id_9444241a_ts_true_hoisted_17, [
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SVCalcvue_type_template_id_9444241a_ts_true_hoisted_18, [
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SVCalcvue_type_template_id_9444241a_ts_true_hoisted_19, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('wallet.stakingvault.lock.svpool.label')), 1),
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_FormattedAmount, {
                                amount: _ctx.estRewards?.svPoolRewards,
                                "balance-always-visible": "",
                                "text-c-s-s": "flex-nowrap inline"
                            }, null, 8, ["amount"]),
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SVCalcvue_type_template_id_9444241a_ts_true_hoisted_20, [
                                (0,runtime_core_esm_bundler/* createElementVNode */._)("span", SVCalcvue_type_template_id_9444241a_ts_true_hoisted_21, [
                                    (0,runtime_core_esm_bundler/* createTextVNode */.Uk)("("),
                                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_FormattedAmount, {
                                        amount: _ctx.estRewards?.svPoolROS,
                                        percent: true,
                                        "whole-c-s-s": "",
                                        "fraction-c-s-s": "",
                                        decimals: 2,
                                        "text-c-s-s": "mr-1"
                                    }, null, 8, ["amount"]),
                                    (0,runtime_core_esm_bundler/* createTextVNode */.Uk)("ROS),")
                                ]),
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_FormattedAmount, {
                                    amount: _ctx.estRewards?.pctMoreRewards,
                                    percent: true,
                                    "whole-c-s-s": "",
                                    "fraction-c-s-s": "",
                                    decimals: 2,
                                    "text-c-s-s": "mr-1"
                                }, null, 8, ["amount"]),
                                SVCalcvue_type_template_id_9444241a_ts_true_hoisted_22
                            ])
                        ])
                    ])
                ]))
                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
            (_ctx.estRewards && _ctx.allMezList.length > 0)
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", SVCalcvue_type_template_id_9444241a_ts_true_hoisted_23, [
                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, { hr: "" }),
                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                        label: _ctx.it('wallet.stakingvault.lock.mez.select')
                    }, null, 8, ["label"]),
                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                        text: _ctx.it('wallet.stakingvault.lock.mez.info')
                    }, null, 8, ["text"]),
                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, { hr: "" }),
                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridTokenList, {
                        "network-id": _ctx.account.network,
                        "wallet-id": _ctx.wallet.id,
                        "token-list": _ctx.allMezList,
                        "token-selected-list": _ctx.selectedMezList,
                        "send-enabled": true,
                        onAddToken: _cache[1] || (_cache[1] = ($event) => (_ctx.onTokenUpdateEvent('add', $event))),
                        onDelToken: _cache[2] || (_cache[2] = ($event) => (_ctx.onTokenUpdateEvent('del', $event))),
                        onTokenReset: _cache[3] || (_cache[3] = () => { })
                    }, null, 8, ["network-id", "wallet-id", "token-list", "token-selected-list"])
                ]))
                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
        ])
    ]));
}

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/stakingvault/SVCalc.vue?vue&type=template&id=9444241a&ts=true

// EXTERNAL MODULE: ./src/composables/ccw/store/useTokenLib_v2.ts + 1 modules
var useTokenLib_v2 = __webpack_require__(74510);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/summary/GridTokenList.vue + 9 modules
var GridTokenList = __webpack_require__(84003);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/stakingvault/AdaInput.vue + 4 modules
var AdaInput = __webpack_require__(85495);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/BigMathLib.ts + 1 modules
var BigMathLib = __webpack_require__(99149);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/stakingvault/SVCalc.vue?vue&type=script&lang=ts

;















/* harmony default export */ const SVCalcvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'SVCalc',
    components: {
        GridHeadline: GridHeadline/* default */.Z,
        GridText: GridText/* default */.Z,
        GridTextArea: GridTextArea/* default */.Z,
        GridSpace: GridSpace/* default */.Z,
        AdaInput: AdaInput/* default */.Z,
        FormattedAmount: FormattedAmount/* default */.Z,
        GridTokenList: GridTokenList/* default */.Z
    },
    props: {
        account: { type: Object, required: true },
        wallet: { type: Object, required: true }
    },
    setup(props) {
        const { it } = (0,useTranslation/* useTranslation */.$)();
        const $q = (0,use_quasar/* default */.Z)();
        const { chainTip } = (0,useChainTip/* useChainTip */.K)();
        const { getAssetInfo } = (0,useTokenLib_v2/* useTokenLibV2 */.P)();
        const { formatDatetime } = (0,useFormatter/* useFormatter */.G)();
        const networkId = props.account.network;
        const numEpochsToLock = (0,reactivity_esm_bundler/* ref */.iH)(18);
        const lockAmount = (0,reactivity_esm_bundler/* ref */.iH)('');
        const allMezList = (0,reactivity_esm_bundler/* ref */.iH)([]);
        const selectedMezList = (0,reactivity_esm_bundler/* ref */.iH)([]);
        const selectedMezBoost = (0,reactivity_esm_bundler/* ref */.iH)(0);
        const estRewards = (0,reactivity_esm_bundler/* ref */.iH)(null);
        const calcEpoch = (0,ChainLib/* getCalculatedEpoch */.uJ)(networkId);
        const calcSlotInEpoch = (0,ChainLib/* getCalculatedEpochSlot */.dK)(networkId);
        const calcSlotsInEpoch = networkId === 'guild' ? 3600 : 432000;
        const calcPercent = calcSlotInEpoch / calcSlotsInEpoch;
        const unlockDate = (0,reactivity_esm_bundler/* ref */.iH)('');
        const isValidNetwork = networkId === 'mainnet' || networkId === 'guild';
        const isValidStartSlot = (networkId === 'guild') ? (chainTip.epochSlot > (2 * 60)) : (chainTip.epochSlot > (3600 * 4));
        const isValidEpochTime = (0,runtime_core_esm_bundler/* computed */.Fl)(() => isValidNetwork && isValidStartSlot && calcPercent <= 0.8 && (calcSlotInEpoch - chainTip.epochSlot < 600));
        function onLockPeriodChange(event) {
            numEpochsToLock.value = event ? Number(event.target.options[event.target.options.selectedIndex].value) : numEpochsToLock.value;
            const unlockSlot = (0,ChainLib/* getEpochStart */.iT)(networkId, calcEpoch + numEpochsToLock.value);
            unlockDate.value = formatDatetime(unlockSlot.timestamp);
            if (!BigMathLib.isZero(getLockAmountInAda())) {
                calculateEstRewards();
            }
        }
        function onAdaInput(amount) {
            lockAmount.value = amount;
        }
        const getLockAmountInAda = () => lockAmount.value && lockAmount.value.length > 0 ? lockAmount.value : '0';
        const getLockAmountInLovelace = () => BigMathLib.multiply(getLockAmountInAda(), 1000000);
        function calculateEstRewards() {
            estRewards.value = (0,TimeLockUtils/* calculateRewardsAndROS */.If)(networkId, getLockAmountInLovelace(), numEpochsToLock.value);
            if (selectedMezBoost.value > 0) {
                const rewards = (0,TimeLockUtils/* getMezBoost */.b5)(estRewards.value.svPoolRewards, estRewards.value.svPoolROS, estRewards.value.pctMoreRewards, selectedMezBoost.value);
                estRewards.value.svPoolRewards = rewards.rewards;
                estRewards.value.svPoolROS = rewards.ros;
                estRewards.value.pctMoreRewards = rewards.pctMoreRewards;
            }
        }
        onLockPeriodChange(null);
        let tamount = -1;
        (0,runtime_core_esm_bundler/* watch */.YP)(lockAmount, () => {
            clearTimeout(tamount);
            if (!BigMathLib.isZero(getLockAmountInLovelace())) {
                tamount = setTimeout(() => {
                    calculateEstRewards();
                }, 300);
            }
            else {
                estRewards.value = null;
            }
        });
        async function theMesmerizerCheck(tokens) {
            if (!props.account) {
                return { tokens: [], boost: 0 };
            }
            let boost = 0;
            const mezList = [];
            for (const token of tokens) {
                if (token.policy === TimeLockConstants/* policyMesmerizer */.r8) {
                    const tokenData = await getAssetInfo(props.account.network, token);
                    const metaBoost = tokenData ? tokenData.mintingTxMetadata.find(t => 'boost' in t.json)?.json.boost : null;
                    if (metaBoost) {
                        mezList.push(token);
                        boost += parseFloat(metaBoost.slice(0, -1));
                    }
                }
            }
            return { tokens: mezList, boost };
        }
        async function onTokenUpdateEvent(type, e) {
            const mezLeft = 2 - selectedMezList.value.length;
            switch (type) {
                case 'add':
                    if (mezLeft > 0) {
                        Array.isArray(e) ? selectedMezList.value.push(...e.slice(0, mezLeft)) : selectedMezList.value.push(e);
                    }
                    if (Array.isArray(e) ? e.length > mezLeft : mezLeft === 0) {
                        $q.notify({
                            color: 'primary',
                            textColor: 'white',
                            message: it('wallet.stakingvault.lock.mez.notify'),
                            position: 'top-left'
                        });
                    }
                    break;
                case 'del':
                    if (!e) {
                        selectedMezList.value.splice(0);
                    }
                    else {
                        const index = selectedMezList.value.findIndex(t => t.token.policy === e.policy && t.token.name === e.name);
                        if (index >= 0) {
                            selectedMezList.value.splice(index, 1);
                        }
                    }
                    break;
                default: throw new Error('Error: onTokenUpdateEvent: unknown comparison.');
            }
            selectedMezBoost.value = (await theMesmerizerCheck(selectedMezList.value.map(m => m.token))).boost;
            if (!BigMathLib.isZero(getLockAmountInAda())) {
                calculateEstRewards();
            }
        }
        (0,runtime_core_esm_bundler/* onMounted */.bv)(async () => {
            const mez = await theMesmerizerCheck(props.account.balance.tokenBalance ?? []);
            allMezList.value = mez.tokens;
        });
        const validLockPeriods = [];
        for (let i = TimeLockConstants/* svMinLockEpochs */.sr; i <= TimeLockConstants/* svMaxLockEpochs */.QT; i++) {
            validLockPeriods.push({
                // TODO: What normal day count to show here. Maybe calculate it already?
                label: i + ' epochs ',
                lockPeriod: i
            });
        }
        return {
            it,
            lockAmount,
            numEpochsToLock,
            estRewards,
            allMezList,
            selectedMezList,
            selectedMezBoost,
            isValidNetwork,
            isValidEpochTime,
            validLockPeriods,
            svMinLockAmount: TimeLockConstants/* svMinLockAmount */.WF,
            svMaxLockAmount: TimeLockConstants/* svMaxLockAmount */.my,
            onLockPeriodChange,
            onAdaInput,
            onTokenUpdateEvent,
            unlockDate
        };
    }
}));

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/stakingvault/SVCalc.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/stakingvault/SVCalc.vue




;
const SVCalc_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(SVCalcvue_type_script_lang_ts, [['render',SVCalcvue_type_template_id_9444241a_ts_true_render]])

/* harmony default export */ const SVCalc = (SVCalc_exports_);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/stakingvault/SVSummary.vue?vue&type=script&lang=ts









/* harmony default export */ const SVSummaryvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'SVSummary',
    components: {
        GridHeadline: GridHeadline/* default */.Z,
        GridText: GridText/* default */.Z,
        GridSpace: GridSpace/* default */.Z,
        SVCreateAccount: SVCreateAccount,
        SVLockList: SVLockList,
        SVCalc: SVCalc,
    },
    props: {
        account: { type: Object, required: true },
        wallet: { type: Object, required: true }
    },
    setup(props) {
        const { it } = (0,useTranslation/* useTranslation */.$)();
        const svAccount = (0,reactivity_esm_bundler/* ref */.iH)((0,TimeLockUtils/* getSVAccount */.cM)(props.wallet));
        (0,runtime_core_esm_bundler/* watch */.YP)(() => props.wallet.accounts, () => { svAccount.value = (0,TimeLockUtils/* getSVAccount */.cM)(props.wallet); });
        return {
            it,
            svAccount
        };
    }
}));

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/stakingvault/SVSummary.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/stakingvault/SVSummary.vue




;
const SVSummary_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(SVSummaryvue_type_script_lang_ts, [['render',SVSummaryvue_type_template_id_b64c8938_ts_true_render]])

/* harmony default export */ const SVSummary = (SVSummary_exports_);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/stakingvault/SVLock.vue?vue&type=template&id=49fb55a2&ts=true

const SVLockvue_type_template_id_49fb55a2_ts_true_hoisted_1 = {
    key: 3,
    class: "cc-grid"
};
const SVLockvue_type_template_id_49fb55a2_ts_true_hoisted_2 = { class: "col-span-12 cc-none sm:flex flex-row flex-nowrap justify-start whitespace-pre-wrap" };
const SVLockvue_type_template_id_49fb55a2_ts_true_hoisted_3 = {
    key: 4,
    class: "cc-grid"
};
const SVLockvue_type_template_id_49fb55a2_ts_true_hoisted_4 = {
    key: 2,
    class: "col-span-12 grid grid-cols-12 cc-gap"
};
const SVLockvue_type_template_id_49fb55a2_ts_true_hoisted_5 = {
    key: 0,
    class: "col-span-12 grid grid-cols-12 cc-gap"
};
const SVLockvue_type_template_id_49fb55a2_ts_true_hoisted_6 = { class: "col-span-12 grid grid-cols-11 cc-gap p-2 ring-2 ring-yellow-500 cc-rounded" };
const SVLockvue_type_template_id_49fb55a2_ts_true_hoisted_7 = { class: "flex flex-col" };
const SVLockvue_type_template_id_49fb55a2_ts_true_hoisted_8 = { class: "cc-text-semi-bold whitespace-nowrap cc-text-sm mb-1 sm:mb-2" };
const SVLockvue_type_template_id_49fb55a2_ts_true_hoisted_9 = { class: "w-full sm:w-auto" };
const SVLockvue_type_template_id_49fb55a2_ts_true_hoisted_10 = ["selected", "value"];
const SVLockvue_type_template_id_49fb55a2_ts_true_hoisted_11 = { class: "mt-1" };
const SVLockvue_type_template_id_49fb55a2_ts_true_hoisted_12 = { class: "flex-grow flex flex-col" };
const SVLockvue_type_template_id_49fb55a2_ts_true_hoisted_13 = { class: "cc-text-semi-bold whitespace-nowrap cc-text-sm mb-1 sm:mb-2" };
const SVLockvue_type_template_id_49fb55a2_ts_true_hoisted_14 = {
    key: 4,
    class: "col-span-12 grid grid-cols-11 cc-gap p-2 ring-2 ring-green-700 cc-rounded"
};
const SVLockvue_type_template_id_49fb55a2_ts_true_hoisted_15 = { class: "col-span-11 sm:col-span-5 cc-rounded cc-bg-light-0 p-1.5" };
const SVLockvue_type_template_id_49fb55a2_ts_true_hoisted_16 = { class: "w-full flex flex-col flex-nowrap justify-center items-center cc-text-sm" };
const SVLockvue_type_template_id_49fb55a2_ts_true_hoisted_17 = { class: "italic whitespace-nowrap" };
const SVLockvue_type_template_id_49fb55a2_ts_true_hoisted_18 = { class: "flex flex-row flex-nowrap" };
const SVLockvue_type_template_id_49fb55a2_ts_true_hoisted_19 = /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("div", { class: "col-span-11 sm:col-span-1 flex flex-row flex-nowrap justify-center items-center h-4 sm:h-full" }, [
    /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("i", { class: "mdi mdi-compare-horizontal text-2xl" })
], -1);
const SVLockvue_type_template_id_49fb55a2_ts_true_hoisted_20 = { class: "col-span-11 sm:col-span-5 cc-rounded cc-bg-light-0 p-1.5" };
const SVLockvue_type_template_id_49fb55a2_ts_true_hoisted_21 = { class: "w-full flex flex-col flex-nowrap justify-center items-center cc-text-sm" };
const SVLockvue_type_template_id_49fb55a2_ts_true_hoisted_22 = { class: "italic whitespace-nowrap" };
const SVLockvue_type_template_id_49fb55a2_ts_true_hoisted_23 = { class: "flex flex-row flex-nowrap" };
const _hoisted_24 = { class: "flex flex-row flex-nowrap mr-1" };
const _hoisted_25 = /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("i", { class: "text-green-600 mdi mdi-finance ml-1" }, null, -1);
const _hoisted_26 = {
    key: 6,
    class: "col-span-12 mt-2 sm:mt-3 grid grid-cols-12 cc-gap"
};
function SVLockvue_type_template_id_49fb55a2_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_SVCalc = (0,runtime_core_esm_bundler/* resolveComponent */.up)("SVCalc");
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    const _component_GridTextArea = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridTextArea");
    const _component_GridHeadline = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridHeadline");
    const _component_GridText = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridText");
    const _component_AdaInput = (0,runtime_core_esm_bundler/* resolveComponent */.up)("AdaInput");
    const _component_FormattedAmount = (0,runtime_core_esm_bundler/* resolveComponent */.up)("FormattedAmount");
    const _component_GridButtonPrimary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonPrimary");
    const _component_GridTokenList = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridTokenList");
    const _component_GridButtonSecondary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonSecondary");
    const _component_SendConfirm = (0,runtime_core_esm_bundler/* resolveComponent */.up)("SendConfirm");
    const _component_SendSubmit = (0,runtime_core_esm_bundler/* resolveComponent */.up)("SendSubmit");
    const _component_GridSteps = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSteps");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, [
        ((_ctx.account && _ctx.wallet) && !_ctx.svAccount)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_SVCalc, {
                key: 0,
                wallet: _ctx.wallet,
                account: _ctx.account
            }, null, 8, ["wallet", "account"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        ((_ctx.account && _ctx.wallet) && !_ctx.svAccount)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridSpace, {
                key: 1,
                hr: ""
            }))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (!_ctx.svAccount)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridTextArea, {
                key: 2,
                label: _ctx.it('wallet.stakingvault.lock.warning.instructions.account.label'),
                text: _ctx.it('wallet.stakingvault.lock.warning.instructions.account.text'),
                icon: _ctx.it('wallet.stakingvault.lock.warning.instructions.account.icon'),
                html: "",
                class: "col-span-12",
                "text-c-s-s": "cc-text-normal text-justify",
                css: "cc-rounded cc-banner-blue"
            }, null, 8, ["label", "text", "icon"]))
            : ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", SVLockvue_type_template_id_49fb55a2_ts_true_hoisted_1, [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                    label: _ctx.it('wallet.stakingvault.lock.headline')
                }, null, 8, ["label"]),
                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SVLockvue_type_template_id_49fb55a2_ts_true_hoisted_2, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('wallet.stakingvault.lock.caption')), 1),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, { hr: "" })
            ])),
        (_ctx.svAccount)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", SVLockvue_type_template_id_49fb55a2_ts_true_hoisted_3, [
                (!_ctx.unsignedTx && _ctx.isValidEpochTime)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridTextArea, {
                        key: 0,
                        label: _ctx.it('wallet.stakingvault.lock.warning.instructions.process.label'),
                        text: _ctx.it('wallet.stakingvault.lock.warning.instructions.process.text'),
                        icon: _ctx.it('wallet.stakingvault.lock.warning.instructions.process.icon'),
                        html: "",
                        class: "col-span-12",
                        "text-c-s-s": "cc-text-normal text-justify",
                        css: "cc-rounded cc-banner-blue"
                    }, null, 8, ["label", "text", "icon"]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                (!_ctx.unsignedTx && _ctx.isValidEpochTime)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridSpace, {
                        key: 1,
                        hr: ""
                    }))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                (!_ctx.unsignedTx)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", SVLockvue_type_template_id_49fb55a2_ts_true_hoisted_4, [
                        (!_ctx.isValidEpochTime)
                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", SVLockvue_type_template_id_49fb55a2_ts_true_hoisted_5, [
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                                    label: _ctx.it('wallet.stakingvault.lock.note.label')
                                }, null, 8, ["label"]),
                                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SVLockvue_type_template_id_49fb55a2_ts_true_hoisted_6, [
                                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                                        class: "col-span-11",
                                        text: _ctx.it('wallet.stakingvault.lock.note.text')
                                    }, null, 8, ["text"])
                                ]),
                                ((_ctx.account && _ctx.wallet))
                                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridSpace, {
                                        key: 0,
                                        hr: ""
                                    }))
                                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                                ((_ctx.account && _ctx.wallet))
                                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_SVCalc, {
                                        key: 1,
                                        wallet: _ctx.wallet,
                                        account: _ctx.account
                                    }, null, 8, ["wallet", "account"]))
                                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                            ]))
                            : ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", {
                                key: 1,
                                class: "col-span-12 flex flex-col sm:flex-row cc-gap-lg",
                                onKeydown: _cache[1] || (_cache[1] = (0,runtime_dom_esm_bundler/* withKeys */.D2)(
                                //@ts-ignore
                                (...args) => (_ctx.onLockAda && _ctx.onLockAda(...args)), ["enter"]))
                            }, [
                                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SVLockvue_type_template_id_49fb55a2_ts_true_hoisted_7, [
                                    (0,runtime_core_esm_bundler/* createElementVNode */._)("span", SVLockvue_type_template_id_49fb55a2_ts_true_hoisted_8, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('wallet.stakingvault.lock.period')), 1),
                                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SVLockvue_type_template_id_49fb55a2_ts_true_hoisted_9, [
                                        (0,runtime_core_esm_bundler/* createElementVNode */._)("select", {
                                            class: "h-11 cc-rounded-xl cc-dropdown cc-text-sm w-full",
                                            required: true,
                                            onChange: _cache[0] || (_cache[0] = ($event) => (_ctx.onLockPeriodChange($event)))
                                        }, [
                                            ((0,runtime_core_esm_bundler/* openBlock */.wg)(true), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, (0,runtime_core_esm_bundler/* renderList */.Ko)(_ctx.validLockPeriods, (item) => {
                                                return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("option", {
                                                    key: item.label + '_option',
                                                    selected: item.lockPeriod === _ctx.numEpochsToLock,
                                                    value: item.lockPeriod
                                                }, (0,shared_esm_bundler/* toDisplayString */.zw)(item.label), 9, SVLockvue_type_template_id_49fb55a2_ts_true_hoisted_10));
                                            }), 128))
                                        ], 32)
                                    ]),
                                    (0,runtime_core_esm_bundler/* createElementVNode */._)("span", SVLockvue_type_template_id_49fb55a2_ts_true_hoisted_11, "Unlocks at: " + (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.unlockDate), 1)
                                ]),
                                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SVLockvue_type_template_id_49fb55a2_ts_true_hoisted_12, [
                                    (0,runtime_core_esm_bundler/* createElementVNode */._)("span", SVLockvue_type_template_id_49fb55a2_ts_true_hoisted_13, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('wallet.stakingvault.lock.amount.label')), 1),
                                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_AdaInput, {
                                        "text-id": "wallet.stakingvault.lock.amount",
                                        "default-value": _ctx.lockAmount,
                                        "min-lovelace": _ctx.svMinLockAmount,
                                        "max-lovelace": _ctx.svMaxLockAmount,
                                        onUpdate: _ctx.onAdaInput,
                                        "check-funds": ""
                                    }, null, 8, ["default-value", "min-lovelace", "max-lovelace", "onUpdate"])
                                ])
                            ], 32)),
                        (_ctx.estRewards)
                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridSpace, {
                                key: 2,
                                hr: ""
                            }))
                            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                        (_ctx.estRewards)
                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridHeadline, {
                                key: 3,
                                label: _ctx.it('wallet.stakingvault.lock.rewards')
                            }, null, 8, ["label"]))
                            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                        (_ctx.estRewards)
                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", SVLockvue_type_template_id_49fb55a2_ts_true_hoisted_14, [
                                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SVLockvue_type_template_id_49fb55a2_ts_true_hoisted_15, [
                                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SVLockvue_type_template_id_49fb55a2_ts_true_hoisted_16, [
                                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SVLockvue_type_template_id_49fb55a2_ts_true_hoisted_17, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('wallet.stakingvault.lock.refpool.label')), 1),
                                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_FormattedAmount, {
                                            amount: _ctx.estRewards?.refPoolRewards,
                                            "balance-always-visible": "",
                                            "text-c-s-s": "flex-nowrap inline"
                                        }, null, 8, ["amount"]),
                                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SVLockvue_type_template_id_49fb55a2_ts_true_hoisted_18, [
                                            (0,runtime_core_esm_bundler/* createTextVNode */.Uk)(" ("),
                                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_FormattedAmount, {
                                                amount: _ctx.estRewards?.refPoolROS,
                                                percent: true,
                                                "whole-c-s-s": "",
                                                "fraction-c-s-s": "",
                                                decimals: 2,
                                                "text-c-s-s": "mr-1"
                                            }, null, 8, ["amount"]),
                                            (0,runtime_core_esm_bundler/* createTextVNode */.Uk)("ROS) ")
                                        ])
                                    ])
                                ]),
                                SVLockvue_type_template_id_49fb55a2_ts_true_hoisted_19,
                                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SVLockvue_type_template_id_49fb55a2_ts_true_hoisted_20, [
                                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SVLockvue_type_template_id_49fb55a2_ts_true_hoisted_21, [
                                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SVLockvue_type_template_id_49fb55a2_ts_true_hoisted_22, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('wallet.stakingvault.lock.svpool.label')), 1),
                                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_FormattedAmount, {
                                            amount: _ctx.estRewards?.svPoolRewards,
                                            "balance-always-visible": "",
                                            "text-c-s-s": "flex-nowrap inline"
                                        }, null, 8, ["amount"]),
                                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SVLockvue_type_template_id_49fb55a2_ts_true_hoisted_23, [
                                            (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_24, [
                                                (0,runtime_core_esm_bundler/* createTextVNode */.Uk)("("),
                                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_FormattedAmount, {
                                                    amount: _ctx.estRewards?.svPoolROS,
                                                    percent: true,
                                                    "whole-c-s-s": "",
                                                    "fraction-c-s-s": "",
                                                    decimals: 2,
                                                    "text-c-s-s": "mr-1"
                                                }, null, 8, ["amount"]),
                                                (0,runtime_core_esm_bundler/* createTextVNode */.Uk)("ROS),")
                                            ]),
                                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_FormattedAmount, {
                                                amount: _ctx.estRewards?.pctMoreRewards,
                                                percent: true,
                                                "whole-c-s-s": "",
                                                "fraction-c-s-s": "",
                                                decimals: 2,
                                                "text-c-s-s": "mr-1"
                                            }, null, 8, ["amount"]),
                                            _hoisted_25
                                        ])
                                    ])
                                ])
                            ]))
                            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                        (_ctx.estRewards)
                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridButtonPrimary, {
                                key: 5,
                                label: _ctx.it('wallet.stakingvault.lock.button'),
                                disabled: !_ctx.lockAmount,
                                link: _ctx.onLockAda,
                                class: "col-start-7 col-span-6 sm:col-start-9 sm:col-span-4"
                            }, null, 8, ["label", "disabled", "link"]))
                            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                        (_ctx.estRewards && _ctx.allMezList.length > 0)
                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_26, [
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, { hr: "" }),
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                                    label: _ctx.it('wallet.stakingvault.lock.mez.select')
                                }, null, 8, ["label"]),
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                                    text: _ctx.it('wallet.stakingvault.lock.mez.info')
                                }, null, 8, ["text"]),
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, { hr: "" }),
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridTokenList, {
                                    "network-id": _ctx.account.network,
                                    "wallet-id": _ctx.wallet.id,
                                    "token-list": _ctx.allMezList,
                                    "token-selected-list": _ctx.selectedMezList,
                                    "send-enabled": true,
                                    onAddToken: _cache[2] || (_cache[2] = ($event) => (_ctx.onTokenUpdateEvent('add', $event))),
                                    onDelToken: _cache[3] || (_cache[3] = ($event) => (_ctx.onTokenUpdateEvent('del', $event))),
                                    onTokenReset: _cache[4] || (_cache[4] = () => { })
                                }, null, 8, ["network-id", "wallet-id", "token-list", "token-selected-list"])
                            ]))
                            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                    ]))
                    : ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridSteps, {
                        key: 3,
                        onBack: _ctx.goBack,
                        steps: _ctx.optionsSteps,
                        currentStep: _ctx.currentStep,
                        "small-c-s-s": "pr-20 xs:pr-20 lg:pr-24"
                    }, {
                        step0: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_SendConfirm, {
                                "text-id": "wallet.send.step.confirm",
                                wallet: _ctx.wallet,
                                account: _ctx.account,
                                "unsigned-tx": _ctx.unsignedTx,
                                "is-lock-tx": "",
                                onSubmit: _ctx.gotoNext
                            }, {
                                btnBack: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonSecondary, {
                                        label: _ctx.it('common.label.cancel'),
                                        link: _ctx.goBack,
                                        class: "col-start-0 col-span-6 sm:col-span-3 lg:col-start-0 lg:col-span-3"
                                    }, null, 8, ["label", "link"])
                                ]),
                                _: 1
                            }, 8, ["wallet", "account", "unsigned-tx", "onSubmit"])
                        ]),
                        step1: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_SendSubmit, {
                                onError: _ctx.onSubmitError,
                                onSending: _ctx.onTxSending,
                                onPending: _ctx.onTxPending,
                                onConfirmed: _ctx.onTxConfirmed,
                                "text-id": "wallet.send.step.submit"
                            }, {
                                btnBack: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                                    (_ctx.hasSubmitError)
                                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridButtonSecondary, {
                                            key: 0,
                                            label: _ctx.it('common.label.retry'),
                                            link: _ctx.goBack,
                                            class: "col-start-0 col-span-6 lg:col-start-0 lg:col-span-3 mt-4"
                                        }, null, 8, ["label", "link"]))
                                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                                ]),
                                _: 1
                            }, 8, ["onError", "onSending", "onPending", "onConfirmed"])
                        ]),
                        _: 1
                    }, 8, ["onBack", "steps", "currentStep"]))
            ]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
    ], 64));
}

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/stakingvault/SVLock.vue?vue&type=template&id=49fb55a2&ts=true

// EXTERNAL MODULE: ./src/ext/worker.api.ts
var worker_api = __webpack_require__(45855);
// EXTERNAL MODULE: ../ccw-lib2/core/IToken.ts
var IToken = __webpack_require__(82798);
// EXTERNAL MODULE: ../ccw-lib2/core/IStakeAddressInfo.ts
var IStakeAddressInfo = __webpack_require__(40056);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/OwnedKeyLib.ts
var OwnedKeyLib = __webpack_require__(38562);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/tx/TxBasicUtils.ts
var TxBasicUtils = __webpack_require__(31837);
// EXTERNAL MODULE: ./src/lib/utils/AccountUTxOLists.ts
var AccountUTxOLists = __webpack_require__(97083);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/csl/CSLFreeUtils.ts + 1 modules
var CSLFreeUtils = __webpack_require__(40177);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/stakingvault/SVLock.vue?vue&type=script&lang=ts

;




































/* harmony default export */ const SVLockvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'SVLock',
    components: {
        SVCreateAccount: SVCreateAccount,
        SVCalc: SVCalc,
        GridHeadline: GridHeadline/* default */.Z,
        GridText: GridText/* default */.Z,
        GridTextArea: GridTextArea/* default */.Z,
        GridToggle: GridToggle/* default */.Z,
        GridSpace: GridSpace/* default */.Z,
        GridSteps: GridSteps/* default */.Z,
        AdaInput: AdaInput/* default */.Z,
        FormattedAmount: FormattedAmount/* default */.Z,
        GridButtonPrimary: GridButtonPrimary/* default */.Z,
        GridButtonSecondary: GridButtonSecondary/* default */.Z,
        SendConfirm: SendConfirm/* default */.Z,
        SendSubmit: SendSubmit/* default */.Z,
        GridTokenList: GridTokenList/* default */.Z
    },
    props: {
        account: { type: Object, required: true },
        wallet: { type: Object, required: true }
    },
    setup(props) {
        const { it } = (0,useTranslation/* useTranslation */.$)();
        const { gotoWalletPage } = (0,useNavigation/* useNavigation */.HJ)();
        const $q = (0,use_quasar/* default */.Z)();
        const { chainTip } = (0,useChainTip/* useChainTip */.K)();
        const { resetBuildTx, setBuiltTx, setTxBody, setMetadata, setKeyList, setWitnessSet, getBuildStatus } = (0,useBuildTx_v3/* useBuildTxV3 */.b)();
        const { getAssetInfo } = (0,useTokenLib_v2/* useTokenLibV2 */.P)();
        const { formatDatetime } = (0,useFormatter/* useFormatter */.G)();
        const networkId = props.account.network;
        const numEpochsToLock = (0,reactivity_esm_bundler/* ref */.iH)(18);
        const lockAmount = (0,reactivity_esm_bundler/* ref */.iH)('');
        const allMezList = (0,reactivity_esm_bundler/* ref */.iH)([]);
        const selectedMezList = (0,reactivity_esm_bundler/* ref */.iH)([]);
        const selectedMezBoost = (0,reactivity_esm_bundler/* ref */.iH)(0);
        const estRewards = (0,reactivity_esm_bundler/* ref */.iH)(null);
        const calcEpoch = (0,ChainLib/* getCalculatedEpoch */.uJ)(networkId);
        const calcSlotInEpoch = (0,ChainLib/* getCalculatedEpochSlot */.dK)(networkId);
        const calcSlotsInEpoch = networkId === 'guild' ? 3600 : 432000;
        const calcPercent = calcSlotInEpoch / calcSlotsInEpoch;
        const unlockDate = (0,reactivity_esm_bundler/* ref */.iH)('');
        const isValidNetwork = networkId === 'mainnet' || networkId === 'guild';
        const isValidStartSlot = (networkId === 'guild') ? (chainTip.epochSlot > (2 * 60)) : (chainTip.epochSlot > (3600 * 4));
        const isValidEpochTime = (0,runtime_core_esm_bundler/* computed */.Fl)(() => isValidNetwork && isValidStartSlot && calcPercent <= 0.9666 && (calcSlotInEpoch - chainTip.epochSlot < 600));
        function onLockPeriodChange(event) {
            numEpochsToLock.value = event ? Number(event.target.options[event.target.options.selectedIndex].value) : numEpochsToLock.value;
            const unlockSlot = (0,ChainLib/* getEpochStart */.iT)(networkId, calcEpoch + numEpochsToLock.value);
            unlockDate.value = formatDatetime(unlockSlot.timestamp);
            if (!BigMathLib.isZero(getLockAmountInAda())) {
                calculateEstRewards();
            }
        }
        function onAdaInput(amount) {
            lockAmount.value = amount;
        }
        const getLockAmountInAda = () => lockAmount.value && lockAmount.value.length > 0 ? lockAmount.value : '0';
        const getLockAmountInLovelace = () => BigMathLib.multiply(getLockAmountInAda(), 1000000);
        function calculateEstRewards() {
            estRewards.value = (0,TimeLockUtils/* calculateRewardsAndROS */.If)(networkId, getLockAmountInLovelace(), numEpochsToLock.value);
            if (selectedMezBoost.value > 0) {
                const rewards = (0,TimeLockUtils/* getMezBoost */.b5)(estRewards.value.svPoolRewards, estRewards.value.svPoolROS, estRewards.value.pctMoreRewards, selectedMezBoost.value);
                estRewards.value.svPoolRewards = rewards.rewards;
                estRewards.value.svPoolROS = rewards.ros;
                estRewards.value.pctMoreRewards = rewards.pctMoreRewards;
            }
        }
        onLockPeriodChange(null);
        let tamount = -1;
        (0,runtime_core_esm_bundler/* watch */.YP)(lockAmount, () => {
            clearTimeout(tamount);
            if (!BigMathLib.isZero(getLockAmountInLovelace())) {
                tamount = setTimeout(() => {
                    calculateEstRewards();
                }, 300);
            }
            else {
                estRewards.value = null;
            }
        });
        const hasSubmitError = (0,runtime_core_esm_bundler/* computed */.Fl)(() => (props.account ? (getBuildStatus(props.account.pub) === useBuildTx_v3/* IBuildStatus.error */.k.error) : null));
        const currentStep = (0,reactivity_esm_bundler/* ref */.iH)(0);
        const optionsSteps = (0,reactivity_esm_bundler/* reactive */.qj)([
            { id: 'confirm', label: it('wallet.stakingvault.steps.stepper.confirm') },
            { id: 'submit', label: it('wallet.stakingvault.steps.stepper.submit') }
        ]);
        const unsignedTx = (0,reactivity_esm_bundler/* ref */.iH)(null);
        const svAccount = (0,reactivity_esm_bundler/* ref */.iH)((0,TimeLockUtils/* getSVAccount */.cM)(props.wallet));
        (0,runtime_core_esm_bundler/* watch */.YP)(() => props.wallet.accounts, () => { svAccount.value = (0,TimeLockUtils/* getSVAccount */.cM)(props.wallet); });
        const confirmAccount = (0,reactivity_esm_bundler/* ref */.iH)(null);
        const createAccCounter = (0,reactivity_esm_bundler/* ref */.iH)(0);
        function onStakeVaultAccountAdded() {
            svAccount.value = (0,TimeLockUtils/* getSVAccount */.cM)(props.wallet);
            // SV account added but might take a moment before its available, check for 5s, then abort with error
            if (!svAccount.value) {
                if (createAccCounter.value > 50) {
                    $q.notify({
                        type: 'negative',
                        message: it('wallet.stakingvault.error.lockaccount'),
                        position: 'top',
                        timeout: 6000
                    });
                    createAccCounter.value = 0;
                    return; // stop recursion
                }
                createAccCounter.value++;
                setTimeout(() => { onStakeVaultAccountAdded(); }, 100);
            }
        }
        async function onLockAda() {
            unsignedTx.value = null;
            const lovelace = getLockAmountInLovelace();
            if (BigMathLib.compare(lovelace, '<', TimeLockConstants/* svMinLockAmount */.WF)) {
                return;
            }
            if (BigMathLib.compare(lovelace, '>', TimeLockConstants/* svMaxLockAmount */.my)) {
                return;
            }
            const account = props.account;
            const wallet = props.wallet;
            if (!wallet || !account) {
                console.error("Active wallet/account not set.", wallet, account);
                return;
            }
            const { changeAddrBech32, autoWithdrawalEnabled, tokenFragmentationBundleSize } = (0,AppWalletLib/* getWalletSettings */.Ml)(wallet, account);
            const forceWithdrawal = false;
            const accUtxoList = await (0,AccountUTxOLists/* getAccountFilteredUtxoList */.q1)(account, wallet);
            if (!changeAddrBech32) {
                console.error("Unable to get change address for wallet.");
                return;
            }
            try {
                $q.loading.show({
                    message: it('wallet.stakingvault.building'),
                });
                const address = (0,TxBasicUtils/* getDonationAddress */.V9)(account.network);
                // balance the lock transaction locally first. Select the input utxos, and send only those utxos.
                const tokenList = (0,IToken/* createITokenList */.GB)(selectedMezList.value.map(mez => mez.token));
                const stakeInfoList = (0,IStakeAddressInfo/* createTrimmedIStakeAddressInfoList */.XZ)(account.base.stake);
                const tmpUtxoList = await (0,TxLib_wip/* getUtxosForAmount */.dh)(account.network, accUtxoList, stakeInfoList, account.keys, lovelace, tokenList, address, autoWithdrawalEnabled, forceWithdrawal, tokenFragmentationBundleSize);
                const url = '/' + networkId + '/v1/sv/create';
                const res = await worker_api/* api.post */.h.post(url, {
                    accPubHD: account.pub,
                    accIndex: account.index,
                    accUtxoListHD: tmpUtxoList,
                    accStakeHD: stakeInfoList,
                    accChangeHD: changeAddrBech32,
                    accPubSV: svAccount.value.pub,
                    lockAmount: lovelace,
                    numEpochsToLock: numEpochsToLock.value,
                    mezTokenList: tokenList,
                    autoWithdrawalEnabled: autoWithdrawalEnabled,
                    forceWithdrawal: forceWithdrawal,
                    tokenFragmentationBundleSize: tokenFragmentationBundleSize
                }).catch((err) => {
                    throw new Error(err?.response ? JSON.parse(err?.response).data
                        ?? (JSON.parse(err?.response).msg
                            ?? 'Unknown API error')
                        : 'API Error');
                });
                if (!res?.data?.serializedTx) {
                    throw new Error(it('wallet.stakingvault.error.create'));
                }
                prepareTx(account, res.data.serializedTx);
            }
            catch (e) {
                $q.notify({
                    type: 'negative',
                    message: (e?.message ?? 'an unknown error occurred'),
                    position: 'top',
                    timeout: 6000
                });
                console.error('onLockAda error:', e?.message ?? e);
            }
            $q.loading.hide();
        }
        const ownedKeyList = [];
        async function prepareTx(account, txCbor) {
            if (txCbor) {
                let convertedTx;
                const accountPubKey = account.pub;
                resetBuildTx(accountPubKey);
                try {
                    const free = [];
                    const cslTx = (0,CSLFreeUtils/* getCSLTransaction */.ue)(txCbor, free);
                    convertedTx = await (0,TxParser/* convertTxToITx */.F4)(account, cslTx, txCbor, ExtApiLib/* loadTxDetailsList */.LG);
                    setTxBody(accountPubKey, cslTx.body());
                    setMetadata(accountPubKey, cslTx.auxiliary_data() ?? null);
                    setWitnessSet(accountPubKey, cslTx.witness_set());
                    (0,CSLFreeUtils/* freeCSLObjects */.pC)(free);
                }
                catch (e) {
                    // Should not be a TransactionBody as CIP-30 declares that a Transaction CBOR should be provided, but check anyway.
                    // If tx body deserialization also fails, thrown error is to be caught in calling component
                    throw new Error('Transaction could not be build.');
                }
                if (convertedTx.canOnlySignPartially) {
                    throw new Error('This transaction cannot be signed completely by this wallet.');
                }
                unsignedTx.value = convertedTx.tx;
                (0,OwnedKeyLib/* addTxKeys */.yS)(convertedTx.ownedKeyList, ownedKeyList);
                setBuiltTx(accountPubKey, convertedTx.tx);
                setKeyList(accountPubKey, convertedTx.ownedKeyList);
            }
            else {
                unsignedTx.value = null;
            }
        }
        function goBack() {
            if (currentStep.value === 0) {
                unsignedTx.value = null;
            }
            if (currentStep.value === 1) {
                currentStep.value = 0;
            }
        }
        function gotoNext() {
            if (!svAccount.value || !props.account) {
                console.error("Active wallet/account or Staking Vault account not set.", svAccount.value, props.account);
                return;
            }
            if (currentStep.value === 0) {
                currentStep.value = 1;
            }
        }
        function onSubmitError() { console.error('submit error!!'); }
        function onTxSending() { }
        function onTxPending() {
            gotoWalletPage('Transactions', 'pending');
        }
        function onTxConfirmed() { }
        async function theMesmerizerCheck(tokens) {
            if (!props.account) {
                return { tokens: [], boost: 0 };
            }
            let boost = 0;
            const mezList = [];
            for (const token of tokens) {
                if (token.policy === TimeLockConstants/* policyMesmerizer */.r8) {
                    const tokenData = await getAssetInfo(props.account.network, token);
                    const metaBoost = tokenData ? tokenData.mintingTxMetadata.find(t => 'boost' in t.json)?.json.boost : null;
                    if (metaBoost) {
                        mezList.push(token);
                        boost += parseFloat(metaBoost.slice(0, -1));
                    }
                }
            }
            return { tokens: mezList, boost };
        }
        async function onTokenUpdateEvent(type, e) {
            const mezLeft = 2 - selectedMezList.value.length;
            switch (type) {
                case 'add':
                    if (mezLeft > 0) {
                        Array.isArray(e) ? selectedMezList.value.push(...e.slice(0, mezLeft)) : selectedMezList.value.push(e);
                    }
                    if (Array.isArray(e) ? e.length > mezLeft : mezLeft === 0) {
                        $q.notify({
                            color: 'primary',
                            textColor: 'white',
                            message: it('wallet.stakingvault.lock.mez.notify'),
                            position: 'top-left'
                        });
                    }
                    break;
                case 'del':
                    if (!e) {
                        selectedMezList.value.splice(0);
                    }
                    else {
                        const index = selectedMezList.value.findIndex(t => t.token.policy === e.policy && t.token.name === e.name);
                        if (index >= 0) {
                            selectedMezList.value.splice(index, 1);
                        }
                    }
                    break;
                default: throw new Error('Error: onTokenUpdateEvent: unknown comparison.');
            }
            selectedMezBoost.value = (await theMesmerizerCheck(selectedMezList.value.map(m => m.token))).boost;
            if (!BigMathLib.isZero(getLockAmountInAda())) {
                calculateEstRewards();
            }
        }
        (0,runtime_core_esm_bundler/* onMounted */.bv)(async () => {
            const mez = await theMesmerizerCheck(props.account.balance.tokenBalance ?? []);
            allMezList.value = mez.tokens;
        });
        const validLockPeriods = [];
        for (let i = TimeLockConstants/* svMinLockEpochs */.sr; i <= TimeLockConstants/* svMaxLockEpochs */.QT; i++) {
            validLockPeriods.push({
                // TODO: What normal day count to show here. Maybe calculate it already?
                label: i + ' epochs ',
                lockPeriod: i
            });
        }
        const faqAccepted = (0,reactivity_esm_bundler/* ref */.iH)(svAccount.value !== null);
        return {
            it,
            confirmAccount,
            svAccount,
            faqAccepted,
            lockAmount,
            numEpochsToLock,
            estRewards,
            allMezList,
            selectedMezList,
            selectedMezBoost,
            isValidNetwork,
            isValidEpochTime,
            validLockPeriods,
            svMinLockAmount: TimeLockConstants/* svMinLockAmount */.WF,
            svMaxLockAmount: TimeLockConstants/* svMaxLockAmount */.my,
            policyMesmerizer: TimeLockConstants/* policyMesmerizer */.r8,
            unsignedTx,
            hasSubmitError,
            optionsSteps,
            currentStep,
            onStakeVaultAccountAdded,
            onLockPeriodChange,
            onAdaInput,
            onLockAda,
            onTokenUpdateEvent,
            getMezBoost: TimeLockUtils/* getMezBoost */.b5,
            onSubmitError,
            onTxSending,
            onTxPending,
            onTxConfirmed,
            goBack,
            gotoNext,
            unlockDate
        };
    }
}));

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/stakingvault/SVLock.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/stakingvault/SVLock.vue




;
const SVLock_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(SVLockvue_type_script_lang_ts, [['render',SVLockvue_type_template_id_49fb55a2_ts_true_render]])

/* harmony default export */ const SVLock = (SVLock_exports_);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/stakingvault/SVFAQ.vue?vue&type=template&id=fd32b43e&ts=true

const SVFAQvue_type_template_id_fd32b43e_ts_true_hoisted_1 = { class: "cc-grid" };
const SVFAQvue_type_template_id_fd32b43e_ts_true_hoisted_2 = { class: "col-span-12 grid grid-cols-12 cc-gap" };
const SVFAQvue_type_template_id_fd32b43e_ts_true_hoisted_3 = { class: "col-span-12 sm:col-span-12 flex flex-col items-start justify-start space-y-1" };
const SVFAQvue_type_template_id_fd32b43e_ts_true_hoisted_4 = { class: "col-span-12 sm:col-span-6 flex flex-col items-start justify-start space-y-1" };
const SVFAQvue_type_template_id_fd32b43e_ts_true_hoisted_5 = { class: "col-span-12 sm:col-span-6 flex flex-col items-start justify-start space-y-1" };
const SVFAQvue_type_template_id_fd32b43e_ts_true_hoisted_6 = { class: "col-span-12 sm:col-span-6 flex flex-col items-start justify-start space-y-1" };
const SVFAQvue_type_template_id_fd32b43e_ts_true_hoisted_7 = { class: "col-span-12 sm:col-span-6 flex flex-col items-start justify-start space-y-1" };
const SVFAQvue_type_template_id_fd32b43e_ts_true_hoisted_8 = { class: "col-span-12 sm:col-span-6 flex flex-col items-start justify-start space-y-1" };
const SVFAQvue_type_template_id_fd32b43e_ts_true_hoisted_9 = { class: "col-span-12 sm:col-span-6 flex flex-col items-start justify-start space-y-1" };
const SVFAQvue_type_template_id_fd32b43e_ts_true_hoisted_10 = { class: "col-span-12 sm:col-span-6 flex flex-col items-start justify-start space-y-1" };
const SVFAQvue_type_template_id_fd32b43e_ts_true_hoisted_11 = { class: "ml-2 mt-12 mb-2 col-span-12 sm:col-span-6 cc-none sm:flex flex-row flex-nowrap justify-start whitespace-pre-wrap font-mono" };
const SVFAQvue_type_template_id_fd32b43e_ts_true_hoisted_12 = { class: "col-span-12 sm:col-span-12 flex flex-col items-start justify-start space-y-1" };
const SVFAQvue_type_template_id_fd32b43e_ts_true_hoisted_13 = { class: "col-span-12 sm:col-span-6 flex flex-col items-start justify-start space-y-1" };
const SVFAQvue_type_template_id_fd32b43e_ts_true_hoisted_14 = { class: "col-span-12 sm:col-span-6 flex flex-col items-start justify-start space-y-1" };
const SVFAQvue_type_template_id_fd32b43e_ts_true_hoisted_15 = { class: "col-span-12 sm:col-span-6 flex flex-col items-start justify-start space-y-1" };
const SVFAQvue_type_template_id_fd32b43e_ts_true_hoisted_16 = { class: "col-span-12 sm:col-span-6 flex flex-col items-start justify-start space-y-1" };
function SVFAQvue_type_template_id_fd32b43e_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridHeadline = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridHeadline");
    const _component_GridText = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridText");
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", SVFAQvue_type_template_id_fd32b43e_ts_true_hoisted_1, [
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SVFAQvue_type_template_id_fd32b43e_ts_true_hoisted_2, [
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                label: _ctx.it('wallet.stakingvault.faq.headline'),
                class: "cc-text-lg cc-text-extra-bold italic underline"
            }, null, 8, ["label"]),
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                text: _ctx.it('wallet.stakingvault.faq.caption'),
                class: "cc-sv-faq-text"
            }, null, 8, ["text"])
        ]),
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SVFAQvue_type_template_id_fd32b43e_ts_true_hoisted_3, [
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                label: _ctx.it('wallet.stakingvault.faq.faq11.headline'),
                "do-capitalize": false,
                class: "cc-sv-faq-headline"
            }, null, 8, ["label"]),
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                text: _ctx.it('wallet.stakingvault.faq.faq11.text'),
                class: "cc-banner-blue p-2"
            }, null, 8, ["text"])
        ]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, {
            hr: "",
            class: "mt-4 mb-2"
        }),
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SVFAQvue_type_template_id_fd32b43e_ts_true_hoisted_4, [
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                label: _ctx.it('wallet.stakingvault.faq.faq0.headline'),
                "do-capitalize": false,
                class: "cc-sv-faq-headline"
            }, null, 8, ["label"]),
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                text: _ctx.it('wallet.stakingvault.faq.faq0.text'),
                class: "cc-sv-faq-text"
            }, null, 8, ["text"])
        ]),
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SVFAQvue_type_template_id_fd32b43e_ts_true_hoisted_5, [
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                label: _ctx.it('wallet.stakingvault.faq.faq1.headline'),
                "do-capitalize": false,
                class: "cc-sv-faq-headline"
            }, null, 8, ["label"]),
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                text: _ctx.it('wallet.stakingvault.faq.faq1.text'),
                class: "cc-sv-faq-text"
            }, null, 8, ["text"])
        ]),
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SVFAQvue_type_template_id_fd32b43e_ts_true_hoisted_6, [
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                label: _ctx.it('wallet.stakingvault.faq.faq2.headline'),
                "do-capitalize": false,
                class: "cc-sv-faq-headline"
            }, null, 8, ["label"]),
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                text: _ctx.it('wallet.stakingvault.faq.faq2.text'),
                class: "cc-sv-faq-text"
            }, null, 8, ["text"])
        ]),
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SVFAQvue_type_template_id_fd32b43e_ts_true_hoisted_7, [
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                label: _ctx.it('wallet.stakingvault.faq.faq3.headline'),
                "do-capitalize": false,
                class: "cc-sv-faq-headline"
            }, null, 8, ["label"]),
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                text: _ctx.it('wallet.stakingvault.faq.faq3.text'),
                class: "cc-sv-faq-text"
            }, null, 8, ["text"])
        ]),
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SVFAQvue_type_template_id_fd32b43e_ts_true_hoisted_8, [
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                label: _ctx.it('wallet.stakingvault.faq.faq4.headline'),
                "do-capitalize": false,
                class: "cc-sv-faq-headline"
            }, null, 8, ["label"]),
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                text: _ctx.it('wallet.stakingvault.faq.faq4.text'),
                class: "cc-sv-faq-text"
            }, null, 8, ["text"])
        ]),
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SVFAQvue_type_template_id_fd32b43e_ts_true_hoisted_9, [
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                label: _ctx.it('wallet.stakingvault.faq.faq5.headline'),
                "do-capitalize": false,
                class: "cc-sv-faq-headline"
            }, null, 8, ["label"]),
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                text: _ctx.it('wallet.stakingvault.faq.faq5.text'),
                class: "cc-sv-faq-text"
            }, null, 8, ["text"])
        ]),
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SVFAQvue_type_template_id_fd32b43e_ts_true_hoisted_10, [
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                label: _ctx.it('wallet.stakingvault.faq.faq6.headline'),
                "do-capitalize": false,
                class: "cc-sv-faq-headline"
            }, null, 8, ["label"]),
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                text: _ctx.it('wallet.stakingvault.faq.faq6.text'),
                class: "cc-sv-faq-text"
            }, null, 8, ["text"])
        ]),
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SVFAQvue_type_template_id_fd32b43e_ts_true_hoisted_11, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('wallet.stakingvault.faq.faq6.text_1')), 1),
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SVFAQvue_type_template_id_fd32b43e_ts_true_hoisted_12, [
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                text: _ctx.it('wallet.stakingvault.faq.faq6.text_1_1'),
                class: "ml-2 mb-2 w-full col-span-12 sm:col-span-6 font-mono flex sm:hidden"
            }, null, 8, ["text"]),
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                text: _ctx.it('wallet.stakingvault.faq.faq6.text_2'),
                class: "cc-sv-faq-text w-full"
            }, null, 8, ["text"])
        ]),
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SVFAQvue_type_template_id_fd32b43e_ts_true_hoisted_13, [
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                label: _ctx.it('wallet.stakingvault.faq.faq7.headline'),
                "do-capitalize": false,
                class: "cc-sv-faq-headline"
            }, null, 8, ["label"]),
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                text: _ctx.it('wallet.stakingvault.faq.faq7.text'),
                class: "cc-sv-faq-text"
            }, null, 8, ["text"])
        ]),
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SVFAQvue_type_template_id_fd32b43e_ts_true_hoisted_14, [
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                label: _ctx.it('wallet.stakingvault.faq.faq8.headline'),
                "do-capitalize": false,
                class: "cc-sv-faq-headline"
            }, null, 8, ["label"]),
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                text: _ctx.it('wallet.stakingvault.faq.faq8.text'),
                class: "cc-sv-faq-text"
            }, null, 8, ["text"])
        ]),
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SVFAQvue_type_template_id_fd32b43e_ts_true_hoisted_15, [
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                label: _ctx.it('wallet.stakingvault.faq.faq9.headline'),
                "do-capitalize": false,
                class: "cc-sv-faq-headline"
            }, null, 8, ["label"]),
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                text: _ctx.it('wallet.stakingvault.faq.faq9.text'),
                class: "cc-sv-faq-text"
            }, null, 8, ["text"])
        ]),
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SVFAQvue_type_template_id_fd32b43e_ts_true_hoisted_16, [
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                label: _ctx.it('wallet.stakingvault.faq.faq10.headline'),
                "do-capitalize": false,
                class: "cc-sv-faq-headline"
            }, null, 8, ["label"]),
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                text: _ctx.it('wallet.stakingvault.faq.faq10.text'),
                class: "cc-sv-faq-text"
            }, null, 8, ["text"])
        ])
    ]));
}

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/stakingvault/SVFAQ.vue?vue&type=template&id=fd32b43e&ts=true

;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/stakingvault/SVFAQ.vue?vue&type=script&lang=ts





/* harmony default export */ const SVFAQvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'SVFAQ',
    components: {
        GridHeadline: GridHeadline/* default */.Z,
        GridText: GridText/* default */.Z,
        GridSpace: GridSpace/* default */.Z,
    },
    setup() {
        const { it } = (0,useTranslation/* useTranslation */.$)();
        return {
            it
        };
    }
}));

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/stakingvault/SVFAQ.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/stakingvault/SVFAQ.vue




;
const SVFAQ_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(SVFAQvue_type_script_lang_ts, [['render',SVFAQvue_type_template_id_fd32b43e_ts_true_render]])

/* harmony default export */ const SVFAQ = (SVFAQ_exports_);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridTabs.vue + 4 modules
var GridTabs = __webpack_require__(49510);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/StakingVault.vue?vue&type=script&lang=ts







/* harmony default export */ const StakingVaultvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'StakingVault',
    components: {
        GridTabs: GridTabs/* default */.Z,
        SVSummary: SVSummary,
        SVLock: SVLock,
        SVFAQ: SVFAQ,
    },
    setup() {
        const { t } = (0,useTranslation/* useTranslation */.$)();
        const { activeAccount, activeWalletData } = (0,useActiveWallet/* useActiveWallet */.r)();
        const optionsTabs = (0,reactivity_esm_bundler/* reactive */.qj)([
            { id: 'overview', label: 'Overview', index: 0 },
            // { id: 'lock',     label: 'Lock ADA' },
            { id: 'faq', label: 'FAQ', index: 1 }
        ]);
        return {
            t,
            activeAccount,
            activeWalletData,
            optionsTabs
        };
    }
}));

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/StakingVault.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/StakingVault.vue




;
const StakingVault_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(StakingVaultvue_type_script_lang_ts, [['render',render]])

/* harmony default export */ const StakingVault = (StakingVault_exports_);

/***/ })

}]);
//# sourceMappingURL=4437.js.map