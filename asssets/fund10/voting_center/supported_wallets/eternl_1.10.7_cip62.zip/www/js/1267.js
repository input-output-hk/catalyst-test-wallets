"use strict";
(this["webpackChunkccw_frontend"] = this["webpackChunkccw_frontend"] || []).push([[1267],{

/***/ 71267:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "_downloadJSON": () => (/* binding */ _downloadJSON),
/* harmony export */   "_downloadPNG": () => (/* binding */ _downloadPNG),
/* harmony export */   "_downloadText": () => (/* binding */ _downloadText)
/* harmony export */ });
/* harmony import */ var _capacitor_filesystem__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(21010);
/* harmony import */ var _capacitor_share__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(27815);


const _downloadJSON = async (dbEntry) => {
    if (!dbEntry) {
        return false;
    }
    const fileName = 'eternl-' + dbEntry.name.toLowerCase().replace(/\s/g, '-') + '-' + dbEntry.id.toLowerCase().replace(/\s/g, '-') + '.json';
    const result = await _capacitor_filesystem__WEBPACK_IMPORTED_MODULE_0__/* .Filesystem.writeFile */ .fy.writeFile({
        path: fileName,
        data: JSON.stringify(dbEntry),
        directory: _capacitor_filesystem__WEBPACK_IMPORTED_MODULE_0__/* .Directory.Cache */ .tP.Cache,
        encoding: _capacitor_filesystem__WEBPACK_IMPORTED_MODULE_0__/* .Encoding.UTF8 */ .ez.UTF8
    });
    await _capacitor_share__WEBPACK_IMPORTED_MODULE_1__/* .Share.share */ .m.share({
        dialogTitle: 'Download wallet backup',
        title: fileName,
        url: result.uri,
    });
    return true;
};
const _downloadText = async (text, fileName) => {
    if (!text) {
        return false;
    }
    const result = await _capacitor_filesystem__WEBPACK_IMPORTED_MODULE_0__/* .Filesystem.writeFile */ .fy.writeFile({
        path: fileName,
        data: text,
        directory: _capacitor_filesystem__WEBPACK_IMPORTED_MODULE_0__/* .Directory.Cache */ .tP.Cache,
        encoding: _capacitor_filesystem__WEBPACK_IMPORTED_MODULE_0__/* .Encoding.UTF8 */ .ez.UTF8
    });
    await _capacitor_share__WEBPACK_IMPORTED_MODULE_1__/* .Share.share */ .m.share({
        dialogTitle: 'Store text file',
        title: fileName,
        url: result.uri,
    });
    return true;
};
const _downloadPNG = async (imgDataURL, fileName) => {
    if (!imgDataURL) {
        return false;
    }
    const result = await _capacitor_filesystem__WEBPACK_IMPORTED_MODULE_0__/* .Filesystem.writeFile */ .fy.writeFile({
        path: fileName,
        data: imgDataURL,
        directory: _capacitor_filesystem__WEBPACK_IMPORTED_MODULE_0__/* .Directory.Cache */ .tP.Cache
    });
    await _capacitor_share__WEBPACK_IMPORTED_MODULE_1__/* .Share.share */ .m.share({
        dialogTitle: 'Store image file',
        title: fileName,
        url: result.uri,
    });
    return true;
};


/***/ })

}]);
//# sourceMappingURL=1267.js.map