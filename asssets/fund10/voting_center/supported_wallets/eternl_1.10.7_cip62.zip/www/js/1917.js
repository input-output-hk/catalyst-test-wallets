"use strict";
(this["webpackChunkccw_frontend"] = this["webpackChunkccw_frontend"] || []).push([[1917],{

/***/ 42278:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Staking)
});

// EXTERNAL MODULE: ./node_modules/@vue/runtime-core/dist/runtime-core.esm-bundler.js
var runtime_core_esm_bundler = __webpack_require__(83673);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/Staking.vue?vue&type=template&id=784e2f31&ts=true

const _hoisted_1 = { class: "cc-page-wallet cc-text-sz dark:text-cc-gray" };
const _hoisted_2 = /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("div", { class: "cc-none lg:block lg:col-span-3" }, null, -1);
function render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridHeadline = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridHeadline");
    const _component_GridText = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridText");
    const _component_GridStakePoolList = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridStakePoolList");
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    const _component_IconPencil = (0,runtime_core_esm_bundler/* resolveComponent */.up)("IconPencil");
    const _component_GridInput = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridInput");
    const _component_GridTabs = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridTabs");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_1, [
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridTabs, { tabs: _ctx.optionsTabs }, {
            tab0: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                (_ctx.delegatedPoolList.length > 0)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridHeadline, {
                        key: 0,
                        label: _ctx.t('wallet.staking.poollist.delegated.headline')
                    }, null, 8, ["label"]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                (_ctx.delegatedPoolList.length > 0)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridText, {
                        key: 1,
                        text: _ctx.t('wallet.staking.poollist.delegated.caption')
                    }, null, 8, ["text"]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                (_ctx.delegatedPoolList.length > 0)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridStakePoolList, {
                        key: 2,
                        poolList: _ctx.delegatedPoolList,
                        delegatedPoolList: _ctx.delegatedPoolList,
                        dense: "",
                        selected: ""
                    }, null, 8, ["poolList", "delegatedPoolList"]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                (_ctx.delegatedPoolList.length > 0)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridSpace, {
                        key: 3,
                        hr: "",
                        class: "mt-1 mb-1"
                    }))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                    label: _ctx.t('wallet.staking.poollist.headline')
                }, null, 8, ["label"]),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                    text: _ctx.t('wallet.staking.poollist.caption')
                }, null, 8, ["text"]),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, {
                    hr: "",
                    class: "mt-1 mb-1"
                }),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridInput, {
                    class: "col-span-12 sm:col-span-6 mb-1",
                    "input-text": _ctx.searchInput,
                    "onUpdate:input-text": _cache[0] || (_cache[0] = ($event) => ((_ctx.searchInput) = $event)),
                    "input-error": _ctx.searchInputError,
                    "onUpdate:input-error": _cache[1] || (_cache[1] = ($event) => ((_ctx.searchInputError) = $event)),
                    onLostFocus: _ctx.validateSearchInput,
                    onReset: _ctx.resetFilter,
                    label: _ctx.t('wallet.staking.search.label'),
                    "input-hint": _ctx.t('wallet.staking.search.hint'),
                    alwaysShowInfo: false,
                    "input-id": "searchInput",
                    "input-type": "text",
                    autocomplete: "name",
                    inputDisabled: _ctx.searchDisabled,
                    "show-reset": true,
                    "dense-input": ""
                }, {
                    "icon-prepend": (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_IconPencil, { class: "h-5 w-5" })
                    ]),
                    _: 1
                }, 8, ["input-text", "input-error", "onLostFocus", "onReset", "label", "input-hint", "inputDisabled"]),
                _hoisted_2,
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, {
                    hr: "",
                    class: "mb-1"
                }),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridStakePoolList, {
                    poolList: _ctx.showGroupPoolList ? _ctx.groupPoolList : _ctx.filteredPoolList,
                    delegatedPoolList: _ctx.delegatedPoolList,
                    dense: ""
                }, null, 8, ["poolList", "delegatedPoolList"])
            ]),
            tab1: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                (_ctx.delegatedPoolList.length > 0)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridHeadline, {
                        key: 0,
                        label: _ctx.t('wallet.staking.poollist.delegated.headline')
                    }, null, 8, ["label"]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                (_ctx.delegatedPoolList.length > 0)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridText, {
                        key: 1,
                        text: _ctx.t('wallet.staking.poollist.delegated.caption')
                    }, null, 8, ["text"]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                (_ctx.delegatedPoolList.length > 0)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridStakePoolList, {
                        key: 2,
                        poolList: _ctx.delegatedPoolList,
                        delegatedPoolList: _ctx.delegatedPoolList,
                        dense: "",
                        selected: ""
                    }, null, 8, ["poolList", "delegatedPoolList"]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                (_ctx.delegatedPoolList.length > 0)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridSpace, {
                        key: 3,
                        hr: "",
                        class: "mt-1 mb-1"
                    }))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                (!_ctx.isTestnet)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridHeadline, {
                        key: 4,
                        label: _ctx.t('wallet.staking.poollist.featured.headline')
                    }, null, 8, ["label"]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                    text: _ctx.isTestnet ? _ctx.t('wallet.staking.poollist.featured.testnet') : _ctx.t('wallet.staking.poollist.featured.caption')
                }, null, 8, ["text"]),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, {
                    hr: "",
                    class: "mt-1 mb-1"
                }),
                (!_ctx.isTestnet)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridStakePoolList, {
                        key: 5,
                        poolList: _ctx.featuredPoolList,
                        "md-select-enabled": false,
                        delegatedPoolList: _ctx.delegatedPoolList,
                        dense: "",
                        "no-rank": ""
                    }, null, 8, ["poolList", "delegatedPoolList"]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
            ]),
            _: 1
        }, 8, ["tabs"])
    ]));
}

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/Staking.vue?vue&type=template&id=784e2f31&ts=true

// EXTERNAL MODULE: ./node_modules/@vue/reactivity/dist/reactivity.esm-bundler.js
var reactivity_esm_bundler = __webpack_require__(61959);
// EXTERNAL MODULE: ./src/composables/ccw/useNetworkId.ts
var useNetworkId = __webpack_require__(36648);
// EXTERNAL MODULE: ./src/composables/ccw/useTranslation.ts
var useTranslation = __webpack_require__(19376);
// EXTERNAL MODULE: ./src/composables/ccw/store/usePoolAPI.ts
var usePoolAPI = __webpack_require__(8614);
// EXTERNAL MODULE: ./src/composables/ccw/store/useActiveWallet.ts
var useActiveWallet = __webpack_require__(52144);
// EXTERNAL MODULE: ./src/composables/ccw/store/useDelegationHistory.ts
var useDelegationHistory = __webpack_require__(22096);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridHeadline.vue + 3 modules
var GridHeadline = __webpack_require__(63593);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridSpace.vue + 4 modules
var GridSpace = __webpack_require__(14740);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridText.vue + 4 modules
var GridText = __webpack_require__(96834);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridInput.vue + 4 modules
var GridInput = __webpack_require__(27209);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridTabs.vue + 4 modules
var GridTabs = __webpack_require__(49510);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/icons/IconPencil.vue + 4 modules
var IconPencil = __webpack_require__(44814);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/staking/GridStakePoolList.vue + 4 modules
var GridStakePoolList = __webpack_require__(20099);
// EXTERNAL MODULE: ./node_modules/@vue/shared/dist/shared.esm-bundler.js
var shared_esm_bundler = __webpack_require__(62323);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/staking/MDStaking.vue?vue&type=template&id=f97c2950&ts=true

const MDStakingvue_type_template_id_f97c2950_ts_true_hoisted_1 = { class: "col-span-12 flex flex-col flex-nowrap mb-2" };
const MDStakingvue_type_template_id_f97c2950_ts_true_hoisted_2 = { class: "w-full flex flex-row flex-nowrap" };
const _hoisted_3 = /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("span", { class: "font-mono cc-text-semi-bold text-green-700 mr-2" }, "+", -1);
const _hoisted_4 = { class: "text-green-900" };
const _hoisted_5 = { class: "w-full flex flex-row flex-nowrap" };
const _hoisted_6 = /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("span", { class: "font-mono cc-text-semi-bold text-green-700 mr-2" }, "+", -1);
const _hoisted_7 = { class: "text-green-900" };
const _hoisted_8 = { class: "w-full flex flex-row flex-nowrap" };
const _hoisted_9 = /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("span", { class: "font-mono cc-text-semi-bold text-green-700 mr-2" }, "+", -1);
const _hoisted_10 = { class: "text-green-900" };
const _hoisted_11 = { class: "w-full flex flex-row flex-nowrap" };
const _hoisted_12 = /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("span", { class: "font-mono cc-text-semi-bold text-green-700 mr-2" }, "+", -1);
const _hoisted_13 = { class: "text-green-900" };
const _hoisted_14 = { class: "w-full flex flex-row flex-nowrap" };
const _hoisted_15 = /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("span", { class: "font-mono cc-text-semi-bold text-red-800 mr-2" }, "-", -1);
const _hoisted_16 = { class: "text-red-900" };
const _hoisted_17 = { class: "text-gray-600 cc-text-sm sm:cc-text-md cc-text-semi-bold" };
const _hoisted_18 = { class: "text-gray-500 cc-text-sm sm:cc-text-md" };
const _hoisted_19 = { class: "text-blue-700 cc-text-semi-bold cc-text-sz" };
const _hoisted_20 = { class: "italic text-gray-400 cc-text-sz" };
const _hoisted_21 = {
    key: 0,
    class: "text-gray-500 text-md cc-text-semi-bold"
};
const _hoisted_22 = { class: "text-gray-400 cc-text-sm" };
const _hoisted_23 = /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("div", { class: "cc-none xl:block xl:col-span-3" }, null, -1);
const _hoisted_24 = {
    key: 1,
    class: "col-span-12 grid grid-cols-12 cc-gap"
};
const _hoisted_25 = { class: "col-span-12 flex flex-row cc-input-info cc-rounded p-2" };
const _hoisted_26 = { class: "col-span-12 mr-2" };
const _hoisted_27 = {
    key: 0,
    class: "col-span-12 flex flex-row flex-nowrap items-center cc-input-error cc-rounded p-2"
};
function MDStakingvue_type_template_id_f97c2950_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridHeadline = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridHeadline");
    const _component_GridText = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridText");
    const _component_q_item_section = (0,runtime_core_esm_bundler/* resolveComponent */.up)("q-item-section");
    const _component_q_item = (0,runtime_core_esm_bundler/* resolveComponent */.up)("q-item");
    const _component_q_select = (0,runtime_core_esm_bundler/* resolveComponent */.up)("q-select");
    const _component_GridButtonPrimary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonPrimary");
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    const _component_FormattedAmount = (0,runtime_core_esm_bundler/* resolveComponent */.up)("FormattedAmount");
    const _component_IconWarning = (0,runtime_core_esm_bundler/* resolveComponent */.up)("IconWarning");
    const _component_GridStakePoolList = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridStakePoolList");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, [
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
            label: _ctx.t('wallet.staking.md.headline')
        }, null, 8, ["label"]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
            text: _ctx.t('wallet.staking.md.caption')
        }, null, 8, ["text"]),
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", MDStakingvue_type_template_id_f97c2950_ts_true_hoisted_1, [
            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", MDStakingvue_type_template_id_f97c2950_ts_true_hoisted_2, [
                _hoisted_3,
                (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_4, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.staking.md.positive.i1')), 1)
            ]),
            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_5, [
                _hoisted_6,
                (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_7, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.staking.md.positive.i2')), 1)
            ]),
            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_8, [
                _hoisted_9,
                (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_10, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.staking.md.positive.i3')), 1)
            ]),
            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_11, [
                _hoisted_12,
                (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_13, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.staking.md.positive.i4')), 1)
            ]),
            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_14, [
                _hoisted_15,
                (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_16, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.staking.md.negative.i1')), 1)
            ])
        ]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_q_select, {
            modelValue: _ctx.selectedPortfolio,
            "onUpdate:modelValue": [
                _cache[0] || (_cache[0] = ($event) => ((_ctx.selectedPortfolio) = $event)),
                _ctx.onPortfolioChange
            ],
            "use-input": "",
            dense: "",
            "label-slot": "",
            "bottom-slots": "",
            "input-debounce": "0",
            options: _ctx.portfolioOptions,
            "option-value": "name",
            "option-label": "name",
            "input-class": "bg-gray-100 focus:ring-0 cc-text-sm",
            onFilter: _ctx.filterFn,
            class: "col-span-12 sm:col-span-6 sm:mr-4 mb-2"
        }, {
            option: (0,runtime_core_esm_bundler/* withCtx */.w5)((scope) => [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_q_item, (0,shared_esm_bundler/* normalizeProps */.vs)((0,runtime_core_esm_bundler/* guardReactiveProps */.F4)(scope.itemProps)), {
                    default: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_q_item_section, null, {
                            default: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                                (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_17, (0,shared_esm_bundler/* toDisplayString */.zw)(scope.opt.name), 1),
                                (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_18, (0,shared_esm_bundler/* toDisplayString */.zw)(scope.opt.description), 1)
                            ]),
                            _: 2
                        }, 1024)
                    ]),
                    _: 2
                }, 1040)
            ]),
            selected: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_19, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.selectedPortfolio?.name ?? ''), 1)
            ]),
            "no-option": (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_q_item, null, {
                    default: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_q_item_section, null, {
                            default: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                                (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_20, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.staking.md.select.noresult')), 1)
                            ]),
                            _: 1
                        })
                    ]),
                    _: 1
                })
            ]),
            label: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                (_ctx.selectedPortfolio === null)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_21, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.staking.md.select.label')), 1))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
            ]),
            hint: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_22, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.staking.md.select.hint')), 1)
            ]),
            _: 1
        }, 8, ["modelValue", "options", "onUpdate:modelValue", "onFilter"]),
        _hoisted_23,
        (_ctx.multiDelegationList.length > 0)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridButtonPrimary, {
                key: 0,
                label: _ctx.t('wallet.staking.button.md.submit'),
                link: _ctx.onMultiDelegation,
                class: "col-span-12 sm:col-span-6 xl:col-span-3 self-end h-11 mt-2 sm:mt-0 mb-1 px-2",
                disabled: !_ctx.mdValid
            }, null, 8, ["label", "link", "disabled"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (_ctx.selectedPortfolio)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_24, [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, { hr: "" }),
                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_25, [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_26, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.staking.md.ada.total')), 1),
                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_FormattedAmount, {
                        amount: _ctx.mdTotal,
                        "balance-always-visible": ""
                    }, null, 8, ["amount"])
                ]),
                (_ctx.mdFundsLow)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_27, [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_IconWarning, { class: "w-7 flex-none mr-2" }),
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                            text: _ctx.t('wallet.staking.md.error.fundsLow')
                                .replace('###reserved###', _ctx.formatADAString(_ctx.reservedFunds, true, 0))
                                .replace('###base###', _ctx.formatADAString(_ctx.baseLimit, true, 0))
                                .replace('###pool###', _ctx.formatADAString(_ctx.poolAddition, true, 0)),
                            class: "cc-text-sz"
                        }, null, 8, ["text"])
                    ]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, { hr: "" })
            ]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridStakePoolList, {
            ref: "stakePoolListRef",
            onAmountSet: _ctx.onPoolDelegationAmountSet,
            onCloneInput: _ctx.onCloneInput,
            poolList: _ctx.multiDelegationList.map(md => md.pool),
            "md-select-enabled": false,
            "md-selected-pool-list": _ctx.multiDelegationList,
            "md-input-enabled": true,
            delegatedPoolList: _ctx.multiDelegationList.map(md => md.pool),
            dense: ""
        }, null, 8, ["onAmountSet", "onCloneInput", "poolList", "md-selected-pool-list", "delegatedPoolList"])
    ], 64));
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/staking/MDStaking.vue?vue&type=template&id=f97c2950&ts=true

// EXTERNAL MODULE: ./src/composables/ccw/useNavigation.ts
var useNavigation = __webpack_require__(52439);
// EXTERNAL MODULE: ./src/composables/ccw/store/useFormatter.ts
var useFormatter = __webpack_require__(16938);
// EXTERNAL MODULE: ./src/composables/ccw/store/useBuildTx_v3.ts + 1 modules
var useBuildTx_v3 = __webpack_require__(72107);
// EXTERNAL MODULE: ./src/components/ccw/common/FormattedAmount.vue + 3 modules
var FormattedAmount = __webpack_require__(6200);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridButtonPrimary.vue + 3 modules
var GridButtonPrimary = __webpack_require__(12559);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/icons/IconWarning.vue + 4 modules
var IconWarning = __webpack_require__(97515);
// EXTERNAL MODULE: ./src/lib/ExtOfflineDataLib.ts
var ExtOfflineDataLib = __webpack_require__(8387);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/BigMathLib.ts + 1 modules
var BigMathLib = __webpack_require__(99149);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/staking/MDStaking.vue?vue&type=script&lang=ts
















/* harmony default export */ const MDStakingvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'MDStaking',
    components: {
        FormattedAmount: FormattedAmount/* default */.Z,
        GridButtonPrimary: GridButtonPrimary/* default */.Z,
        GridSpace: GridSpace/* default */.Z,
        GridHeadline: GridHeadline/* default */.Z,
        GridText: GridText/* default */.Z,
        IconWarning: IconWarning/* default */.Z,
        GridStakePoolList: GridStakePoolList/* default */.Z
    },
    setup() {
        const { t } = (0,useTranslation/* useTranslation */.$)();
        const { gotoWalletPage } = (0,useNavigation/* useNavigation */.HJ)();
        const { activeWalletData, activeAccount } = (0,useActiveWallet/* useActiveWallet */.r)();
        const {} = (0,useBuildTx_v3/* useBuildTxV3 */.b)();
        const { formatADAString, getDecimalNumber } = (0,useFormatter/* useFormatter */.G)();
        const { getPoolInfo } = (0,usePoolAPI/* usePoolAPI */.b)();
        const stakePoolListRef = (0,reactivity_esm_bundler/* ref */.iH)();
        let savedPortfolios = [];
        (0,runtime_core_esm_bundler/* onBeforeMount */.wF)(async () => {
            if (!activeAccount.value) {
                return;
            }
            const setting = await (0,ExtOfflineDataLib/* loadData */.mu)(activeAccount.value.network, 'poolPortfolio');
            if (setting) {
                savedPortfolios = setting.value.portfolios;
            }
        });
        const multiDelegationList = (0,reactivity_esm_bundler/* ref */.iH)([]);
        const selectedPortfolio = (0,reactivity_esm_bundler/* ref */.iH)(null);
        const portfolioOptions = (0,reactivity_esm_bundler/* ref */.iH)([]);
        const mdTotal = (0,reactivity_esm_bundler/* ref */.iH)('0');
        const decimalNumber = getDecimalNumber();
        const baseLimit = BigMathLib.multiply(10, decimalNumber);
        const poolAddition = BigMathLib.multiply(2, decimalNumber);
        const reservedFunds = (0,runtime_core_esm_bundler/* computed */.Fl)(() => BigMathLib.add(BigMathLib.multiply(selectedPortfolio.value?.pools.length ?? 0, poolAddition), baseLimit));
        const mdFundsLow = (0,runtime_core_esm_bundler/* computed */.Fl)(() => BigMathLib.compare(BigMathLib.add(mdTotal.value, reservedFunds.value), '>', activeAccount.value?.balance.total ?? 0));
        const mdValid = (0,runtime_core_esm_bundler/* computed */.Fl)(() => !mdFundsLow.value && BigMathLib.compare(mdTotal.value, '>', BigMathLib.multiply(5, decimalNumber)));
        function filterFn(val, update) {
            if (val === '') {
                update(() => {
                    portfolioOptions.value = [...savedPortfolios];
                });
                return;
            }
            update(() => {
                const needle = val.toLowerCase();
                portfolioOptions.value = savedPortfolios.filter(v => v.name.toLowerCase().indexOf(needle) > -1);
            });
        }
        let mdtot = -1;
        (0,runtime_core_esm_bundler/* watch */.YP)(multiDelegationList, () => {
            clearTimeout(mdtot);
            mdtot = setTimeout(() => {
                mdTotal.value = '0';
                for (const md of multiDelegationList.value) {
                    if (md.amount.length === 0 || md.amount === '0') {
                        continue;
                    }
                    mdTotal.value = BigMathLib.add(mdTotal.value, md.amount);
                }
            }, 250);
        }, {
            deep: true
        });
        function onPoolDelegationAmountSet(event) {
            const poolMD = multiDelegationList.value.find(pmd => pmd.pool.pb === event.pool.pb);
            if (poolMD) {
                poolMD.amount = event.amount;
            }
            else {
                console.error('onPoolDelegationAmountSet: couldn\'t find pool in list');
            }
        }
        const onCloneInput = (value) => stakePoolListRef.value?.setStakePoolInputs(value);
        function onPortfolioChange(value) {
            multiDelegationList.value.splice(0);
            if (!value)
                return;
            const portfolio = savedPortfolios.find(po => po.name === value.name);
            if (portfolio) {
                for (const pool of portfolio.pools) {
                    const info = getPoolInfo(pool);
                    if (info) {
                        multiDelegationList.value.push({ pool: info, amount: '' });
                    }
                }
            }
        }
        function onMultiDelegation() {
            if (!activeWalletData.value || !activeAccount.value)
                return;
            // setMultiDelegationList(activeAccount.value!.pub, multiDelegationList.value)
            // buildMultiDelegationTx(activeWalletData.value, activeAccount.value)
            //gotoWalletPage('Delegation')
        }
        return {
            t, BML: BigMathLib,
            decimalNumber,
            formatADAString,
            stakePoolListRef,
            multiDelegationList,
            mdValid,
            mdTotal,
            reservedFunds,
            baseLimit,
            poolAddition,
            mdFundsLow,
            portfolioOptions,
            selectedPortfolio,
            filterFn,
            onMultiDelegation,
            onPortfolioChange,
            onPoolDelegationAmountSet,
            onCloneInput
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/staking/MDStaking.vue?vue&type=script&lang=ts
 
// EXTERNAL MODULE: ./node_modules/vue-loader/dist/exportHelper.js
var exportHelper = __webpack_require__(74260);
// EXTERNAL MODULE: ./node_modules/quasar/src/components/select/QSelect.js + 5 modules
var QSelect = __webpack_require__(18877);
// EXTERNAL MODULE: ./node_modules/quasar/src/components/item/QItem.js
var QItem = __webpack_require__(83414);
// EXTERNAL MODULE: ./node_modules/quasar/src/components/item/QItemSection.js
var QItemSection = __webpack_require__(52035);
// EXTERNAL MODULE: ./node_modules/@quasar/app/lib/webpack/runtime.auto-import.js
var runtime_auto_import = __webpack_require__(7518);
var runtime_auto_import_default = /*#__PURE__*/__webpack_require__.n(runtime_auto_import);
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/staking/MDStaking.vue




;
const __exports__ = /*#__PURE__*/(0,exportHelper/* default */.Z)(MDStakingvue_type_script_lang_ts, [['render',MDStakingvue_type_template_id_f97c2950_ts_true_render]])

/* harmony default export */ const MDStaking = (__exports__);
;



runtime_auto_import_default()(MDStakingvue_type_script_lang_ts, 'components', {QSelect: QSelect/* default */.Z,QItem: QItem/* default */.Z,QItemSection: QItemSection/* default */.Z});

// EXTERNAL MODULE: ../ccw-lib2/core/INetwork.ts
var INetwork = __webpack_require__(34234);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/Staking.vue?vue&type=script&lang=ts















/* harmony default export */ const Stakingvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'Staking',
    components: {
        GridTabs: GridTabs/* default */.Z,
        GridText: GridText/* default */.Z,
        GridSpace: GridSpace/* default */.Z,
        GridHeadline: GridHeadline/* default */.Z,
        GridInput: GridInput/* default */.Z,
        GridStakePoolList: GridStakePoolList/* default */.Z,
        MDStaking: MDStaking,
        IconPencil: IconPencil/* default */.Z
    },
    setup() {
        const { t } = (0,useTranslation/* useTranslation */.$)();
        const { generateDelegationHistory } = (0,useDelegationHistory/* useDelegationHistory */.I)();
        const { networkId, isTestnet } = (0,useNetworkId/* useNetworkId */.h)();
        const { activeAccount } = (0,useActiveWallet/* useActiveWallet */.r)();
        const { filteredPoolList, groupPoolList, featuredPoolList, updateFilteredPools } = (0,usePoolAPI/* usePoolAPI */.b)();
        const delegatedPoolList = (0,reactivity_esm_bundler/* ref */.iH)([]);
        function generateDelegationList() {
            delegatedPoolList.value.splice(0);
            if (activeAccount.value && activeAccount.value.base.stake.length > 0) {
                const { afterNextDelegations } = generateDelegationHistory(activeAccount.value.keys.stake[0], activeAccount.value.base.stake[0]);
                delegatedPoolList.value.push(...afterNextDelegations);
            }
        }
        (0,runtime_core_esm_bundler/* watchEffect */.m0)(() => {
            if (activeAccount.value && groupPoolList.value.length > 0) {
                generateDelegationList();
            }
        });
        const searchInput = (0,reactivity_esm_bundler/* ref */.iH)('');
        const searchInputError = (0,reactivity_esm_bundler/* ref */.iH)('');
        const searchDisabled = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const optionsTabs = (0,reactivity_esm_bundler/* reactive */.qj)([
            { id: 'ranked', label: t('wallet.staking.tab.ranked'), index: 0 },
            //{ id: 'md',       label: t('wallet.staking.tab.md') },
        ]);
        if (networkId.value === INetwork/* mainnet.id */.RJ.id) {
            optionsTabs.push({ id: 'featured', label: t('wallet.staking.tab.featured'), index: 1 });
        }
        function validateSearchInput(external) {
            searchInputError.value = '';
            return searchInputError.value;
        }
        function resetFilter() { searchInput.value = ''; }
        (0,runtime_core_esm_bundler/* watch */.YP)(searchInput, () => {
            validateSearchInput(false);
            updateFilteredPools(searchInput.value);
        });
        const showGroupPoolList = (0,runtime_core_esm_bundler/* computed */.Fl)(() => searchInput.value.toLowerCase().length < 3);
        return {
            t,
            isTestnet,
            optionsTabs,
            filteredPoolList,
            delegatedPoolList,
            showGroupPoolList,
            groupPoolList,
            featuredPoolList,
            searchInput,
            searchInputError,
            searchDisabled,
            validateSearchInput,
            resetFilter,
        };
    }
}));

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/Staking.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/Staking.vue




;
const Staking_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(Stakingvue_type_script_lang_ts, [['render',render]])

/* harmony default export */ const Staking = (Staking_exports_);

/***/ })

}]);
//# sourceMappingURL=1917.js.map