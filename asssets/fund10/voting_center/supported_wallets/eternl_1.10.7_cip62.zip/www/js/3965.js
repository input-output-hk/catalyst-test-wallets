"use strict";
(this["webpackChunkccw_frontend"] = this["webpackChunkccw_frontend"] || []).push([[3965],{

/***/ 33965:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "routesBex": () => (/* binding */ routesBex)
/* harmony export */ });
/* harmony import */ var src_ccw_lib_Print__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(72302);

//@ts-ignore
if (src_ccw_lib_Print__WEBPACK_IMPORTED_MODULE_0__/* ["default"].frontend.routes */ .Z.frontend.routes)
    console.log('setup: routes.bex: process.env.ccw.MODE:', {"HOST_API_STAGING":"https://api.staging.eternl.io","HOST_API":"https://api.eternl.io","ENVIRONMENT":"production","TOKEN":"#!l4n56cGPHoHM3Z@xiT&CV8","PEN":"k%%2Gb6^!m8iMIvwlnS2xpWC","MODE":"bex","IS_STAGING":"no"}.MODE);
const routesBex = [
    // Initial path re-routing is done in useNavigation.useNavigationFromRouter
    { path: '/', redirect: { name: 'LandingPage', params: { networkid: 'mainnet' } }, name: 'Default' },
    { path: '/txviewer/:networkid', component: () => Promise.all(/* import() */[__webpack_require__.e(4736), __webpack_require__.e(3064), __webpack_require__.e(4603)]).then(__webpack_require__.bind(__webpack_require__, 67234)), name: 'TxViewer' },
    // initial re-routing will figure out, that this is the bex mode.
    { path: '/tmp', component: () => __webpack_require__.e(/* import() */ 3605).then(__webpack_require__.bind(__webpack_require__, 15292)), name: 'TmpPageBex' },
    { path: '/full', redirect: { name: 'TmpPageBex' }, name: 'Full' },
    { path: '/full/:networkid', redirect: { name: 'TmpPageBex' }, name: 'FullId' },
    { path: '/popup', redirect: { name: 'TmpPageBex' }, name: 'Popup' },
    { path: '/popup/:networkid', redirect: { name: 'TmpPageBex' }, name: 'PopupId' },
    { path: '/dapp', redirect: { name: 'TmpPageBex' }, name: 'Dapp' },
    { path: '/dapp/:networkid', redirect: { name: 'TmpPageBex' }, name: 'DappId' },
    { path: '/enable', redirect: { name: 'TmpPageBex' }, name: 'Enable' },
    { path: '/connect/:networkid', component: () => Promise.all(/* import() */[__webpack_require__.e(4736), __webpack_require__.e(3064), __webpack_require__.e(6266)]).then(__webpack_require__.bind(__webpack_require__, 41038)),
        props: { api: 'onEnabled' },
        children: [
            { path: 'connect', component: () => Promise.all(/* import() */[__webpack_require__.e(3064), __webpack_require__.e(1479)]).then(__webpack_require__.bind(__webpack_require__, 68458)), name: 'Connect' },
            { path: 'noorigin', component: () => Promise.all(/* import() */[__webpack_require__.e(4736), __webpack_require__.e(4968)]).then(__webpack_require__.bind(__webpack_require__, 74968)), name: 'NoOrigin' }
        ]
    },
    { path: '/signtx', redirect: { name: 'TmpPageBex' }, name: 'SignTx' },
    { path: '/signtx/:networkid', component: () => Promise.all(/* import() */[__webpack_require__.e(4736), __webpack_require__.e(3064), __webpack_require__.e(7949)]).then(__webpack_require__.bind(__webpack_require__, 5536)),
        children: [
            { path: 'noorigin', component: () => Promise.all(/* import() */[__webpack_require__.e(4736), __webpack_require__.e(4968)]).then(__webpack_require__.bind(__webpack_require__, 74968)), name: 'NoOrigin_SignTx' },
            { path: 'wallet', component: () => __webpack_require__.e(/* import() */ 4675).then(__webpack_require__.bind(__webpack_require__, 74675)),
                children: [
                    { path: ':walletid', component: () => Promise.all(/* import() */[__webpack_require__.e(4736), __webpack_require__.e(3064), __webpack_require__.e(4599)]).then(__webpack_require__.bind(__webpack_require__, 95804)), name: 'WalletDetails_SignTx',
                        children: [
                            { path: 'sign', component: () => Promise.all(/* import() */[__webpack_require__.e(4736), __webpack_require__.e(3064), __webpack_require__.e(3052)]).then(__webpack_require__.bind(__webpack_require__, 96845)), name: 'SignTxPage' }
                        ]
                    }
                ]
            }
        ]
    },
    { path: '/signdata', redirect: { name: 'TmpPageBex' }, name: 'SignData' },
    { path: '/signdata/:networkid', component: () => Promise.all(/* import() */[__webpack_require__.e(4736), __webpack_require__.e(3064), __webpack_require__.e(7949)]).then(__webpack_require__.bind(__webpack_require__, 5536)),
        children: [
            { path: 'noorigin', component: () => Promise.all(/* import() */[__webpack_require__.e(4736), __webpack_require__.e(4968)]).then(__webpack_require__.bind(__webpack_require__, 74968)), name: 'NoOrigin_SignData' },
            { path: 'wallet', component: () => __webpack_require__.e(/* import() */ 4675).then(__webpack_require__.bind(__webpack_require__, 74675)),
                children: [
                    { path: ':walletid', component: () => Promise.all(/* import() */[__webpack_require__.e(4736), __webpack_require__.e(3064), __webpack_require__.e(4599)]).then(__webpack_require__.bind(__webpack_require__, 95804)), name: 'WalletDetails_SignData',
                        children: [
                            { path: 'sign', component: () => Promise.all(/* import() */[__webpack_require__.e(4736), __webpack_require__.e(3064), __webpack_require__.e(185)]).then(__webpack_require__.bind(__webpack_require__, 19960)), name: 'SignDataPage' }
                        ]
                    }
                ]
            }
        ]
    },
    { path: '/cip62/enable', redirect: { name: 'TmpPageBex' }, name: 'CIP62_Enable' },
    { path: '/cip62/connect/:networkid', component: () => Promise.all(/* import() */[__webpack_require__.e(4736), __webpack_require__.e(3064), __webpack_require__.e(6266)]).then(__webpack_require__.bind(__webpack_require__, 41038)),
        props: { api: 'onCIP62Enabled' },
        children: [
            { path: 'connect', component: () => Promise.all(/* import() */[__webpack_require__.e(3064), __webpack_require__.e(1479)]).then(__webpack_require__.bind(__webpack_require__, 68458)), name: 'CIP62_Enable_Connect' },
            { path: 'noorigin', component: () => Promise.all(/* import() */[__webpack_require__.e(4736), __webpack_require__.e(4968)]).then(__webpack_require__.bind(__webpack_require__, 74968)), name: 'CIP62_Enable_NoOrigin' }
        ]
    },
    { path: '/cip62/credentials', redirect: { name: 'TmpPageBex' }, name: 'CIP62_Credentials' },
    { path: '/cip62/credentials/:networkid', component: () => Promise.all(/* import() */[__webpack_require__.e(4736), __webpack_require__.e(3064), __webpack_require__.e(7949)]).then(__webpack_require__.bind(__webpack_require__, 5536)),
        children: [
            { path: 'noorigin', component: () => Promise.all(/* import() */[__webpack_require__.e(4736), __webpack_require__.e(4968)]).then(__webpack_require__.bind(__webpack_require__, 74968)), name: 'CIP62_Credentials_NoOrigin' },
            { path: 'wallet', component: () => __webpack_require__.e(/* import() */ 4675).then(__webpack_require__.bind(__webpack_require__, 74675)),
                children: [
                    { path: ':walletid', component: () => Promise.all(/* import() */[__webpack_require__.e(4736), __webpack_require__.e(3064), __webpack_require__.e(4599)]).then(__webpack_require__.bind(__webpack_require__, 95804)), name: 'CIP62_Credentials_WalletDetails',
                        children: [
                            { path: 'sign', component: () => Promise.all(/* import() */[__webpack_require__.e(4736), __webpack_require__.e(3064), __webpack_require__.e(616)]).then(__webpack_require__.bind(__webpack_require__, 37351)), name: 'CIP62_Credentials_Page' }
                        ]
                    }
                ]
            }
        ]
    },
    { path: '/cip62/delegation', redirect: { name: 'TmpPageBex' }, name: 'CIP62_Delegation' },
    { path: '/cip62/delegation/:networkid', component: () => Promise.all(/* import() */[__webpack_require__.e(4736), __webpack_require__.e(3064), __webpack_require__.e(7949)]).then(__webpack_require__.bind(__webpack_require__, 5536)),
        children: [
            { path: 'noorigin', component: () => Promise.all(/* import() */[__webpack_require__.e(4736), __webpack_require__.e(4968)]).then(__webpack_require__.bind(__webpack_require__, 74968)), name: 'CIP62_Delegation_NoOrigin' },
            { path: 'wallet', component: () => __webpack_require__.e(/* import() */ 4675).then(__webpack_require__.bind(__webpack_require__, 74675)),
                children: [
                    { path: ':walletid', component: () => Promise.all(/* import() */[__webpack_require__.e(4736), __webpack_require__.e(3064), __webpack_require__.e(4599)]).then(__webpack_require__.bind(__webpack_require__, 95804)), name: 'CIP62_Delegation_WalletDetails',
                        children: [
                            { path: 'sign', component: () => Promise.all(/* import() */[__webpack_require__.e(4736), __webpack_require__.e(3064), __webpack_require__.e(935)]).then(__webpack_require__.bind(__webpack_require__, 24521)), name: 'CIP62_Delegation_Page' }
                        ]
                    }
                ]
            }
        ]
    },
    { path: '/cip62/signvotes', redirect: { name: 'TmpPageBex' }, name: 'CIP62_SignVotes' },
    { path: '/cip62/signvotes/:networkid', component: () => Promise.all(/* import() */[__webpack_require__.e(4736), __webpack_require__.e(3064), __webpack_require__.e(7949)]).then(__webpack_require__.bind(__webpack_require__, 5536)),
        children: [
            { path: 'noorigin', component: () => Promise.all(/* import() */[__webpack_require__.e(4736), __webpack_require__.e(4968)]).then(__webpack_require__.bind(__webpack_require__, 74968)), name: 'CIP62_SignVotes_NoOrigin' },
            { path: 'wallet', component: () => __webpack_require__.e(/* import() */ 4675).then(__webpack_require__.bind(__webpack_require__, 74675)),
                children: [
                    { path: ':walletid', component: () => Promise.all(/* import() */[__webpack_require__.e(4736), __webpack_require__.e(3064), __webpack_require__.e(4599)]).then(__webpack_require__.bind(__webpack_require__, 95804)), name: 'CIP62_SignVotes_WalletDetails',
                        children: [
                            { path: 'sign', component: () => Promise.all(/* import() */[__webpack_require__.e(4736), __webpack_require__.e(3064), __webpack_require__.e(4497)]).then(__webpack_require__.bind(__webpack_require__, 82875)), name: 'CIP62_SignVotes_Page' }
                        ]
                    }
                ]
            }
        ]
    },
    // initial re-routing will figure out, that this is the bex mode.
    { path: '/app/:networkid', component: () => Promise.all(/* import() */[__webpack_require__.e(4736), __webpack_require__.e(3064), __webpack_require__.e(6331)]).then(__webpack_require__.bind(__webpack_require__, 53431)), redirect: { name: 'LandingPage' }, name: 'TmpPage',
        children: [
            { path: 'welcome', component: () => __webpack_require__.e(/* import() */ 3064).then(__webpack_require__.bind(__webpack_require__, 37809)), name: 'LandingPage' },
            { path: 'imprint', component: () => Promise.all(/* import() */[__webpack_require__.e(3064), __webpack_require__.e(1479)]).then(__webpack_require__.bind(__webpack_require__, 68458)), name: 'Imprint' },
            { path: 'news', component: () => Promise.all(/* import() */[__webpack_require__.e(4736), __webpack_require__.e(3064), __webpack_require__.e(3855)]).then(__webpack_require__.bind(__webpack_require__, 54445)), name: 'Announcements' },
            { path: 'faq', component: () => Promise.all(/* import() */[__webpack_require__.e(4736), __webpack_require__.e(3064), __webpack_require__.e(5318)]).then(__webpack_require__.bind(__webpack_require__, 81526)), name: 'FAQ' },
            { path: 'dapps', component: () => Promise.all(/* import() */[__webpack_require__.e(4736), __webpack_require__.e(3064), __webpack_require__.e(2910)]).then(__webpack_require__.bind(__webpack_require__, 98363)), name: 'DApps' },
            { path: 'wallet', component: () => __webpack_require__.e(/* import() */ 4675).then(__webpack_require__.bind(__webpack_require__, 74675)),
                children: [
                    { path: '', component: () => Promise.all(/* import() */[__webpack_require__.e(3064), __webpack_require__.e(3085)]).then(__webpack_require__.bind(__webpack_require__, 73085)), name: 'Wallets' },
                    { path: 'add', component: () => Promise.all(/* import() */[__webpack_require__.e(4736), __webpack_require__.e(3064), __webpack_require__.e(3939)]).then(__webpack_require__.bind(__webpack_require__, 57481)), name: 'WalletAdd' },
                    { path: 'create', component: () => Promise.all(/* import() */[__webpack_require__.e(4736), __webpack_require__.e(3064), __webpack_require__.e(5915)]).then(__webpack_require__.bind(__webpack_require__, 16206)), name: 'WalletCreate' },
                    { path: 'import', component: () => Promise.all(/* import() */[__webpack_require__.e(4736), __webpack_require__.e(3064), __webpack_require__.e(6200)]).then(__webpack_require__.bind(__webpack_require__, 11250)), name: 'WalletImport' },
                    { path: 'importkey', component: () => Promise.all(/* import() */[__webpack_require__.e(4736), __webpack_require__.e(3064), __webpack_require__.e(2814)]).then(__webpack_require__.bind(__webpack_require__, 92594)), name: 'WalletImportKey' },
                    { path: 'restore', component: () => Promise.all(/* import() */[__webpack_require__.e(4736), __webpack_require__.e(3064), __webpack_require__.e(3543)]).then(__webpack_require__.bind(__webpack_require__, 81226)), name: 'WalletRestore' },
                    { path: 'pair', component: () => Promise.all(/* import() */[__webpack_require__.e(4736), __webpack_require__.e(3064), __webpack_require__.e(6308)]).then(__webpack_require__.bind(__webpack_require__, 21084)), name: 'WalletPair' },
                    { path: ':walletid', component: () => Promise.all(/* import() */[__webpack_require__.e(4736), __webpack_require__.e(3064), __webpack_require__.e(4599)]).then(__webpack_require__.bind(__webpack_require__, 95804)), redirect: { name: 'Summary' }, name: 'WalletDetails',
                        children: [
                            { path: 'summary', component: () => Promise.all(/* import() */[__webpack_require__.e(4736), __webpack_require__.e(3064), __webpack_require__.e(6592)]).then(__webpack_require__.bind(__webpack_require__, 79680)), name: 'Summary' },
                            { path: 'transactions', component: () => Promise.all(/* import() */[__webpack_require__.e(4736), __webpack_require__.e(3064), __webpack_require__.e(7415)]).then(__webpack_require__.bind(__webpack_require__, 33913)), name: 'Transactions' },
                            { path: 'send', component: () => Promise.all(/* import() */[__webpack_require__.e(4736), __webpack_require__.e(3064), __webpack_require__.e(5131)]).then(__webpack_require__.bind(__webpack_require__, 1075)), name: 'Send' },
                            { path: 'collateral', component: () => Promise.all(/* import() */[__webpack_require__.e(4736), __webpack_require__.e(3064), __webpack_require__.e(5390)]).then(__webpack_require__.bind(__webpack_require__, 37205)), name: 'Collateral' },
                            { path: 'delegation', component: () => Promise.all(/* import() */[__webpack_require__.e(4736), __webpack_require__.e(3064), __webpack_require__.e(4430)]).then(__webpack_require__.bind(__webpack_require__, 76284)), name: 'Delegation' },
                            { path: 'withdrawal', component: () => Promise.all(/* import() */[__webpack_require__.e(4736), __webpack_require__.e(3064), __webpack_require__.e(9442)]).then(__webpack_require__.bind(__webpack_require__, 60946)), name: 'Withdrawal' },
                            { path: 'deregistration', component: () => Promise.all(/* import() */[__webpack_require__.e(4736), __webpack_require__.e(3064), __webpack_require__.e(993)]).then(__webpack_require__.bind(__webpack_require__, 74516)), name: 'Deregistration' },
                            { path: 'receive', component: () => Promise.all(/* import() */[__webpack_require__.e(4736), __webpack_require__.e(3064), __webpack_require__.e(1367)]).then(__webpack_require__.bind(__webpack_require__, 89734)), name: 'Receive' },
                            { path: 'staking', component: () => Promise.all(/* import() */[__webpack_require__.e(4736), __webpack_require__.e(3064), __webpack_require__.e(1917)]).then(__webpack_require__.bind(__webpack_require__, 42278)), name: 'Staking' },
                            { path: 'vault', component: () => Promise.all(/* import() */[__webpack_require__.e(4736), __webpack_require__.e(3064), __webpack_require__.e(4437)]).then(__webpack_require__.bind(__webpack_require__, 2821)), name: 'StakingVault' },
                            { path: 'voting', component: () => Promise.all(/* import() */[__webpack_require__.e(4736), __webpack_require__.e(3064), __webpack_require__.e(8094)]).then(__webpack_require__.bind(__webpack_require__, 80164)), name: 'Voting' },
                            { path: 'settings', component: () => Promise.all(/* import() */[__webpack_require__.e(4736), __webpack_require__.e(3064), __webpack_require__.e(900)]).then(__webpack_require__.bind(__webpack_require__, 73265)), name: 'WalletSettings' },
                            { path: 'verification', component: () => Promise.all(/* import() */[__webpack_require__.e(4736), __webpack_require__.e(3064), __webpack_require__.e(8260)]).then(__webpack_require__.bind(__webpack_require__, 57161)), name: 'WalletVerification' },
                            { path: 'swap', component: () => Promise.all(/* import() */[__webpack_require__.e(4736), __webpack_require__.e(3064), __webpack_require__.e(4888)]).then(__webpack_require__.bind(__webpack_require__, 3617)), name: 'Swap' },
                            { path: 'signtx', component: () => Promise.all(/* import() */[__webpack_require__.e(4736), __webpack_require__.e(3064), __webpack_require__.e(5134)]).then(__webpack_require__.bind(__webpack_require__, 87534)), name: 'SignTransaction' },
                        ]
                    }
                ]
            }
        ]
    },
    // Always leave this as last one,
    // but you can also remove it
    {
        path: '/404', component: () => Promise.all(/* import() */[__webpack_require__.e(4736), __webpack_require__.e(3064), __webpack_require__.e(1652)]).then(__webpack_require__.bind(__webpack_require__, 83777)), name: 'Error'
    },
    {
        path: '/:pathMatch(.*)*', component: () => Promise.all(/* import() */[__webpack_require__.e(4736), __webpack_require__.e(3064), __webpack_require__.e(1652)]).then(__webpack_require__.bind(__webpack_require__, 83777)), name: 'ErrorAll'
    }
];
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (routesBex);


/***/ })

}]);
//# sourceMappingURL=3965.js.map