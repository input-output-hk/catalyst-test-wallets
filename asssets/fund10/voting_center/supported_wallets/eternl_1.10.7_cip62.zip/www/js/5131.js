"use strict";
(this["webpackChunkccw_frontend"] = this["webpackChunkccw_frontend"] || []).push([[5131,5134],{

/***/ 1075:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Send)
});

// EXTERNAL MODULE: ./node_modules/@vue/runtime-core/dist/runtime-core.esm-bundler.js
var runtime_core_esm_bundler = __webpack_require__(83673);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/Send.vue?vue&type=template&id=49253a45&ts=true

const _hoisted_1 = { class: "cc-page-wallet cc-text-sz dark:text-cc-gray" };
function render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_SendGuide = (0,runtime_core_esm_bundler/* resolveComponent */.up)("SendGuide");
    const _component_SendBuilder = (0,runtime_core_esm_bundler/* resolveComponent */.up)("SendBuilder");
    const _component_SendImport = (0,runtime_core_esm_bundler/* resolveComponent */.up)("SendImport");
    const _component_GridTabs = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridTabs");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_1, [
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridTabs, { tabs: _ctx.optionsTabs }, {
            tab0: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_SendGuide)
            ]),
            tab1: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_SendBuilder)
            ]),
            tab2: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_SendImport)
            ]),
            _: 1
        }, 8, ["tabs"])
    ]));
}

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/Send.vue?vue&type=template&id=49253a45&ts=true

// EXTERNAL MODULE: ./node_modules/@vue/reactivity/dist/reactivity.esm-bundler.js
var reactivity_esm_bundler = __webpack_require__(61959);
// EXTERNAL MODULE: ./src/composables/ccw/useTranslation.ts
var useTranslation = __webpack_require__(19376);
// EXTERNAL MODULE: ./src/composables/ccw/store/useActiveWallet.ts
var useActiveWallet = __webpack_require__(52144);
// EXTERNAL MODULE: ./src/composables/ccw/store/useBuildTx_v3.ts + 1 modules
var useBuildTx_v3 = __webpack_require__(72107);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/send/SendGuide.vue?vue&type=template&id=6715396b&ts=true

const SendGuidevue_type_template_id_6715396b_ts_true_hoisted_1 = { class: "cc-grid" };
function SendGuidevue_type_template_id_6715396b_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_SendAddrInput = (0,runtime_core_esm_bundler/* resolveComponent */.up)("SendAddrInput");
    const _component_GridButtonSecondary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonSecondary");
    const _component_SendAssetsInput = (0,runtime_core_esm_bundler/* resolveComponent */.up)("SendAssetsInput");
    const _component_SendConfirm = (0,runtime_core_esm_bundler/* resolveComponent */.up)("SendConfirm");
    const _component_SendSubmit = (0,runtime_core_esm_bundler/* resolveComponent */.up)("SendSubmit");
    const _component_GridSteps = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSteps");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", SendGuidevue_type_template_id_6715396b_ts_true_hoisted_1, [
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSteps, {
            onBack: _ctx.goBack,
            steps: _ctx.optionsSteps,
            currentStep: _ctx.currentStep,
            "small-c-s-s": "pr-9 sm:pr-20 md:pr-18 lg:pr-32"
        }, {
            step0: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_SendAddrInput, {
                    onSubmit: _ctx.gotoNext,
                    onReset: _ctx.onAddrInputReset,
                    onBridgeUpdate: _ctx.onBridgeUpdate,
                    "prefilled-address": _ctx.output ? _ctx.output.paymentAddr.bech32 : undefined,
                    "text-id": "wallet.send.step.receiveAddr",
                    "show-account-list": ""
                }, null, 8, ["onSubmit", "onReset", "onBridgeUpdate", "prefilled-address"])
            ]),
            step1: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                (_ctx.activeAccount && _ctx.activeWalletData && _ctx.output)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_SendAssetsInput, {
                        key: 0,
                        onSubmit: _ctx.gotoNext,
                        onOutputUpdate: _ctx.onOutputUpdate,
                        account: _ctx.activeAccount,
                        wallet: _ctx.activeWalletData,
                        "staging-output": _ctx.output,
                        "send-all-enabled": _ctx.activeWalletEnabledSendAll,
                        "enabled-collateral": _ctx.activeWalletEnabledCollateral,
                        previousStep: _ctx.previousStep,
                        "text-id": "wallet.send.step.assets"
                    }, {
                        btnBack: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonSecondary, {
                                label: _ctx.t('common.label.back'),
                                link: _ctx.goBack,
                                class: "col-start-0 col-span-6 lg:col-start-7 lg:col-span-3"
                            }, null, 8, ["label", "link"])
                        ]),
                        _: 1
                    }, 8, ["onSubmit", "onOutputUpdate", "account", "wallet", "staging-output", "send-all-enabled", "enabled-collateral", "previousStep"]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
            ]),
            step2: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_SendConfirm, {
                    onSubmit: _ctx.gotoNext,
                    account: _ctx.activeAccount,
                    wallet: _ctx.activeWalletData,
                    "unsigned-tx": _ctx.tx,
                    "text-id": "wallet.send.step.confirm"
                }, {
                    btnBack: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonSecondary, {
                            label: _ctx.t('wallet.send.step.confirm.button.back'),
                            link: _ctx.goBack,
                            class: "col-start-0 col-span-6 lg:col-start-0 lg:col-span-3"
                        }, null, 8, ["label", "link"])
                    ]),
                    _: 1
                }, 8, ["onSubmit", "account", "wallet", "unsigned-tx"])
            ]),
            step3: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_SendSubmit, {
                    onError: _ctx.onSubmitError,
                    onPending: _ctx.onTxPending,
                    onConfirmed: _ctx.onTxConfirmed,
                    "text-id": "wallet.send.step.submit"
                }, {
                    btnBack: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                        (_ctx.hasSubmitError)
                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridButtonSecondary, {
                                key: 0,
                                label: _ctx.t('wallet.send.step.submit.button.back'),
                                link: _ctx.goBack,
                                class: "col-start-0 col-span-6 lg:col-start-0 lg:col-span-3 mt-4"
                            }, null, 8, ["label", "link"]))
                            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                    ]),
                    _: 1
                }, 8, ["onError", "onPending", "onConfirmed"])
            ]),
            _: 1
        }, 8, ["onBack", "steps", "currentStep"])
    ]));
}

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/send/SendGuide.vue?vue&type=template&id=6715396b&ts=true

// EXTERNAL MODULE: ./src/composables/ccw/useNavigation.ts
var useNavigation = __webpack_require__(52439);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/send/SendAddrInput.vue + 29 modules
var SendAddrInput = __webpack_require__(99677);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/send/SendAssetsInput.vue + 4 modules
var SendAssetsInput = __webpack_require__(40123);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/send/SendConfirm.vue + 4 modules
var SendConfirm = __webpack_require__(12662);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/send/SendSubmit.vue + 3 modules
var SendSubmit = __webpack_require__(65778);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridHeadline.vue + 3 modules
var GridHeadline = __webpack_require__(63593);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridText.vue + 4 modules
var GridText = __webpack_require__(96834);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridSpace.vue + 4 modules
var GridSpace = __webpack_require__(14740);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridSteps.vue + 14 modules
var GridSteps = __webpack_require__(58217);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridTextArea.vue + 4 modules
var GridTextArea = __webpack_require__(15660);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridButtonPrimary.vue + 3 modules
var GridButtonPrimary = __webpack_require__(12559);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridButtonSecondary.vue + 3 modules
var GridButtonSecondary = __webpack_require__(72713);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/CSLUtils.ts
var CSLUtils = __webpack_require__(58173);
// EXTERNAL MODULE: ../ccw-lib2/core/IMetadata.ts
var IMetadata = __webpack_require__(66198);
// EXTERNAL MODULE: ./src/lib/ExtMilkomeda.ts
var ExtMilkomeda = __webpack_require__(91323);
// EXTERNAL MODULE: ../ccw-lib2/core/ITxOut.ts
var ITxOut = __webpack_require__(84530);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/send/SendGuide.vue?vue&type=script&lang=ts




















/* harmony default export */ const SendGuidevue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'SendGuide',
    components: {
        GridSpace: GridSpace/* default */.Z,
        GridHeadline: GridHeadline/* default */.Z,
        GridText: GridText/* default */.Z,
        GridTextArea: GridTextArea/* default */.Z,
        GridSteps: GridSteps/* default */.Z,
        GridButtonPrimary: GridButtonPrimary/* default */.Z,
        GridButtonSecondary: GridButtonSecondary/* default */.Z,
        SendAddrInput: SendAddrInput/* default */.Z,
        SendAssetsInput: SendAssetsInput/* default */.Z,
        SendConfirm: SendConfirm/* default */.Z,
        SendSubmit: SendSubmit/* default */.Z,
    },
    setup() {
        const { t } = (0,useTranslation/* useTranslation */.$)();
        const { gotoWalletPage } = (0,useNavigation/* useNavigation */.HJ)();
        const currentStep = (0,reactivity_esm_bundler/* ref */.iH)(0);
        const previousStep = (0,reactivity_esm_bundler/* ref */.iH)(0);
        const { activeWalletEnabledSendAll, activeWalletEnabledCollateral, activeWalletData, activeAccount } = (0,useActiveWallet/* useActiveWallet */.r)();
        const { setOutput, resetBuildTx, getBuildStatus, getStagingTx, getBuiltTx, setMetadata, setBridgeFee, setBridgeAddr, } = (0,useBuildTx_v3/* useBuildTxV3 */.b)();
        resetBuildTx(activeAccount.value?.pub ?? null);
        const tx = (0,runtime_core_esm_bundler/* computed */.Fl)(() => {
            if (!activeAccount.value) {
                return null;
            }
            return getBuiltTx(activeAccount.value?.pub);
        });
        const output = (0,runtime_core_esm_bundler/* computed */.Fl)(() => {
            if (!activeAccount.value) {
                return null;
            }
            return getStagingTx(activeAccount.value?.pub).outputList[0] ?? null;
        });
        let accountPub = (0,runtime_core_esm_bundler/* computed */.Fl)(() => (activeAccount.value?.pub ?? null));
        let resetPreventingAccPub = '';
        (0,runtime_core_esm_bundler/* watchEffect */.m0)(() => {
            if (accountPub.value && accountPub.value !== resetPreventingAccPub) {
                resetPreventingAccPub = accountPub.value;
                currentStep.value = 0;
                previousStep.value = 0;
            }
        });
        const hasSubmitError = (0,runtime_core_esm_bundler/* computed */.Fl)(() => (accountPub.value ? (getBuildStatus(accountPub.value) === useBuildTx_v3/* IBuildStatus.error */.k.error) : null));
        (0,runtime_core_esm_bundler/* onErrorCaptured */.d1)((e) => { console.error('Wallet: Send: onErrorCaptured', e); return true; });
        const optionsSteps = (0,reactivity_esm_bundler/* reactive */.qj)([
            { id: 'receiveAddr', label: t('wallet.send.step.stepper.receiveAddr') },
            { id: 'assets', label: t('wallet.send.step.stepper.assets') },
            { id: 'confirm', label: t('wallet.send.step.stepper.confirm') },
            { id: 'submit', label: t('wallet.send.step.stepper.submit') }
        ]);
        function goBack() {
            previousStep.value = currentStep.value;
            if (currentStep.value === 1) {
                currentStep.value = 0;
            }
            else if (currentStep.value === 2) {
                currentStep.value = 1;
            }
            else if (currentStep.value === 3) {
                currentStep.value = 2;
            }
        }
        function gotoNext(event) {
            previousStep.value = currentStep.value;
            if (currentStep.value === 0) { // address input
                const itx = getStagingTx(activeAccount.value.pub);
                if (itx.outputList.length === 0) {
                    const output = (0,ITxOut/* createITxOut */.jO)();
                    output.paymentAddr.bech32 = event;
                    setOutput(activeAccount.value, output);
                }
                else {
                    itx.outputList[0].paymentAddr.bech32 = event;
                }
                currentStep.value = 1;
            }
            else if (currentStep.value === 1) {
                currentStep.value = 2;
            }
            else if (currentStep.value === 2) {
                currentStep.value = 3;
            }
        }
        function onAddrInputReset() {
            if (activeAccount.value) {
                resetBuildTx(activeAccount.value.pub);
            }
        }
        function onBridgeUpdate(event) {
            if (!activeAccount.value) {
                return;
            }
            if (event.addr) {
                setBridgeFee(activeAccount.value.pub, event.fee);
                setBridgeAddr(activeAccount.value.pub, event.addr);
                setMetadata(activeAccount.value.pub, (0,CSLUtils/* getMetadataFromJSON */.SP)((0,IMetadata/* createITxMetadataList */.Z)([
                    (0,IMetadata/* createIMetadata */.D)({ label: ExtMilkomeda/* networkMetadataUrlKey */.Zt, metadatum: ExtMilkomeda/* networkMetadataUrl */.Mz[activeAccount.value.network] }),
                    (0,IMetadata/* createIMetadata */.D)({ label: ExtMilkomeda/* networkMetadataAddressKey */.m7, metadatum: event.addr }),
                ])));
            }
            else {
                setBridgeFee(activeAccount.value.pub, null);
                setBridgeAddr(activeAccount.value.pub, null);
            }
        }
        function onOutputUpdate(out) {
            if (!activeAccount.value) {
                return;
            }
            setOutput(activeAccount.value, out);
        }
        function onSubmitError() { console.error('submit error!!'); }
        function onTxPending() {
            gotoWalletPage('Transactions', 'pending');
        }
        function onTxConfirmed() { }
        return {
            t,
            activeWalletData,
            activeAccount,
            tx,
            output,
            activeWalletEnabledSendAll,
            activeWalletEnabledCollateral,
            optionsSteps,
            currentStep,
            previousStep,
            hasSubmitError,
            goBack,
            gotoNext,
            onAddrInputReset,
            onBridgeUpdate,
            onOutputUpdate,
            onSubmitError,
            onTxPending,
            onTxConfirmed
        };
    }
}));

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/send/SendGuide.vue?vue&type=script&lang=ts
 
// EXTERNAL MODULE: ./node_modules/vue-loader/dist/exportHelper.js
var exportHelper = __webpack_require__(74260);
;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/send/SendGuide.vue




;
const __exports__ = /*#__PURE__*/(0,exportHelper/* default */.Z)(SendGuidevue_type_script_lang_ts, [['render',SendGuidevue_type_template_id_6715396b_ts_true_render]])

/* harmony default export */ const SendGuide = (__exports__);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/send/SendBuilder.vue?vue&type=template&id=2f904fcc&ts=true

const SendBuildervue_type_template_id_2f904fcc_ts_true_hoisted_1 = { class: "cc-grid" };
const _hoisted_2 = { class: "col-span-12 grid grid-cols-12 cc-gap md:ml-2 mb-2" };
const _hoisted_3 = { class: "grow-0 shrink-0 w-full flex flex-row flex-nowrap items-start justify-between border-b cc-p" };
const _hoisted_4 = { class: "flex flex-col cc-text-sz" };
const _hoisted_5 = { class: "min-h-40 flex flex-col flex-nowrap space-y-2 w-full p-4" };
const _hoisted_6 = { class: "grid grid-cols-12 cc-gap w-full p-2" };
const _hoisted_7 = { class: "grow-0 shrink-0 w-full flex flex-row flex-nowrap items-start justify-between cc-bg-white-0 border-b cc-p" };
const _hoisted_8 = { class: "flex flex-col cc-text-sz" };
const _hoisted_9 = { class: "min-h-40 flex flex-col flex-nowrap cc-p w-full p-4 cc-bg-light-1" };
const _hoisted_10 = { class: "grow-0 shrink-0 w-full flex flex-row flex-nowrap items-start justify-between border-b cc-p" };
const _hoisted_11 = { class: "flex flex-col cc-text-sz" };
const _hoisted_12 = { class: "p-4" };
const _hoisted_13 = { class: "grid grid-cols-12 cc-gap p-2 w-full" };
const _hoisted_14 = { class: "grow-0 shrink-0 w-full flex flex-row flex-nowrap items-start justify-between border-b cc-p" };
const _hoisted_15 = { class: "flex flex-col cc-text-sz" };
const _hoisted_16 = { class: "grid grid-cols-12 cc-gap p-2 w-full" };
const _hoisted_17 = { class: "grow-0 shrink-0 w-full flex flex-row flex-nowrap items-start justify-between border-b cc-p" };
const _hoisted_18 = { class: "flex flex-col cc-text-sz" };
const _hoisted_19 = { class: "p-4" };
const _hoisted_20 = { class: "grid grid-cols-12 cc-gap p-2 w-full" };
const _hoisted_21 = { class: "grow-0 shrink-0 w-full flex flex-row flex-nowrap items-start justify-between border-b cc-p" };
const _hoisted_22 = { class: "flex flex-col cc-text-sz" };
const _hoisted_23 = { class: "p-4" };
const _hoisted_24 = { class: "grid grid-cols-12 cc-gap p-2 w-full" };
function SendBuildervue_type_template_id_2f904fcc_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridHeadline = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridHeadline");
    const _component_GridText = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridText");
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    const _component_GridTxListEntry = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridTxListEntry");
    const _component_Checkbox = (0,runtime_core_esm_bundler/* resolveComponent */.up)("Checkbox");
    const _component_GridButtonAbort = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonAbort");
    const _component_GridButtonPrimary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonPrimary");
    const _component_GridTextArea = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridTextArea");
    const _component_GridButtonSecondary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonSecondary");
    const _component_SendConfirmList = (0,runtime_core_esm_bundler/* resolveComponent */.up)("SendConfirmList");
    const _component_SendSubmit = (0,runtime_core_esm_bundler/* resolveComponent */.up)("SendSubmit");
    const _component_GridSteps = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSteps");
    const _component_GridAccountUtxoList = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridAccountUtxoList");
    const _component_Modal = (0,runtime_core_esm_bundler/* resolveComponent */.up)("Modal");
    const _component_OutputBuilder = (0,runtime_core_esm_bundler/* resolveComponent */.up)("OutputBuilder");
    const _component_AdaInput = (0,runtime_core_esm_bundler/* resolveComponent */.up)("AdaInput");
    const _component_TTLInput = (0,runtime_core_esm_bundler/* resolveComponent */.up)("TTLInput");
    const _component_SendMetadataInput = (0,runtime_core_esm_bundler/* resolveComponent */.up)("SendMetadataInput");
    const _component_SendMetadataLabelInput = (0,runtime_core_esm_bundler/* resolveComponent */.up)("SendMetadataLabelInput");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", SendBuildervue_type_template_id_2f904fcc_ts_true_hoisted_1, [
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSteps, {
            onBack: _ctx.goBack,
            steps: _ctx.optionsSteps,
            currentStep: _ctx.currentStep,
            "small-c-s-s": "pr-9 sm:pr-20 md:pr-18 lg:pr-32"
        }, {
            step0: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                    label: _ctx.t('wallet.send.builder.label'),
                    class: "col-span-12"
                }, null, 8, ["label"]),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                    text: _ctx.t('wallet.send.builder.caption'),
                    class: "col-span-12 cc-text-sz"
                }, null, 8, ["text"]),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, {
                    hr: "",
                    class: "col-span-12 my-0.5 sm:mt-2"
                }),
                (_ctx.activeWalletData)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridTxListEntry, {
                        key: 0,
                        tx: _ctx.stagingTx,
                        wallet: _ctx.activeWalletData,
                        "network-id": _ctx.activeWalletData?.network,
                        onAddInput: _ctx.onInputSelect,
                        onAddOutput: _ctx.onOutputAdd,
                        onDelOutput: _ctx.onOutputDel,
                        onDelInput: _ctx.onInputDel,
                        onAddDonation: _ctx.onDonationAdd,
                        onSetTTL: _ctx.onTTLSet,
                        onAddMetadata: _ctx.onMetadataAdd,
                        onAddMetadataLabel: _ctx.onMetadataLabelAdd,
                        onDelMetadata: _ctx.onMetadataDel,
                        onExpired: _cache[0] || (_cache[0] = ($event) => { _ctx.isExpired = true; _ctx.builtTxList.splice(0); }),
                        "always-open": "",
                        "tx-builder": "",
                        "staging-tx": ""
                    }, null, 8, ["tx", "wallet", "network-id", "onAddInput", "onAddOutput", "onDelOutput", "onDelInput", "onAddDonation", "onSetTTL", "onAddMetadata", "onAddMetadataLabel", "onDelMetadata"]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_2, [
                    (_ctx.hasRewards)
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_Checkbox, {
                            key: 0,
                            id: "withdrawal",
                            label: _ctx.t('wallet.send.step.assets.withdrawal'),
                            "custom-c-s-s": "ml-1 col-span-12 md: cursor-pointer flex flex-row flex-nowrap items-center justify-start cc-text-medium",
                            "default-value": _ctx.forceWithdrawal,
                            onCheckToggle: _ctx.onWithdrawalToggle
                        }, null, 8, ["label", "default-value", "onCheckToggle"]))
                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_Checkbox, {
                        id: "utxomanagement",
                        label: _ctx.t('wallet.send.step.assets.utxoManagement'),
                        "label-hover": _ctx.t('wallet.send.step.assets.utxoManagementHover'),
                        "custom-c-s-s": "ml-1 col-span-12 cursor-pointer flex flex-row flex-nowrap items-center justify-start cc-text-medium",
                        "default-value": _ctx.allowUtxoManagement,
                        onCheckToggle: _ctx.onUtxoManagementToggle
                    }, null, 8, ["label", "label-hover", "default-value", "onCheckToggle"])
                ]),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonAbort, {
                    label: _ctx.t('common.label.reset'),
                    link: _ctx.onTxBuilderReset,
                    disabled: _ctx.isBuilding,
                    class: "col-span-4 lg:col-span-3"
                }, null, 8, ["label", "link", "disabled"]),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonPrimary, {
                    label: _ctx.t('wallet.send.builder.button.tf'),
                    link: _ctx.onBuildTokenFragmentationTx,
                    icon: _ctx.iconBuildingTF,
                    disabled: _ctx.isBuilding,
                    class: "col-start-0 col-span-4 sm:col-span-4 lg:col-span-3"
                }, null, 8, ["label", "link", "icon", "disabled"]),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonPrimary, {
                    label: _ctx.t('wallet.send.builder.button.cu'),
                    link: _ctx.onBuildCollectUTxOsTxList,
                    icon: _ctx.iconBuildingCU,
                    disabled: _ctx.isBuilding,
                    class: "col-start-0 col-span-4 sm:col-span-4 lg:col-span-3"
                }, null, 8, ["label", "link", "icon", "disabled"]),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonPrimary, {
                    label: _ctx.t('wallet.send.builder.button.build'),
                    link: _ctx.onBuildTx,
                    icon: _ctx.iconBuilding,
                    disabled: _ctx.isExpired || _ctx.isBuilding,
                    class: "col-span-6 lg:col-start-10 lg:col-span-3"
                }, null, 8, ["label", "link", "icon", "disabled"]),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonPrimary, {
                    label: _ctx.t('common.label.next'),
                    link: _ctx.gotoNext,
                    disabled: _ctx.builtTxList.length === 0 || _ctx.isBuilding,
                    class: "col-span-6 lg:col-start-10 lg:col-span-3"
                }, null, 8, ["label", "link", "disabled"]),
                (_ctx.isBuilding)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridSpace, {
                        key: 1,
                        hr: "",
                        class: "mt-2"
                    }))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                (_ctx.iconBuildingTF.length > 0)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridTextArea, {
                        key: 2,
                        text: _ctx.t('wallet.send.builder.tf.hint'),
                        icon: 'mdi mdi-update',
                        class: "col-span-12",
                        "text-c-s-s": "cc-text-normal text-justify flex justify-start items-center",
                        css: "cc-rounded cc-banner-warning"
                    }, null, 8, ["text"]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                (_ctx.iconBuildingCU.length > 0)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridTextArea, {
                        key: 3,
                        text: _ctx.t('wallet.send.builder.cu.hint'),
                        icon: 'mdi mdi-update',
                        class: "col-span-12",
                        "text-c-s-s": "cc-text-normal text-justify flex justify-start items-center",
                        css: "cc-rounded cc-banner-warning"
                    }, null, 8, ["text"]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                (_ctx.buildError.length > 0)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridTextArea, {
                        key: 4,
                        label: _ctx.t('wallet.send.builder.build.error.label'),
                        text: _ctx.buildError,
                        icon: _ctx.t('wallet.send.builder.build.error.icon'),
                        class: "col-span-12",
                        "text-c-s-s": "cc-text-normal text-justify flex justify-start items-center",
                        css: "cc-rounded cc-banner-warning"
                    }, null, 8, ["label", "text", "icon"]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                (_ctx.builtTxList.length > 0)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridSpace, {
                        key: 5,
                        hr: "",
                        label: _ctx.t('wallet.send.builder.builtTx'),
                        "label-c-s-s": "cc-text-md cc-text-semi-bold",
                        class: "col-span-12 my-2"
                    }, null, 8, ["label"]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                (_ctx.activeWalletData && _ctx.builtTxList.length > 0)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(true), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, { key: 6 }, (0,runtime_core_esm_bundler/* renderList */.Ko)(_ctx.builtTxList, (item) => {
                        return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridTxListEntry, {
                            key: item.txHash,
                            tx: item,
                            wallet: _ctx.activeWalletData,
                            "network-id": _ctx.activeWalletData?.network,
                            "always-open": "",
                            "staging-tx": ""
                        }, null, 8, ["tx", "wallet", "network-id"]));
                    }), 128))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
            ]),
            step1: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_SendConfirmList, {
                    onSubmit: _ctx.gotoNext,
                    account: _ctx.activeAccount,
                    wallet: _ctx.activeWalletData,
                    "unsigned-tx-list": _ctx.builtTxList,
                    "text-id": "wallet.send.step.confirm"
                }, {
                    btnBack: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonSecondary, {
                            label: _ctx.t('wallet.send.step.confirm.button.back'),
                            link: _ctx.goBack,
                            class: "col-start-0 col-span-6 lg:col-start-0 lg:col-span-3"
                        }, null, 8, ["label", "link"])
                    ]),
                    _: 1
                }, 8, ["onSubmit", "account", "wallet", "unsigned-tx-list"])
            ]),
            step2: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_SendSubmit, {
                    onError: _ctx.onSubmitError,
                    onPending: _ctx.onTxPending,
                    onConfirmed: _ctx.onTxConfirmed,
                    "text-id": "wallet.send.step.submit"
                }, {
                    btnBack: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                        (_ctx.hasSubmitError)
                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridButtonSecondary, {
                                key: 0,
                                label: _ctx.t('wallet.send.step.submit.button.back'),
                                link: _ctx.goBack,
                                class: "col-start-0 col-span-6 lg:col-start-0 lg:col-span-3 mt-4"
                            }, null, 8, ["label", "link"]))
                            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                    ]),
                    _: 1
                }, 8, ["onError", "onPending", "onConfirmed"])
            ]),
            _: 1
        }, 8, ["onBack", "steps", "currentStep"]),
        (_ctx.showInputModal)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_Modal, {
                key: 0,
                "full-width-on-mobile": "",
                onClose: _ctx.onInputCancel
            }, {
                header: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_3, [
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_4, [
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                                label: _ctx.t('wallet.send.builder.modal.input.label'),
                                "do-capitalize": false
                            }, null, 8, ["label"]),
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                                text: _ctx.t('wallet.send.builder.modal.input.caption')
                            }, null, 8, ["text"])
                        ])
                    ])
                ]),
                content: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_5, [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridAccountUtxoList, {
                            account: _ctx.activeAccount,
                            "pre-selected-utxo-list": _ctx.inputList,
                            onSelectionUpdate: _ctx.onInputUpdate
                        }, null, 8, ["account", "pre-selected-utxo-list", "onSelectionUpdate"])
                    ])
                ]),
                footer: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_6, [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonAbort, {
                            label: _ctx.t('common.label.reset'),
                            link: _ctx.onInputReset,
                            class: "col-start-0 col-span-6 lg:col-span-3 cc-btn-abort"
                        }, null, 8, ["label", "link"]),
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonSecondary, {
                            label: _ctx.t('common.label.all'),
                            link: _ctx.onInputSelectAll,
                            class: "col-span-6 lg:col-span-3"
                        }, null, 8, ["label", "link"]),
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonSecondary, {
                            label: _ctx.t('common.label.cancel'),
                            link: _ctx.onInputCancel,
                            class: "col-span-6 lg:col-span-3"
                        }, null, 8, ["label", "link"]),
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonPrimary, {
                            label: _ctx.t('common.label.save'),
                            link: _ctx.onInputSave,
                            class: "col-span-6 lg:col-span-3"
                        }, null, 8, ["label", "link"])
                    ])
                ]),
                _: 1
            }, 8, ["onClose"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (_ctx.showOutputModal)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_Modal, {
                key: 1,
                "full-width-on-mobile": "",
                onClose: _cache[1] || (_cache[1] = ($event) => (_ctx.showOutputModal = false))
            }, {
                header: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_7, [
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_8, [
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                                label: _ctx.t('wallet.send.builder.modal.output.label'),
                                "do-capitalize": false
                            }, null, 8, ["label"]),
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                                text: _ctx.t('wallet.send.builder.modal.output.caption')
                            }, null, 8, ["text"])
                        ])
                    ])
                ]),
                content: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_9, [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_OutputBuilder, {
                            onSubmit: _ctx.onOutputSave,
                            "output-counter": _ctx.outputCounter
                        }, null, 8, ["onSubmit", "output-counter"])
                    ])
                ]),
                _: 1
            }))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (_ctx.showDonationModal)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_Modal, {
                key: 2,
                narrow: "",
                "full-width-on-mobile": "",
                onClose: _ctx.onDonationHide
            }, {
                header: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_10, [
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_11, [
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                                label: _ctx.t('wallet.send.builder.modal.donation.label')
                            }, null, 8, ["label"]),
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                                text: _ctx.t('wallet.send.builder.modal.donation.caption')
                            }, null, 8, ["text"])
                        ])
                    ])
                ]),
                content: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_12, [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_AdaInput, {
                            "text-id": "wallet.send.builder.modal.donation",
                            "default-value": '1',
                            "min-lovelace": _ctx.minDonation,
                            "max-lovelace": _ctx.maxDonation,
                            onUpdate: _ctx.onDonationUpdate,
                            onSubmit: _ctx.onDonationSave
                        }, null, 8, ["min-lovelace", "max-lovelace", "onUpdate", "onSubmit"])
                    ])
                ]),
                footer: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_13, [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonSecondary, {
                            label: _ctx.t('common.label.cancel'),
                            link: _ctx.onDonationHide,
                            class: "col-start-0 col-span-4 lg:col-start-7 lg:col-span-3"
                        }, null, 8, ["label", "link"]),
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonPrimary, {
                            label: _ctx.t('common.label.add'),
                            link: _ctx.onDonationSave,
                            disabled: _ctx.donationInput === '0',
                            class: "col-span-4 lg:col-span-3"
                        }, null, 8, ["label", "link", "disabled"])
                    ])
                ]),
                _: 1
            }, 8, ["onClose"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (_ctx.showTTLModal)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_Modal, {
                key: 3,
                narrow: "",
                "full-width-on-mobile": "",
                onClose: _ctx.onTTLHide
            }, {
                header: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_14, [
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_15, [
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                                label: _ctx.t('wallet.send.builder.modal.ttl.label')
                            }, null, 8, ["label"]),
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                                text: _ctx.t('wallet.send.builder.modal.ttl.caption')
                            }, null, 8, ["text"])
                        ])
                    ])
                ]),
                content: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_TTLInput, {
                        onSubmit: _ctx.onTTLSave,
                        onUpdate: _ctx.onTTLUpdate,
                        "default-value": _ctx.ttlInput
                    }, null, 8, ["onSubmit", "onUpdate", "default-value"])
                ]),
                footer: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_16, [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonSecondary, {
                            label: _ctx.t('common.label.cancel'),
                            link: _ctx.onTTLHide,
                            class: "col-start-0 col-span-4 lg:col-start-7 lg:col-span-3"
                        }, null, 8, ["label", "link"]),
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonPrimary, {
                            label: _ctx.t('common.label.save'),
                            link: _ctx.onTTLSave,
                            class: "col-span-4 lg:col-span-3"
                        }, null, 8, ["label", "link"])
                    ])
                ]),
                _: 1
            }, 8, ["onClose"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (_ctx.showMetadataModal)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_Modal, {
                key: 4,
                narrow: "",
                "full-width-on-mobile": "",
                onClose: _ctx.onMetadataHide
            }, {
                header: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_17, [
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_18, [
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                                label: _ctx.t('wallet.send.builder.modal.metadata.label')
                            }, null, 8, ["label"]),
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                                text: _ctx.t('wallet.send.builder.modal.metadata.caption')
                            }, null, 8, ["text"])
                        ])
                    ])
                ]),
                content: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_19, [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_SendMetadataInput, {
                            "text-id": "wallet.send.step.metadata",
                            onSubmit: _ctx.onMetadataSave,
                            onUpdate: _ctx.onMetadataUpdate,
                            onEncrypt: _ctx.onMetadataEncrypt,
                            rows: 4,
                            "pre-filled-message": _ctx.metadata,
                            "pre-filled-encrypted": _ctx.encMetadata,
                            "pre-filled-password": _ctx.encPassword,
                            "show-only-input": "",
                            "start-expanded": ""
                        }, null, 8, ["onSubmit", "onUpdate", "onEncrypt", "pre-filled-message", "pre-filled-encrypted", "pre-filled-password"])
                    ])
                ]),
                footer: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_20, [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonSecondary, {
                            label: _ctx.t('common.label.cancel'),
                            link: _ctx.onMetadataHide,
                            class: "col-start-0 col-span-4 lg:col-start-7 lg:col-span-3"
                        }, null, 8, ["label", "link"]),
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonPrimary, {
                            label: _ctx.t('common.label.save'),
                            link: _ctx.onMetadataSave,
                            class: "col-span-4 lg:col-span-3"
                        }, null, 8, ["label", "link"])
                    ])
                ]),
                _: 1
            }, 8, ["onClose"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (_ctx.showMetadataLabelModal)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_Modal, {
                key: 5,
                narrow: "",
                "full-width-on-mobile": "",
                onClose: _ctx.onMetadataLabelHide
            }, {
                header: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_21, [
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_22, [
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                                label: _ctx.t('wallet.send.builder.modal.metadataLabel.label')
                            }, null, 8, ["label"]),
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                                text: _ctx.t('wallet.send.builder.modal.metadataLabel.caption')
                            }, null, 8, ["text"])
                        ])
                    ])
                ]),
                content: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_23, [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_SendMetadataLabelInput, {
                            "text-id": "wallet.send.step.metadata",
                            onSubmit: _ctx.onMetadataLabelSave,
                            onUpdate: _ctx.onMetadataLabelUpdate,
                            onLabelUpdate: _ctx.onMetadataLabelKeyUpdate,
                            onError: _cache[2] || (_cache[2] = ($event) => (_ctx.metadataLabelValid = false)),
                            rows: 4,
                            "pre-filled-message": _ctx.metadataLabel,
                            "show-only-input": "",
                            "start-expanded": ""
                        }, null, 8, ["onSubmit", "onUpdate", "onLabelUpdate", "pre-filled-message"])
                    ]),
                    (_ctx.hasMetadataLabel)
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridTextArea, {
                            key: 0,
                            text: _ctx.t('wallet.send.builder.modal.metadataLabel.labelexist'),
                            icon: "mdi mdi-alert-octagon-outline",
                            class: "col-span-12 mb-2",
                            "text-c-s-s": "cc-text-normal text-justify flex justify-start items-center",
                            css: "cc-rounded cc-banner-warning"
                        }, null, 8, ["text"]))
                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                ]),
                footer: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_24, [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonSecondary, {
                            label: _ctx.t('common.label.cancel'),
                            link: _ctx.onMetadataLabelHide,
                            class: "col-start-0 col-span-4 lg:col-start-7 lg:col-span-3"
                        }, null, 8, ["label", "link"]),
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonPrimary, {
                            label: _ctx.hasMetadataLabel ? _ctx.t('common.label.overwrite') : _ctx.t('common.label.save'),
                            link: _ctx.onMetadataLabelSave,
                            disabled: !_ctx.metadataLabelValid,
                            class: "col-span-4 lg:col-span-3"
                        }, null, 8, ["label", "link", "disabled"])
                    ])
                ]),
                _: 1
            }, 8, ["onClose"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
    ]));
}

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/send/SendBuilder.vue?vue&type=template&id=2f904fcc&ts=true

// EXTERNAL MODULE: ./node_modules/quasar/src/composables/use-quasar.js
var use_quasar = __webpack_require__(48825);
// EXTERNAL MODULE: ./src/composables/ccw/store/useFormatter.ts
var useFormatter = __webpack_require__(16938);
// EXTERNAL MODULE: ./src/components/ccw/modal/Modal.vue + 4 modules
var Modal = __webpack_require__(61017);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/send/builder/OutputBuilder.vue?vue&type=template&id=29ada7eb&ts=true

function OutputBuildervue_type_template_id_29ada7eb_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_SendAddrInput = (0,runtime_core_esm_bundler/* resolveComponent */.up)("SendAddrInput");
    const _component_GridButtonSecondary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonSecondary");
    const _component_SendAssetsInput = (0,runtime_core_esm_bundler/* resolveComponent */.up)("SendAssetsInput");
    const _component_GridSteps = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSteps");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridSteps, {
        onBack: _ctx.goBack,
        steps: _ctx.optionsSteps,
        currentStep: _ctx.currentStep,
        "small-c-s-s": "pr-9 sm:pr-20 md:pr-18 lg:pr-32"
    }, {
        step0: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_SendAddrInput, {
                onSubmit: _ctx.onAddressInput,
                "text-id": "wallet.send.step.receiveAddr",
                "allow-message": false,
                "prefilled-address": _ctx.output.paymentAddr.bech32,
                "show-account-list": ""
            }, null, 8, ["onSubmit", "prefilled-address"])
        ]),
        step1: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
            (_ctx.activeAccount && _ctx.activeWalletData)
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_SendAssetsInput, {
                    key: 0,
                    onSubmit: _ctx.onOutputDone,
                    onOutputUpdate: _ctx.onOutputUpdate,
                    onOutputValid: _ctx.onOutputBuilt,
                    account: _ctx.activeAccount,
                    wallet: _ctx.activeWalletData,
                    "send-all-enabled": _ctx.activeWalletEnabledSendAll,
                    "enabled-collateral": _ctx.activeWalletEnabledCollateral,
                    previousStep: _ctx.previousStep,
                    "staging-output": _ctx.output,
                    "send-options-enabled": false,
                    "next-label": _ctx.t('common.label.add'),
                    "text-id": "wallet.send.step.assets"
                }, {
                    btnBack: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonSecondary, {
                            label: _ctx.t('common.label.back'),
                            link: _ctx.goBack,
                            class: "col-start-0 col-span-6 lg:col-start-7 lg:col-span-3"
                        }, null, 8, ["label", "link"])
                    ]),
                    _: 1
                }, 8, ["onSubmit", "onOutputUpdate", "onOutputValid", "account", "wallet", "send-all-enabled", "enabled-collateral", "previousStep", "staging-output", "next-label"]))
                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
        ]),
        _: 1
    }, 8, ["onBack", "steps", "currentStep"]));
}

;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/send/builder/OutputBuilder.vue?vue&type=script&lang=ts














/* harmony default export */ const OutputBuildervue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'OutputBuilder',
    components: {
        GridSpace: GridSpace/* default */.Z,
        GridHeadline: GridHeadline/* default */.Z,
        GridText: GridText/* default */.Z,
        GridTextArea: GridTextArea/* default */.Z,
        GridSteps: GridSteps/* default */.Z,
        GridButtonPrimary: GridButtonPrimary/* default */.Z,
        GridButtonSecondary: GridButtonSecondary/* default */.Z,
        SendAddrInput: SendAddrInput/* default */.Z,
        SendAssetsInput: SendAssetsInput/* default */.Z
    },
    props: {
        outputCounter: { type: Number, required: true },
    },
    emits: ['submit'],
    setup(props, { emit }) {
        const { t } = (0,useTranslation/* useTranslation */.$)();
        const { activeWalletEnabledSendAll, activeWalletEnabledCollateral, activeWalletData, activeAccount } = (0,useActiveWallet/* useActiveWallet */.r)();
        const { addOutput, getStagingTx } = (0,useBuildTx_v3/* useBuildTxV3 */.b)();
        const currentStep = (0,reactivity_esm_bundler/* ref */.iH)(0);
        const previousStep = (0,reactivity_esm_bundler/* ref */.iH)(0);
        const output = (0,reactivity_esm_bundler/* ref */.iH)((0,ITxOut/* createITxOut */.jO)());
        const counter = (0,reactivity_esm_bundler/* ref */.iH)(0);
        (0,runtime_core_esm_bundler/* watch */.YP)(() => props.outputCounter, (newValue) => {
            if (newValue > counter.value) {
                output.value = (0,ITxOut/* createITxOut */.jO)();
            }
        });
        (0,runtime_core_esm_bundler/* onErrorCaptured */.d1)((e) => { console.error('Wallet: Send: onErrorCaptured', e); return true; });
        const optionsSteps = (0,reactivity_esm_bundler/* reactive */.qj)([
            { id: 'receiveAddr', label: t('wallet.send.step.stepper.receiveAddr') },
            { id: 'assets', label: t('wallet.send.step.stepper.assets') }
        ]);
        function goBack() {
            previousStep.value = currentStep.value;
            currentStep.value = 0;
            output.value.output = '0';
            output.value.tokenList.splice(0);
        }
        function onAddressInput(receiverAddr) {
            previousStep.value = currentStep.value;
            currentStep.value = 1;
            output.value.paymentAddr.bech32 = receiverAddr;
        }
        function onOutputDone() {
            if (!activeAccount.value) {
                return;
            }
            addOutput(activeAccount.value, output.value);
            emit('submit');
        }
        function onOutputUpdate(out) {
            if (!activeAccount.value) {
                return;
            }
            addOutput(activeAccount.value, out);
            output.value = out;
        }
        function onOutputBuilt(valid) {
            if (!activeAccount.value) {
                return;
            }
            getStagingTx(activeAccount.value.pub).outputList.pop();
        }
        return {
            t,
            output,
            activeWalletData,
            activeAccount,
            activeWalletEnabledSendAll,
            activeWalletEnabledCollateral,
            optionsSteps,
            currentStep,
            previousStep,
            goBack,
            onAddressInput,
            onOutputDone,
            onOutputUpdate,
            onOutputBuilt
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/send/builder/OutputBuilder.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/send/builder/OutputBuilder.vue




;
const OutputBuilder_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(OutputBuildervue_type_script_lang_ts, [['render',OutputBuildervue_type_template_id_29ada7eb_ts_true_render]])

/* harmony default export */ const OutputBuilder = (OutputBuilder_exports_);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/send/builder/TTLInput.vue?vue&type=template&id=c907e92a&ts=true

function TTLInputvue_type_template_id_c907e92a_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridInput = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridInput");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridInput, {
        class: "col-span-12 py-4 px-2",
        "input-text": _ctx.ttlInputText,
        "onUpdate:input-text": _cache[0] || (_cache[0] = ($event) => ((_ctx.ttlInputText) = $event)),
        "input-error": _ctx.ttlInputError,
        "onUpdate:input-error": _cache[1] || (_cache[1] = ($event) => ((_ctx.ttlInputError) = $event)),
        "onUpdate:inputText": _ctx.validateTTLInput,
        onEnter: _ctx.onSubmit,
        onReset: _ctx.onReset,
        "input-hint": _ctx.t('common.label.minutes'),
        "show-reset": true,
        "manual-update": _ctx.manualUpdate,
        autofocus: "",
        autocomplete: "off",
        "input-id": "inputTTL",
        "input-type": "text"
    }, null, 8, ["input-text", "input-error", "onUpdate:inputText", "onEnter", "onReset", "input-hint", "manual-update"]));
}

// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridInput.vue + 4 modules
var GridInput = __webpack_require__(27209);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/send/builder/TTLInput.vue?vue&type=script&lang=ts



/* harmony default export */ const TTLInputvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'TTLInput',
    components: {
        GridInput: GridInput/* default */.Z
    },
    props: {
        defaultValue: { type: Number, required: false, default: 180 }
    },
    emits: ['submit', 'update'],
    setup(props, { emit }) {
        const { t } = (0,useTranslation/* useTranslation */.$)();
        const ttlInputText = (0,reactivity_esm_bundler/* ref */.iH)(props.defaultValue + '');
        const ttlInputError = (0,reactivity_esm_bundler/* ref */.iH)('');
        const manualUpdate = (0,reactivity_esm_bundler/* ref */.iH)(0);
        const onReset = () => {
            ttlInputText.value = props.defaultValue + '';
            ttlInputError.value = '';
        };
        const onSubmit = () => {
            if (ttlInputText.value.length > 0 && ttlInputError.value.length === 0) {
                emit('submit');
            }
        };
        function validateTTLInput(value) {
            ttlInputError.value = '';
            const digits = value.replace(/[^0-9.]/g, '');
            if (digits.length > 0 && parseInt(digits) < 1 || parseInt(digits) > 525600) {
                ttlInputError.value = t('wallet.send.builder.modal.ttl.invalid');
            }
            ttlInputText.value = digits;
            manualUpdate.value = manualUpdate.value + 1;
            if (ttlInputText.value.length > 0 && ttlInputError.value.length === 0) {
                emit('update', parseInt(ttlInputText.value));
            }
        }
        return {
            t,
            ttlInputText,
            ttlInputError,
            manualUpdate,
            onReset,
            onSubmit,
            validateTTLInput
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/send/builder/TTLInput.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/send/builder/TTLInput.vue




;
const TTLInput_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(TTLInputvue_type_script_lang_ts, [['render',TTLInputvue_type_template_id_c907e92a_ts_true_render]])

/* harmony default export */ const TTLInput = (TTLInput_exports_);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/stakingvault/AdaInput.vue + 4 modules
var AdaInput = __webpack_require__(85495);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/send/SendMetadataInput.vue + 4 modules
var SendMetadataInput = __webpack_require__(8794);
// EXTERNAL MODULE: ./node_modules/@vue/runtime-dom/dist/runtime-dom.esm-bundler.js
var runtime_dom_esm_bundler = __webpack_require__(98880);
// EXTERNAL MODULE: ./node_modules/@vue/shared/dist/shared.esm-bundler.js
var shared_esm_bundler = __webpack_require__(62323);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/send/SendMetadataLabelInput.vue?vue&type=template&id=7e840694&ts=true

const SendMetadataLabelInputvue_type_template_id_7e840694_ts_true_hoisted_1 = {
    key: 2,
    class: "col-span-12 grid grid-cols-12 cc-gap"
};
function SendMetadataLabelInputvue_type_template_id_7e840694_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    const _component_GridHeadline = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridHeadline");
    const _component_GridText = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridText");
    const _component_IconPencil = (0,runtime_core_esm_bundler/* resolveComponent */.up)("IconPencil");
    const _component_GridInput = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridInput");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, [
        (!_ctx.showOnlyInput)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridSpace, {
                key: 0,
                hr: "",
                class: "col-span-12 my-0.5"
            }))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (!_ctx.showOnlyInput)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", {
                key: 1,
                class: "col-span-12 flex flex-row flex-nowrap items-center cursor-pointer",
                onClick: _cache[0] || (_cache[0] = (0,runtime_dom_esm_bundler/* withModifiers */.iM)(($event) => (_ctx.showMessageInput = !_ctx.showMessageInput), ["stop"]))
            }, [
                (0,runtime_core_esm_bundler/* createElementVNode */._)("i", {
                    class: (0,shared_esm_bundler/* normalizeClass */.C_)(["relative text-xl mr-1", _ctx.showMessageInput ? 'mdi mdi-chevron-down' : 'mdi mdi-chevron-right'])
                }, null, 2),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                    label: _ctx.t(_ctx.textId + '.label'),
                    class: "w-full"
                }, null, 8, ["label"])
            ]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (_ctx.showMessageInput)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", SendMetadataLabelInputvue_type_template_id_7e840694_ts_true_hoisted_1, [
                (!_ctx.showOnlyInput)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridText, {
                        key: 0,
                        text: _ctx.t(_ctx.textId + '.caption'),
                        class: "col-span-12 cc-text-sz"
                    }, null, 8, ["text"]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridInput, {
                    "input-text": _ctx.metaLabelInput,
                    "onUpdate:input-text": _cache[1] || (_cache[1] = ($event) => ((_ctx.metaLabelInput) = $event)),
                    "input-error": _ctx.metaLabelInputError,
                    "onUpdate:input-error": _cache[2] || (_cache[2] = ($event) => ((_ctx.metaLabelInputError) = $event)),
                    "onUpdate:inputText": _ctx.validateLabelInput,
                    onEnter: _ctx.onSubmit,
                    onReset: _ctx.onReset,
                    class: "col-span-12",
                    "multiline-input": false,
                    "input-hint": _ctx.t(_ctx.textId + '.hintLabel'),
                    alwaysShowInfo: false,
                    showReset: true,
                    autofocus: "",
                    "input-id": "inputMetadataLabel",
                    "input-type": "text"
                }, {
                    "icon-prepend": (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_IconPencil, { class: "h-5 w-5" })
                    ]),
                    _: 1
                }, 8, ["input-text", "input-error", "onUpdate:inputText", "onEnter", "onReset", "input-hint"]),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridInput, {
                    "input-text": _ctx.metaInput,
                    "onUpdate:input-text": _cache[3] || (_cache[3] = ($event) => ((_ctx.metaInput) = $event)),
                    "input-error": _ctx.metaInputError,
                    "onUpdate:input-error": _cache[4] || (_cache[4] = ($event) => ((_ctx.metaInputError) = $event)),
                    "onUpdate:inputText": _ctx.validateMessageInput,
                    onEnter: _ctx.onSubmit,
                    onReset: _ctx.onReset,
                    class: "col-span-12",
                    "multiline-input": true,
                    rows: _ctx.rows,
                    "input-hint": _ctx.t(_ctx.textId + '.hintJson'),
                    alwaysShowInfo: false,
                    showReset: true,
                    "input-id": "inputMetadata",
                    "input-type": "text"
                }, {
                    "icon-prepend": (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_IconPencil, { class: "h-5 w-5" })
                    ]),
                    _: 1
                }, 8, ["input-text", "input-error", "onUpdate:inputText", "onEnter", "onReset", "rows", "input-hint"])
            ]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
    ], 64));
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/send/SendMetadataLabelInput.vue?vue&type=template&id=7e840694&ts=true

// EXTERNAL MODULE: ./src/components/ccw/grid/v2/icons/IconPencil.vue + 4 modules
var IconPencil = __webpack_require__(44814);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/send/SendMetadataLabelInput.vue?vue&type=script&lang=ts








/* harmony default export */ const SendMetadataLabelInputvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'SendMetadataLabelInput',
    components: {
        IconPencil: IconPencil/* default */.Z,
        GridHeadline: GridHeadline/* default */.Z,
        GridText: GridText/* default */.Z,
        GridSpace: GridSpace/* default */.Z,
        GridInput: GridInput/* default */.Z
    },
    props: {
        textId: { type: String, required: true, default: '' },
        preFilledLabel: { type: String, required: false, default: '' },
        preFilledMessage: { type: Array, required: false, default: [] },
        startExpanded: { type: Boolean, required: false },
        showOnlyInput: { type: Boolean, required: false, default: false },
        rows: { type: Number, required: false },
    },
    emits: ['submit', 'update', 'labelUpdate', 'error'],
    setup(props, { emit }) {
        const { t } = (0,useTranslation/* useTranslation */.$)();
        const metaLabelInput = (0,reactivity_esm_bundler/* ref */.iH)(props.preFilledLabel ?? '');
        const metaLabelInputError = (0,reactivity_esm_bundler/* ref */.iH)('');
        const metaInput = (0,reactivity_esm_bundler/* ref */.iH)(props.preFilledMessage?.join('\n') ?? '');
        const metaInputError = (0,reactivity_esm_bundler/* ref */.iH)('');
        const showMessageInput = (0,reactivity_esm_bundler/* ref */.iH)(props.startExpanded ? props.startExpanded : metaInput.value.length > 0);
        function validateLabelInput(value) {
            metaInputError.value = '';
            metaLabelInput.value = value;
            try {
                if (Number.isNaN(parseInt(metaLabelInput.value))) {
                    throw new Error('Label is not a valid number.');
                }
                const label = parseInt(metaLabelInput.value);
                if (label < 0 || label > 65536) {
                    throw new Error('Label out of range (0 - 65536).');
                }
                emit('labelUpdate', metaLabelInput.value);
                if (metaInput.value.length > 0) {
                    validateMessageInput(metaInput.value);
                }
            }
            catch (err) {
                metaInputError.value = err.message;
                emit('error', err.message);
            }
        }
        function validateMessageInput(value) {
            metaInputError.value = '';
            metaInput.value = value;
            try {
                if (Number.isNaN(parseInt(metaLabelInput.value))) {
                    throw new Error('Label is not a valid number.');
                }
                const label = parseInt(metaLabelInput.value);
                if (label < 0 || label > 65536) {
                    throw new Error('Label out of range (0 - 65536).');
                }
                (0,CSLUtils/* getTxMetadataFromJson */.De)(metaInput.value.length > 0 ? metaInput.value : '{}', label);
                emit('update', [metaLabelInput.value, metaInput.value]);
            }
            catch (err) {
                metaInputError.value = err.message;
                emit('error', err.message);
            }
        }
        function onReset() {
            metaLabelInput.value = '';
            metaLabelInputError.value = '';
            metaInput.value = '';
            metaInputError.value = '';
            emit('update', []);
        }
        function onSubmit() {
            if (metaLabelInputError.value.length === 0 && metaInputError.value.length === 0) {
                emit('submit');
            }
        }
        return {
            t,
            showMessageInput,
            metaLabelInput,
            metaLabelInputError,
            metaInput,
            metaInputError,
            validateLabelInput,
            validateMessageInput,
            onReset,
            onSubmit
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/send/SendMetadataLabelInput.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/send/SendMetadataLabelInput.vue




;
const SendMetadataLabelInput_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(SendMetadataLabelInputvue_type_script_lang_ts, [['render',SendMetadataLabelInputvue_type_template_id_7e840694_ts_true_render]])

/* harmony default export */ const SendMetadataLabelInput = (SendMetadataLabelInput_exports_);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/send/SendConfirmList.vue?vue&type=template&id=97a9e756&ts=true

const SendConfirmListvue_type_template_id_97a9e756_ts_true_hoisted_1 = {
    key: 4,
    class: "col-span-12 grid grid-cols-12 cc-gap"
};
const SendConfirmListvue_type_template_id_97a9e756_ts_true_hoisted_2 = {
    key: 5,
    class: "col-span-12 grid grid-cols-12 cc-gap"
};
const SendConfirmListvue_type_template_id_97a9e756_ts_true_hoisted_3 = { class: "col-span-12 flex flex-row flex-nowrap items-center whitespace-pre-wrap cc-text-sz" };
const SendConfirmListvue_type_template_id_97a9e756_ts_true_hoisted_4 = {
    key: 6,
    class: "col-span-12 grid grid-cols-12"
};
function SendConfirmListvue_type_template_id_97a9e756_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridHeadline = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridHeadline");
    const _component_GridText = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridText");
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    const _component_GridFormSignWithPassword = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridFormSignWithPassword");
    const _component_IconInfo = (0,runtime_core_esm_bundler/* resolveComponent */.up)("IconInfo");
    const _component_IconError = (0,runtime_core_esm_bundler/* resolveComponent */.up)("IconError");
    const _component_LedgerTransport = (0,runtime_core_esm_bundler/* resolveComponent */.up)("LedgerTransport");
    const _component_GridButtonPrimary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonPrimary");
    const _component_GridTextArea = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridTextArea");
    const _component_GridTxListEntry = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridTxListEntry");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, [
        (_ctx.showLabel)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridHeadline, {
                key: 0,
                label: _ctx.t(_ctx.textId + '.label'),
                class: "col-span-12"
            }, null, 8, ["label"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (_ctx.showLabel)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridText, {
                key: 1,
                text: _ctx.t(_ctx.textId + '.caption'),
                class: "col-span-12 cc-text-sz"
            }, null, 8, ["text"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (_ctx.showLabel)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridSpace, {
                key: 2,
                hr: "",
                class: "col-span-12 my-0.5 sm:mt-2"
            }))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (!_ctx.isConfirmed && _ctx.isMnemonic)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridFormSignWithPassword, {
                key: 3,
                onSubmit: _ctx.onSubmitPassword,
                class: "col-span-12",
                autocomplete: "off",
                "skip-validation": ""
            }, {
                btnBack: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                    (0,runtime_core_esm_bundler/* renderSlot */.WI)(_ctx.$slots, "btnBack")
                ]),
                _: 3
            }, 8, ["onSubmit"]))
            : (_ctx.isReadOnly)
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", SendConfirmListvue_type_template_id_97a9e756_ts_true_hoisted_1, [
                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                        text: _ctx.t(_ctx.textId + '.info.readonly')
                    }, null, 8, ["text"])
                ]))
                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        ((_ctx.isLedger || _ctx.isTrezor || _ctx.signError.length > 0) && !_ctx.isConfirmed)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", SendConfirmListvue_type_template_id_97a9e756_ts_true_hoisted_2, [
                (_ctx.signError.length > 0 && _ctx.isMnemonic)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridSpace, {
                        key: 0,
                        class: "col-span-12 mt-2 sm:mt-4"
                    }))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SendConfirmListvue_type_template_id_97a9e756_ts_true_hoisted_3, [
                    (_ctx.signError.length === 0)
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_IconInfo, {
                            key: 0,
                            class: "w-7 flex-none mr-2"
                        }))
                        : ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_IconError, {
                            key: 1,
                            class: "w-7 flex-none mr-2"
                        })),
                    (_ctx.signError.length === 0)
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridText, {
                            key: 2,
                            text: _ctx.t(_ctx.textId + '.info' + (_ctx.isLedger ? '.ledger' : '.trezor'))
                        }, null, 8, ["text"]))
                        : ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridText, {
                            key: 3,
                            text: _ctx.signError
                        }, null, 8, ["text"]))
                ])
            ]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (_ctx.isLedger && !_ctx.isConfirmed && _ctx.hasWebUSB)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", SendConfirmListvue_type_template_id_97a9e756_ts_true_hoisted_4, [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, { hr: "" }),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_LedgerTransport),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, {
                    hr: "",
                    class: "mb-2"
                })
            ]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (_ctx.isLedger || _ctx.isTrezor)
            ? (0,runtime_core_esm_bundler/* renderSlot */.WI)(_ctx.$slots, "btnBack", { key: 7 })
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (!_ctx.isConfirmed && (_ctx.isLedger || _ctx.isTrezor))
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridButtonPrimary, {
                key: 8,
                label: _ctx.t(_ctx.textId + '.button.sign'),
                link: _ctx.signTx,
                class: "col-start-7 col-span-6 sm:col-start-10 sm:col-span-3"
            }, null, 8, ["label", "link"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (_ctx.isConfirmed && !_ctx.autoSubmit)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridButtonPrimary, {
                key: 9,
                label: _ctx.t(_ctx.textId + '.button.submit'),
                link: _ctx.submit,
                class: "col-start-7 col-span-6 sm:col-start-10 sm:col-span-3"
            }, null, 8, ["label", "link"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (!_ctx.isSubmitted)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridButtonPrimary, {
                key: 10,
                label: _ctx.t(_ctx.textId + '.button.download'),
                link: _ctx.onDownload,
                class: "col-start-7 col-span-6 sm:col-start-10 sm:col-span-3"
            }, null, 8, ["label", "link"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (_ctx.isSubmitted)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridTextArea, {
                key: 11,
                text: _ctx.t(_ctx.textId + '.info.submitList'),
                icon: 'mdi mdi-update',
                class: "col-span-12 mt-2",
                "text-c-s-s": "cc-text-normal text-justify flex justify-start items-center",
                css: "cc-rounded cc-banner-green"
            }, null, 8, ["text"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (!_ctx.isConfirmed)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridSpace, {
                key: 12,
                hr: "",
                class: "col-span-12 my-0.5 sm:my-2"
            }))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (!_ctx.isConfirmed)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridHeadline, {
                key: 13,
                label: _ctx.t(_ctx.textId + '.preview.label'),
                class: "col-span-12"
            }, null, 8, ["label"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (!_ctx.isConfirmed)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridText, {
                key: 14,
                text: _ctx.t(_ctx.textId + '.preview.caption'),
                class: "col-span-12 cc-text-sz"
            }, null, 8, ["text"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (_ctx.usesLockedUTxO)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridTextArea, {
                key: 15,
                class: "col-span-12",
                css: "cc-rounded cc-banner-warning",
                dense: "",
                text: _ctx.t('wallet.send.locked.caption'),
                icon: "mdi mdi-information-outline"
            }, null, 8, ["text"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (!_ctx.isSubmitted && _ctx.unsignedTxList.length > 0)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(true), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, { key: 16 }, (0,runtime_core_esm_bundler/* renderList */.Ko)(_ctx.unsignedTxList, (item) => {
                return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridTxListEntry, {
                    key: item.txHash,
                    tx: item,
                    wallet: _ctx.wallet,
                    "network-id": _ctx.wallet.network,
                    onExpired: _cache[0] || (_cache[0] = ($event) => (_ctx.isExpired = true)),
                    "hide-divider": false,
                    "always-open": "",
                    "staging-tx": ""
                }, null, 8, ["tx", "wallet", "network-id"]));
            }), 128))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
    ], 64));
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/send/SendConfirmList.vue?vue&type=template&id=97a9e756&ts=true

// EXTERNAL MODULE: ./src/composables/ccw/useDownload.ts
var useDownload = __webpack_require__(22510);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/icons/IconInfo.vue + 4 modules
var IconInfo = __webpack_require__(31599);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/icons/IconCheck.vue + 4 modules
var IconCheck = __webpack_require__(59548);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/icons/IconError.vue + 4 modules
var IconError = __webpack_require__(66934);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/icons/IconLockClosed.vue + 4 modules
var IconLockClosed = __webpack_require__(18807);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/txlist/GridTxListEntry.vue + 79 modules
var GridTxListEntry = __webpack_require__(55075);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/forms/GridFormSignWithPassword.vue + 3 modules
var GridFormSignWithPassword = __webpack_require__(58315);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/settings/LedgerTransport.vue + 4 modules
var LedgerTransport = __webpack_require__(44844);
// EXTERNAL MODULE: ./src/lib/utils/useAppMode.ts
var useAppMode = __webpack_require__(4254);
// EXTERNAL MODULE: ./src/lib/utils/useLocalStorage.ts
var useLocalStorage = __webpack_require__(34787);
// EXTERNAL MODULE: ./src/lib/utils/TxCheck.ts
var TxCheck = __webpack_require__(17563);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/send/SendConfirmList.vue?vue&type=script&lang=ts

;





















/* harmony default export */ const SendConfirmListvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'SendConfirmList',
    components: {
        GridFormSignWithPassword: GridFormSignWithPassword/* default */.Z,
        GridTxListEntry: GridTxListEntry/* default */.Z,
        GridHeadline: GridHeadline/* default */.Z,
        GridText: GridText/* default */.Z,
        GridTextArea: GridTextArea/* default */.Z,
        GridSpace: GridSpace/* default */.Z,
        GridInput: GridInput/* default */.Z,
        GridButtonSecondary: GridButtonSecondary/* default */.Z,
        GridButtonPrimary: GridButtonPrimary/* default */.Z,
        IconInfo: IconInfo/* default */.Z,
        IconCheck: IconCheck/* default */.Z,
        IconError: IconError/* default */.Z,
        IconLockClosed: IconLockClosed/* default */.Z,
        LedgerTransport: LedgerTransport/* default */.Z
    },
    props: {
        type: { type: String, required: false, default: '' },
        textId: { type: String, required: true, default: '' },
        showLabel: { type: Boolean, required: false, default: true },
        account: { type: Object, required: true },
        wallet: { type: Object, required: false, default: null },
        unsignedTxList: { type: Array, required: true }
    },
    emits: ['submit'],
    setup(props, { emit }) {
        const { t } = (0,useTranslation/* useTranslation */.$)();
        const { gotoWalletPage } = (0,useNavigation/* useNavigation */.HJ)();
        const { downloadText } = (0,useDownload/* useDownload */.i)();
        const { getTxSerialized, getTxHash } = (0,useBuildTx_v3/* useBuildTxV3 */.b)();
        const $q = (0,use_quasar/* default */.Z)();
        const isMnemonic = props.account.signType === 'mnemonic' ?? false;
        const isLedger = props.account.signType === 'ledger' ?? false;
        const isTrezor = props.account.signType === 'trezor' ?? false;
        const isReadOnly = props.account.signType === 'readonly' ?? false;
        const isConfirmed = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const isExpired = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const isSubmitted = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const autoSubmit = (0,reactivity_esm_bundler/* ref */.iH)((0,useLocalStorage/* getAutoSubmit */.fi)());
        const usesLockedUTxO = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const { confirmTx, submitTx } = (0,useBuildTx_v3/* useBuildTxV3 */.b)();
        const spendingPassword = (0,reactivity_esm_bundler/* ref */.iH)('');
        const signError = (0,reactivity_esm_bundler/* ref */.iH)('');
        (0,runtime_core_esm_bundler/* watch */.YP)(spendingPassword, () => signError.value = '');
        (0,runtime_core_esm_bundler/* onBeforeMount */.wF)(() => {
            usesLockedUTxO.value = (0,TxCheck/* checkInputsForHash */.c)(props.unsignedTxList, props.account.lockedUtxoHashList);
        });
        async function sendTx(index) {
            if (!props.account) {
                return null;
            }
            submitTx(props.account.network, props.account.pub, index);
        }
        async function signTx() {
            if (!props.account) {
                return null;
            }
            for (let i = 0; i < props.unsignedTxList.length; i++) {
                const confirmRes = await confirmTx(props.account, spendingPassword.value, i, i < props.unsignedTxList.length - 1);
                signError.value = confirmRes.error;
                if (isLedger || isTrezor) {
                    $q.loading.hide();
                }
                if (signError.value.length === 0) {
                    isConfirmed.value = true;
                }
                else {
                    $q.notify({
                        type: 'negative',
                        message: (signError.value),
                        position: 'top-left',
                        timeout: 10000
                    });
                }
            }
            if (isConfirmed.value && autoSubmit.value) {
                setTimeout(() => { submit(); }, 5);
            }
        }
        const submit = () => {
            if (!props.account) {
                return null;
            }
            for (let i = 0; i < props.unsignedTxList.length; i++) {
                if (isConfirmed.value && !isExpired.value) {
                    sendTx(i);
                    isSubmitted.value = true;
                }
                else {
                    $q.notify({
                        type: 'negative',
                        message: (signError.value),
                        position: 'top-left',
                        timeout: 10000
                    });
                }
            }
            setTimeout(() => {
                gotoWalletPage('Transactions', 'pending');
            }, 4000);
        };
        async function onSubmitPassword(payload) {
            spendingPassword.value = payload.password;
            signTx();
        }
        function onDownload() {
            const fileContent = [];
            const description = isConfirmed.value ? 'signed' : 'unsigned';
            for (let txIndex = 0; txIndex < props.unsignedTxList.length; txIndex++) {
                const txHash = getTxHash(props.account.pub, txIndex);
                const txCbor = getTxSerialized(props.account.pub, txIndex);
                if (txCbor && txHash) {
                    const content = {
                        type: 'Tx MaryEra',
                        description: description,
                        hash: txHash,
                        cborHex: txCbor
                    };
                    fileContent.push(content);
                }
            }
            downloadText(JSON.stringify(fileContent, null, 2), 'eternl-tx-' + fileContent.reduce((carry, element) => element.hash + carry + '_', '') + description + '.txt');
        }
        return {
            t,
            isMnemonic,
            isLedger,
            isTrezor,
            isReadOnly,
            isConfirmed,
            isExpired,
            usesLockedUTxO,
            hasWebUSB: useAppMode/* hasWebUSB */.d$,
            spendingPassword,
            signError,
            signTx,
            submit,
            onSubmitPassword,
            onDownload,
            isSubmitted,
            autoSubmit
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/send/SendConfirmList.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/send/SendConfirmList.vue




;
const SendConfirmList_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(SendConfirmListvue_type_script_lang_ts, [['render',SendConfirmListvue_type_template_id_97a9e756_ts_true_render]])

/* harmony default export */ const SendConfirmList = (SendConfirmList_exports_);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/summary/GridAccountUtxoList.vue + 4 modules
var GridAccountUtxoList = __webpack_require__(10329);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridButtonAbort.vue + 3 modules
var GridButtonAbort = __webpack_require__(57504);
// EXTERNAL MODULE: ./src/components/ccw/common/Checkbox.vue + 3 modules
var Checkbox = __webpack_require__(75620);
// EXTERNAL MODULE: ./src/lib/utils/AccountUTxOLists.ts
var AccountUTxOLists = __webpack_require__(97083);
// EXTERNAL MODULE: ../ccw-lib2/core/INetwork.ts
var INetwork = __webpack_require__(34234);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/ChainLib.ts
var ChainLib = __webpack_require__(48011);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/tx/TxBasicUtils.ts
var TxBasicUtils = __webpack_require__(31837);
// EXTERNAL MODULE: ../ccw-lib2/core/IKeys.ts
var IKeys = __webpack_require__(41822);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/BigMathLib.ts + 1 modules
var BigMathLib = __webpack_require__(99149);
// EXTERNAL MODULE: ./src/lib/utils/MessageEncryption.ts
var MessageEncryption = __webpack_require__(27364);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/send/SendBuilder.vue?vue&type=script&lang=ts

;

































/* harmony default export */ const SendBuildervue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'SendBuilder',
    components: {
        OutputBuilder: OutputBuilder,
        TTLInput: TTLInput,
        AdaInput: AdaInput/* default */.Z,
        SendMetadataInput: SendMetadataInput/* default */.Z,
        SendMetadataLabelInput: SendMetadataLabelInput,
        SendConfirmList: SendConfirmList,
        SendSubmit: SendSubmit/* default */.Z,
        GridSteps: GridSteps/* default */.Z,
        GridAccountUtxoList: GridAccountUtxoList/* default */.Z,
        GridSpace: GridSpace/* default */.Z,
        GridHeadline: GridHeadline/* default */.Z,
        GridText: GridText/* default */.Z,
        GridTextArea: GridTextArea/* default */.Z,
        GridButtonPrimary: GridButtonPrimary/* default */.Z,
        GridButtonSecondary: GridButtonSecondary/* default */.Z,
        GridButtonAbort: GridButtonAbort/* default */.Z,
        GridTxListEntry: GridTxListEntry/* default */.Z,
        Checkbox: Checkbox/* default */.Z,
        Modal: Modal/* default */.Z
    },
    setup() {
        const $q = (0,use_quasar/* default */.Z)();
        const { t } = (0,useTranslation/* useTranslation */.$)();
        const { gotoWalletPage } = (0,useNavigation/* useNavigation */.HJ)();
        const { activeWalletEnabledCollateral, defaultToAdvancedUTxOManagement, activeWalletData, activeAccount } = (0,useActiveWallet/* useActiveWallet */.r)();
        const { resetBuildTx, getBuildStatus, getStagingTx, getBuiltTx, getBuiltTxList, buildSendTx, addOutput, addMetadata, setForceWithdrawal, setAllowUtxoManagement, buildCleanUpAccountTxList, buildCollectUTxOsList } = (0,useBuildTx_v3/* useBuildTxV3 */.b)();
        const { formatADAString, getDecimalNumber } = (0,useFormatter/* useFormatter */.G)();
        resetBuildTx(activeAccount.value?.pub ?? null);
        const inputList = (0,reactivity_esm_bundler/* ref */.iH)([]);
        const _inputList = [];
        const outputCounter = (0,reactivity_esm_bundler/* ref */.iH)(0);
        const ttlInput = (0,reactivity_esm_bundler/* ref */.iH)(0);
        const donationInput = (0,reactivity_esm_bundler/* ref */.iH)('0');
        const decimalNumber = getDecimalNumber((0,INetwork/* getNetworkDecimals */.cJ)(activeAccount.value?.network ?? null));
        const minDonation = BigMathLib.multiply(1, decimalNumber);
        const maxDonation = BigMathLib.multiply(1000000, decimalNumber);
        const metadata = (0,reactivity_esm_bundler/* ref */.iH)([]);
        const encMetadata = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const encPassword = (0,reactivity_esm_bundler/* ref */.iH)('');
        const metadataLabel = (0,reactivity_esm_bundler/* ref */.iH)([]);
        const metadataKeys = (0,reactivity_esm_bundler/* ref */.iH)([]);
        const metadataLabelValid = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const hasMetadataLabel = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const isExpired = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const showInputModal = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const showOutputModal = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const showDonationModal = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const showTTLModal = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const showMetadataModal = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const showMetadataLabelModal = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const accountPub = (0,runtime_core_esm_bundler/* computed */.Fl)(() => (activeAccount.value?.pub ?? ''));
        const hasSubmitError = (0,runtime_core_esm_bundler/* computed */.Fl)(() => (accountPub.value ? (getBuildStatus(accountPub.value) === useBuildTx_v3/* IBuildStatus.error */.k.error) : null));
        const hasRewards = (0,reactivity_esm_bundler/* ref */.iH)(activeAccount.value ? BigMathLib.compare(activeAccount.value.balance.rewards, '>', 0) : false);
        const forceWithdrawal = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const allowUtxoManagement = (0,reactivity_esm_bundler/* ref */.iH)(defaultToAdvancedUTxOManagement.value);
        const stagingTx = (0,reactivity_esm_bundler/* ref */.iH)(getStagingTx(accountPub.value));
        const builtTxList = (0,reactivity_esm_bundler/* reactive */.qj)([]);
        const buildError = (0,reactivity_esm_bundler/* ref */.iH)('');
        const iconBuilding = (0,reactivity_esm_bundler/* ref */.iH)('');
        const iconBuildingTF = (0,reactivity_esm_bundler/* ref */.iH)('');
        const iconBuildingCU = (0,reactivity_esm_bundler/* ref */.iH)('');
        (0,runtime_core_esm_bundler/* onErrorCaptured */.d1)((e, instance, info) => {
            iconBuilding.value = '';
            iconBuildingTF.value = '';
            iconBuildingCU.value = '';
            $q.notify({
                type: 'negative',
                message: (e?.message ?? 'no error message'),
                position: 'top-left',
                timeout: 10000
            });
            console.error('Wallet: Send: TxBuilder: onErrorCaptured:', e);
            return false;
        });
        const currentStep = (0,reactivity_esm_bundler/* ref */.iH)(0);
        const previousStep = (0,reactivity_esm_bundler/* ref */.iH)(0);
        const optionsSteps = (0,reactivity_esm_bundler/* reactive */.qj)([
            { id: 'build', label: t('wallet.send.step.stepper.build') },
            { id: 'confirm', label: t('wallet.send.step.stepper.confirm') },
            { id: 'submit', label: t('wallet.send.step.stepper.submit') }
        ]);
        function goBack() {
            previousStep.value = currentStep.value;
            if (currentStep.value === 1) {
                currentStep.value = 0;
            }
            else if (currentStep.value === 2) {
                currentStep.value = 1;
            }
        }
        function gotoNext() {
            previousStep.value = currentStep.value;
            if (currentStep.value === 0) {
                currentStep.value = 1;
            }
            else if (currentStep.value === 1) {
                currentStep.value = 2;
            }
        }
        const onTxBuilderReset = () => {
            resetBuildTx(accountPub.value);
            buildError.value = '';
            stagingTx.value = getStagingTx(accountPub.value);
            builtTxList.splice(0);
            isExpired.value = false;
            _inputList.splice(0);
            inputList.value.splice(0);
            forceWithdrawal.value = false;
            encPassword.value = '';
            encMetadata.value = false;
            metadata.value.splice(0);
            allowUtxoManagement.value = defaultToAdvancedUTxOManagement.value;
        };
        const onInputCancel = () => {
            inputList.value.splice(0);
            inputList.value.push(...stagingTx.value.inputList.map(utxo => `${utxo.txHash}#${utxo.txIndex}`));
            showInputModal.value = false;
        };
        const onInputSelect = () => showInputModal.value = true;
        const onInputSelectAll = async () => {
            if (!activeAccount.value) {
                return;
            }
            const utxoList = (await (0,AccountUTxOLists/* getAccountFilteredUtxoList */.q1)(activeAccount.value, activeWalletData.value)).map(utxo => `${utxo.txHash}#${utxo.txIndex}`);
            inputList.value.splice(0);
            _inputList.splice(0);
            inputList.value.push(...utxoList);
            _inputList.push(...utxoList);
        };
        const onInputReset = () => {
            inputList.value.splice(0);
            _inputList.splice(0);
        };
        const onInputUpdate = (list) => {
            _inputList.splice(0);
            _inputList.push(...list);
        };
        const onInputSave = async (hideModal = true) => {
            if (!accountPub.value) {
                return;
            }
            builtTxList.splice(0);
            stagingTx.value = getStagingTx(accountPub.value);
            inputList.value.splice(0);
            inputList.value.push(..._inputList);
            const accUtxoList = (await (0,AccountUTxOLists/* getAccountFilteredUtxoList */.q1)(activeAccount.value, activeWalletData.value));
            stagingTx.value.inputList.splice(0);
            stagingTx.value.inputList.push(...accUtxoList.filter(utxo => inputList.value.includes(`${utxo.txHash}#${utxo.txIndex}`)));
            if (hideModal) {
                showInputModal.value = false;
            }
        };
        const onOutputAdd = () => showOutputModal.value = true;
        const onOutputDel = (index) => {
            if (!accountPub.value) {
                return;
            }
            builtTxList.splice(0);
            stagingTx.value = getStagingTx(accountPub.value);
            stagingTx.value.outputList.splice(index, 1);
        };
        const onOutputSave = () => {
            if (!accountPub.value) {
                return;
            }
            builtTxList.splice(0);
            stagingTx.value = getStagingTx(accountPub.value);
            showOutputModal.value = false;
            outputCounter.value++;
        };
        const onInputDel = (index) => {
            if (!accountPub.value) {
                return;
            }
            builtTxList.splice(0);
            stagingTx.value = getStagingTx(accountPub.value);
            stagingTx.value.inputList.splice(index, 1);
        };
        const onDonationHide = () => showDonationModal.value = false;
        const onDonationAdd = () => {
            donationInput.value = '1';
            showDonationModal.value = true;
        };
        const onDonationUpdate = (ADA) => donationInput.value = ADA.length === 0 ? '0' : ADA;
        const onDonationSave = () => {
            if (!activeAccount.value || donationInput.value.length === 0) {
                return;
            }
            builtTxList.splice(0);
            stagingTx.value = getStagingTx(accountPub.value);
            const output = (0,ITxOut/* createITxOut */.jO)();
            output.paymentAddr.bech32 = (0,TxBasicUtils/* getDonationAddress */.V9)(activeAccount.value.network);
            output.output = BigMathLib.multiply(donationInput.value, decimalNumber);
            addOutput(activeAccount.value, output, 0, IKeys/* KeyType.external */.J.external);
            onDonationHide();
        };
        const onTTLHide = () => showTTLModal.value = false;
        const onTTLSet = () => {
            if (ttlInput.value === 0) {
                ttlInput.value = 180;
            }
            showTTLModal.value = true;
        };
        const onTTLUpdate = (ttl) => ttlInput.value = ttl;
        const onTTLSave = () => {
            if (!activeAccount.value) {
                return;
            }
            builtTxList.splice(0);
            isExpired.value = false;
            stagingTx.value = getStagingTx(accountPub.value);
            stagingTx.value.invalidHereafter = (0,ChainLib/* getCalculatedChainTip */.YB)(activeAccount.value.network) + ttlInput.value * 60;
            onTTLHide();
        };
        const onMetadataHide = () => showMetadataModal.value = false;
        const onMetadataAdd = () => showMetadataModal.value = true;
        const onMetadataDel = (index) => {
            if (!accountPub.value) {
                return;
            }
            builtTxList.splice(0);
            stagingTx.value = getStagingTx(accountPub.value);
            stagingTx.value.metadataList.splice(index, 1);
            metadataKeys.value = stagingTx.value.metadataList.map(m => m.key);
        };
        const onMetadataEncrypt = (payload) => {
            encMetadata.value = payload.encrypt;
            encPassword.value = payload.password;
        };
        const onMetadataUpdate = (msg) => metadata.value = msg;
        const onMetadataSave = async () => {
            if (!accountPub.value) {
                return;
            }
            builtTxList.splice(0);
            try {
                if (encMetadata.value) {
                    try {
                        const encString = await (0,MessageEncryption/* encryptMessage */.Wg)(metadata.value, encPassword.value.length === 0 ? MessageEncryption/* DEFAULT_MSG_PASSWORD */.fx : encPassword.value);
                        metadata.value = encString.match(/.{1,64}/g) ?? [];
                    }
                    catch (err) {
                        console.error(err.message ?? err);
                        $q.notify({
                            type: 'negative',
                            message: t('wallet.send.builder.modal.metadata.encerror'),
                            position: 'top-left'
                        });
                        return;
                    }
                }
                const meta = (0,CSLUtils/* getTxMetadataFromStringArray */.l7)(metadata.value, 674, (encMetadata.value ? 'basic' : undefined));
                if (meta) {
                    addMetadata(accountPub.value, meta);
                }
            }
            catch (err) {
                console.error(err.message ?? err);
                $q.notify({
                    type: 'negative',
                    message: t('wallet.send.builder.modal.metadata.builderror'),
                    position: 'top-left'
                });
                return;
            }
            stagingTx.value = getStagingTx(accountPub.value);
            metadataKeys.value = stagingTx.value.metadataList.map(m => m.key);
            onMetadataHide();
        };
        const onMetadataLabelHide = () => {
            showMetadataLabelModal.value = false;
            hasMetadataLabel.value = false;
            metadataLabelValid.value = false;
            metadataLabel.value.splice(0);
        };
        const onMetadataLabelAdd = () => showMetadataLabelModal.value = true;
        const onMetadataLabelDel = (index) => {
            if (!accountPub.value) {
                return;
            }
            builtTxList.splice(0);
            stagingTx.value = getStagingTx(accountPub.value);
            stagingTx.value.metadataList.splice(index, 1);
        };
        const onMetadataLabelUpdate = (msg) => {
            metadataLabel.value = msg;
            msg.length === 0 ? hasMetadataLabel.value = false : false;
            metadataLabelValid.value = msg.length === 2 && msg[1].length > 0;
        };
        const onMetadataLabelKeyUpdate = (label) => hasMetadataLabel.value = metadataKeys.value.includes(label);
        const onMetadataLabelSave = () => {
            if (!accountPub.value) {
                return;
            }
            builtTxList.splice(0);
            let label = null;
            let json = null;
            const arr = metadataLabel.value.concat();
            if (arr.length !== 2) {
                return;
            }
            try {
                label = Number(arr[0]);
                json = (0,CSLUtils/* getTxMetadataFromJson */.De)(arr[1], label);
                if (json)
                    addMetadata(accountPub.value, json);
            }
            catch (err) { }
            stagingTx.value = getStagingTx(accountPub.value);
            metadataKeys.value = stagingTx.value.metadataList.map(m => m.key);
            onMetadataLabelHide();
        };
        const onWithdrawalToggle = (e) => {
            if (!accountPub.value) {
                return;
            }
            forceWithdrawal.value = e.checked;
            setForceWithdrawal(accountPub.value, e.checked);
        };
        const onUtxoManagementToggle = (e) => {
            if (!accountPub.value) {
                return;
            }
            allowUtxoManagement.value = e.checked;
            setAllowUtxoManagement(accountPub.value, e.checked);
        };
        const onBuildTx = async () => {
            if (!activeWalletData.value || !activeAccount.value) {
                return;
            }
            builtTxList.splice(0);
            iconBuilding.value = 'mdi mdi-update';
            buildError.value = (await buildSendTx(activeWalletData.value, activeAccount.value, inputList.value.length !== 0)).error;
            if (!buildError.value) {
                builtTxList.push(getBuiltTx(accountPub.value));
                $q.notify({
                    type: 'positive',
                    message: t('wallet.send.builder.build.ok'),
                    position: 'top-left'
                });
                iconBuilding.value = '';
                return;
            }
            else if (buildError.value.includes('less than the minimum UTXO value')) {
                const msgAr = buildError.value.split(' ');
                if (msgAr.length > 0) {
                    buildError.value = 'wallet.send.step.assets.error.minoutput'.replace('###AMOUNT###', formatADAString(msgAr[msgAr.length - 1], true));
                }
            }
            $q.notify({
                type: 'negative',
                message: t('wallet.send.builder.build.error.label'),
                position: 'top-left'
            });
            builtTxList.splice(0);
            iconBuilding.value = '';
        };
        const _onBuildTokenFragmentationTx = async () => {
            if (!activeWalletData.value || !activeAccount.value) {
                return;
            }
            iconBuildingTF.value = 'mdi mdi-update';
            try {
                buildError.value = (await buildCleanUpAccountTxList(activeWalletData.value, activeAccount.value)).error;
                if (!buildError.value) {
                    builtTxList.push(getBuiltTx(accountPub.value));
                    $q.notify({
                        type: 'positive',
                        message: t('wallet.send.builder.build.ok'),
                        position: 'top-left'
                    });
                    iconBuildingTF.value = '';
                    return;
                }
                else if (buildError.value.includes('less than the minimum UTXO value')) {
                    const msgAr = buildError.value.split(' ');
                    if (msgAr.length > 0) {
                        buildError.value = 'wallet.send.step.assets.error.minoutput'.replace('###AMOUNT###', formatADAString(msgAr[msgAr.length - 1], true));
                    }
                }
                $q.notify({
                    type: 'negative',
                    message: t('wallet.send.builder.build.error.label'),
                    position: 'top-left'
                });
                builtTxList.splice(0);
                iconBuildingTF.value = '';
            }
            catch (e) {
                if (e?.message?.startsWith('Token fragmentation not necessary.')) {
                    $q.notify({
                        type: 'positive',
                        message: e.message,
                        position: 'top-left'
                    });
                }
                else {
                    $q.notify({
                        type: 'negative',
                        message: e?.message ?? 'No error given.',
                        position: 'top-left'
                    });
                }
                builtTxList.splice(0);
                iconBuildingTF.value = '';
            }
        };
        const onBuildTokenFragmentationTx = async () => {
            if (!activeWalletData.value || !activeAccount.value) {
                return;
            }
            iconBuildingTF.value = 'mdi mdi-update';
            setTimeout(_onBuildTokenFragmentationTx, 250);
        };
        const _onBuildCollectUTxOsTxList = async () => {
            if (!activeWalletData.value || !activeAccount.value) {
                return;
            }
            iconBuildingCU.value = 'mdi mdi-update';
            try {
                builtTxList.splice(0);
                await buildCollectUTxOsList(activeWalletData.value, activeAccount.value);
                $q.notify({
                    type: 'positive',
                    message: t('wallet.send.builder.build.ok'),
                    position: 'top-left'
                });
            }
            catch (e) {
                if (e?.message?.startsWith('Collecting UTxOs not necessary.')) {
                    $q.notify({
                        type: 'positive',
                        message: e.message,
                        position: 'top-left'
                    });
                }
                else {
                    $q.notify({
                        type: 'negative',
                        message: e?.message ?? 'No error given.',
                        position: 'top-left'
                    });
                }
            }
            const tmpTxList = getBuiltTxList(accountPub.value);
            for (let i = 0; i < tmpTxList.length; i++) {
                if (tmpTxList[i].builtTx) {
                    builtTxList.push(tmpTxList[i].builtTx);
                }
            }
            iconBuildingCU.value = '';
        };
        const onBuildCollectUTxOsTxList = async () => {
            if (!activeWalletData.value || !activeAccount.value) {
                return;
            }
            iconBuildingCU.value = 'mdi mdi-update';
            setTimeout(_onBuildCollectUTxOsTxList, 250);
        };
        function onSubmitError() { console.error('submit error!!'); }
        function onTxPending() {
            gotoWalletPage('Transactions', 'pending');
        }
        function onTxConfirmed() { }
        const isBuilding = (0,runtime_core_esm_bundler/* computed */.Fl)(() => iconBuilding.value.length > 0 || iconBuildingTF.value.length > 0 || iconBuildingCU.value.length > 0);
        return {
            t,
            activeAccount,
            activeWalletData,
            activeWalletEnabledCollateral,
            mainnet: INetwork/* mainnet */.RJ,
            optionsSteps,
            currentStep,
            previousStep,
            gotoNext,
            goBack,
            stagingTx,
            builtTxList,
            buildError,
            inputList,
            donationInput,
            metadata,
            encMetadata,
            encPassword,
            metadataLabel,
            hasMetadataLabel,
            metadataLabelValid,
            outputCounter,
            isExpired,
            ttlInput,
            onInputCancel,
            onInputSelect,
            onInputSelectAll,
            onInputUpdate,
            onInputSave,
            onInputReset,
            onOutputAdd,
            onOutputDel,
            onOutputSave,
            onInputDel,
            onDonationHide,
            onDonationAdd,
            onDonationUpdate,
            onDonationSave,
            minDonation,
            maxDonation,
            onTTLHide,
            onTTLSet,
            onTTLSave,
            onTTLUpdate,
            onMetadataHide,
            onMetadataAdd,
            onMetadataDel,
            onMetadataUpdate,
            onMetadataSave,
            onMetadataEncrypt,
            onMetadataLabelHide,
            onMetadataLabelAdd,
            onMetadataLabelDel,
            onMetadataLabelUpdate,
            onMetadataLabelKeyUpdate,
            onMetadataLabelSave,
            onBuildTx,
            onBuildTokenFragmentationTx,
            onBuildCollectUTxOsTxList,
            onTxBuilderReset,
            showInputModal,
            showOutputModal,
            showDonationModal,
            showTTLModal,
            showMetadataModal,
            showMetadataLabelModal,
            hasSubmitError,
            allowUtxoManagement,
            onUtxoManagementToggle,
            hasRewards,
            forceWithdrawal,
            onWithdrawalToggle,
            onSubmitError,
            onTxPending,
            onTxConfirmed,
            iconBuilding,
            iconBuildingTF,
            iconBuildingCU,
            isBuilding
        };
    }
}));

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/send/SendBuilder.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/send/SendBuilder.vue




;
const SendBuilder_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(SendBuildervue_type_script_lang_ts, [['render',SendBuildervue_type_template_id_2f904fcc_ts_true_render]])

/* harmony default export */ const SendBuilder = (SendBuilder_exports_);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/send/SendImport.vue?vue&type=template&id=9bb76030&ts=true

const SendImportvue_type_template_id_9bb76030_ts_true_hoisted_1 = { class: "cc-grid" };
const SendImportvue_type_template_id_9bb76030_ts_true_hoisted_2 = { class: "cc-grid" };
const SendImportvue_type_template_id_9bb76030_ts_true_hoisted_3 = {
    key: 0,
    class: "relative cc-grid"
};
const SendImportvue_type_template_id_9bb76030_ts_true_hoisted_4 = { class: "col-span-12 grid grid-cols-12 cc-gap" };
const SendImportvue_type_template_id_9bb76030_ts_true_hoisted_5 = { class: "col-span-12 flex flex-row items-center" };
const SendImportvue_type_template_id_9bb76030_ts_true_hoisted_6 = { class: "mr-2" };
const SendImportvue_type_template_id_9bb76030_ts_true_hoisted_7 = {
    key: 1,
    class: "col-span-12 grid grid-cols-12 cc-gap"
};
const SendImportvue_type_template_id_9bb76030_ts_true_hoisted_8 = {
    key: 2,
    class: "relative col-span-12 -top-2"
};
const SendImportvue_type_template_id_9bb76030_ts_true_hoisted_9 = {
    key: 3,
    class: "relative col-span-12 -top-2 grid grid-cols-12 cc-gap"
};
const SendImportvue_type_template_id_9bb76030_ts_true_hoisted_10 = { class: "col-span-12 flex flex-row flex-nowrap items-center whitespace-pre-wrap cc-text-sz" };
const SendImportvue_type_template_id_9bb76030_ts_true_hoisted_11 = {
    key: 4,
    class: "relative col-span-12 -top-2 grid grid-cols-12 cc-gap"
};
const SendImportvue_type_template_id_9bb76030_ts_true_hoisted_12 = { class: "col-span-12 flex flex-row flex-nowrap items-center whitespace-pre-wrap cc-text-sz cc-input-error cc-rounded" };
const SendImportvue_type_template_id_9bb76030_ts_true_hoisted_13 = {
    key: 2,
    class: "relative col-span-12 -top-2 grid grid-cols-12 cc-gap"
};
const SendImportvue_type_template_id_9bb76030_ts_true_hoisted_14 = { class: "col-span-12 flex flex-row flex-nowrap items-center whitespace-pre-wrap cc-text-sz cc-input-error cc-rounded" };
const SendImportvue_type_template_id_9bb76030_ts_true_hoisted_15 = {
    key: 0,
    class: "cc-grid cc-rounded cc-banner-blue pb-2"
};
const SendImportvue_type_template_id_9bb76030_ts_true_hoisted_16 = { class: "col-span-full pl-2" };
const SendImportvue_type_template_id_9bb76030_ts_true_hoisted_17 = /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("br", null, null, -1);
const SendImportvue_type_template_id_9bb76030_ts_true_hoisted_18 = {
    key: 3,
    class: "break-all cc-grid max-w-full overflow-hidden cc-rounded"
};
function SendImportvue_type_template_id_9bb76030_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridHeadline = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridHeadline");
    const _component_GridText = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridText");
    const _component_GridTextArea = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridTextArea");
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    const _component_GridButtonPrimary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonPrimary");
    const _component_grid_space = (0,runtime_core_esm_bundler/* resolveComponent */.up)("grid-space");
    const _component_GridForm = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridForm");
    const _component_GridButtonSecondary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonSecondary");
    const _component_GridFormSignWithPassword = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridFormSignWithPassword");
    const _component_LedgerTransport = (0,runtime_core_esm_bundler/* resolveComponent */.up)("LedgerTransport");
    const _component_IconInfo = (0,runtime_core_esm_bundler/* resolveComponent */.up)("IconInfo");
    const _component_IconError = (0,runtime_core_esm_bundler/* resolveComponent */.up)("IconError");
    const _component_GridSteps = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSteps");
    const _component_GridLoading = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridLoading");
    const _component_GridTxListEntry = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridTxListEntry");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", SendImportvue_type_template_id_9bb76030_ts_true_hoisted_1, [
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
            label: _ctx.t(_ctx.textId + '.headline'),
            class: "col-span-12"
        }, null, 8, ["label"]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
            text: _ctx.t(_ctx.textId + '.caption'),
            class: "col-span-12 cc-text-sz"
        }, null, 8, ["text"]),
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SendImportvue_type_template_id_9bb76030_ts_true_hoisted_2, [
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSteps, {
                onBack: _ctx.goBack,
                steps: _ctx.optionsSteps,
                currentStep: _ctx.currentStep,
                "small-c-s-s": "pr-9 sm:pr-20 md:pr-18 lg:pr-32"
            }, {
                step0: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                    ((_ctx.importError.length > 0))
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", SendImportvue_type_template_id_9bb76030_ts_true_hoisted_3, [
                            (_ctx.importError)
                                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridTextArea, {
                                    key: 0,
                                    text: _ctx.importError,
                                    icon: 'mdi mdi-alert-octagon-outline',
                                    class: "col-span-12",
                                    "text-c-s-s": "cc-text-normal text-justify",
                                    css: "cc-rounded cc-banner-red"
                                }, null, 8, ["text"]))
                                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, { hr: "" })
                        ]))
                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridForm, {
                        class: "col-span-12",
                        onDoFormReset: _ctx.onReset,
                        onDoFormSubmit: _ctx.gotoNext,
                        "form-id": "GridFormTxImport",
                        "reset-button-label": _ctx.t('common.label.reset'),
                        "submit-button-label": !_ctx.showSubmit && !_ctx.showSign ? _ctx.t('common.label.next') : _ctx.fileUploadType === 'signed' ? _ctx.t(_ctx.textId + '.button.submit') : _ctx.t(_ctx.textId + '.button.sign'),
                        "submit-disabled": (!_ctx.showSubmit && !_ctx.showSign) || _ctx.isExpired || _ctx.importError.length > 0,
                        "reset-disabled": (!_ctx.showSubmit && !_ctx.showSign)
                    }, {
                        btnBack: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SendImportvue_type_template_id_9bb76030_ts_true_hoisted_4, [
                                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SendImportvue_type_template_id_9bb76030_ts_true_hoisted_5, [
                                    (0,runtime_core_esm_bundler/* createElementVNode */._)("span", SendImportvue_type_template_id_9bb76030_ts_true_hoisted_6, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t(_ctx.textId + '.import.upload')) + ":", 1),
                                    (0,runtime_core_esm_bundler/* createElementVNode */._)("input", {
                                        ref: "file",
                                        class: "hidden mb-2",
                                        id: "iconFileUpload",
                                        accept: "text/plain, application/json",
                                        onChange: _cache[0] || (_cache[0] =
                                            //@ts-ignore
                                            (...args) => (_ctx.handleTxFileUpload && _ctx.handleTxFileUpload(...args))),
                                        type: "file"
                                    }, null, 544),
                                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonPrimary, {
                                        onClick: _ctx.chooseTxFile,
                                        class: "inline-block w-48 ml-2",
                                        label: _ctx.t('common.label.selectFile')
                                    }, null, 8, ["onClick", "label"])
                                ]),
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_grid_space, { hr: "" })
                            ])
                        ]),
                        _: 1
                    }, 8, ["onDoFormReset", "onDoFormSubmit", "reset-button-label", "submit-button-label", "submit-disabled", "reset-disabled"])
                ]),
                step1: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                    (!_ctx.isConfirmed && _ctx.isMnemonic)
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridFormSignWithPassword, {
                            key: 0,
                            onSubmit: _ctx.onSubmitPassword,
                            class: "col-span-12",
                            autocomplete: "off",
                            "skip-validation": ""
                        }, {
                            btnBack: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonSecondary, {
                                    onClick: _ctx.goBack,
                                    label: _ctx.t('common.label.cancel'),
                                    class: "col-start-0 col-span-6 sm:col-start-0 sm:col-span-3"
                                }, null, 8, ["onClick", "label"])
                            ]),
                            _: 1
                        }, 8, ["onSubmit"]))
                        : (_ctx.isReadOnly)
                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", SendImportvue_type_template_id_9bb76030_ts_true_hoisted_7, [
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                                    text: _ctx.t('wallet.send.step.confirm.info.readonly')
                                }, null, 8, ["text"])
                            ]))
                            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                    (_ctx.isLedger && !_ctx.isConfirmed && _ctx.hasWebUSB)
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", SendImportvue_type_template_id_9bb76030_ts_true_hoisted_8, [
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_LedgerTransport),
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, { hr: "" })
                        ]))
                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                    ((_ctx.isLedger || _ctx.isTrezor || _ctx.importError.length > 0) && !_ctx.isConfirmed)
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", SendImportvue_type_template_id_9bb76030_ts_true_hoisted_9, [
                            (_ctx.importError.length > 0 && _ctx.isMnemonic)
                                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridSpace, {
                                    key: 0,
                                    class: "col-span-12 mt-2 sm:mt-4"
                                }))
                                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SendImportvue_type_template_id_9bb76030_ts_true_hoisted_10, [
                                (_ctx.importError.length === 0)
                                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_IconInfo, {
                                        key: 0,
                                        class: "w-7 flex-none mr-2"
                                    }))
                                    : ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_IconError, {
                                        key: 1,
                                        class: "w-7 flex-none mr-2"
                                    })),
                                (_ctx.importError.length === 0)
                                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridText, {
                                        key: 2,
                                        text: _ctx.t('wallet.send.step.confirm.info' + (_ctx.isLedger ? '.ledger' : '.trezor'))
                                    }, null, 8, ["text"]))
                                    : ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridText, {
                                        key: 3,
                                        text: _ctx.importError
                                    }, null, 8, ["text"]))
                            ]),
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, { hr: "" })
                        ]))
                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                    ((_ctx.importError.length > 0))
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", SendImportvue_type_template_id_9bb76030_ts_true_hoisted_11, [
                            (_ctx.importError.length > 0)
                                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridSpace, {
                                    key: 0,
                                    class: "col-span-12 mt-2 sm:mt-4"
                                }))
                                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SendImportvue_type_template_id_9bb76030_ts_true_hoisted_12, [
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_IconInfo, { class: "w-7 flex-none" }),
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                                    text: _ctx.importError,
                                    class: "cc-text-sz p-2"
                                }, null, 8, ["text"])
                            ]),
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, { hr: "" })
                        ]))
                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                    (!_ctx.isConfirmed && (_ctx.isLedger || _ctx.isTrezor))
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridButtonPrimary, {
                            key: 5,
                            label: _ctx.t('common.label.sign'),
                            link: _ctx.signTx,
                            class: "col-start-7 col-span-6 sm:col-start-10 sm:col-span-3"
                        }, null, 8, ["label", "link"]))
                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                ]),
                step2: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                    (_ctx.isConfirmed && _ctx.showSubmit)
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridButtonPrimary, {
                            key: 0,
                            label: _ctx.t('common.label.submit'),
                            link: _ctx.submit,
                            disabled: _ctx.isExpired,
                            class: "col-start-7 col-span-6 sm:col-start-10 sm:col-span-3"
                        }, null, 8, ["label", "link", "disabled"]))
                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                    (_ctx.txHash && _ctx.txCbor)
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridButtonPrimary, {
                            key: 1,
                            label: _ctx.t('common.label.download'),
                            link: _ctx.onDownload,
                            class: "col-start-7 col-span-6 sm:col-start-10 sm:col-span-3"
                        }, null, 8, ["label", "link"]))
                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                    ((_ctx.importError.length > 0))
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", SendImportvue_type_template_id_9bb76030_ts_true_hoisted_13, [
                            (_ctx.importError.length > 0)
                                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridSpace, {
                                    key: 0,
                                    class: "col-span-12 mt-2 sm:mt-4"
                                }))
                                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SendImportvue_type_template_id_9bb76030_ts_true_hoisted_14, [
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_IconInfo, { class: "w-7 flex-none" }),
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                                    text: _ctx.importError,
                                    class: "cc-text-sz p-2"
                                }, null, 8, ["text"])
                            ]),
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, { hr: "" })
                        ]))
                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                ]),
                _: 1
            }, 8, ["onBack", "steps", "currentStep"])
        ]),
        (_ctx.otherWallet && !_ctx.isConfirmed)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", SendImportvue_type_template_id_9bb76030_ts_true_hoisted_15, [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridTextArea, {
                    text: _ctx.t(_ctx.textId + '.differentWallet.info.' + (_ctx.otherWalletType === 'mnemonic' ? 'mnemonic' : 'hardware')),
                    class: "col-span-12",
                    "text-c-s-s": "cc-text-normal text-justify",
                    css: ""
                }, null, 8, ["text"]),
                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SendImportvue_type_template_id_9bb76030_ts_true_hoisted_16, [
                    (0,runtime_core_esm_bundler/* createTextVNode */.Uk)((0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t(_ctx.textId + '.differentWallet.wallet') + ' ' + _ctx.otherWalletName), 1),
                    SendImportvue_type_template_id_9bb76030_ts_true_hoisted_17,
                    (0,runtime_core_esm_bundler/* createTextVNode */.Uk)(" " + (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t(_ctx.textId + '.differentWallet.account') + ' ' + _ctx.otherAccountName), 1)
                ])
            ]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridLoading, { active: _ctx.isLoading }, null, 8, ["active"]),
        (_ctx.txList && _ctx.wallet && !_ctx.isLoading)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridTxListEntry, {
                key: 1,
                tx: _ctx.txList,
                wallet: _ctx.wallet,
                signed: _ctx.isConfirmed,
                "network-id": _ctx.networkId,
                "always-open": "",
                "staging-tx": ""
            }, null, 8, ["tx", "wallet", "signed", "network-id"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (_ctx.txCbor)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", {
                key: 2,
                class: "col-span-12 flex flex-row flex-nowrap items-center cursor-pointer",
                onClick: _cache[1] || (_cache[1] = (0,runtime_dom_esm_bundler/* withModifiers */.iM)(($event) => (_ctx.showRawCbor = !_ctx.showRawCbor), ["stop"]))
            }, [
                (0,runtime_core_esm_bundler/* createElementVNode */._)("i", {
                    class: (0,shared_esm_bundler/* normalizeClass */.C_)(["relative text-xl mr-1", _ctx.showRawCbor ? 'mdi mdi-chevron-down' : 'mdi mdi-chevron-right'])
                }, null, 2),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                    label: _ctx.t(_ctx.textId + '.cbor'),
                    class: "w-full"
                }, null, 8, ["label"])
            ]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (_ctx.showRawCbor)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", SendImportvue_type_template_id_9bb76030_ts_true_hoisted_18, [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridTextArea, {
                    text: _ctx.txCbor,
                    class: "col-span-12",
                    "text-c-s-s": "cc-text-normal text-justify",
                    css: "cc-rounded cc-banner-blue"
                }, null, 8, ["text"])
            ]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
    ]));
}

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/send/SendImport.vue?vue&type=template&id=9bb76030&ts=true

// EXTERNAL MODULE: ./src/composables/ccw/useNetworkId.ts
var useNetworkId = __webpack_require__(36648);
// EXTERNAL MODULE: ./src/composables/ccw/store/useWalletList.ts
var useWalletList = __webpack_require__(4905);
// EXTERNAL MODULE: ./src/components/ccw/modal/BaseModal.vue + 4 modules
var BaseModal = __webpack_require__(57044);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridLoading.vue + 4 modules
var GridLoading = __webpack_require__(54753);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/forms/GridForm.vue + 3 modules
var GridForm = __webpack_require__(76798);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/CSLCredentials.ts
var CSLCredentials = __webpack_require__(84431);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/AccountLib.ts
var AccountLib = __webpack_require__(19276);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/tx/TxParser.ts
var TxParser = __webpack_require__(90095);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/tx/TxBuilderUtils.ts
var TxBuilderUtils = __webpack_require__(90140);
// EXTERNAL MODULE: ./src/ext/AppWalletManager.ts + 1 modules
var AppWalletManager = __webpack_require__(33931);
// EXTERNAL MODULE: ./src/lib/ExtApiLib.ts
var ExtApiLib = __webpack_require__(1553);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/send/SendImport.vue?vue&type=script&lang=ts
/* provided dependency */ var Buffer = __webpack_require__(14244)["Buffer"];

;




































/* harmony default export */ const SendImportvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'SendImport',
    components: {
        BaseModal: BaseModal/* default */.Z,
        Checkbox: Checkbox/* default */.Z,
        GridLoading: GridLoading/* default */.Z,
        IconError: IconError/* default */.Z,
        GridAccountUtxoList: GridAccountUtxoList/* default */.Z,
        GridForm: GridForm/* default */.Z,
        GridSpace: GridSpace/* default */.Z,
        GridHeadline: GridHeadline/* default */.Z,
        GridText: GridText/* default */.Z,
        GridTextArea: GridTextArea/* default */.Z,
        GridButtonPrimary: GridButtonPrimary/* default */.Z,
        GridButtonSecondary: GridButtonSecondary/* default */.Z,
        GridButtonAbort: GridButtonAbort/* default */.Z,
        GridSteps: GridSteps/* default */.Z,
        GridTxListEntry: GridTxListEntry/* default */.Z,
        GridFormSignWithPassword: GridFormSignWithPassword/* default */.Z,
        IconInfo: IconInfo/* default */.Z,
        LedgerTransport: LedgerTransport/* default */.Z,
    },
    setup() {
        const textId = 'wallet.importTx';
        const $q = (0,use_quasar/* default */.Z)();
        const { t } = (0,useTranslation/* useTranslation */.$)();
        const { gotoWalletPage } = (0,useNavigation/* useNavigation */.HJ)();
        const { createWitnessSet, setKeyList, getKeyList, setBuiltTx, getBuiltTx, setTxBody, setWitnessSet, getTxHash } = (0,useBuildTx_v3/* useBuildTxV3 */.b)();
        const { activeWalletData, activeAccount } = (0,useActiveWallet/* useActiveWallet */.r)();
        const { downloadText } = (0,useDownload/* useDownload */.i)();
        const file = (0,reactivity_esm_bundler/* ref */.iH)();
        const uploadedFile = (0,reactivity_esm_bundler/* ref */.iH)();
        const { networkId } = (0,useNetworkId/* useNetworkId */.h)();
        const { walletList } = (0,useWalletList/* useWalletList */.M)();
        const currentStep = (0,reactivity_esm_bundler/* ref */.iH)(0);
        const previousStep = (0,reactivity_esm_bundler/* ref */.iH)(0);
        const txList = (0,reactivity_esm_bundler/* ref */.iH)();
        const spendingPassword = (0,reactivity_esm_bundler/* ref */.iH)('');
        const isConfirmed = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const isExpired = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const showSign = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const showSubmit = (0,reactivity_esm_bundler/* ref */.iH)(false);
        // The wallet that is used in the tx
        const wallet = (0,reactivity_esm_bundler/* ref */.iH)();
        // The account that is used in the tx
        const account = (0,reactivity_esm_bundler/* ref */.iH)();
        const isMnemonic = (0,runtime_core_esm_bundler/* computed */.Fl)(() => (account.value && account.value.signType === 'mnemonic') ?? false);
        const isLedger = (0,runtime_core_esm_bundler/* computed */.Fl)(() => (account.value && account.value.signType === 'ledger') ?? false);
        const isTrezor = (0,runtime_core_esm_bundler/* computed */.Fl)(() => (account.value && account.value.signType === 'trezor') ?? false);
        const isReadOnly = (0,runtime_core_esm_bundler/* computed */.Fl)(() => (account.value && account.value.signType === 'readonly') ?? false);
        const txCbor = (0,reactivity_esm_bundler/* ref */.iH)();
        const signedTxCbor = (0,reactivity_esm_bundler/* ref */.iH)();
        const txHash = (0,runtime_core_esm_bundler/* computed */.Fl)(() => account.value ? getTxHash(account.value.pub) : null);
        const showRawCbor = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const otherWallet = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const otherWalletName = (0,reactivity_esm_bundler/* ref */.iH)();
        const otherAccountName = (0,reactivity_esm_bundler/* ref */.iH)();
        const otherWalletType = (0,reactivity_esm_bundler/* ref */.iH)();
        const canOnlySignPartially = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const fileUploadType = (0,reactivity_esm_bundler/* ref */.iH)('unsigned');
        const isLoading = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const importError = (0,reactivity_esm_bundler/* ref */.iH)('');
        const optionsSteps = (0,reactivity_esm_bundler/* reactive */.qj)([
            { id: 'select', label: t(textId + '.steps.select') },
            { id: 'sign', label: t(textId + '.steps.sign') },
            { id: 'submit', label: t(textId + '.steps.submit') },
        ]);
        const onReset = () => {
            uploadedFile.value = undefined;
            importError.value = '';
            showSign.value = false;
            isConfirmed.value = false;
            showSign.value = false;
            showSubmit.value = false;
            isExpired.value = false;
            currentStep.value = 0;
            txCbor.value = '';
            signedTxCbor.value = '';
            txList.value = null;
            otherWallet.value = false;
        };
        (0,runtime_core_esm_bundler/* onErrorCaptured */.d1)((e) => {
            console.error('Wallet: Send: onErrorCaptured', e);
            return true;
        });
        function goBack() {
            previousStep.value = currentStep.value;
            if (currentStep.value === 1) {
                currentStep.value = 0;
            }
            else if (currentStep.value === 2) {
                currentStep.value = previousStep.value;
            }
        }
        function gotoNext() {
            previousStep.value = currentStep.value;
            if (currentStep.value === 0) {
                if (fileUploadType.value === 'signed') {
                    currentStep.value = 2;
                    submit();
                }
                else {
                    currentStep.value = 1;
                }
            }
            else if (currentStep.value === 1) {
                currentStep.value = 2;
            }
        }
        // TODO: Check import compontent to get the correct importing scripts... make it composable?
        /**
         * Load the content of the uploaded file
         *
         * @param file
         * @param processor
         */
        const loadFileContent = async (file, processor) => {
            const reader = new FileReader();
            const text = new Text();
            reader.addEventListener("load", () => {
                try {
                    text.data = reader.result;
                    processor(text);
                }
                catch (error) {
                    importError.value = t(textId + '.error.upload');
                }
            }, false);
            reader.readAsDataURL(file);
        };
        const parseJsonUpload = (fileContent) => {
            if (fileContent.textContent) {
                let file = fileContent.textContent.split(',');
                let formatInfo = file[0];
                let content = Buffer.from(file[1], 'base64').toString();
                if (formatInfo.includes('application/json') || content.includes('[') || content.includes('{')) {
                    if (content.includes('[')) {
                        const transactions = JSON.parse(content);
                        if (transactions.length > 1) {
                            importError.value = t(textId + '.error.multiple');
                            throw new Error(t(textId + '.error.multiple'));
                        }
                        transactions.forEach((upload, index) => {
                            // if(index === 0) {
                            //   fileUploadType.value = upload.description
                            // } else {
                            //   if(fileUploadType.value !== upload.description) {
                            //     throw new Error("Cannot mix unsigned and signed transactions. (for now)")//ToDo: Add possibility to only sign unsigned messages and send all in one go
                            //   }
                            // }
                            unserializeTx(upload.cborHex, networkId.value);
                        });
                    }
                    else {
                        const upload = JSON.parse(content);
                        fileUploadType.value = upload.description;
                        unserializeTx(upload.cborHex, networkId.value);
                    }
                }
                else if (formatInfo.includes('text/plain')) {
                    unserializeTx(content, networkId.value);
                }
            }
        };
        const handleTxFileUpload = () => {
            if (file.value && file.value.files && file.value.files.length > 0) {
                uploadedFile.value = file.value.files[0];
                loadFileContent(uploadedFile.value, parseJsonUpload);
            }
            else {
                importError.value = t(textId + '.error.upload');
            }
        };
        const chooseTxFile = () => {
            importError.value = '';
            const target = document.getElementById("iconFileUpload");
            if (target !== null) {
                target.value = '';
                target.click();
            }
        };
        const findAccounts = async (utxoList, witnessCredList) => {
            // map each input to a specific wallet and account
            const inputAccountMap = [];
            inputLoop: for (let i = 0; i < utxoList.length; i++) {
                const input = utxoList[i];
                for (const wallet of walletList.filter(w => !w.locked && w.wallet)) {
                    for (const account of wallet.wallet?.accounts.filter(a => (0,AccountLib/* isHDAccountPath */._B)(a)) ?? []) {
                        const ownUtxo = (0,AccountLib/* getOwnedUtxoByTxHashId */.J1)(account, input.txHash, input.txIndex);
                        if (ownUtxo) {
                            // only add if cred not already in witnessSet
                            if (!witnessCredList.some(w => w === ownUtxo.paymentAddr.cred)) {
                                inputAccountMap.push({
                                    txHash: input.txHash,
                                    txIndex: input.txIndex,
                                    walletId: wallet.wallet.id,
                                    accPub: account.pub
                                });
                            }
                            continue inputLoop;
                        }
                    }
                }
            }
            return inputAccountMap;
        };
        const unserializeTx = async (cbor, networkId) => {
            otherWallet.value = false;
            txList.value = null;
            showSign.value = false;
            showSubmit.value = false;
            isLoading.value = true;
            if (cbor.length === 0 || !networkId)
                return;
            (0,runtime_core_esm_bundler/* nextTick */.Y3)(async () => {
                try {
                    const parsed = cbor.replace(/<[^>]*>/g, '');
                    const cslTx = (0,CSLUtils/* getTransaction */.fo)(parsed);
                    const inputUtxoList = [];
                    for (let i = 0; i < cslTx.body().inputs().len(); i++) {
                        const input = cslTx.body().inputs().get(i);
                        const utxo = (0,ITxOut/* createITxOut */.jO)();
                        utxo.txHash = input.transaction_id().to_hex();
                        utxo.txIndex = input.index();
                        inputUtxoList.push(utxo);
                    }
                    const witnessCredList = (0,CSLCredentials/* getCredsFromVkeys */.dB)(cslTx.witness_set().vkeys());
                    const inputAccountMap = await findAccounts(inputUtxoList, witnessCredList);
                    if (inputAccountMap.length > 0) {
                        // First check if active wallet and account is present
                        let inputIndex = inputAccountMap.findIndex(i => i.walletId === activeWalletData.value?.id && i.accPub === activeAccount.value?.pub);
                        // If not found, use first account found
                        if (inputIndex < 0) {
                            inputIndex = 0;
                        }
                        const foundWallet = walletList.find(w => w.wallet?.id === inputAccountMap[inputIndex].walletId);
                        const foundAccount = foundWallet?.wallet?.accounts.find(a => a.pub === inputAccountMap[inputIndex].accPub);
                        if (!foundWallet?.wallet || !foundAccount) {
                            importError.value = t(textId + '.error.wallet');
                            isLoading.value = false;
                            return;
                        }
                        if (foundWallet.wallet.id !== activeWalletData.value?.id) {
                            otherWalletName.value = foundWallet.dbEntry.name;
                            otherAccountName.value = foundAccount.name ?? 'Index: ' + foundAccount.index;
                            otherWalletType.value = foundWallet.dbEntry.signType;
                            otherWallet.value = true;
                        }
                        wallet.value = foundWallet.wallet ?? undefined;
                        account.value = foundAccount;
                    }
                    else {
                        wallet.value = activeWalletData.value ?? undefined;
                        account.value = activeAccount.value ?? undefined;
                    }
                    if (!wallet.value || !account.value) {
                        importError.value = t(textId + '.error.wallet');
                        isLoading.value = false;
                        return;
                    }
                    const convertedTx = await (0,TxParser/* convertTxToITx */.F4)(account.value, cslTx, cbor, ExtApiLib/* loadTxDetailsList */.LG);
                    const remainingSeconds = convertedTx.tx.invalidHereafter - (0,ChainLib/* getCalculatedChainTip */.YB)(networkId);
                    if (remainingSeconds <= 0) {
                        importError.value = t(textId + '.error.expired');
                        showSign.value = false;
                        showSubmit.value = false;
                        isExpired.value = true;
                    }
                    if (convertedTx.tx.inputList.every((tx) => tx.signed)) {
                        fileUploadType.value = 'signed';
                        isConfirmed.value = true;
                        canOnlySignPartially.value = false;
                    }
                    else {
                        for (const unsignedInput of convertedTx.tx.inputList.filter(i => !i.signed)) {
                            if (!walletList.some(w => (w.wallet?.accounts ?? []).some(a => (0,AccountLib/* getAccountUtxoList */.ub)(a).some(u => u.paymentAddr.cred === unsignedInput.paymentAddr.cred)))) {
                                // Couldn't find unsigned utxo in any unlocked wallet
                                canOnlySignPartially.value = true;
                                break;
                            }
                        }
                        fileUploadType.value = 'unsigned';
                    }
                    if (fileUploadType.value === 'signed') {
                        showSign.value = false;
                        showSubmit.value = true;
                        signedTxCbor.value = parsed;
                    }
                    else {
                        showSign.value = true;
                        showSubmit.value = false;
                    }
                    txCbor.value = cbor;
                    setKeyList(account.value.pub, convertedTx.ownedKeyList);
                    convertedTx.tx.inputList.forEach((inputUtxo) => {
                        (0,TxBuilderUtils/* getTxOutCborSize */.l8)(inputUtxo, true);
                    });
                    const epochParams = (0,TxBasicUtils/* checkEpochParams */.H3)(networkId);
                    (0,TxBuilderUtils/* setInputScores */.J1)(convertedTx.tx.inputList, epochParams.txFeePerByte, 0);
                    setBuiltTx(account.value.pub, convertedTx.tx);
                    setTxBody(account.value.pub, cslTx.body());
                    setWitnessSet(account.value.pub, cslTx.witness_set());
                    txList.value = convertedTx.tx;
                    $q.notify({
                        type: 'positive',
                        message: t(textId + '.import.success'),
                        position: 'top-left',
                        timeout: 4000
                    });
                }
                catch (e) {
                    importError.value = "Tx parse error, correct network for transaction?: " + (e.message ?? e.toString());
                    console.error("Error while parsing transaction, correct network for transaction?", e);
                }
                isLoading.value = false;
            });
        };
        const signTx = async () => {
            if (!account.value) {
                throw new Error('Cannot sign without account.');
            }
            try {
                const witnessSet = await createWitnessSet(account.value, txCbor.value, getBuiltTx(account.value.pub), getKeyList(account.value.pub), spendingPassword.value);
                if (witnessSet.status === useBuildTx_v3/* IBuildStatus.signed */.k.signed) {
                    const txAfterSign = (0,CSLUtils/* setTxWitnessSet */.jX)(txCbor.value, (0,CSLUtils/* getTxWitnessSetFromHex */._J)(witnessSet.witnesses));
                    if (!txAfterSign) {
                        throw new Error('Signed tx can not be found.');
                    }
                    isConfirmed.value = true;
                    signedTxCbor.value = txAfterSign;
                    const cslTx = (0,CSLUtils/* getTransaction */.fo)(txAfterSign);
                    const convertedTx = await (0,TxParser/* convertTxToITx */.F4)(account.value, cslTx, txCbor.value, ExtApiLib/* loadTxDetailsList */.LG);
                    txList.value = convertedTx.tx;
                    showSign.value = false;
                    showSubmit.value = !convertedTx.tx.inputList.some(i => !i.signed);
                    gotoNext();
                }
                else if (witnessSet.error !== '') {
                    importError.value = witnessSet.error;
                    showSubmit.value = false;
                }
                else {
                    importError.value = 'Unknown error, status: ' + witnessSet.status;
                    throw new Error('Unknown error, status: ' + witnessSet.status);
                }
            }
            catch (error) {
                console.error('Error when signing: ', error);
                throw new Error('Error when signing: ' + error);
            }
        };
        async function onSubmitPassword(payload) {
            clearError();
            spendingPassword.value = payload.password;
            await signTx();
        }
        const clearError = () => {
            importError.value = '';
        };
        const submit = async () => {
            if (!networkId.value) {
                throw new Error('No network id found.');
            }
            if (!account.value) {
                throw new Error('No submit account found.');
            }
            if (!wallet.value) {
                throw new Error('No submit wallet found.');
            }
            if (!signedTxCbor.value) {
                throw new Error('No signed tx found.');
            }
            // for already signed tx just send out the tx!
            if (fileUploadType.value === "signed" && txCbor.value) {
                await doSubmit(txCbor.value);
                return;
            }
            await doSubmit(signedTxCbor.value);
        };
        const doSubmit = async (cbor) => {
            try {
                const resCode = await (0,ExtApiLib/* sendTransaction */.T7)(networkId.value, cbor, 'cc');
                await (0,AppWalletManager.immediatelySyncAppWallet)(wallet.value.id);
                gotoWalletPage('Transactions', 'pending');
            }
            catch (error) {
                if (error.toString().includes('consumed')) {
                    importError.value = t(textId + '.error.utxoMissing');
                }
                else {
                    importError.value = t(textId + '.error.submit') + error;
                }
            }
        };
        function onDownload() {
            if (txCbor.value && txHash.value) {
                const description = isConfirmed.value ? 'signed' : 'unsigned';
                const content = {
                    type: 'Tx MaryEra',
                    description: description,
                    cborHex: isConfirmed.value ? signedTxCbor.value : txCbor.value
                };
                downloadText(JSON.stringify(content, null, 2), 'eternl-tx-' + txHash.value + '-' + description + '.txt');
            }
        }
        return {
            t,
            chooseTxFile,
            handleTxFileUpload,
            onSubmitPassword,
            signTx,
            txHash,
            submit,
            onReset,
            gotoNext,
            goBack,
            onDownload,
            hasWebUSB: useAppMode/* hasWebUSB */.d$,
            file,
            txList,
            wallet,
            account,
            networkId,
            isConfirmed,
            isExpired,
            isLoading,
            isMnemonic,
            isLedger,
            isTrezor,
            isReadOnly,
            showSign,
            showSubmit,
            importError,
            textId,
            optionsSteps,
            currentStep,
            fileUploadType,
            showRawCbor,
            txCbor,
            otherWallet,
            otherWalletName,
            otherAccountName,
            otherWalletType,
            uploadedFile
        };
    }
}));

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/send/SendImport.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/send/SendImport.vue




;
const SendImport_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(SendImportvue_type_script_lang_ts, [['render',SendImportvue_type_template_id_9bb76030_ts_true_render]])

/* harmony default export */ const SendImport = (SendImport_exports_);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridTabs.vue + 4 modules
var GridTabs = __webpack_require__(49510);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/Send.vue?vue&type=script&lang=ts








/* harmony default export */ const Sendvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'Send',
    components: {
        GridTabs: GridTabs/* default */.Z,
        SendGuide: SendGuide,
        SendBuilder: SendBuilder,
        SendImport: SendImport
    },
    setup() {
        const { t } = (0,useTranslation/* useTranslation */.$)();
        const { activeAccount } = (0,useActiveWallet/* useActiveWallet */.r)();
        const { resetBuildTx } = (0,useBuildTx_v3/* useBuildTxV3 */.b)();
        const optionsTabs = (0,reactivity_esm_bundler/* reactive */.qj)([
            { id: 'send', label: t('menu.wallet.send.submenu.send'), index: 0 },
            { id: 'builder', label: t('menu.wallet.send.submenu.builder'), index: 1 },
            { id: 'import', label: t('menu.wallet.send.submenu.import'), index: 2 }
        ]);
        (0,runtime_core_esm_bundler/* onBeforeUnmount */.Jd)(() => {
            if (activeAccount.value) {
                resetBuildTx(activeAccount.value.pub);
            }
        });
        return {
            t,
            optionsTabs
        };
    }
}));

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/Send.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/Send.vue




;
const Send_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(Sendvue_type_script_lang_ts, [['render',render]])

/* harmony default export */ const Send = (Send_exports_);

/***/ })

}]);
//# sourceMappingURL=5131.js.map