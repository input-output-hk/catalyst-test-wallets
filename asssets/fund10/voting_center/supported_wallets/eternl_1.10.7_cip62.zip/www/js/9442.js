"use strict";
(this["webpackChunkccw_frontend"] = this["webpackChunkccw_frontend"] || []).push([[9442,5134],{

/***/ 60946:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Withdrawal)
});

// EXTERNAL MODULE: ./node_modules/@vue/runtime-core/dist/runtime-core.esm-bundler.js
var runtime_core_esm_bundler = __webpack_require__(83673);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/Withdrawal.vue?vue&type=template&id=76b5d560&ts=true

const _hoisted_1 = { class: "cc-page-wallet cc-text-sz" };
const _hoisted_2 = { class: "col-span-12 lg:col-span-6 grid grid-cols-12 cc-gap" };
function render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridHeadline = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridHeadline");
    const _component_GridButtonSecondary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonSecondary");
    const _component_SendConfirm = (0,runtime_core_esm_bundler/* resolveComponent */.up)("SendConfirm");
    const _component_SendSubmit = (0,runtime_core_esm_bundler/* resolveComponent */.up)("SendSubmit");
    const _component_GridSteps = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSteps");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_1, [
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_2, [
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                label: _ctx.t('wallet.withdrawal.headline')
            }, null, 8, ["label"])
        ]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSteps, {
            onBack: _ctx.goBack,
            steps: _ctx.optionsSteps,
            currentStep: _ctx.currentStep,
            "small-c-s-s": "pr-20 xs:pr-20 lg:pr-24"
        }, {
            step0: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_SendConfirm, {
                    onSubmit: _ctx.gotoNext,
                    account: _ctx.activeAccount,
                    wallet: _ctx.activeWalletData,
                    "unsigned-tx": _ctx.tx,
                    "text-id": "wallet.send.step.confirm"
                }, {
                    btnBack: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonSecondary, {
                            label: _ctx.t('common.label.cancel'),
                            link: _ctx.goBack,
                            type: "button",
                            class: "col-start-0 col-span-6 lg:col-start-0 lg:col-span-3"
                        }, null, 8, ["label", "link"])
                    ]),
                    _: 1
                }, 8, ["onSubmit", "account", "wallet", "unsigned-tx"])
            ]),
            step1: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_SendSubmit, {
                    onError: _ctx.onSubmitError,
                    onSending: _ctx.onTxSending,
                    onPending: _ctx.onTxPending,
                    onConfirmed: _ctx.onTxConfirmed,
                    "text-id": "wallet.send.step.submit"
                }, {
                    btnBack: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                        (_ctx.hasSubmitError)
                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridButtonSecondary, {
                                key: 0,
                                label: _ctx.t('common.label.retry'),
                                link: _ctx.goBack,
                                class: "col-start-0 col-span-6 lg:col-start-0 lg:col-span-3 mt-4"
                            }, null, 8, ["label", "link"]))
                            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                    ]),
                    _: 1
                }, 8, ["onError", "onSending", "onPending", "onConfirmed"])
            ]),
            _: 1
        }, 8, ["onBack", "steps", "currentStep"])
    ]));
}

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/Withdrawal.vue?vue&type=template&id=76b5d560&ts=true

// EXTERNAL MODULE: ./node_modules/@vue/reactivity/dist/reactivity.esm-bundler.js
var reactivity_esm_bundler = __webpack_require__(61959);
// EXTERNAL MODULE: ./src/composables/ccw/useTranslation.ts
var useTranslation = __webpack_require__(19376);
// EXTERNAL MODULE: ./src/composables/ccw/useNavigation.ts
var useNavigation = __webpack_require__(52439);
// EXTERNAL MODULE: ./src/composables/ccw/store/useBuildTx_v3.ts + 1 modules
var useBuildTx_v3 = __webpack_require__(72107);
// EXTERNAL MODULE: ./src/composables/ccw/store/useActiveWallet.ts
var useActiveWallet = __webpack_require__(52144);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/send/SendConfirm.vue + 4 modules
var SendConfirm = __webpack_require__(12662);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/send/SendSubmit.vue + 3 modules
var SendSubmit = __webpack_require__(65778);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridHeadline.vue + 3 modules
var GridHeadline = __webpack_require__(63593);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridSteps.vue + 14 modules
var GridSteps = __webpack_require__(58217);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridButtonSecondary.vue + 3 modules
var GridButtonSecondary = __webpack_require__(72713);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/Withdrawal.vue?vue&type=script&lang=ts










/* harmony default export */ const Withdrawalvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'Withdrawal',
    components: {
        GridHeadline: GridHeadline/* default */.Z,
        GridSteps: GridSteps/* default */.Z,
        GridButtonSecondary: GridButtonSecondary/* default */.Z,
        SendConfirm: SendConfirm/* default */.Z,
        SendSubmit: SendSubmit/* default */.Z,
    },
    setup(props, { emit }) {
        const { t } = (0,useTranslation/* useTranslation */.$)();
        const { gotoWalletPage } = (0,useNavigation/* useNavigation */.HJ)();
        const { activeWalletData, activeAccount } = (0,useActiveWallet/* useActiveWallet */.r)();
        const currentStep = (0,reactivity_esm_bundler/* ref */.iH)(0);
        const { getBuildStatus, getBuiltTx } = (0,useBuildTx_v3/* useBuildTxV3 */.b)();
        const tx = (0,runtime_core_esm_bundler/* computed */.Fl)(() => {
            if (!activeAccount.value) {
                return null;
            }
            return getBuiltTx(activeAccount.value?.pub);
        });
        const hasSubmitError = (0,runtime_core_esm_bundler/* computed */.Fl)(() => (activeAccount.value ? (getBuildStatus(activeAccount.value.pub) === useBuildTx_v3/* IBuildStatus.error */.k.error) : null));
        const optionsSteps = (0,reactivity_esm_bundler/* reactive */.qj)([
            { id: 'confirm', label: t('wallet.withdrawal.steps.stepper.confirm') },
            { id: 'submit', label: t('wallet.withdrawal.steps.stepper.submit') }
        ]);
        function goBack() {
            if (currentStep.value === 0) {
                gotoWalletPage('Summary');
            }
            if (currentStep.value === 1) {
                currentStep.value = 0;
            }
        }
        function gotoNext() {
            if (currentStep.value === 0) {
                currentStep.value = 1;
            }
        }
        const onSubmitError = function () {
            emit('error');
        };
        function onTxSending() { }
        function onTxPending() {
            gotoWalletPage('Transactions', 'pending');
        }
        function onTxConfirmed() { }
        return {
            t,
            activeWalletData,
            activeAccount,
            tx,
            optionsSteps,
            currentStep,
            goBack,
            gotoNext,
            onSubmitError,
            onTxSending,
            onTxPending,
            onTxConfirmed,
            hasSubmitError
        };
    }
}));

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/Withdrawal.vue?vue&type=script&lang=ts
 
// EXTERNAL MODULE: ./node_modules/vue-loader/dist/exportHelper.js
var exportHelper = __webpack_require__(74260);
;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/Withdrawal.vue




;
const __exports__ = /*#__PURE__*/(0,exportHelper/* default */.Z)(Withdrawalvue_type_script_lang_ts, [['render',render]])

/* harmony default export */ const Withdrawal = (__exports__);

/***/ })

}]);
//# sourceMappingURL=9442.js.map