"use strict";
(this["webpackChunkccw_frontend"] = this["webpackChunkccw_frontend"] || []).push([[8094,5134],{

/***/ 80164:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Voting)
});

// EXTERNAL MODULE: ./node_modules/@vue/runtime-core/dist/runtime-core.esm-bundler.js
var runtime_core_esm_bundler = __webpack_require__(83673);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/Voting.vue?vue&type=template&id=0e305555&ts=true

const _hoisted_1 = { class: "cc-page-wallet cc-text-sz" };
function render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_VoteInfo = (0,runtime_core_esm_bundler/* resolveComponent */.up)("VoteInfo");
    const _component_VoteDelegation = (0,runtime_core_esm_bundler/* resolveComponent */.up)("VoteDelegation");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_1, [
        (!_ctx.showRegister && _ctx.activeWalletData && _ctx.activeAccount)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_VoteInfo, {
                key: 0,
                "own-vote-key": _ctx.ownVoteKey,
                wallet: _ctx.activeWalletData,
                account: _ctx.activeAccount,
                onVotekeycreated: _ctx.onVoteKeyCreated,
                onRegister: _cache[0] || (_cache[0] = ($event) => (_ctx.showRegister = true))
            }, null, 8, ["own-vote-key", "wallet", "account", "onVotekeycreated"]))
            : (_ctx.showRegister && _ctx.activeWalletData && _ctx.activeAccount)
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_VoteDelegation, {
                    key: 1,
                    "own-vote-key": _ctx.ownVoteKey,
                    wallet: _ctx.activeWalletData,
                    account: _ctx.activeAccount,
                    onCancel: _cache[1] || (_cache[1] = ($event) => (_ctx.showRegister = false))
                }, null, 8, ["own-vote-key", "wallet", "account"]))
                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
    ]));
}

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/Voting.vue?vue&type=template&id=0e305555&ts=true

// EXTERNAL MODULE: ./node_modules/@vue/reactivity/dist/reactivity.esm-bundler.js
var reactivity_esm_bundler = __webpack_require__(61959);
// EXTERNAL MODULE: ./src/composables/ccw/store/useActiveWallet.ts
var useActiveWallet = __webpack_require__(52144);
// EXTERNAL MODULE: ./node_modules/@vue/runtime-dom/dist/runtime-dom.esm-bundler.js
var runtime_dom_esm_bundler = __webpack_require__(98880);
// EXTERNAL MODULE: ./node_modules/@vue/shared/dist/shared.esm-bundler.js
var shared_esm_bundler = __webpack_require__(62323);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/voting/VoteInfo.vue?vue&type=template&id=76e4db62&ts=true

const VoteInfovue_type_template_id_76e4db62_ts_true_hoisted_1 = { class: "col-span-12" };
const _hoisted_2 = { key: 1 };
const _hoisted_3 = { class: "col-span-12 grid grid-cols-12 cc-gap-lg" };
const _hoisted_4 = { class: "col-span-12 sm:col-span-6 xl:col-span-3 cc-area-light p-2" };
const _hoisted_5 = { class: "col-span-12 sm:col-span-6 xl:col-span-3 cc-area-light p-2" };
const _hoisted_6 = { class: "col-span-12 sm:col-span-6 xl:col-span-3 cc-area-light p-2" };
const _hoisted_7 = { class: "col-span-12 sm:col-span-6 lg:col-span-3 lg:pl-2 cc-area-light p-2" };
const _hoisted_8 = { class: "col-span-12" };
const _hoisted_9 = {
    key: 3,
    class: "col-span-12 grid grid-cols-12 cc-gap-lg"
};
const _hoisted_10 = { class: "cc-text-semi-bold" };
function VoteInfovue_type_template_id_76e4db62_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_ConfirmationModal = (0,runtime_core_esm_bundler/* resolveComponent */.up)("ConfirmationModal");
    const _component_GridButtonSecondary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonSecondary");
    const _component_VoteKeyConfirm = (0,runtime_core_esm_bundler/* resolveComponent */.up)("VoteKeyConfirm");
    const _component_base_modal = (0,runtime_core_esm_bundler/* resolveComponent */.up)("base-modal");
    const _component_GridHeadline = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridHeadline");
    const _component_GridText = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridText");
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    const _component_GridTextArea = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridTextArea");
    const _component_GridButtonPrimary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonPrimary");
    const _component_ExternalLink = (0,runtime_core_esm_bundler/* resolveComponent */.up)("ExternalLink");
    const _component_GridTimeline = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridTimeline");
    const _component_GridFundChallengeList = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridFundChallengeList");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, [
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_ConfirmationModal, {
            title: _ctx.t('wallet.voting.warning.registerForNextFund.label'),
            caption: _ctx.t('wallet.voting.warning.registerForNextFund.caption'),
            "show-modal": _ctx.showWarningModal,
            onConfirm: _cache[0] || (_cache[0] = ($event) => (_ctx.confirmSnapshot())),
            onClose: _cache[1] || (_cache[1] = ($event) => (_ctx.showWarningModal.display = false)),
            onCancel: _cache[2] || (_cache[2] = ($event) => (_ctx.showWarningModal.display = false))
        }, null, 8, ["title", "caption", "show-modal"]),
        (_ctx.showCreateKeyModal)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_base_modal, {
                key: 0,
                onClose: _cache[4] || (_cache[4] = ($event) => (_ctx.showCreateKeyModal = false)),
                "show-modal": _ctx.showCreateKeyModal,
                persistent: false,
                title: _ctx.t('wallet.voting.info.create.label'),
                caption: _ctx.t('wallet.voting.info.create.caption'),
                "modal-c-s-s": "m-1 sm:max-w-xl cc-bg-light-1 flex flex-col flex-nowrap pb-2 relative",
                "header-c-s-s": "grow-0 flex items-start justify-between cc-bg-light-0 border-b cc-p",
                "content-c-s-s": "grow bg-transparent relative flex flex-col flex-nowrap relative h-full m-1 cc-p"
            }, {
                content: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_VoteKeyConfirm, {
                        onSubmit: _ctx.onVoteKeyCreated,
                        account: _ctx.account,
                        wallet: _ctx.wallet,
                        "show-label": false,
                        "text-id": "dapps.voting.key"
                    }, {
                        btnBack: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonSecondary, {
                                label: _ctx.t('common.label.cancel'),
                                onClick: _cache[3] || (_cache[3] = ($event) => (_ctx.showCreateKeyModal = false)),
                                class: "col-start-0 col-span-6 sm:col-start-0 sm:col-span-3"
                            }, null, 8, ["label"])
                        ]),
                        _: 1
                    }, 8, ["onSubmit", "account", "wallet"])
                ]),
                _: 1
            }, 8, ["show-modal", "title", "caption"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
            label: _ctx.t('wallet.voting.headline'),
            class: "col-span-12"
        }, null, 8, ["label"]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
            text: _ctx.t('wallet.voting.caption'),
            class: "col-span-12 cc-text-sz"
        }, null, 8, ["text"]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, {
            hr: "",
            class: "col-span-12 my-0.5 sm:my-2"
        }),
        (_ctx.votingPreReqError.length > 0)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridTextArea, {
                key: 1,
                text: _ctx.votingPreReqError,
                icon: "mdi mdi-alert-octagon-outline",
                class: "col-span-12 mb-2",
                "text-c-s-s": "cc-text-normal text-justify flex justify-start items-center",
                css: "cc-rounded cc-banner-warning"
            }, null, 8, ["text"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", VoteInfovue_type_template_id_76e4db62_ts_true_hoisted_1, [
            (!_ctx.ownVoteKey)
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridTextArea, {
                    key: 0,
                    text: _ctx.t('wallet.voting.info.create.text'),
                    icon: "mdi mdi-information-outline",
                    class: "col-span-12 mb-2",
                    "text-c-s-s": "cc-text-normal text-justify flex justify-start items-center",
                    css: "cc-rounded cc-banner-blue"
                }, null, 8, ["text"]))
                : ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_2, " User Voting Key & vote data from VIT station (registered?, power etc.) "))
        ]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonPrimary, {
            label: _ctx.t('wallet.voting.info.button.' + (!_ctx.ownVoteKey ? 'create' : (_ctx.isRegistered ? 'update' : 'register'))),
            link: _ctx.onRegister,
            disabled: _ctx.votingPreReqError.length > 0,
            class: "col-start-0 col-span-12 sm:col-start-7 sm:col-span-6 lg:col-start-10 lg:col-span-3"
        }, null, 8, ["label", "link", "disabled"]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, {
            hr: "",
            class: "col-span-12 my-0.5 sm:my-2"
        }),
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_3, [
            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_4, [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                    label: _ctx.t('wallet.voting.info.ideascale.header')
                }, null, 8, ["label"]),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                    text: _ctx.t('wallet.voting.info.ideascale.caption'),
                    class: "cc-text-sz italic"
                }, null, 8, ["text"]),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                    text: _ctx.t('wallet.voting.info.ideascale.text'),
                    class: "cc-text-sz mt-2"
                }, null, 8, ["text"]),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_ExternalLink, {
                    url: _ctx.t('wallet.voting.info.ideascale.button.link'),
                    label: _ctx.t('wallet.voting.info.ideascale.button.label'),
                    "label-c-s-s": 'cc-text-semi-bold cc-text-color cc-text-highlight-hover',
                    class: "mt-2 whitespace-nowrap"
                }, null, 8, ["url", "label"])
            ]),
            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_5, [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                    label: _ctx.t('wallet.voting.info.newsletter.header')
                }, null, 8, ["label"]),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                    text: _ctx.t('wallet.voting.info.newsletter.caption'),
                    class: "cc-text-sz italic"
                }, null, 8, ["text"]),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                    text: _ctx.t('wallet.voting.info.newsletter.text'),
                    class: "cc-text-sz mt-2"
                }, null, 8, ["text"]),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_ExternalLink, {
                    url: _ctx.t('wallet.voting.info.newsletter.button.link'),
                    label: _ctx.t('wallet.voting.info.newsletter.button.label'),
                    "label-c-s-s": 'cc-text-semi-bold cc-text-color cc-text-highlight-hover',
                    class: "mt-2 whitespace-nowrap"
                }, null, 8, ["url", "label"])
            ]),
            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_6, [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                    label: _ctx.t('wallet.voting.info.engage.header')
                }, null, 8, ["label"]),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                    text: _ctx.t('wallet.voting.info.engage.caption'),
                    class: "cc-text-sz italic"
                }, null, 8, ["text"]),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                    text: _ctx.t('wallet.voting.info.engage.text'),
                    class: "cc-text-sz mt-2"
                }, null, 8, ["text"]),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_ExternalLink, {
                    url: _ctx.t('wallet.voting.info.engage.button1.link'),
                    label: _ctx.t('wallet.voting.info.engage.button1.label'),
                    "label-c-s-s": 'cc-text-semi-bold cc-text-color cc-text-highlight-hover',
                    class: "mt-2 whitespace-nowrap"
                }, null, 8, ["url", "label"]),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_ExternalLink, {
                    url: _ctx.t('wallet.voting.info.engage.button2.link'),
                    label: _ctx.t('wallet.voting.info.engage.button2.label'),
                    "label-c-s-s": 'cc-text-semi-bold cc-text-color cc-text-highlight-hover',
                    class: "mt-2 whitespace-nowrap"
                }, null, 8, ["url", "label"])
            ]),
            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_7, [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                    label: _ctx.t('wallet.voting.info.townhall.header')
                }, null, 8, ["label"]),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                    text: _ctx.t('wallet.voting.info.townhall.caption'),
                    class: "cc-text-sz italic"
                }, null, 8, ["text"]),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                    text: _ctx.t('wallet.voting.info.townhall.text'),
                    class: "cc-text-sz mt-2"
                }, null, 8, ["text"]),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_ExternalLink, {
                    url: _ctx.t('wallet.voting.info.townhall.button.link'),
                    label: _ctx.t('wallet.voting.info.townhall.button.label'),
                    "label-c-s-s": 'cc-text-semi-bold cc-text-color cc-text-highlight-hover',
                    class: "mt-2 whitespace-nowrap"
                }, null, 8, ["url", "label"])
            ])
        ]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, {
            hr: "",
            class: "col-span-12 my-0.5 sm:my-2"
        }),
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_8, [
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                label: _ctx.catalystData?.fund_name
            }, null, 8, ["label"]),
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                text: _ctx.catalystData?.fund_goal,
                class: "italic"
            }, null, 8, ["text"])
        ]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
            text: _ctx.t('wallet.voting.info.fund.timeline.caption'),
            class: "col-span-12 cc-text-sz"
        }, null, 8, ["text"]),
        (_ctx.timelineItems.length > 0)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridTimeline, {
                key: 2,
                steps: _ctx.timelineItems,
                currentStep: _ctx.currentTimelineItem,
                "stepper-c-s-s": "whitespace-nowrap ml-4 pb-3"
            }, null, 8, ["steps", "currentStep"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (_ctx.catalystData)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_9, [
                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", {
                    onClick: _cache[5] || (_cache[5] = (0,runtime_dom_esm_bundler/* withModifiers */.iM)(($event) => (_ctx.showChallenges = !_ctx.showChallenges), ["stop"])),
                    class: "col-span-12 cursor-pointer"
                }, [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("i", {
                        class: (0,shared_esm_bundler/* normalizeClass */.C_)(["mr-2", _ctx.showChallenges ? 'mdi mdi-chevron-down' : 'mdi mdi-chevron-right'])
                    }, null, 2),
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_10, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.voting.info.fund.challenges.' + (!_ctx.showChallenges ? 'show' : 'hide'))), 1)
                ]),
                (_ctx.showChallenges)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridFundChallengeList, {
                        key: 0,
                        "challenge-list": _ctx.catalystData?.challenges,
                        dense: ""
                    }, null, 8, ["challenge-list"]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
            ]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
    ], 64));
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/voting/VoteInfo.vue?vue&type=template&id=76e4db62&ts=true

// EXTERNAL MODULE: ./src/composables/ccw/useTranslation.ts
var useTranslation = __webpack_require__(19376);
// EXTERNAL MODULE: ./src/composables/ccw/store/useVoteLib.ts
var useVoteLib = __webpack_require__(24198);
// EXTERNAL MODULE: ./src/components/ccw/common/ExternalLink.vue + 3 modules
var ExternalLink = __webpack_require__(14789);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/voting/GridFundChallengeList.vue?vue&type=template&id=28f7b3de&ts=true

const GridFundChallengeListvue_type_template_id_28f7b3de_ts_true_hoisted_1 = { class: "col-span-12 flex justify-center" };
function GridFundChallengeListvue_type_template_id_28f7b3de_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridFundChallenge = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridFundChallenge");
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    const _component_q_pagination = (0,runtime_core_esm_bundler/* resolveComponent */.up)("q-pagination");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, [
        ((0,runtime_core_esm_bundler/* openBlock */.wg)(true), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, (0,runtime_core_esm_bundler/* renderList */.Ko)(_ctx.challengeListFiltered, (challenge) => {
            return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridFundChallenge, {
                class: (0,shared_esm_bundler/* normalizeClass */.C_)(_ctx.dense ? 'col-span-12 sm:col-span-6 2xl:col-span-4' : 'col-span-12'),
                key: challenge.id,
                challenge: challenge
            }, null, 8, ["class", "challenge"]));
        }), 128)),
        (_ctx.showPagination)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridSpace, {
                key: 0,
                hr: "",
                class: "mt-0.5"
            }))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", GridFundChallengeListvue_type_template_id_28f7b3de_ts_true_hoisted_1, [
            (_ctx.showPagination)
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_q_pagination, {
                    key: 0,
                    modelValue: _ctx.currentPage,
                    "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => ((_ctx.currentPage) = $event)),
                    "model-value": _ctx.currentPage,
                    max: _ctx.maxPages,
                    "max-pages": 6,
                    "boundary-numbers": "",
                    flat: "",
                    color: "teal-90",
                    "text-color": "teal-90",
                    "active-color": "teal-90",
                    "active-text-color": "teal-90",
                    "active-design": "unelevated"
                }, null, 8, ["modelValue", "model-value", "max"]))
                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
        ])
    ], 64));
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/voting/GridFundChallengeList.vue?vue&type=template&id=28f7b3de&ts=true

// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridSpace.vue + 4 modules
var GridSpace = __webpack_require__(14740);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/voting/GridFundChallenge.vue?vue&type=template&id=02dfe511&scoped=true&ts=true

const _withScopeId = n => ((0,runtime_core_esm_bundler/* pushScopeId */.dD)("data-v-02dfe511"), n = n(), (0,runtime_core_esm_bundler/* popScopeId */.Cn)(), n);
const GridFundChallengevue_type_template_id_02dfe511_scoped_true_ts_true_hoisted_1 = { class: "relative cc-area-light cc-text-sz flex-1 w-full inline-flex flex-col flex-nowrap justify-start items-start" };
const GridFundChallengevue_type_template_id_02dfe511_scoped_true_ts_true_hoisted_2 = { class: "relative w-full h-full" };
const GridFundChallengevue_type_template_id_02dfe511_scoped_true_ts_true_hoisted_3 = { class: "h-full flex flex-col items-stretch overflow-hidden px-2 py-2" };
const GridFundChallengevue_type_template_id_02dfe511_scoped_true_ts_true_hoisted_4 = { class: "flex flex-row flex-nowrap items-start justify-between" };
const GridFundChallengevue_type_template_id_02dfe511_scoped_true_ts_true_hoisted_5 = { class: "flex flex-row flex-nowrap" };
const GridFundChallengevue_type_template_id_02dfe511_scoped_true_ts_true_hoisted_6 = { class: "item-text cc-text-semi-bold break-words" };
const GridFundChallengevue_type_template_id_02dfe511_scoped_true_ts_true_hoisted_7 = {
    key: 0,
    class: "h-5 cc-badge-blue whitespace-nowrap mx-2"
};
const GridFundChallengevue_type_template_id_02dfe511_scoped_true_ts_true_hoisted_8 = {
    key: 0,
    class: "badge-social cc-flex-fixed"
};
const GridFundChallengevue_type_template_id_02dfe511_scoped_true_ts_true_hoisted_9 = ["href"];
const GridFundChallengevue_type_template_id_02dfe511_scoped_true_ts_true_hoisted_10 = /*#__PURE__*/ _withScopeId(() => /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("i", { class: "mdi mdi-web text-blue-500" }, null, -1));
const _hoisted_11 = [
    GridFundChallengevue_type_template_id_02dfe511_scoped_true_ts_true_hoisted_10
];
const _hoisted_12 = { class: "text-xs break-words" };
const _hoisted_13 = { class: "flex flex-grow items-end mt-2 text-xs" };
const _hoisted_14 = { class: "cc-text-semi-bold whitespace-nowrap mr-2" };
function GridFundChallengevue_type_template_id_02dfe511_scoped_true_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_Tooltip = (0,runtime_core_esm_bundler/* resolveComponent */.up)("Tooltip");
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    const _component_FormattedAmount = (0,runtime_core_esm_bundler/* resolveComponent */.up)("FormattedAmount");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", GridFundChallengevue_type_template_id_02dfe511_scoped_true_ts_true_hoisted_1, [
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", GridFundChallengevue_type_template_id_02dfe511_scoped_true_ts_true_hoisted_2, [
            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", GridFundChallengevue_type_template_id_02dfe511_scoped_true_ts_true_hoisted_3, [
                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", GridFundChallengevue_type_template_id_02dfe511_scoped_true_ts_true_hoisted_4, [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", GridFundChallengevue_type_template_id_02dfe511_scoped_true_ts_true_hoisted_5, [
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("span", GridFundChallengevue_type_template_id_02dfe511_scoped_true_ts_true_hoisted_6, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.challenge.title), 1),
                        (_ctx.challenge.challenge_type !== 'simple')
                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", GridFundChallengevue_type_template_id_02dfe511_scoped_true_ts_true_hoisted_7, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.challenge.challenge_type), 1))
                            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                    ]),
                    (_ctx.challenge.challenge_url)
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", GridFundChallengevue_type_template_id_02dfe511_scoped_true_ts_true_hoisted_8, [
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_Tooltip, {
                                "tooltip-c-s-s": "whitespace-nowrap",
                                offset: [0, -44],
                                "transition-show": "scale",
                                "transition-hide": "scale"
                            }, {
                                default: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                                    (0,runtime_core_esm_bundler/* createTextVNode */.Uk)((0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.voting.info.fund.challenges.link')), 1)
                                ]),
                                _: 1
                            }),
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("a", {
                                href: _ctx.challenge.challenge_url,
                                target: "_blank",
                                rel: "noopener noreferrer"
                            }, _hoisted_11, 8, GridFundChallengevue_type_template_id_02dfe511_scoped_true_ts_true_hoisted_9)
                        ]))
                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                ]),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, {
                    hr: "",
                    class: "py-1"
                }),
                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_12, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.challenge.description), 1),
                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_13, [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_14, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.voting.info.fund.challenges.allocation')), 1),
                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_FormattedAmount, {
                        amount: _ctx.challenge.rewards_total.toString(),
                        currency: "USD",
                        "is-whole-number": "",
                        decimals: 0
                    }, null, 8, ["amount"])
                ])
            ])
        ])
    ]));
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/voting/GridFundChallenge.vue?vue&type=template&id=02dfe511&scoped=true&ts=true

// EXTERNAL MODULE: ./src/components/ccw/common/ExplorerLink.vue + 3 modules
var ExplorerLink = __webpack_require__(61413);
// EXTERNAL MODULE: ./src/components/ccw/common/Tooltip.vue + 3 modules
var Tooltip = __webpack_require__(30105);
// EXTERNAL MODULE: ./src/components/ccw/common/FormattedAmount.vue + 3 modules
var FormattedAmount = __webpack_require__(6200);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/voting/GridFundChallenge.vue?vue&type=script&lang=ts






/* harmony default export */ const GridFundChallengevue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'GridFundChallenge',
    components: {
        FormattedAmount: FormattedAmount/* default */.Z,
        GridSpace: GridSpace/* default */.Z,
        ExplorerLink: ExplorerLink/* default */.Z,
        Tooltip: Tooltip/* default */.Z
    },
    props: {
        challenge: { type: Object, required: true }
    },
    setup() {
        const { t } = (0,useTranslation/* useTranslation */.$)();
        (0,runtime_core_esm_bundler/* onErrorCaptured */.d1)((e) => { console.error('Wallet: GridFundChallenge: onErrorCaptured', e); return true; });
        return {
            t
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/voting/GridFundChallenge.vue?vue&type=script&lang=ts
 
// EXTERNAL MODULE: ./node_modules/vue-loader/dist/exportHelper.js
var exportHelper = __webpack_require__(74260);
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/voting/GridFundChallenge.vue




;


const __exports__ = /*#__PURE__*/(0,exportHelper/* default */.Z)(GridFundChallengevue_type_script_lang_ts, [['render',GridFundChallengevue_type_template_id_02dfe511_scoped_true_ts_true_render],['__scopeId',"data-v-02dfe511"]])

/* harmony default export */ const GridFundChallenge = (__exports__);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/voting/GridFundChallengeList.vue?vue&type=script&lang=ts



/* harmony default export */ const GridFundChallengeListvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'GridFundChallengeList',
    components: {
        GridSpace: GridSpace/* default */.Z,
        GridFundChallenge: GridFundChallenge
    },
    props: {
        challengeList: { type: Array, required: true },
        dense: { type: Boolean, default: false }
    },
    setup(props) {
        const itemsOnPage = 12;
        const currentPage = (0,reactivity_esm_bundler/* ref */.iH)(1);
        const showPagination = (0,runtime_core_esm_bundler/* computed */.Fl)(() => props.challengeList.length > itemsOnPage);
        const currentPageStart = (0,runtime_core_esm_bundler/* computed */.Fl)(() => (currentPage.value - 1) * itemsOnPage);
        const maxPages = (0,runtime_core_esm_bundler/* computed */.Fl)(() => Math.ceil(props.challengeList.length / itemsOnPage));
        const challengeListFiltered = (0,runtime_core_esm_bundler/* computed */.Fl)(() => props.challengeList.slice(currentPageStart.value, currentPageStart.value + itemsOnPage));
        return {
            currentPage,
            showPagination,
            maxPages,
            challengeListFiltered
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/voting/GridFundChallengeList.vue?vue&type=script&lang=ts
 
// EXTERNAL MODULE: ./node_modules/quasar/src/components/pagination/QPagination.js
var QPagination = __webpack_require__(87300);
// EXTERNAL MODULE: ./node_modules/@quasar/app/lib/webpack/runtime.auto-import.js
var runtime_auto_import = __webpack_require__(7518);
var runtime_auto_import_default = /*#__PURE__*/__webpack_require__.n(runtime_auto_import);
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/voting/GridFundChallengeList.vue




;
const GridFundChallengeList_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(GridFundChallengeListvue_type_script_lang_ts, [['render',GridFundChallengeListvue_type_template_id_28f7b3de_ts_true_render]])

/* harmony default export */ const GridFundChallengeList = (GridFundChallengeList_exports_);
;

runtime_auto_import_default()(GridFundChallengeListvue_type_script_lang_ts, 'components', {QPagination: QPagination/* default */.Z});

// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridHeadline.vue + 3 modules
var GridHeadline = __webpack_require__(63593);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridText.vue + 4 modules
var GridText = __webpack_require__(96834);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/common/GridTimeline.vue?vue&type=template&id=4c70d18c&ts=true

const GridTimelinevue_type_template_id_4c70d18c_ts_true_hoisted_1 = { class: "relative col-span-12 grid grid-cols-12 cc-gap cc-text-sz mt-3 md:mt-4" };
const GridTimelinevue_type_template_id_4c70d18c_ts_true_hoisted_2 = {
    "aria-label": "Progress",
    class: "col-span-12 inline-flex justify-start"
};
const GridTimelinevue_type_template_id_4c70d18c_ts_true_hoisted_3 = { class: "flex flex-col items-start justify-start" };
function GridTimelinevue_type_template_id_4c70d18c_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_TimelineButton = (0,runtime_core_esm_bundler/* resolveComponent */.up)("TimelineButton");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", GridTimelinevue_type_template_id_4c70d18c_ts_true_hoisted_1, [
        (0,runtime_core_esm_bundler/* createElementVNode */._)("nav", GridTimelinevue_type_template_id_4c70d18c_ts_true_hoisted_2, [
            (0,runtime_core_esm_bundler/* createElementVNode */._)("ol", GridTimelinevue_type_template_id_4c70d18c_ts_true_hoisted_3, [
                ((0,runtime_core_esm_bundler/* openBlock */.wg)(true), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, (0,runtime_core_esm_bundler/* renderList */.Ko)(_ctx.internalSteps, (step, stepIdx) => {
                    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("li", {
                        key: step.option.id,
                        class: (0,shared_esm_bundler/* normalizeClass */.C_)(["relative flex flex-row items-start", _ctx.stepperCSS])
                    }, [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_TimelineButton, {
                            status: step.status,
                            item: step.option,
                            last: stepIdx === (_ctx.internalSteps.length - 1)
                        }, null, 8, ["status", "item", "last"])
                    ], 2));
                }), 128))
            ])
        ])
    ]));
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/common/GridTimeline.vue?vue&type=template&id=4c70d18c&ts=true

;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/common/steps/TimelineButton.vue?vue&type=template&id=61aad67c&ts=true

const TimelineButtonvue_type_template_id_61aad67c_ts_true_hoisted_1 = { class: "relative ml-4 flex flex-col" };
const TimelineButtonvue_type_template_id_61aad67c_ts_true_hoisted_2 = { class: "absolute -top-0.5 lg:-top-1 cc-text-semi-bold" };
const TimelineButtonvue_type_template_id_61aad67c_ts_true_hoisted_3 = { class: "mt-5 font-mono" };
const TimelineButtonvue_type_template_id_61aad67c_ts_true_hoisted_4 = {
    key: 0,
    class: "mt-1 text-sm text-gray-400"
};
function TimelineButtonvue_type_template_id_61aad67c_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_TimelineLine = (0,runtime_core_esm_bundler/* resolveComponent */.up)("TimelineLine");
    const _component_IconCheck = (0,runtime_core_esm_bundler/* resolveComponent */.up)("IconCheck");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, [
        (!_ctx.last)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_TimelineLine, {
                key: 0,
                active: _ctx.status === 'complete'
            }, null, 8, ["active"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", {
            class: (0,shared_esm_bundler/* normalizeClass */.C_)(["relative w-5 h-5 rounded-full flex flex-row flex-nowrap items-center cc-text-sz", _ctx.status === 'complete' ? 'cc-bg-highlight ' : 'bg-white border-2 ' +
                    (_ctx.status === 'current' ? 'cc-border-highlight ' : 'cc-border-inactive ')])
        }, [
            (_ctx.status === 'complete')
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_IconCheck, {
                    key: 0,
                    class: "w-5 h-5 text-white",
                    "aria-hidden": "true"
                }))
                : ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("span", {
                    key: 1,
                    class: (0,shared_esm_bundler/* normalizeClass */.C_)(["ml-1 h-2 w-2 rounded-full", _ctx.status === 'current' ? 'cc-bg-highlight' : 'bg-transparent']),
                    "aria-hidden": "true"
                }, null, 2))
        ], 2),
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", TimelineButtonvue_type_template_id_61aad67c_ts_true_hoisted_1, [
            (0,runtime_core_esm_bundler/* createElementVNode */._)("span", TimelineButtonvue_type_template_id_61aad67c_ts_true_hoisted_2, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.item.label), 1),
            (0,runtime_core_esm_bundler/* createElementVNode */._)("span", TimelineButtonvue_type_template_id_61aad67c_ts_true_hoisted_3, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.formatDatetime(_ctx.item.date, true, _ctx.item.time)), 1),
            (_ctx.item.caption.length > 0)
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("span", TimelineButtonvue_type_template_id_61aad67c_ts_true_hoisted_4, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.item.caption), 1))
                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
        ])
    ], 64));
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/common/steps/TimelineButton.vue?vue&type=template&id=61aad67c&ts=true

// EXTERNAL MODULE: ./src/components/ccw/grid/v2/icons/IconCheck.vue + 4 modules
var IconCheck = __webpack_require__(59548);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/common/steps/TimelineLine.vue?vue&type=template&id=38ffc028&ts=true

const TimelineLinevue_type_template_id_38ffc028_ts_true_hoisted_1 = {
    class: "w-5 top-5 absolute inset-0 flex justify-center",
    "aria-hidden": "true"
};
function TimelineLinevue_type_template_id_38ffc028_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", TimelineLinevue_type_template_id_38ffc028_ts_true_hoisted_1, [
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", {
            class: (0,shared_esm_bundler/* normalizeClass */.C_)(["w-0.5 h-full", _ctx.active ? 'cc-bg-highlight' : 'cc-bg-inactive'])
        }, null, 2)
    ]));
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/common/steps/TimelineLine.vue?vue&type=template&id=38ffc028&ts=true

;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/common/steps/TimelineLine.vue?vue&type=script&lang=ts

/* harmony default export */ const TimelineLinevue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'TimelineLine',
    props: {
        active: { type: Boolean, default: false }
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/common/steps/TimelineLine.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/common/steps/TimelineLine.vue




;
const TimelineLine_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(TimelineLinevue_type_script_lang_ts, [['render',TimelineLinevue_type_template_id_38ffc028_ts_true_render]])

/* harmony default export */ const TimelineLine = (TimelineLine_exports_);
// EXTERNAL MODULE: ./src/composables/ccw/store/useFormatter.ts
var useFormatter = __webpack_require__(16938);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/common/steps/TimelineButton.vue?vue&type=script&lang=ts




/* harmony default export */ const TimelineButtonvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'TimelineButton',
    components: {
        TimelineLine: TimelineLine,
        IconCheck: IconCheck/* default */.Z
    },
    props: {
        status: { type: String, default: 'upcoming' },
        item: { type: Object, required: true },
        last: { type: Boolean, required: false, default: false }
    },
    setup() {
        const { formatDatetime } = (0,useFormatter/* useFormatter */.G)();
        return {
            formatDatetime
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/common/steps/TimelineButton.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/common/steps/TimelineButton.vue




;
const TimelineButton_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(TimelineButtonvue_type_script_lang_ts, [['render',TimelineButtonvue_type_template_id_61aad67c_ts_true_render]])

/* harmony default export */ const TimelineButton = (TimelineButton_exports_);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/common/GridTimeline.vue?vue&type=script&lang=ts


/* harmony default export */ const GridTimelinevue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'GridTimeline',
    components: {
        TimelineButton: TimelineButton
    },
    props: {
        steps: { type: Array, required: true },
        currentStep: { type: Number, required: true, default: 0 },
        stepperCSS: { type: String, required: false, default: '' }
    },
    setup(props) {
        const internalSteps = (0,reactivity_esm_bundler/* reactive */.qj)([]);
        let index = 0;
        for (const step of props.steps) {
            if (index < props.currentStep) {
                internalSteps.push({ option: step, status: 'complete' });
            }
            else if (index === props.currentStep) {
                internalSteps.push({ option: step, status: 'current' });
            }
            else {
                internalSteps.push({ option: step, status: 'upcoming' });
            }
            index++;
        }
        const stepIndex = (0,reactivity_esm_bundler/* ref */.iH)(0);
        (0,runtime_core_esm_bundler/* watch */.YP)(() => props.currentStep, () => {
            stepIndex.value = props.currentStep;
            index = 0;
            for (const step of internalSteps) {
                if (index < stepIndex.value) {
                    step.status = 'complete';
                }
                else if (index === stepIndex.value) {
                    step.status = 'current';
                }
                else {
                    step.status = 'upcoming';
                }
                index++;
            }
        });
        return {
            internalSteps,
            stepIndex
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/common/GridTimeline.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/common/GridTimeline.vue




;
const GridTimeline_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(GridTimelinevue_type_script_lang_ts, [['render',GridTimelinevue_type_template_id_4c70d18c_ts_true_render]])

/* harmony default export */ const GridTimeline = (GridTimeline_exports_);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridTextArea.vue + 4 modules
var GridTextArea = __webpack_require__(15660);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridButtonPrimary.vue + 3 modules
var GridButtonPrimary = __webpack_require__(12559);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridButtonSecondary.vue + 3 modules
var GridButtonSecondary = __webpack_require__(72713);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/voting/VoteKeyConfirm.vue + 4 modules
var VoteKeyConfirm = __webpack_require__(46535);
// EXTERNAL MODULE: ./src/components/ccw/modal/ConfirmationModal.vue + 4 modules
var ConfirmationModal = __webpack_require__(65455);
// EXTERNAL MODULE: ./src/components/ccw/modal/BaseModal.vue + 4 modules
var BaseModal = __webpack_require__(57044);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/VoteLib.ts
var VoteLib = __webpack_require__(77263);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/voting/VoteInfo.vue?vue&type=script&lang=ts
















/* harmony default export */ const VoteInfovue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'VoteInfo',
    components: {
        GridFundChallengeList: GridFundChallengeList,
        ExternalLink: ExternalLink/* default */.Z,
        GridSpace: GridSpace/* default */.Z,
        GridHeadline: GridHeadline/* default */.Z,
        GridText: GridText/* default */.Z,
        GridTextArea: GridTextArea/* default */.Z,
        GridTimeline: GridTimeline,
        GridButtonPrimary: GridButtonPrimary/* default */.Z,
        GridButtonSecondary: GridButtonSecondary/* default */.Z,
        VoteKeyConfirm: VoteKeyConfirm/* default */.Z,
        ConfirmationModal: ConfirmationModal/* default */.Z,
        BaseModal: BaseModal/* default */.Z
    },
    emits: ['votekeycreated', 'register'],
    props: {
        ownVoteKey: { type: Object, required: true },
        account: { type: Object, required: true },
        wallet: { type: Object, required: true }
    },
    setup(props, { emit }) {
        const { t } = (0,useTranslation/* useTranslation */.$)();
        const { getCatalystData, pullLatestCatalystData } = (0,useVoteLib/* useVoteLib */.n)();
        const showChallenges = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const catalystData = (0,reactivity_esm_bundler/* ref */.iH)(null);
        const isRegistered = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const showCreateKeyModal = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const votingPreReqError = (0,reactivity_esm_bundler/* ref */.iH)('');
        const timelineItems = (0,reactivity_esm_bundler/* reactive */.qj)([]);
        (0,runtime_core_esm_bundler/* onMounted */.bv)(async () => {
            catalystData.value = await getCatalystData(props.account.network);
            if (catalystData.value) {
                loadVotingSchedule();
            }
            const newCatalystData = await pullLatestCatalystData(props.account.network);
            if (newCatalystData && JSON.stringify(catalystData.value) !== JSON.stringify(newCatalystData)) {
                catalystData.value = newCatalystData;
                loadVotingSchedule();
            }
            votingPrerequisites();
        });
        const currentTimelineItem = (0,reactivity_esm_bundler/* ref */.iH)(0);
        function loadVotingSchedule() {
            timelineItems.splice(0);
            timelineItems.push({
                id: 'snapshot',
                date: catalystData.value.registration_snapshot_time,
                time: true,
                label: t('wallet.voting.info.fund.timeline.snapshot.label'),
                caption: t('wallet.voting.info.fund.timeline.snapshot.caption'),
            }, {
                id: 'votestart',
                date: catalystData.value.fund_start_time,
                time: true,
                label: t('wallet.voting.info.fund.timeline.votestart.label'),
                caption: t('wallet.voting.info.fund.timeline.votestart.caption'),
            }, {
                id: 'voteend',
                date: catalystData.value.fund_end_time,
                time: true,
                label: t('wallet.voting.info.fund.timeline.voteend.label'),
                caption: t('wallet.voting.info.fund.timeline.voteend.caption'),
            }, {
                id: 'result',
                date: (0,VoteLib/* getResultsDate */.Nk)(catalystData.value).toISOString(),
                time: false,
                label: t('wallet.voting.info.fund.timeline.result.label'),
                caption: t('wallet.voting.info.fund.timeline.result.caption'),
            });
            for (const item of timelineItems) {
                const now = Date.now();
                if (now >= (new Date(item.date).getTime())) {
                    currentTimelineItem.value++;
                }
            }
        }
        const showWarningModal = (0,reactivity_esm_bundler/* ref */.iH)({ display: false });
        const confirmSnapshot = () => {
            showWarningModal.value.display = false;
            emit('register');
        };
        function votingPrerequisites() {
            if (!catalystData.value) {
                votingPreReqError.value = t('wallet.voting.error.api');
                return;
            }
            const isRegistered = props.account.base.stake.length > 0 && props.account.base.stake[0].registered;
            if (!isRegistered) {
                votingPreReqError.value = t('wallet.voting.error.notregistered');
                return;
            }
        }
        function onVoteKeyCreated(payload) {
            showCreateKeyModal.value = false;
            emit('votekeycreated');
        }
        function onRegister() {
            if (!props.ownVoteKey) {
                showCreateKeyModal.value = true;
                return;
            }
            //check if Snapshot has already been made and show warning
            const snapshotDate = catalystData.value.registration_snapshot_time;
            const now = Date.now();
            if (now >= (new Date(snapshotDate).getTime())) {
                showWarningModal.value.display = true;
            }
            else {
                emit('register');
            }
        }
        (0,runtime_core_esm_bundler/* onErrorCaptured */.d1)((e) => { console.error('Wallet: Voting: onErrorCaptured', e); return true; });
        return {
            t,
            votingPreReqError,
            isRegistered,
            catalystData,
            timelineItems,
            currentTimelineItem,
            showChallenges,
            showWarningModal,
            showCreateKeyModal,
            confirmSnapshot,
            onVoteKeyCreated,
            onRegister
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/voting/VoteInfo.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/voting/VoteInfo.vue




;
const VoteInfo_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(VoteInfovue_type_script_lang_ts, [['render',VoteInfovue_type_template_id_76e4db62_ts_true_render]])

/* harmony default export */ const VoteInfo = (VoteInfo_exports_);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/voting/VoteDelegation.vue?vue&type=template&id=5000fa7a&ts=true

const VoteDelegationvue_type_template_id_5000fa7a_ts_true_hoisted_1 = { key: 0 };
const VoteDelegationvue_type_template_id_5000fa7a_ts_true_hoisted_2 = { key: 1 };
const VoteDelegationvue_type_template_id_5000fa7a_ts_true_hoisted_3 = { class: "w-full lg:w-1/2" };
const VoteDelegationvue_type_template_id_5000fa7a_ts_true_hoisted_4 = {
    key: 1,
    class: "col-span-12 flex flex-row flex-nowrap items-center"
};
const VoteDelegationvue_type_template_id_5000fa7a_ts_true_hoisted_5 = {
    key: 2,
    class: "col-span-12 flex flex-row flex-nowrap items-center"
};
function VoteDelegationvue_type_template_id_5000fa7a_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_ConfirmationModal = (0,runtime_core_esm_bundler/* resolveComponent */.up)("ConfirmationModal");
    const _component_base_modal = (0,runtime_core_esm_bundler/* resolveComponent */.up)("base-modal");
    const _component_GridHeadline = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridHeadline");
    const _component_GridText = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridText");
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    const _component_VoteDelegationRatio = (0,runtime_core_esm_bundler/* resolveComponent */.up)("VoteDelegationRatio");
    const _component_IconPencil = (0,runtime_core_esm_bundler/* resolveComponent */.up)("IconPencil");
    const _component_IconDelete = (0,runtime_core_esm_bundler/* resolveComponent */.up)("IconDelete");
    const _component_GridTextArea = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridTextArea");
    const _component_GridButtonPrimary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonPrimary");
    const _component_GridButtonSecondary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonSecondary");
    const _component_IconWarning = (0,runtime_core_esm_bundler/* resolveComponent */.up)("IconWarning");
    const _component_SendConfirm = (0,runtime_core_esm_bundler/* resolveComponent */.up)("SendConfirm");
    const _component_SendSubmit = (0,runtime_core_esm_bundler/* resolveComponent */.up)("SendSubmit");
    const _component_GridSteps = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSteps");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, [
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_ConfirmationModal, {
            title: _ctx.t('wallet.voting.step.votepower.modal.delete.label'),
            caption: _ctx.t('wallet.voting.step.votepower.modal.delete.caption') + '\n\n' + _ctx.delegationList[_ctx.mod_index]?.voteKey,
            "show-modal": _ctx.showDeleteModal,
            onConfirm: _cache[0] || (_cache[0] = ($event) => (_ctx.confirmDelete())),
            onClose: _ctx.onCloseModal,
            onCancel: _ctx.onCloseModal
        }, null, 8, ["title", "caption", "show-modal", "onClose", "onCancel"]),
        (_ctx.showEditModal)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_base_modal, {
                key: 0,
                onClose: _ctx.onCloseModal,
                "show-modal": _ctx.showEditModal,
                persistent: false,
                title: _ctx.t('wallet.voting.step.votepower.modal.' + (_ctx.mod_index ? 'edit' : 'add') + '.label'),
                caption: _ctx.t('wallet.voting.step.votepower.modal.' + (_ctx.mod_index ? 'edit' : 'add') + '.caption'),
                "modal-c-s-s": "m-1 sm:max-w-xl cc-bg-light-1 flex flex-col flex-nowrap pb-2 relative",
                "header-c-s-s": "grow-0 flex items-start justify-between cc-bg-light-0 border-b cc-p",
                "content-c-s-s": "grow bg-transparent relative flex flex-col flex-nowrap relative h-full m-1 cc-p"
            }, {
                content: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                    (!_ctx.mod_index)
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", VoteDelegationvue_type_template_id_5000fa7a_ts_true_hoisted_1, " add new "))
                        : ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", VoteDelegationvue_type_template_id_5000fa7a_ts_true_hoisted_2, " edit: " + (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.delegationList[_ctx.mod_index]?.weight) + " - " + (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.delegationList[_ctx.mod_index]?.voteKey), 1))
                ]),
                _: 1
            }, 8, ["onClose", "show-modal", "title", "caption"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
            label: _ctx.t('wallet.voting.headline'),
            class: "col-span-12"
        }, null, 8, ["label"]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
            text: _ctx.t('wallet.voting.caption'),
            class: "col-span-12 cc-text-sz"
        }, null, 8, ["text"]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, {
            hr: "",
            class: "col-span-12 my-0.5 sm:my-2"
        }),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSteps, {
            onBack: _ctx.goBack,
            steps: _ctx.optionsSteps,
            currentStep: _ctx.currentStep,
            "small-c-s-s": "pr-9 sm:pr-20 md:pr-18 lg:pr-32"
        }, {
            step0: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                    label: _ctx.t('wallet.voting.step.votepower.header'),
                    class: "col-span-12"
                }, null, 8, ["label"]),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                    text: _ctx.t('wallet.voting.step.votepower.caption'),
                    class: "col-span-12 cc-text-sz"
                }, null, 8, ["text"]),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, {
                    hr: "",
                    class: "col-span-12 my-0.5 sm:my-2"
                }),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                    label: _ctx.t('dapps.voting.delegation.ratio.headline'),
                    class: "w-full"
                }, null, 8, ["label"]),
                ((0,runtime_core_esm_bundler/* openBlock */.wg)(true), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, (0,runtime_core_esm_bundler/* renderList */.Ko)(_ctx.delegationList, (delegation, index) => {
                    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", {
                        class: "col-span-12 flex flex-row flex-nowrap items-center",
                        key: index
                    }, [
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", VoteDelegationvue_type_template_id_5000fa7a_ts_true_hoisted_3, [
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_VoteDelegationRatio, {
                                "network-id": _ctx.networkId,
                                "voting-key": _ctx.byteaToHex(delegation.voteKey),
                                weight: delegation.weight,
                                "total-weight": _ctx.totalWeight,
                                "is-own": _ctx.byteaToHex(delegation.voteKey) === _ctx.ownVoteKeyHex
                            }, null, 8, ["network-id", "voting-key", "weight", "total-weight", "is-own"])
                        ]),
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_IconPencil, {
                            class: "h-5 flex-none cursor-pointer ml-2",
                            onClick: (0,runtime_dom_esm_bundler/* withModifiers */.iM)(($event) => (_ctx.openEditModal(index)), ["stop"])
                        }, null, 8, ["onClick"]),
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_IconDelete, {
                            class: "h-5 flex-none cc-text-color-error cursor-pointer ml-2",
                            onClick: (0,runtime_dom_esm_bundler/* withModifiers */.iM)(($event) => (_ctx.openDeleteModal(index)), ["stop"])
                        }, null, 8, ["onClick"])
                    ]));
                }), 128)),
                (_ctx.delegationList.length === 0)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridTextArea, {
                        key: 0,
                        text: _ctx.t('wallet.voting.step.votepower.empty'),
                        icon: "mdi mdi-information-outline",
                        class: "col-span-12 mb-2",
                        "text-c-s-s": "cc-text-normal text-justify flex justify-start items-center",
                        css: "cc-rounded cc-banner-blue"
                    }, null, 8, ["text"]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonPrimary, {
                    label: _ctx.t('wallet.voting.step.votepower.button.add'),
                    link: _ctx.onAddDelegation,
                    class: "col-start-7 col-span-6 lg:col-start-10 lg:col-span-3"
                }, null, 8, ["label", "link"]),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, {
                    hr: "",
                    class: "col-span-12 py-2"
                }),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonSecondary, {
                    label: _ctx.t('common.label.cancel'),
                    link: _ctx.goBack,
                    class: "col-start-0 col-span-6 lg:col-start-0 lg:col-span-3"
                }, null, 8, ["label", "link"]),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonPrimary, {
                    label: _ctx.t('wallet.voting.step.votepower.button.next'),
                    link: _ctx.gotoNext,
                    class: "col-start-7 col-span-6 lg:col-start-10 lg:col-span-3"
                }, null, 8, ["label", "link"])
            ]),
            step1: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                    label: _ctx.t('wallet.voting.step.tx.' + (_ctx.delegationList.length === 0 ? 'de' : '') + 'registration.header'),
                    class: "col-span-12"
                }, null, 8, ["label"]),
                (_ctx.delegationList.length > 0)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridText, {
                        key: 0,
                        text: _ctx.t('wallet.voting.step.tx.registration.caption'),
                        class: "col-span-12 cc-text-sz"
                    }, null, 8, ["text"]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                (_ctx.delegationList.length > 0)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", VoteDelegationvue_type_template_id_5000fa7a_ts_true_hoisted_4, [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_IconWarning, { class: "w-7 flex-none mr-2" }),
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                            text: _ctx.t('wallet.voting.step.tx.warning'),
                            class: "cc-text-sz"
                        }, null, 8, ["text"])
                    ]))
                    : ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", VoteDelegationvue_type_template_id_5000fa7a_ts_true_hoisted_5, [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_IconWarning, { class: "w-7 flex-none mr-2" }),
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                            text: _ctx.t('wallet.voting.step.tx.deregistration.caption'),
                            class: "cc-text-sz"
                        }, null, 8, ["text"])
                    ])),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, {
                    hr: "",
                    class: "col-span-12 my-0.5 sm:my-2"
                }),
                (_ctx.tx && !_ctx.txSigned)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_SendConfirm, {
                        key: 3,
                        onSubmit: _ctx.onTxSigned,
                        account: _ctx.account,
                        wallet: _ctx.wallet,
                        "unsigned-tx": _ctx.tx,
                        type: "voting",
                        "show-label": false,
                        "text-id": "wallet.send.step.confirm"
                    }, {
                        btnBack: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonSecondary, {
                                label: _ctx.t('common.label.back'),
                                link: _ctx.goBack,
                                class: "col-start-0 col-span-6 lg:col-start-0 lg:col-span-3"
                            }, null, 8, ["label", "link"])
                        ]),
                        _: 1
                    }, 8, ["onSubmit", "account", "wallet", "unsigned-tx"]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
            ]),
            step2: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                (_ctx.txSigned || _ctx.hasSubmitError)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_SendSubmit, {
                        key: 0,
                        onError: _ctx.onSubmitError,
                        onPending: _ctx.onTxPending,
                        onConfirmed: _ctx.onTxConfirmed,
                        "text-id": "wallet.send.step.submit"
                    }, {
                        btnBack: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, { class: "col-span-12" }),
                            (_ctx.hasSubmitError)
                                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridButtonSecondary, {
                                    key: 0,
                                    label: _ctx.t('common.label.back'),
                                    link: _ctx.goBack,
                                    class: "col-start-0 col-span-6 lg:col-start-0 lg:col-span-3"
                                }, null, 8, ["label", "link"]))
                                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                        ]),
                        _: 1
                    }, 8, ["onError", "onPending", "onConfirmed"]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
            ]),
            _: 1
        }, 8, ["onBack", "steps", "currentStep"])
    ], 64));
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/voting/VoteDelegation.vue?vue&type=template&id=5000fa7a&ts=true

// EXTERNAL MODULE: ./node_modules/quasar/src/composables/use-quasar.js
var use_quasar = __webpack_require__(48825);
// EXTERNAL MODULE: ./src/composables/ccw/useNavigation.ts
var useNavigation = __webpack_require__(52439);
// EXTERNAL MODULE: ./src/composables/ccw/useNetworkId.ts
var useNetworkId = __webpack_require__(36648);
// EXTERNAL MODULE: ./src/composables/ccw/store/useBuildTx_v3.ts + 1 modules
var useBuildTx_v3 = __webpack_require__(72107);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/send/SendConfirm.vue + 4 modules
var SendConfirm = __webpack_require__(12662);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/send/SendSubmit.vue + 3 modules
var SendSubmit = __webpack_require__(65778);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/voting/VoteDelegationRatio.vue + 4 modules
var VoteDelegationRatio = __webpack_require__(36009);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/icons/IconWarning.vue + 4 modules
var IconWarning = __webpack_require__(97515);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridSteps.vue + 14 modules
var GridSteps = __webpack_require__(58217);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/icons/IconPencil.vue + 4 modules
var IconPencil = __webpack_require__(44814);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/icons/IconDelete.vue + 4 modules
var IconDelete = __webpack_require__(76766);
// EXTERNAL MODULE: ../ccw-lib2/core/ICatalyst.ts
var ICatalyst = __webpack_require__(36594);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/CSLUtils.ts
var CSLUtils = __webpack_require__(58173);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/LibUtils.ts
var LibUtils = __webpack_require__(10751);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/voting/VoteDelegation.vue?vue&type=script&lang=ts

;























/* harmony default export */ const VoteDelegationvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'VoteDelegation',
    components: {
        GridSpace: GridSpace/* default */.Z,
        GridHeadline: GridHeadline/* default */.Z,
        GridText: GridText/* default */.Z,
        GridTextArea: GridTextArea/* default */.Z,
        GridSteps: GridSteps/* default */.Z,
        GridButtonPrimary: GridButtonPrimary/* default */.Z,
        GridButtonSecondary: GridButtonSecondary/* default */.Z,
        IconWarning: IconWarning/* default */.Z,
        IconPencil: IconPencil/* default */.Z,
        IconDelete: IconDelete/* default */.Z,
        ConfirmationModal: ConfirmationModal/* default */.Z,
        BaseModal: BaseModal/* default */.Z,
        VoteDelegationRatio: VoteDelegationRatio/* default */.Z,
        SendConfirm: SendConfirm/* default */.Z,
        SendSubmit: SendSubmit/* default */.Z,
    },
    emits: ['cancel'],
    props: {
        ownVoteKey: { type: Object, required: true },
        account: { type: Object, required: true },
        wallet: { type: Object, required: true }
    },
    setup(props, { emit }) {
        const { t } = (0,useTranslation/* useTranslation */.$)();
        const { gotoWalletPage } = (0,useNavigation/* useNavigation */.HJ)();
        const $q = (0,use_quasar/* default */.Z)();
        const { networkId } = (0,useNetworkId/* useNetworkId */.h)();
        const showEditModal = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const showDeleteModal = (0,reactivity_esm_bundler/* ref */.iH)({ display: false });
        const mod_index = (0,reactivity_esm_bundler/* ref */.iH)(null);
        const currentStep = (0,reactivity_esm_bundler/* ref */.iH)(0);
        const ownVoteKeyHex = (0,CSLUtils/* getEd25519PubKeyHex */.ZG)(props.ownVoteKey.pub);
        const txSigned = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const delegationList = (0,reactivity_esm_bundler/* ref */.iH)([{ voteKey: ownVoteKeyHex, weight: 1 }]);
        const totalWeight = (0,runtime_core_esm_bundler/* computed */.Fl)(() => delegationList.value.reduce((total, amount) => total + amount.weight, 0));
        const { isActiveWalletSyncing } = (0,useActiveWallet/* useActiveWallet */.r)();
        const { resetBuildTx, buildVotingTx, getBuildStatus, getBuiltTx } = (0,useBuildTx_v3/* useBuildTxV3 */.b)();
        const tx = (0,runtime_core_esm_bundler/* computed */.Fl)(() => getBuiltTx(props.account.pub));
        const hasSubmitError = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const buildStatus = (0,runtime_core_esm_bundler/* computed */.Fl)(() => getBuildStatus(props.account.pub));
        const optionsSteps = (0,reactivity_esm_bundler/* reactive */.qj)([
            { id: 'power', label: t('wallet.voting.step.stepper.power') },
            { id: 'tx', label: t('wallet.voting.step.stepper.tx') },
            { id: 'submit', label: t('wallet.voting.step.stepper.submit') },
        ]);
        function goBack() {
            if (currentStep.value === 0) {
                emit('cancel');
            }
            else if (currentStep.value === 1) {
                currentStep.value = 0;
            }
            else if (currentStep.value === 2) {
                currentStep.value = 1;
            }
        }
        async function gotoNext() {
            if (isActiveWalletSyncing.value && currentStep.value === 0) {
                $q.notify({
                    type: 'warning',
                    message: t('wallet.voting.error.syncing'),
                    position: 'top-left'
                });
                return;
            }
            if (currentStep.value === 0) {
                resetBuildTx(props.account.pub);
                try {
                    await buildVotingTx(props.wallet, props.account, { delegations: delegationList.value, purpose: ICatalyst/* ICIP62VotingPurpose.CATALYST */.n.CATALYST });
                    currentStep.value = 1;
                }
                catch (err) {
                    $q.notify({
                        type: 'negative',
                        message: err?.message ?? t('wallet.voting.error.nometadata'),
                        position: 'top-left'
                    });
                }
            }
            else if (currentStep.value === 1) {
                currentStep.value = 2;
            }
        }
        function onTxPending() {
            gotoWalletPage('Transactions', 'pending');
        }
        function onTxConfirmed() { }
        function onSubmitError() {
            hasSubmitError.value = true;
            txSigned.value = false;
        }
        async function onTxSigned() { txSigned.value = true; }
        const openEditModal = (index) => {
            mod_index.value = index;
            showEditModal.value = true;
        };
        const openDeleteModal = (index) => {
            mod_index.value = index;
            showDeleteModal.value.display = true;
        };
        const onCloseModal = () => {
            showEditModal.value = false;
            showDeleteModal.value.display = false;
        };
        const confirmDelete = () => {
            mod_index.value !== null ? delegationList.value.splice(mod_index.value, 1) : false;
            onCloseModal();
        };
        const onAddDelegation = () => {
            mod_index.value = null;
            showEditModal.value = true;
        };
        (0,runtime_core_esm_bundler/* onErrorCaptured */.d1)((e) => { console.error('Wallet: Voting: onErrorCaptured', e); return true; });
        return {
            t,
            networkId,
            tx,
            txSigned,
            ownVoteKeyHex,
            delegationList,
            totalWeight,
            showEditModal,
            showDeleteModal,
            mod_index,
            openEditModal,
            openDeleteModal,
            onCloseModal,
            confirmDelete,
            onAddDelegation,
            optionsSteps,
            currentStep,
            hasSubmitError,
            buildStatus,
            IBuildStatus: useBuildTx_v3/* IBuildStatus */.k,
            byteaToHex: LibUtils/* byteaToHex */.rQ,
            goBack,
            gotoNext,
            onTxSigned,
            onTxPending,
            onTxConfirmed,
            onSubmitError
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/voting/VoteDelegation.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/voting/VoteDelegation.vue




;
const VoteDelegation_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(VoteDelegationvue_type_script_lang_ts, [['render',VoteDelegationvue_type_template_id_5000fa7a_ts_true_render]])

/* harmony default export */ const VoteDelegation = (VoteDelegation_exports_);
// EXTERNAL MODULE: ./src/lib/utils/useLocalStorage.ts
var useLocalStorage = __webpack_require__(34787);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/Voting.vue?vue&type=script&lang=ts







/* harmony default export */ const Votingvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'Voting',
    components: {
        VoteInfo: VoteInfo,
        VoteDelegation: VoteDelegation
    },
    setup() {
        const { activeWalletData, activeAccount } = (0,useActiveWallet/* useActiveWallet */.r)();
        const showRegister = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const ownVoteKey = (0,reactivity_esm_bundler/* ref */.iH)(getVotingKey());
        // Gets the account voting pub key that can be used to derive child keys
        function getVotingKey() {
            if (!activeWalletData.value || !activeAccount.value) {
                return null;
            }
            const path = (0,VoteLib/* getVoteKeyPath */.T8)(activeAccount.value.index);
            const additionalKeys = (0,useLocalStorage/* getAdditionalKeyList */.Ju)();
            let votingKey = null;
            if (additionalKeys) {
                votingKey = additionalKeys[activeWalletData.value?.id]?.find(k => (0,LibUtils/* isSameArray */.EZ)(k.path, path)) ?? null;
            }
            return votingKey;
        }
        function onVoteKeyCreated() {
            ownVoteKey.value = getVotingKey();
        }
        return {
            activeWalletData,
            activeAccount,
            showRegister,
            ownVoteKey,
            onVoteKeyCreated
        };
    }
}));

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/Voting.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/Voting.vue




;
const Voting_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(Votingvue_type_script_lang_ts, [['render',render]])

/* harmony default export */ const Voting = (Voting_exports_);

/***/ })

}]);
//# sourceMappingURL=8094.js.map