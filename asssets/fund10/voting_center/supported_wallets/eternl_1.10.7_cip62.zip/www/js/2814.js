"use strict";
(this["webpackChunkccw_frontend"] = this["webpackChunkccw_frontend"] || []).push([[2814],{

/***/ 92594:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ ImportKey)
});

// EXTERNAL MODULE: ./node_modules/@vue/runtime-core/dist/runtime-core.esm-bundler.js
var runtime_core_esm_bundler = __webpack_require__(83673);
// EXTERNAL MODULE: ./node_modules/@vue/shared/dist/shared.esm-bundler.js
var shared_esm_bundler = __webpack_require__(62323);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/ImportKey.vue?vue&type=template&id=3a4db924&ts=true

const _hoisted_1 = { class: "min-h-16 sm:min-h-20 w-full max-w-full p-3 text-center flex flex-col flex-nowrap justify-center items-center border-t border-b mb-px cc-bg-white-0" };
const _hoisted_2 = { class: "cc-text-semi-bold" };
const _hoisted_3 = { class: "" };
const _hoisted_4 = { class: "cc-page-wallet cc-text-sz" };
function render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_InfoModal = (0,runtime_core_esm_bundler/* resolveComponent */.up)("InfoModal");
    const _component_GridFormAccountKey = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridFormAccountKey");
    const _component_GridButtonSecondary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonSecondary");
    const _component_GridFormWalletName = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridFormWalletName");
    const _component_GridSteps = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSteps");
    const _component_Page = (0,runtime_core_esm_bundler/* resolveComponent */.up)("Page");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_Page, {
        containerCSS: '',
        "align-top": ""
    }, {
        header: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_1, [
                (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_2, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('wallet.importkey.headline')), 1),
                (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_3, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('wallet.importkey.caption')), 1)
            ])
        ]),
        content: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
            (_ctx.showInfoModal)
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_InfoModal, {
                    key: 0,
                    caption: _ctx.it('common.walletCreation.restart'),
                    title: _ctx.it('common.label.notice'),
                    onClose: _ctx.onHideModal,
                    onConfirm: _ctx.onHideModal
                }, null, 8, ["caption", "title", "onClose", "onConfirm"]))
                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_4, [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSteps, {
                    onBack: _ctx.goBack,
                    steps: _ctx.optionsSteps,
                    currentStep: _ctx.currentStep,
                    "small-c-s-s": "pr-20 xs:pr-20 lg:pr-24"
                }, {
                    step0: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridFormAccountKey, {
                            class: "col-span-12",
                            onSubmit: _ctx.gotoNextStepWalletName
                        }, null, 8, ["onSubmit"])
                    ]),
                    step1: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridFormWalletName, {
                            class: "col-span-12",
                            "is-update": false,
                            onSubmit: _ctx.gotoNextStepWalletCreation
                        }, {
                            btnBack: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonSecondary, {
                                    class: "col-start-0 col-span-12 lg:col-start-0 lg:col-span-3",
                                    label: _ctx.it('common.label.back'),
                                    link: _ctx.goBack
                                }, null, 8, ["label", "link"])
                            ]),
                            _: 1
                        }, 8, ["onSubmit"])
                    ]),
                    _: 1
                }, 8, ["onBack", "steps", "currentStep"])
            ])
        ]),
        _: 1
    }));
}

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/ImportKey.vue?vue&type=template&id=3a4db924&ts=true

// EXTERNAL MODULE: ./node_modules/@vue/reactivity/dist/reactivity.esm-bundler.js
var reactivity_esm_bundler = __webpack_require__(61959);
// EXTERNAL MODULE: ./node_modules/quasar/src/composables/use-quasar.js
var use_quasar = __webpack_require__(48825);
// EXTERNAL MODULE: ./src/composables/ccw/useNetworkId.ts
var useNetworkId = __webpack_require__(36648);
// EXTERNAL MODULE: ./src/composables/ccw/useTranslation.ts
var useTranslation = __webpack_require__(19376);
// EXTERNAL MODULE: ./src/composables/ccw/useNavigation.ts
var useNavigation = __webpack_require__(52439);
// EXTERNAL MODULE: ./src/composables/ccw/store/useWalletList.ts
var useWalletList = __webpack_require__(4905);
// EXTERNAL MODULE: ./src/composables/ccw/store/useWalletCreation.ts
var useWalletCreation = __webpack_require__(68139);
// EXTERNAL MODULE: ./src/components/ccw/Page.vue + 21 modules
var Page = __webpack_require__(53707);
// EXTERNAL MODULE: ./src/components/ccw/modal/InfoModal.vue + 4 modules
var InfoModal = __webpack_require__(82172);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridHeadline.vue + 3 modules
var GridHeadline = __webpack_require__(63593);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridText.vue + 4 modules
var GridText = __webpack_require__(96834);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridSpace.vue + 4 modules
var GridSpace = __webpack_require__(14740);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridSteps.vue + 14 modules
var GridSteps = __webpack_require__(58217);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridRadioGroup.vue + 4 modules
var GridRadioGroup = __webpack_require__(46837);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridButtonPrimary.vue + 3 modules
var GridButtonPrimary = __webpack_require__(12559);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridButtonSecondary.vue + 3 modules
var GridButtonSecondary = __webpack_require__(72713);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/forms/GridFormAccountKey.vue?vue&type=template&id=35a7189e&ts=true

const GridFormAccountKeyvue_type_template_id_35a7189e_ts_true_hoisted_1 = { class: "col-span-12 grid grid-cols-12 cc-gap items-end" };
function GridFormAccountKeyvue_type_template_id_35a7189e_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GFEAccountKey = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GFEAccountKey");
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    const _component_GridForm = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridForm");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridForm, {
        onDoFormReset: _ctx.onReset,
        onDoFormSubmit: _ctx.onSubmit,
        "form-id": 'accountkey',
        "reset-button-label": _ctx.it('common.label.reset'),
        "submit-button-label": _ctx.it('common.label.save'),
        "submit-disabled": !_ctx.submitEnabled
    }, {
        content: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", GridFormAccountKeyvue_type_template_id_35a7189e_ts_true_hoisted_1, [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GFEAccountKey, {
                    "always-show-info": "",
                    onOnSubmittable: _ctx.onSetAccountKey,
                    "reset-counter": _ctx.resetCounter,
                    label: _ctx.it('common.accountkey.headline'),
                    hint: _ctx.it('common.accountkey.hint'),
                    info: _ctx.it('common.accountkey.info'),
                    error: _ctx.it('common.accountkey.error')
                }, null, 8, ["onOnSubmittable", "reset-counter", "label", "hint", "info", "error"]),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, {
                    hr: "",
                    class: "my-0.5 sm:my-2"
                })
            ])
        ]),
        btnBack: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
            (0,runtime_core_esm_bundler/* renderSlot */.WI)(_ctx.$slots, "btnBack")
        ]),
        _: 3
    }, 8, ["onDoFormReset", "onDoFormSubmit", "reset-button-label", "submit-button-label", "submit-disabled"]));
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/forms/GridFormAccountKey.vue?vue&type=template&id=35a7189e&ts=true

// EXTERNAL MODULE: ./src/components/ccw/grid/v2/forms/GridForm.vue + 3 modules
var GridForm = __webpack_require__(76798);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/forms/elements/GFEAccountKey.vue?vue&type=template&id=5672f6dc&ts=true

function GFEAccountKeyvue_type_template_id_5672f6dc_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_IconPencil = (0,runtime_core_esm_bundler/* resolveComponent */.up)("IconPencil");
    const _component_GridInput = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridInput");
    const _component_ScanQrCode = (0,runtime_core_esm_bundler/* resolveComponent */.up)("ScanQrCode");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, [
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridInput, {
            "input-text": _ctx.accountKey,
            "onUpdate:input-text": _cache[0] || (_cache[0] = ($event) => ((_ctx.accountKey) = $event)),
            "input-error": _ctx.accountKeyError,
            "onUpdate:input-error": _cache[1] || (_cache[1] = ($event) => ((_ctx.accountKeyError) = $event)),
            class: "col-span-12 md:col-span-11",
            onLostFocus: _ctx.validateAccountKey,
            onEnter: _ctx.validateAccountKey,
            onReset: _ctx.onResetAccountKey,
            label: _ctx.label || _ctx.t('common.accountkey.name.label'),
            "input-hint": _ctx.hint || _ctx.t('common.accountkey.name.hint'),
            "input-info": _ctx.info || _ctx.t('common.accountkey.name.info'),
            autocomplete: _ctx.autocomplete,
            alwaysShowInfo: _ctx.alwaysShowInfo,
            showReset: true,
            "input-id": "inputAccountKey",
            "input-type": "text"
        }, {
            "icon-prepend": (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_IconPencil, { class: "h-5 w-5" })
            ]),
            _: 1
        }, 8, ["input-text", "input-error", "onLostFocus", "onEnter", "onReset", "label", "input-hint", "input-info", "autocomplete", "alwaysShowInfo"]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_ScanQrCode, {
            onDecode: _ctx.onQrCode,
            "button-css": "col-start-0 col-span-6 md:col-start-12 md:col-span-1 h-9 sm:h-11"
        }, null, 8, ["onDecode"])
    ], 64));
}

// EXTERNAL MODULE: ./src/components/ccw/grid/v2/icons/IconPencil.vue + 4 modules
var IconPencil = __webpack_require__(44814);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridInput.vue + 4 modules
var GridInput = __webpack_require__(27209);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/send/ScanQrCode.vue + 12 modules
var ScanQrCode = __webpack_require__(9055);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/forms/elements/GFEAccountKey.vue?vue&type=script&lang=ts







/* harmony default export */ const GFEAccountKeyvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'GFEAccountKey',
    components: {
        IconPencil: IconPencil/* default */.Z,
        GridInput: GridInput/* default */.Z,
        ScanQrCode: ScanQrCode/* default */.Z
    },
    emits: [
        'onSubmittable'
    ],
    props: {
        label: { type: String, required: false, default: null },
        hint: { type: String, required: false, default: null },
        info: { type: String, required: false, default: null },
        error: { type: String, required: false, default: null },
        alwaysShowInfo: { type: Boolean, default: false },
        resetCounter: { type: Number, required: true, default: 0 },
        autocomplete: { type: String, default: 'off' }
    },
    setup(props, context) {
        const { t } = (0,useTranslation/* useTranslation */.$)();
        const accountKey = (0,reactivity_esm_bundler/* ref */.iH)('');
        const accountKeyError = (0,reactivity_esm_bundler/* ref */.iH)('');
        function validateAccountKey(external) {
            let isValid = false;
            if (accountKey.value) {
                const key = accountKey.value;
                if ((key.startsWith('acct_xvk') && key.length === 118) ||
                    (key.startsWith('xpub') && key.length === 114) ||
                    (key.length === 128)) {
                    isValid = true;
                }
            }
            if (accountKey.value.length > 0 && !isValid) {
                accountKeyError.value = props.error || t('common.accountkey.name.error');
            }
            else {
                accountKeyError.value = '';
            }
            context.emit('onSubmittable', {
                accountKey: accountKey.value,
                submittable: accountKey.value.length > 0 && isValid
            });
            return accountKeyError.value;
        }
        let town = -1;
        (0,runtime_core_esm_bundler/* watch */.YP)(accountKey, () => { clearTimeout(town); town = setTimeout(() => validateAccountKey(false), 500); });
        (0,runtime_core_esm_bundler/* watch */.YP)(() => props.resetCounter, () => { onResetAccountKey(); });
        function onResetAccountKey() {
            accountKey.value = '';
            accountKeyError.value = '';
        }
        (0,runtime_core_esm_bundler/* onMounted */.bv)(() => {
            validateAccountKey(false);
        });
        function onQrCode(payload) {
            accountKey.value = payload.content;
        }
        return {
            t,
            onQrCode,
            accountKey,
            accountKeyError,
            validateAccountKey,
            onResetAccountKey
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/forms/elements/GFEAccountKey.vue?vue&type=script&lang=ts
 
// EXTERNAL MODULE: ./node_modules/vue-loader/dist/exportHelper.js
var exportHelper = __webpack_require__(74260);
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/forms/elements/GFEAccountKey.vue




;
const __exports__ = /*#__PURE__*/(0,exportHelper/* default */.Z)(GFEAccountKeyvue_type_script_lang_ts, [['render',GFEAccountKeyvue_type_template_id_5672f6dc_ts_true_render]])

/* harmony default export */ const GFEAccountKey = (__exports__);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/forms/GridFormAccountKey.vue?vue&type=script&lang=ts







/* harmony default export */ const GridFormAccountKeyvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'GridFormAccountKey',
    components: {
        GridForm: GridForm/* default */.Z,
        GFEAccountKey: GFEAccountKey,
        GridSpace: GridSpace/* default */.Z
    },
    emits: ['submit'],
    props: {
        textId: { type: String, required: false, default: '' }
    },
    setup(props, context) {
        const { it } = (0,useTranslation/* useTranslation */.$)();
        const resetCounter = (0,reactivity_esm_bundler/* ref */.iH)(0);
        const submittable = (0,reactivity_esm_bundler/* reactive */.qj)({
            accountKey: false
        });
        const errors = (0,reactivity_esm_bundler/* reactive */.qj)({
            accountKey: false
        });
        const accountKey = (0,reactivity_esm_bundler/* ref */.iH)('');
        function onSetAccountKey(payload) {
            submittable.accountKey = payload.submittable;
            errors.accountKey = payload.error;
            if (submittable.accountKey) {
                accountKey.value = payload.accountKey;
            }
        }
        async function onSubmit() {
            context.emit('submit', {
                accountKey: accountKey.value
            });
            onReset();
        }
        function onReset() {
            resetCounter.value = resetCounter.value + 1;
        }
        const submitEnabled = (0,runtime_core_esm_bundler/* computed */.Fl)(() => ((!errors.accountKey)
            &&
                (submittable.accountKey)));
        return {
            it,
            submittable,
            submitEnabled,
            resetCounter,
            accountKey,
            onSetAccountKey,
            onSubmit,
            onReset
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/forms/GridFormAccountKey.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/forms/GridFormAccountKey.vue




;
const GridFormAccountKey_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(GridFormAccountKeyvue_type_script_lang_ts, [['render',GridFormAccountKeyvue_type_template_id_35a7189e_ts_true_render]])

/* harmony default export */ const GridFormAccountKey = (GridFormAccountKey_exports_);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/forms/GridFormWalletName.vue + 3 modules
var GridFormWalletName = __webpack_require__(81839);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/icons/IconInfo.vue + 4 modules
var IconInfo = __webpack_require__(31599);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/icons/IconWarning.vue + 4 modules
var IconWarning = __webpack_require__(97515);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/ImportKey.vue?vue&type=script&lang=ts


;


















/* harmony default export */ const ImportKeyvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'ImportKey',
    components: {
        Page: Page/* default */.Z,
        InfoModal: InfoModal/* default */.Z,
        GridSpace: GridSpace/* default */.Z,
        GridHeadline: GridHeadline/* default */.Z,
        GridText: GridText/* default */.Z,
        GridSteps: GridSteps/* default */.Z,
        GridRadioGroup: GridRadioGroup/* default */.Z,
        GridButtonPrimary: GridButtonPrimary/* default */.Z,
        GridButtonSecondary: GridButtonSecondary/* default */.Z,
        GridFormAccountKey: GridFormAccountKey,
        GridFormWalletName: GridFormWalletName/* default */.Z,
        IconInfo: IconInfo/* default */.Z,
        IconWarning: IconWarning/* default */.Z
    },
    setup() {
        const { setWalletName, setAccountPubBech32List, generateWalletIdFromPubBech32, createWallet } = (0,useWalletCreation/* useWalletCreation */.c)();
        const { reloadWalletList, hasWalletWithId } = (0,useWalletList/* useWalletList */.M)();
        const { networkId } = (0,useNetworkId/* useNetworkId */.h)();
        const { openWallet, gotoWalletList, } = (0,useNavigation/* useNavigation */.HJ)();
        const { it } = (0,useTranslation/* useTranslation */.$)();
        const $q = (0,use_quasar/* default */.Z)();
        const currentStep = (0,reactivity_esm_bundler/* ref */.iH)(0);
        const showInfoModal = (0,reactivity_esm_bundler/* ref */.iH)(false);
        function resetInputs() {
            setWalletName('');
            setAccountPubBech32List(['']);
        }
        resetInputs();
        function goBack() {
            // if(currentStep.value === 1) { currentStep.value = 0 }
            // else
            if (currentStep.value === 1) {
                currentStep.value = 0;
                resetInputs();
            }
        }
        async function gotoNextStepWalletName(payload) {
            if (payload.accountKey) {
                setWalletName(payload.accountKey); // tmp
                setAccountPubBech32List([payload.accountKey]);
            }
            try {
                const walletId = generateWalletIdFromPubBech32(networkId.value, 'readonly');
                if (hasWalletWithId(walletId)) {
                    $q.notify({
                        type: 'warning',
                        message: it('wallet.importkey.message.duplicate'),
                        position: 'top-left'
                    });
                    openWallet(walletId);
                }
                else {
                    currentStep.value = 1;
                }
            }
            catch (err) {
            }
        }
        async function gotoNextStepWalletCreation(payload) {
            setWalletName(payload.walletName);
            try {
                if (!networkId.value) {
                    throw new Error('Error: No active network.');
                }
                const walletId = await createWallet(networkId.value, 'readonly');
                await reloadWalletList();
                $q.notify({
                    type: 'positive',
                    message: it('wallet.importkey.message.success'),
                    position: 'top-left'
                });
                openWallet(walletId);
            }
            catch (err) {
                console.error('CreateWallet: Error:', err.message);
                showInfoModal.value = true;
            }
        }
        const optionsSteps = (0,reactivity_esm_bundler/* reactive */.qj)([
            { id: 'key', label: it('wallet.importkey.step.key') },
            { id: 'name', label: it('wallet.importkey.step.name') }
        ]);
        function onHideModal() {
            showInfoModal.value = false;
        }
        return {
            it,
            optionsSteps,
            currentStep,
            goBack,
            gotoNextStepWalletName,
            gotoNextStepWalletCreation,
            gotoWalletList,
            showInfoModal,
            onHideModal
        };
    }
}));

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/ImportKey.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/pages/ccw/wallet/ImportKey.vue




;
const ImportKey_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(ImportKeyvue_type_script_lang_ts, [['render',render]])

/* harmony default export */ const ImportKey = (ImportKey_exports_);

/***/ })

}]);
//# sourceMappingURL=2814.js.map