"use strict";
(this["webpackChunkccw_frontend"] = this["webpackChunkccw_frontend"] || []).push([[3085],{

/***/ 73085:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ List)
});

// EXTERNAL MODULE: ./node_modules/@vue/runtime-core/dist/runtime-core.esm-bundler.js
var runtime_core_esm_bundler = __webpack_require__(83673);
// EXTERNAL MODULE: ./node_modules/@vue/shared/dist/shared.esm-bundler.js
var shared_esm_bundler = __webpack_require__(62323);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/List.vue?vue&type=template&id=620a45e1&ts=true

const _hoisted_1 = { class: "relative flex-1 flex justify-center items-center" };
const _hoisted_2 = { class: "flex flex-col flex-nowrap justify-center items-center cc-text-color-caption" };
const _hoisted_3 = /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("i", { class: "mdi mdi-wallet text-8xl sm:text-9xl" }, null, -1);
const _hoisted_4 = { class: "text-2xl text-center" };
function render(_ctx, _cache, $props, $setup, $data, $options) {
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_1, [
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_2, [
            _hoisted_3,
            (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_4, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.list.choose')), 1)
        ])
    ]));
}

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/List.vue?vue&type=template&id=620a45e1&ts=true

// EXTERNAL MODULE: ./src/composables/ccw/state/useMainMenuOpen.ts
var useMainMenuOpen = __webpack_require__(33008);
// EXTERNAL MODULE: ./src/composables/ccw/useTranslation.ts
var useTranslation = __webpack_require__(19376);
// EXTERNAL MODULE: ./src/pages/ccw/LandingPage.vue + 4 modules
var LandingPage = __webpack_require__(37809);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/List.vue?vue&type=script&lang=ts




/* harmony default export */ const Listvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'List',
    components: { LandingPage: LandingPage["default"] },
    setup() {
        const { t } = (0,useTranslation/* useTranslation */.$)();
        const { toggleMainMenu, isMainMenuOpen } = (0,useMainMenuOpen/* useMainMenuOpen */.T)();
        if (!isMainMenuOpen.value) {
            toggleMainMenu();
        }
        return {
            t
        };
    }
}));

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/List.vue?vue&type=script&lang=ts
 
// EXTERNAL MODULE: ./node_modules/vue-loader/dist/exportHelper.js
var exportHelper = __webpack_require__(74260);
;// CONCATENATED MODULE: ./src/pages/ccw/wallet/List.vue




;
const __exports__ = /*#__PURE__*/(0,exportHelper/* default */.Z)(Listvue_type_script_lang_ts, [['render',render]])

/* harmony default export */ const List = (__exports__);

/***/ })

}]);
//# sourceMappingURL=3085.js.map