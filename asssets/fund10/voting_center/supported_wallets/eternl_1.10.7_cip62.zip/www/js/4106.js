"use strict";
(this["webpackChunkccw_frontend"] = this["webpackChunkccw_frontend"] || []).push([[4106],{

/***/ 84106:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "_copyToClipboard": () => (/* binding */ _copyToClipboard)
/* harmony export */ });
/* harmony import */ var _capacitor_clipboard__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(66717);

const _copyToClipboard = async (textToCopy) => {
    try {
        await _capacitor_clipboard__WEBPACK_IMPORTED_MODULE_0__/* .Clipboard.write */ .T.write({ string: textToCopy });
        return true;
    }
    catch (e) {
        console.error(e);
        throw e;
    }
};


/***/ })

}]);
//# sourceMappingURL=4106.js.map