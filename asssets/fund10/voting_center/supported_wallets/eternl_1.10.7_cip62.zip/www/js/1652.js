"use strict";
(this["webpackChunkccw_frontend"] = this["webpackChunkccw_frontend"] || []).push([[1652],{

/***/ 83777:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ ErrorLayout)
});

// EXTERNAL MODULE: ./node_modules/@vue/runtime-core/dist/runtime-core.esm-bundler.js
var runtime_core_esm_bundler = __webpack_require__(83673);
// EXTERNAL MODULE: ./node_modules/@vue/shared/dist/shared.esm-bundler.js
var shared_esm_bundler = __webpack_require__(62323);
// EXTERNAL MODULE: ./node_modules/@vue/runtime-dom/dist/runtime-dom.esm-bundler.js
var runtime_dom_esm_bundler = __webpack_require__(98880);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/layouts/ccw/ErrorLayout.vue?vue&type=template&id=09a505e4&scoped=true&ts=true

const _withScopeId = n => ((0,runtime_core_esm_bundler/* pushScopeId */.dD)("data-v-09a505e4"), n = n(), (0,runtime_core_esm_bundler/* popScopeId */.Cn)(), n);
const _hoisted_1 = {
    class: "relative w-full h-full cc-layout-px cc-layout-py cc-text-color flex flex-col flex-nowrap",
    id: "cc-layout-container"
};
const _hoisted_2 = /*#__PURE__*/ _withScopeId(() => /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("div", {
    class: "fixed inset-0 bg-gradient-to-r from-slate-350 to-stone-300 dark:from-slate-900 dark:to-stone-900",
    id: "cc-background-iframe-container"
}, null, -1));
const _hoisted_3 = {
    class: "relative flex-grow w-full flex-1 cc-site-max-width mx-auto pb-1.5 flex flex-col flex-nowrap",
    id: "cc-main-container"
};
const _hoisted_4 = {
    class: "relative flex-1 flex-grow-1 h-full overflow-hidden cc-rounded-la cc-shadow flex flex-row flex-nowrap",
    style: { "min-height": "222px" }
};
const _hoisted_5 = { class: "relative flex-1 w-full h-full" };
const _hoisted_6 = { class: "relative w-full h-full cc-rounded-la flex flex-row flex-nowrap cc-bg-light-1" };
const _hoisted_7 = { class: "relative h-full flex-1 overflow-hidden focus:outline-none flex flex-col flex-nowrap cc-text-sz" };
const _hoisted_8 = { class: "absolute w-full h-full cc-bg-light-1 overflow-y-auto flex flex-col flex-nowrap justify-center items-center" };
const _hoisted_9 = { class: "relative flex-1 py-4 flex justify-center items-center" };
const _hoisted_10 = { class: "mx-auto max-w-7xl px-4 sm:px-8 flex flex-col flex-nowrap space-y-3 sm:space-y-6 justify-center text-center" };
const _hoisted_11 = { class: "cc-text-extra-bold" };
const _hoisted_12 = { class: "block xl:inline leading-8 text-2xl sm:text-4xl md:text-5xl dark:text-cc-gray-light" };
const _hoisted_13 = { class: "block xl:inline leading-7 mt-1 sm:mt-2 text-lg sm:text-3xl md:text-4xl text-green-600 px-4" };
const _hoisted_14 = { class: "max-w-md md:max-w-3xl mx-auto cc-text-sz text-gray-500 sm:text-lg md:text-xl whitespace-pre-wrap" };
const _hoisted_15 = { class: "max-w-md mx-auto sm:flex sm:justify-center md:mt-8" };
const _hoisted_16 = { class: "cc-rounded cc-shadow" };
function render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_Header = (0,runtime_core_esm_bundler/* resolveComponent */.up)("Header");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_1, [
        _hoisted_2,
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_Header),
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_3, [
            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_4, [
                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_5, [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_6, [
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("main", _hoisted_7, [
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_8, [
                                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_9, [
                                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_10, [
                                        (0,runtime_core_esm_bundler/* createElementVNode */._)("h1", _hoisted_11, [
                                            (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_12, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('error404.headline')), 1),
                                            (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_13, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('error404.caption')), 1)
                                        ]),
                                        (0,runtime_core_esm_bundler/* createElementVNode */._)("p", _hoisted_14, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('error404.text')), 1),
                                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_15, [
                                            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_16, [
                                                (0,runtime_core_esm_bundler/* createElementVNode */._)("button", {
                                                    class: "w-full flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium cc-rounded text-white bg-blue-700 hover:bg-blue-800 md:py-4 md:text-lg md:px-10 dark:bg-cc-dark-800",
                                                    onClick: _cache[0] || (_cache[0] = (0,runtime_dom_esm_bundler/* withModifiers */.iM)(($event) => (_ctx.gotoPage(_ctx.t('error404.button.home.link', true))), ["stop"]))
                                                }, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('error404.button.home.label')), 1)
                                            ])
                                        ])
                                    ])
                                ])
                            ])
                        ])
                    ])
                ])
            ])
        ])
    ]));
}

;// CONCATENATED MODULE: ./src/layouts/ccw/ErrorLayout.vue?vue&type=template&id=09a505e4&scoped=true&ts=true

// EXTERNAL MODULE: ./node_modules/quasar/src/composables/use-quasar.js
var use_quasar = __webpack_require__(48825);
// EXTERNAL MODULE: ./src/composables/ccw/useTranslation.ts
var useTranslation = __webpack_require__(19376);
// EXTERNAL MODULE: ./src/composables/ccw/useNavigation.ts
var useNavigation = __webpack_require__(52439);
// EXTERNAL MODULE: ./src/components/ccw/Header.vue + 28 modules
var Header = __webpack_require__(34928);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/layouts/ccw/ErrorLayout.vue?vue&type=script&lang=ts

;



/* harmony default export */ const ErrorLayoutvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'ErrorLayout',
    components: {
        Header: Header/* default */.Z
    },
    setup() {
        const { t } = (0,useTranslation/* useTranslation */.$)();
        const { gotoPage } = (0,useNavigation/* useNavigation */.HJ)();
        const $q = (0,use_quasar/* default */.Z)();
        (0,runtime_core_esm_bundler/* onErrorCaptured */.d1)((e, instance, info) => {
            $q.notify({
                type: 'negative',
                message: 'error: ' + (e?.message ?? 'no error message') + ' info: ' + info,
                position: 'top-left',
                timeout: 20000
            });
            console.error('Layout: onErrorCaptured', e);
            return true;
        });
        return {
            t,
            gotoPage,
            onErrorCaptured: runtime_core_esm_bundler/* onErrorCaptured */.d1
        };
    }
}));

;// CONCATENATED MODULE: ./src/layouts/ccw/ErrorLayout.vue?vue&type=script&lang=ts
 
// EXTERNAL MODULE: ./node_modules/vue-loader/dist/exportHelper.js
var exportHelper = __webpack_require__(74260);
;// CONCATENATED MODULE: ./src/layouts/ccw/ErrorLayout.vue




;


const __exports__ = /*#__PURE__*/(0,exportHelper/* default */.Z)(ErrorLayoutvue_type_script_lang_ts, [['render',render],['__scopeId',"data-v-09a505e4"]])

/* harmony default export */ const ErrorLayout = (__exports__);

/***/ })

}]);
//# sourceMappingURL=1652.js.map