"use strict";
(this["webpackChunkccw_frontend"] = this["webpackChunkccw_frontend"] || []).push([[5318],{

/***/ 81526:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ FAQ)
});

// EXTERNAL MODULE: ./node_modules/@vue/runtime-core/dist/runtime-core.esm-bundler.js
var runtime_core_esm_bundler = __webpack_require__(83673);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/FAQ.vue?vue&type=template&id=cac68c94&scoped=true&ts=true

const _withScopeId = n => (_pushScopeId("data-v-cac68c94"), n = n(), _popScopeId(), n);
const _hoisted_1 = { class: "relative w-full h-full cc-rounded flex flex-row-reverse flex-nowrap dark:text-cc-gray-dark" };
const _hoisted_2 = { class: "relative h-full flex-1 overflow-hidden focus:outline-none flex flex-col flex-nowrap" };
const _hoisted_3 = { class: "cc-page-wallet cc-text-sz pt-4 sm:pt-6 md:pt-14 px-4 sm:px-8" };
const _hoisted_4 = { class: "col-span-12 grid gap-2 lg:grid-cols-2 lg:gap-x-5 lg:gap-y-2" };
const _hoisted_5 = { class: "mt-1 sm:mt-2 block" };
const _hoisted_6 = ["innerHTML"];
const _hoisted_7 = ["innerHTML"];
function render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridHeadline = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridHeadline");
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    const _component_Page = (0,runtime_core_esm_bundler/* resolveComponent */.up)("Page");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_1, [
        (0,runtime_core_esm_bundler/* createElementVNode */._)("main", _hoisted_2, [
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_Page, {
                containerCSS: '',
                "align-top": ""
            }, {
                content: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_3, [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                            label: _ctx.itd('faq.headline'),
                            class: "cc-text-2xl sm:mt-4"
                        }, null, 8, ["label"]),
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, { hr: "" }),
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_4, [
                            ((0,runtime_core_esm_bundler/* openBlock */.wg)(true), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, (0,runtime_core_esm_bundler/* renderList */.Ko)(_ctx.postList, (post, index) => {
                                return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", {
                                    key: 'faq.' + index,
                                    class: "flex flex-col flex-nowrap justify-between"
                                }, [
                                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_5, [
                                        (0,runtime_core_esm_bundler/* createElementVNode */._)("p", {
                                            class: "cc-text-md font-semibold",
                                            innerHTML: post.question
                                        }, null, 8, _hoisted_6),
                                        (0,runtime_core_esm_bundler/* createElementVNode */._)("p", {
                                            class: "mt-2 sm:mt-3 cc-text-md",
                                            innerHTML: post.answer
                                        }, null, 8, _hoisted_7)
                                    ]),
                                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, {
                                        hr: "",
                                        class: "my-1 sm:my-4"
                                    })
                                ]));
                            }), 128))
                        ])
                    ])
                ]),
                _: 1
            })
        ])
    ]));
}

;// CONCATENATED MODULE: ./src/pages/ccw/FAQ.vue?vue&type=template&id=cac68c94&scoped=true&ts=true

// EXTERNAL MODULE: ./node_modules/@vue/reactivity/dist/reactivity.esm-bundler.js
var reactivity_esm_bundler = __webpack_require__(61959);
// EXTERNAL MODULE: ./src/composables/ccw/useTranslation.ts
var useTranslation = __webpack_require__(19376);
// EXTERNAL MODULE: ./src/lib/utils/useAppMode.ts
var useAppMode = __webpack_require__(4254);
// EXTERNAL MODULE: ./src/components/ccw/Page.vue + 21 modules
var Page = __webpack_require__(53707);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridHeadline.vue + 3 modules
var GridHeadline = __webpack_require__(63593);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridSpace.vue + 4 modules
var GridSpace = __webpack_require__(14740);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridText.vue + 4 modules
var GridText = __webpack_require__(96834);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridButtonPrimary.vue + 3 modules
var GridButtonPrimary = __webpack_require__(12559);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/FAQ.vue?vue&type=script&lang=ts








/* harmony default export */ const FAQvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'FAQ',
    components: { GridButtonPrimary: GridButtonPrimary/* default */.Z, GridText: GridText/* default */.Z, GridSpace: GridSpace/* default */.Z, GridHeadline: GridHeadline/* default */.Z, Page: Page/* default */.Z },
    setup() {
        const { t, itd } = (0,useTranslation/* useTranslation */.$)();
        const postList = (0,reactivity_esm_bundler/* reactive */.qj)([]);
        for (let i = 0; i < 100; i++) {
            if (useAppMode/* isIosApp */.jv && i === 4)
                continue;
            const q = itd('faq.post.faq' + i + '.question');
            if (q && !q.startsWith('faq')) {
                postList.push({
                    question: q,
                    answer: itd('faq.post.faq' + i + '.answer')
                });
            }
            else {
                break;
            }
        }
        return {
            t, itd,
            postList
        };
    }
}));

;// CONCATENATED MODULE: ./src/pages/ccw/FAQ.vue?vue&type=script&lang=ts
 
// EXTERNAL MODULE: ./node_modules/vue-loader/dist/exportHelper.js
var exportHelper = __webpack_require__(74260);
;// CONCATENATED MODULE: ./src/pages/ccw/FAQ.vue




;


const __exports__ = /*#__PURE__*/(0,exportHelper/* default */.Z)(FAQvue_type_script_lang_ts, [['render',render],['__scopeId',"data-v-cac68c94"]])

/* harmony default export */ const FAQ = (__exports__);

/***/ })

}]);
//# sourceMappingURL=5318.js.map