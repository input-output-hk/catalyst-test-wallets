"use strict";
(this["webpackChunkccw_frontend"] = this["webpackChunkccw_frontend"] || []).push([[4888,5134],{

/***/ 3617:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Swap)
});

// EXTERNAL MODULE: ./node_modules/@vue/runtime-core/dist/runtime-core.esm-bundler.js
var runtime_core_esm_bundler = __webpack_require__(83673);
// EXTERNAL MODULE: ./src/composables/ccw/useTranslation.ts
var useTranslation = __webpack_require__(19376);
// EXTERNAL MODULE: ./node_modules/@vue/shared/dist/shared.esm-bundler.js
var shared_esm_bundler = __webpack_require__(62323);
// EXTERNAL MODULE: ./node_modules/@vue/runtime-dom/dist/runtime-dom.esm-bundler.js
var runtime_dom_esm_bundler = __webpack_require__(98880);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/swap/CreateSwap.vue?vue&type=template&id=0f3c6b6e&scoped=true&ts=true

const _withScopeId = n => ((0,runtime_core_esm_bundler/* pushScopeId */.dD)("data-v-0f3c6b6e"), n = n(), (0,runtime_core_esm_bundler/* popScopeId */.Cn)(), n);
const _hoisted_1 = {
    key: 0,
    class: "col-span-12 flex flex-col flex-nowrap justify-center items-center"
};
const _hoisted_2 = {
    key: 1,
    class: "relative col-span-12 flex flex-col items-center -mt-2 xs:mt-0"
};
const _hoisted_3 = { class: "relative w-full max-w-md flex flex-nowrap flex-col" };
const _hoisted_4 = { class: "flex justify-end" };
const _hoisted_5 = {
    key: 0,
    class: "relative flex flex-nowrap flex-col gap-4"
};
const _hoisted_6 = { class: "relative" };
const _hoisted_7 = { class: "relative -top-6 z-50 flex justify-center items-center" };
const _hoisted_8 = { class: "relative -top-12" };
const _hoisted_9 = {
    key: 1,
    class: "relative -top-12 w-full max-w-md my-4 flex flex-row flex-nowrap justify-center"
};
const _hoisted_10 = {
    key: 0,
    class: "min-h-8 w-full flex flex-row flex-nowrap justify-center items-center cc-tabs-button cc-rounded px-2 cursor-zoom-in"
};
const _hoisted_11 = /*#__PURE__*/ _withScopeId(() => /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("i", { class: "mdi mdi-chevron-right mr-1" }, null, -1));
const _hoisted_12 = { class: "ml-1" };
const _hoisted_13 = /*#__PURE__*/ _withScopeId(() => /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("span", { class: "mx-1" }, "/", -1));
const _hoisted_14 = {
    key: 0,
    class: "inline flex flex-row"
};
const _hoisted_15 = /*#__PURE__*/ _withScopeId(() => /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("span", { class: "mx-1" }, "@", -1));
const _hoisted_16 = { class: "capitalize" };
const _hoisted_17 = ["src"];
const _hoisted_18 = {
    key: 1,
    class: "w-full cc-tabs-button cc-rounded px-2 py-1 flex flex-col cursor-zoom-out"
};
const _hoisted_19 = { class: "flex flex-row justify-between cc-text-color" };
const _hoisted_20 = { class: "cc-text-slate-0" };
const _hoisted_21 = { class: "flex flex-row flex-nowrap items-center" };
const _hoisted_22 = ["src"];
const _hoisted_23 = { class: "flex flex-row justify-between cc-text-color" };
const _hoisted_24 = { class: "inline cc-text-slate-0" };
const _hoisted_25 = { class: "flex flex-row flex-nowrap" };
const _hoisted_26 = { class: "ml-1" };
const _hoisted_27 = /*#__PURE__*/ _withScopeId(() => /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("span", { class: "mx-1" }, "/", -1));
const _hoisted_28 = {
    key: 0,
    class: "flex flex-row justify-between cc-text-color"
};
const _hoisted_29 = { class: "cc-text-slate-0" };
const _hoisted_30 = { class: "flex flex-row flex-nowrap" };
const _hoisted_31 = { class: "ml-1" };
const _hoisted_32 = /*#__PURE__*/ _withScopeId(() => /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("span", { class: "mx-1" }, "/", -1));
const _hoisted_33 = {
    key: 1,
    class: "flex flex-row justify-between cc-text-color"
};
const _hoisted_34 = { class: "cc-text-slate-0" };
const _hoisted_35 = { class: "flex flex-row justify-between cc-text-color" };
const _hoisted_36 = { class: "cc-text-slate-0" };
const _hoisted_37 = { class: "flex flex-row items-center" };
const _hoisted_38 = /*#__PURE__*/ _withScopeId(() => /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("i", { class: "ml-1 text-md mdi mdi-transfer-right" }, null, -1));
const _hoisted_39 = { class: "ml-1" };
const _hoisted_40 = { class: "flex flex-row justify-between cc-text-color" };
const _hoisted_41 = { class: "inline cc-text-slate-0" };
const _hoisted_42 = /*#__PURE__*/ _withScopeId(() => /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("span", { class: "ml-1 mr-0.5" }, "(", -1));
const _hoisted_43 = /*#__PURE__*/ _withScopeId(() => /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("span", { class: "ml-1" }, "%", -1));
const _hoisted_44 = { class: "ml-1" };
const _hoisted_45 = /*#__PURE__*/ _withScopeId(() => /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("span", { class: "ml-0.5" }, ")", -1));
const _hoisted_46 = { class: "flex flex-row flex-nowrap" };
const _hoisted_47 = { class: "ml-1" };
const _hoisted_48 = { class: "flex flex-row justify-between cc-text-color" };
const _hoisted_49 = { class: "cc-text-slate-0" };
const _hoisted_50 = { class: "flex flex-row flex-nowrap" };
const _hoisted_51 = { class: "ml-1" };
const _hoisted_52 = { class: "flex flex-row justify-between cc-text-color" };
const _hoisted_53 = { class: "cc-text-slate-0" };
const _hoisted_54 = { class: "flex flex-row flex-nowrap" };
const _hoisted_55 = { class: "flex flex-row justify-between cc-text-color" };
const _hoisted_56 = { class: "cc-text-slate-0" };
const _hoisted_57 = { class: "flex flex-row flex-nowrap" };
const _hoisted_58 = { class: "flex flex-row justify-between cc-text-color" };
const _hoisted_59 = { class: "cc-text-slate-0" };
const _hoisted_60 = {
    key: 0,
    class: "min-h-8 w-full flex flex-row flex-nowrap justify-center items-center cc-tabs-button cc-rounded px-2 cursor-zoom-in"
};
const _hoisted_61 = /*#__PURE__*/ _withScopeId(() => /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("i", { class: "mdi mdi-chevron-right mr-1" }, null, -1));
const _hoisted_62 = { class: "mx-1" };
const _hoisted_63 = {
    key: 1,
    class: "w-full cc-tabs-button cc-rounded px-2 py-1 flex flex-col cursor-zoom-out"
};
const _hoisted_64 = { class: "flex flex-row justify-between cc-text-color" };
const _hoisted_65 = { class: "cc-text-slate-0" };
const _hoisted_66 = { class: "flex flex-row flex-nowrap" };
const _hoisted_67 = { class: "ml-1" };
const _hoisted_68 = { class: "flex flex-row justify-between cc-text-color" };
const _hoisted_69 = { class: "cc-text-slate-0" };
const _hoisted_70 = { class: "flex flex-row flex-nowrap" };
const _hoisted_71 = { class: "flex flex-row justify-between cc-text-color" };
const _hoisted_72 = { class: "cc-text-slate-0" };
const _hoisted_73 = { class: "flex flex-row flex-nowrap" };
const _hoisted_74 = { class: "flex flex-row justify-between cc-text-color" };
const _hoisted_75 = { class: "cc-text-slate-0" };
const _hoisted_76 = { class: "relative -top-12 w-full max-w-md grid grid-cols-12 cc-gap" };
const _hoisted_77 = ["src"];
const _hoisted_78 = { class: "cc-none xs:block" };
const _hoisted_79 = { class: "xs:hidden" };
const _hoisted_80 = { class: "relative -top-8 cc-text-xs opacity-60" };
const _hoisted_81 = { class: "grow-0 shrink-0 w-full flex flex-row flex-nowrap items-start justify-between cc-bg-white-0 border-b cc-p" };
const _hoisted_82 = { class: "flex flex-col cc-text-sz" };
function render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridHeadline = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridHeadline");
    const _component_GridText = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridText");
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    const _component_q_spinner_dots = (0,runtime_core_esm_bundler/* resolveComponent */.up)("q-spinner-dots");
    const _component_SwapSelection = (0,runtime_core_esm_bundler/* resolveComponent */.up)("SwapSelection");
    const _component_SwapInput = (0,runtime_core_esm_bundler/* resolveComponent */.up)("SwapInput");
    const _component_LimitOrder = (0,runtime_core_esm_bundler/* resolveComponent */.up)("LimitOrder");
    const _component_FormattedAmount = (0,runtime_core_esm_bundler/* resolveComponent */.up)("FormattedAmount");
    const _component_GridButtonAbort = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonAbort");
    const _component_GridButtonSecondary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonSecondary");
    const _component_GridButtonPrimary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonPrimary");
    const _component_SignTransaction = (0,runtime_core_esm_bundler/* resolveComponent */.up)("SignTransaction");
    const _component_Modal = (0,runtime_core_esm_bundler/* resolveComponent */.up)("Modal");
    const _component_SwapPoolList = (0,runtime_core_esm_bundler/* resolveComponent */.up)("SwapPoolList");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, [
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
            label: _ctx.t('wallet.swap.create.headline'),
            class: "col-span-12"
        }, null, 8, ["label"]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
            text: _ctx.t('wallet.swap.create.caption'),
            class: "col-span-12 cc-text-sz"
        }, null, 8, ["text"]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, { hr: "" }),
        (!_ctx.isLoaded)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_1, [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_q_spinner_dots, {
                    color: "gray",
                    size: "3em"
                })
            ]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (_ctx.isLoaded)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_2, [
                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_3, [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_4, [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_SwapSelection, {
                            enabled: _ctx.limitEnabled,
                            onInstant: _cache[0] || (_cache[0] = ($event) => (_ctx.onLimitEnabled(false))),
                            onLimit: _cache[1] || (_cache[1] = ($event) => (_ctx.onLimitEnabled(true)))
                        }, null, 8, ["enabled"])
                    ]),
                    (_ctx.isLoaded && _ctx.activeWalletData && _ctx.activeAccount)
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_5, [
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_6, [
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                                    text: _ctx.t('wallet.swap.create.input.from.title'),
                                    class: "absolute -top-3 left-6 z-50 cc-tabs-button-static cc-rounded px-2"
                                }, null, 8, ["text"]),
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_SwapInput, {
                                    onSelect: _ctx.onSourceAssetSelect,
                                    onUpdate: _ctx.onSourceAssetUpdate,
                                    onInputError: _ctx.onSourceInputError,
                                    "text-id": "wallet.swap.create.input",
                                    account: _ctx.activeAccount,
                                    wallet: _ctx.activeWalletData,
                                    "available-assets": _ctx.sourceAssets,
                                    "selected-asset": _ctx.selectedSource,
                                    "is-source": true
                                }, null, 8, ["onSelect", "onUpdate", "onInputError", "account", "wallet", "available-assets", "selected-asset"])
                            ]),
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_7, [
                                (0,runtime_core_esm_bundler/* createElementVNode */._)("i", {
                                    class: (0,shared_esm_bundler/* normalizeClass */.C_)(["mdi mdi-arrow-down-thick text-2xl px-1 cc-rounded", _ctx.selectedSource && _ctx.selectedTarget ? 'cc-tabs-button cursor-pointer rotate180' : 'cc-tabs-button-static']),
                                    onClick: _cache[2] || (_cache[2] =
                                        //@ts-ignore
                                        (...args) => (_ctx.onSwapDirection && _ctx.onSwapDirection(...args)))
                                }, null, 2)
                            ]),
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_8, [
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                                    text: _ctx.t('wallet.swap.create.input.to.title'),
                                    class: "absolute -top-3 left-6 z-50 cc-tabs-button-static cc-rounded px-2"
                                }, null, 8, ["text"]),
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_SwapInput, {
                                    onSelect: _ctx.onTargetAssetSelect,
                                    onUpdate: _ctx.onTargetAssetUpdate,
                                    onInputError: _ctx.onTargetInputError,
                                    "text-id": "wallet.swap.create.input",
                                    account: _ctx.activeAccount,
                                    wallet: _ctx.activeWalletData,
                                    "available-assets": _ctx.targetAssets,
                                    "selected-asset": _ctx.selectedTarget,
                                    "is-source": false,
                                    disabled: !_ctx.selectedSource
                                }, null, 8, ["onSelect", "onUpdate", "onInputError", "account", "wallet", "available-assets", "selected-asset", "disabled"])
                            ])
                        ]))
                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                    (_ctx.limitEnabled && _ctx.selectedSource && _ctx.selectedTarget && _ctx.limitPool)
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_9, [
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_LimitOrder, {
                                "pool-list": _ctx.muesliPools,
                                "limit-pool": _ctx.limitPool,
                                "invert-price": _ctx.priceInverted,
                                "source-metadata": _ctx.sourceMetadata,
                                "target-metadata": _ctx.targetMetadata,
                                "source-name": _ctx.sourceName,
                                "target-name": _ctx.targetName,
                                onPriceUpdate: _ctx.onLimitPriceUpdate,
                                onPoolUpdate: _ctx.onLimitPoolUpdate
                            }, null, 8, ["pool-list", "limit-pool", "invert-price", "source-metadata", "target-metadata", "source-name", "target-name", "onPriceUpdate", "onPoolUpdate"])
                        ]))
                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                    (_ctx.swapInfo && !_ctx.limitEnabled)
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", {
                            key: 2,
                            onClick: _cache[6] || (_cache[6] = (0,runtime_dom_esm_bundler/* withModifiers */.iM)(($event) => (_ctx.swapInfoDetails = !_ctx.swapInfoDetails), ["stop"])),
                            class: "relative -top-12 w-full max-w-md my-4 flex flex-row flex-nowrap justify-center"
                        }, [
                            (!_ctx.swapInfoDetails)
                                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_10, [
                                    _hoisted_11,
                                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_FormattedAmount, {
                                        isWholeNumber: "",
                                        amount: _ctx.swapInfo.effPrice || _ctx.swapInfo.price,
                                        currency: "",
                                        decimals: _ctx.sourceDecimals || _ctx.getDisplayDecimals(_ctx.swapInfo?.effPrice || _ctx.swapInfo?.price),
                                        "text-c-s-s": _ctx.priceDiffColor,
                                        hideFractionIfZero: "",
                                        "clipboard-enabled": false,
                                        onClicked: _cache[3] || (_cache[3] = ($event) => (_ctx.swapInfoDetails = !_ctx.swapInfoDetails))
                                    }, null, 8, ["amount", "decimals", "text-c-s-s"]),
                                    (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_12, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.sourceName), 1),
                                    _hoisted_13,
                                    (0,runtime_core_esm_bundler/* createElementVNode */._)("span", null, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.targetName), 1),
                                    (_ctx.swapInfo?.priceDiff)
                                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_14, [
                                            (0,runtime_core_esm_bundler/* createElementVNode */._)("span", {
                                                class: (0,shared_esm_bundler/* normalizeClass */.C_)(["ml-1 mr-0.5", _ctx.priceDiffColor])
                                            }, "(", 2),
                                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_FormattedAmount, {
                                                percent: "",
                                                amount: _ctx.BML.multiply(_ctx.swapInfo.priceDiff, 100),
                                                decimals: _ctx.getPercentDecimals(_ctx.swapInfo.priceDiff, true),
                                                "text-c-s-s": _ctx.priceDiffColor,
                                                "clipboard-enabled": false,
                                                onClicked: _cache[4] || (_cache[4] = ($event) => (_ctx.swapInfoDetails = !_ctx.swapInfoDetails))
                                            }, null, 8, ["amount", "decimals", "text-c-s-s"]),
                                            (0,runtime_core_esm_bundler/* createElementVNode */._)("span", {
                                                class: (0,shared_esm_bundler/* normalizeClass */.C_)(["ml-0.5", _ctx.priceDiffColor])
                                            }, ")", 2)
                                        ]))
                                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                                    _hoisted_15,
                                    (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_16, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.getProvider(_ctx.swapInfo?.pool.provider).name), 1),
                                    (_ctx.getProvider(_ctx.swapInfo?.pool.provider).image.length > 0)
                                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("img", {
                                            key: 1,
                                            class: "w-4 h-4 ml-2",
                                            loading: "lazy",
                                            src: _ctx.getProvider(_ctx.swapInfo?.pool.provider).image,
                                            alt: "provider logo"
                                        }, null, 8, _hoisted_17))
                                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                                ]))
                                : ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_18, [
                                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_19, [
                                        (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_20, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.swap.create.info.provider')), 1),
                                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_21, [
                                            (_ctx.provider?.image.length > 0)
                                                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("img", {
                                                    key: 0,
                                                    class: "w-4 h-4 mr-2",
                                                    loading: "lazy",
                                                    src: _ctx.provider?.image,
                                                    alt: "provider logo"
                                                }, null, 8, _hoisted_22))
                                                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                                            (0,runtime_core_esm_bundler/* createElementVNode */._)("span", {
                                                class: "capitalize cursor-default",
                                                onClick: _cache[5] || (_cache[5] = (0,runtime_dom_esm_bundler/* withModifiers */.iM)(() => { }, ["stop"]))
                                            }, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.provider?.name), 1)
                                        ])
                                    ]),
                                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_23, [
                                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_24, [
                                            (0,runtime_core_esm_bundler/* createElementVNode */._)("span", null, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.swap.create.info.price')), 1)
                                        ]),
                                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_25, [
                                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_FormattedAmount, {
                                                isWholeNumber: "",
                                                hideFractionIfZero: "",
                                                amount: _ctx.swapInfo?.price,
                                                currency: "",
                                                decimals: _ctx.sourceDecimals,
                                                class: "cursor-pointer"
                                            }, null, 8, ["amount", "decimals"]),
                                            (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_26, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.sourceName), 1),
                                            _hoisted_27,
                                            (0,runtime_core_esm_bundler/* createElementVNode */._)("span", null, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.targetName), 1)
                                        ])
                                    ]),
                                    (_ctx.swapInfo?.effPrice)
                                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_28, [
                                            (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_29, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.swap.create.info.effprice')), 1),
                                            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_30, [
                                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_FormattedAmount, {
                                                    isWholeNumber: "",
                                                    hideFractionIfZero: "",
                                                    amount: _ctx.swapInfo.effPrice,
                                                    currency: "",
                                                    decimals: _ctx.sourceDecimals,
                                                    class: "cursor-pointer"
                                                }, null, 8, ["amount", "decimals"]),
                                                (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_31, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.sourceName), 1),
                                                _hoisted_32,
                                                (0,runtime_core_esm_bundler/* createElementVNode */._)("span", null, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.targetName), 1)
                                            ])
                                        ]))
                                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                                    (_ctx.swapInfo?.priceDiff)
                                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_33, [
                                            (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_34, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.swap.create.info.pricediff')), 1),
                                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_FormattedAmount, {
                                                percent: "",
                                                hideFractionIfZero: "",
                                                amount: _ctx.BML.multiply(_ctx.swapInfo.priceDiff, 100),
                                                decimals: _ctx.getPercentDecimals(_ctx.swapInfo.priceDiff, true),
                                                "text-c-s-s": _ctx.priceDiffColor,
                                                class: "cursor-pointer"
                                            }, null, 8, ["amount", "decimals", "text-c-s-s"])
                                        ]))
                                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_35, [
                                        (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_36, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.swap.create.info.poolfee')), 1),
                                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_37, [
                                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_FormattedAmount, {
                                                percent: "",
                                                hideFractionIfZero: "",
                                                amount: _ctx.swapInfo?.pool.fee.toString(),
                                                decimals: _ctx.getPercentDecimals(_ctx.swapInfo?.pool.fee, false),
                                                class: "cursor-pointer"
                                            }, null, 8, ["amount", "decimals"]),
                                            _hoisted_38,
                                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_FormattedAmount, {
                                                hideFractionIfZero: "",
                                                amount: _ctx.BML.round(_ctx.swapInfo?.poolFee, 0, 'down'),
                                                currency: "",
                                                decimals: _ctx.sourceDecimals,
                                                "text-c-s-s": "ml-1",
                                                class: "cursor-pointer"
                                            }, null, 8, ["amount", "decimals"]),
                                            (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_39, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.sourceName), 1)
                                        ])
                                    ]),
                                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_40, [
                                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_41, [
                                            (0,runtime_core_esm_bundler/* createElementVNode */._)("span", null, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.swap.create.info.minreceive')), 1),
                                            _hoisted_42,
                                            (0,runtime_core_esm_bundler/* createElementVNode */._)("span", null, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.BML.round(_ctx.BML.multiply(_ctx.swapInfo?.slippage, 100), 1)), 1),
                                            _hoisted_43,
                                            (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_44, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.swap.create.info.slippage')), 1),
                                            _hoisted_45
                                        ]),
                                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_46, [
                                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_FormattedAmount, {
                                                hideFractionIfZero: "",
                                                amount: _ctx.swapInfo?.minReceive,
                                                currency: "",
                                                decimals: _ctx.targetDecimals,
                                                class: "cursor-pointer"
                                            }, null, 8, ["amount", "decimals"]),
                                            (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_47, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.targetName), 1)
                                        ])
                                    ]),
                                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, {
                                        hr: "",
                                        label: _ctx.t('wallet.swap.create.info.topay'),
                                        "align-label": "left",
                                        "line-c-s-s": "cc-text-slate-0",
                                        "label-c-s-s": "cc-text-sz cc-text-slate-0"
                                    }, null, 8, ["label"]),
                                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_48, [
                                        (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_49, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.swap.create.input.from.title')), 1),
                                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_50, [
                                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_FormattedAmount, {
                                                hideFractionIfZero: "",
                                                amount: _ctx.selectedSource?.amount,
                                                currency: "",
                                                decimals: _ctx.sourceDecimals,
                                                class: "cursor-pointer"
                                            }, null, 8, ["amount", "decimals"]),
                                            (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_51, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.sourceName), 1)
                                        ])
                                    ]),
                                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_52, [
                                        (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_53, "+ " + (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.swap.create.info.batcherfee')), 1),
                                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_54, [
                                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_FormattedAmount, {
                                                hideFractionIfZero: "",
                                                amount: _ctx.swapInfo?.pool.batcherFee.amount,
                                                class: "cursor-pointer"
                                            }, null, 8, ["amount"])
                                        ])
                                    ]),
                                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_55, [
                                        (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_56, "+ " + (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.swap.create.info.frontend')), 1),
                                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_57, [
                                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_FormattedAmount, {
                                                hideFractionIfZero: "",
                                                amount: _ctx.eternlFee,
                                                class: "cursor-pointer"
                                            }, null, 8, ["amount"])
                                        ])
                                    ]),
                                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_58, [
                                        (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_59, "+ " + (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.swap.create.info.deposit')), 1),
                                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_FormattedAmount, {
                                            hideFractionIfZero: "",
                                            amount: _ctx.swapInfo?.pool.deposit.toString(),
                                            class: "cursor-pointer"
                                        }, null, 8, ["amount"])
                                    ])
                                ]))
                        ]))
                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                    (_ctx.selectedSource && _ctx.selectedTarget && _ctx.limitPool && _ctx.limitEnabled && _ctx.selectedSource.amount.length > 0 && _ctx.selectedTarget.amount.length > 0)
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", {
                            key: 3,
                            onClick: _cache[7] || (_cache[7] = (0,runtime_dom_esm_bundler/* withModifiers */.iM)(($event) => (_ctx.limitFeeDetails = !_ctx.limitFeeDetails), ["stop"])),
                            class: "relative -top-12 w-full max-w-md mb-4 flex flex-row flex-nowrap justify-center"
                        }, [
                            (!_ctx.limitFeeDetails)
                                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_60, [
                                    _hoisted_61,
                                    (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_62, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.swap.create.info.totalfee')) + ":", 1),
                                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_FormattedAmount, {
                                        hideFractionIfZero: "",
                                        amount: _ctx.BML.add(_ctx.limitPool?.batcherFee.amount, _ctx.eternlFee),
                                        class: "cursor-pointer"
                                    }, null, 8, ["amount"])
                                ]))
                                : ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_63, [
                                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_64, [
                                        (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_65, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.swap.create.input.from.title')), 1),
                                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_66, [
                                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_FormattedAmount, {
                                                hideFractionIfZero: "",
                                                amount: _ctx.selectedSource?.amount,
                                                currency: "",
                                                decimals: _ctx.sourceDecimals,
                                                class: "cursor-pointer"
                                            }, null, 8, ["amount", "decimals"]),
                                            (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_67, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.sourceName), 1)
                                        ])
                                    ]),
                                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_68, [
                                        (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_69, "+ " + (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.swap.create.info.batcherfee')), 1),
                                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_70, [
                                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_FormattedAmount, {
                                                hideFractionIfZero: "",
                                                amount: _ctx.limitPool?.batcherFee.amount,
                                                class: "cursor-pointer"
                                            }, null, 8, ["amount"])
                                        ])
                                    ]),
                                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_71, [
                                        (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_72, "+ " + (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.swap.create.info.frontend')), 1),
                                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_73, [
                                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_FormattedAmount, {
                                                hideFractionIfZero: "",
                                                amount: _ctx.eternlFee,
                                                class: "cursor-pointer"
                                            }, null, 8, ["amount"])
                                        ])
                                    ]),
                                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_74, [
                                        (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_75, "+ " + (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.swap.create.info.deposit')), 1),
                                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_FormattedAmount, {
                                            hideFractionIfZero: "",
                                            amount: _ctx.swapInfo?.pool.deposit.toString(),
                                            class: "cursor-pointer"
                                        }, null, 8, ["amount"])
                                    ])
                                ]))
                        ]))
                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                ]),
                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_76, [
                    ((!_ctx.limitEnabled && !_ctx.swapInfo) || (_ctx.limitEnabled && (!_ctx.selectedSource || !_ctx.selectedTarget || !_ctx.limitPool)))
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridSpace, {
                            key: 0,
                            dense: "",
                            class: "mt-2"
                        }))
                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                    (_ctx.selectedSource || _ctx.selectedTarget)
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridButtonAbort, {
                            key: 1,
                            label: _ctx.t('common.label.reset'),
                            link: _ctx.onClearSwapSelection,
                            class: (0,shared_esm_bundler/* normalizeClass */.C_)(_ctx.muesliPools.length > 0 ? 'col-span-4' : 'col-span-6')
                        }, null, 8, ["label", "link", "class"]))
                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                    ((!_ctx.limitEnabled && _ctx.manualPool) || (_ctx.limitEnabled && _ctx.limitPool))
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", {
                            key: 2,
                            class: "col-span-4 flex flex-row flex-nowrap whitespace-nowrap items-center justify-center cursor-pointer px-4 py-1 rounded cc-btn-secondary cc-text-md cc-text-semi-bold",
                            onClick: _cache[8] || (_cache[8] = ($event) => (_ctx.showProviderModal = true))
                        }, [
                            (_ctx.provider?.image.length > 0)
                                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("img", {
                                    key: 0,
                                    class: "w-6 h-6 mr-2 my-0.5 sm:my-1.5",
                                    loading: "lazy",
                                    src: _ctx.provider?.image,
                                    alt: "provider logo"
                                }, null, 8, _hoisted_77))
                                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_78, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.provider?.name), 1),
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_79, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.provider?.nameShort), 1)
                        ]))
                        : (_ctx.muesliPools.length > 0)
                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridButtonSecondary, {
                                key: 3,
                                label: _ctx.t('wallet.swap.button.pool'),
                                link: _ctx.onShowProviderModal,
                                capitalize: false,
                                class: "col-span-4"
                            }, null, 8, ["label", "link"]))
                            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonPrimary, {
                        label: _ctx.t('wallet.swap.button.swap'),
                        link: _ctx.onSwap,
                        disabled: !_ctx.selectedSource ||
                            !_ctx.selectedTarget ||
                            !_ctx.swapInfo ||
                            (_ctx.limitEnabled && (!_ctx.limitPool || _ctx.limitPrice === '0')) ||
                            _ctx.hasInputError ||
                            _ctx.selectedSource?.amount.length === 0 ||
                            _ctx.selectedTarget?.amount.length === 0 ||
                            _ctx.BML.compare(_ctx.selectedSource?.amount, '<', '1'),
                        class: (0,shared_esm_bundler/* normalizeClass */.C_)(_ctx.muesliPools.length > 0 ? 'col-span-4' : 'col-span-6')
                    }, null, 8, ["label", "link", "disabled", "class"])
                ]),
                (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_80, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.swap.create.credit')), 1),
                (_ctx.showSwapModal)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_Modal, {
                        key: 0,
                        onClose: _ctx.onSwapCancel
                    }, {
                        header: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_81, [
                                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_82, [
                                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                                        label: _ctx.t('wallet.swap.create.modal.swap.label'),
                                        "do-capitalize": false
                                    }, null, 8, ["label"])
                                ])
                            ])
                        ]),
                        content: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_SignTransaction, {
                                "cancel-emits": "",
                                onCancel: _ctx.onSwapCancel,
                                class: "p-4"
                            }, null, 8, ["onCancel"])
                        ]),
                        _: 1
                    }, 8, ["onClose"]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                (_ctx.selectedSource && _ctx.selectedTarget && _ctx.sourceMetadata && _ctx.targetMetadata)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_SwapPoolList, {
                        key: 1,
                        "show-modal": _ctx.showProviderModal,
                        "target-name": _ctx.targetName,
                        "source-name": _ctx.sourceName,
                        "target-metadata": _ctx.targetMetadata,
                        "source-metadata": _ctx.sourceMetadata,
                        "pool-list": _ctx.muesliPools,
                        "show-auto-select-button": !_ctx.limitEnabled,
                        onCloseModal: _cache[9] || (_cache[9] = ($event) => (_ctx.showProviderModal = false)),
                        onPoolUpdate: _ctx.onPoolSelected
                    }, null, 8, ["show-modal", "target-name", "source-name", "target-metadata", "source-metadata", "pool-list", "show-auto-select-button", "onPoolUpdate"]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
            ]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
    ], 64));
}

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/swap/CreateSwap.vue?vue&type=template&id=0f3c6b6e&scoped=true&ts=true

// EXTERNAL MODULE: ./node_modules/@vue/reactivity/dist/reactivity.esm-bundler.js
var reactivity_esm_bundler = __webpack_require__(61959);
// EXTERNAL MODULE: ./node_modules/quasar/src/composables/use-quasar.js
var use_quasar = __webpack_require__(48825);
// EXTERNAL MODULE: ./src/composables/ccw/store/useActiveWallet.ts
var useActiveWallet = __webpack_require__(52144);
// EXTERNAL MODULE: ./src/composables/ccw/store/useTokenLib_v2.ts + 1 modules
var useTokenLib_v2 = __webpack_require__(74510);
// EXTERNAL MODULE: ./src/composables/ccw/store/useSwapLib.ts
var useSwapLib = __webpack_require__(22653);
// EXTERNAL MODULE: ./src/composables/ccw/store/useFormatter.ts
var useFormatter = __webpack_require__(16938);
// EXTERNAL MODULE: ./src/composables/ccw/store/useBuildTx_v3.ts + 1 modules
var useBuildTx_v3 = __webpack_require__(72107);
// EXTERNAL MODULE: ./src/components/ccw/common/FormattedAmount.vue + 3 modules
var FormattedAmount = __webpack_require__(6200);
// EXTERNAL MODULE: ./src/components/ccw/modal/Modal.vue + 4 modules
var Modal = __webpack_require__(61017);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridHeadline.vue + 3 modules
var GridHeadline = __webpack_require__(63593);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridText.vue + 4 modules
var GridText = __webpack_require__(96834);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridSpace.vue + 4 modules
var GridSpace = __webpack_require__(14740);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridTextArea.vue + 4 modules
var GridTextArea = __webpack_require__(15660);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridButtonPrimary.vue + 3 modules
var GridButtonPrimary = __webpack_require__(12559);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridButtonSecondary.vue + 3 modules
var GridButtonSecondary = __webpack_require__(72713);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridButtonAbort.vue + 3 modules
var GridButtonAbort = __webpack_require__(57504);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/swap/SwapInput.vue?vue&type=template&id=d900b054&ts=true

const SwapInputvue_type_template_id_d900b054_ts_true_hoisted_1 = { class: "w-full h-full flex justify-center items-center cc-text-lg cc-text-slate-0" };
const SwapInputvue_type_template_id_d900b054_ts_true_hoisted_2 = { class: "grow-0 shrink-0 w-full flex flex-row flex-nowrap items-start justify-between border-b cc-p" };
const SwapInputvue_type_template_id_d900b054_ts_true_hoisted_3 = { class: "flex flex-col cc-text-sz" };
const SwapInputvue_type_template_id_d900b054_ts_true_hoisted_4 = { class: "flex flex-col flex-nowrap p-4 w-full" };
function SwapInputvue_type_template_id_d900b054_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridTokenCard = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridTokenCard");
    const _component_GridHeadline = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridHeadline");
    const _component_GridText = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridText");
    const _component_GridTokenList = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridTokenList");
    const _component_Modal = (0,runtime_core_esm_bundler/* resolveComponent */.up)("Modal");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, [
        (!_ctx.selectedAsset)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", {
                key: 0,
                class: (0,shared_esm_bundler/* normalizeClass */.C_)(["cc-rounded cc-bg-light-0 px-3 pt-3 pb-3 min-h-36 h-full", _ctx.disabled ? 'cc-tabs-button-static' : 'cursor-pointer cc-tabs-button']),
                onClick: _cache[0] || (_cache[0] = ($event) => (_ctx.disabled ? false : _ctx.showAssetModal = true))
            }, [
                (0,runtime_core_esm_bundler/* createElementVNode */._)("span", SwapInputvue_type_template_id_d900b054_ts_true_hoisted_1, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.disabled ? '' : _ctx.t(_ctx.textId + '.clickselect')), 1)
            ], 2))
            : ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", {
                key: 1,
                class: (0,shared_esm_bundler/* normalizeClass */.C_)(_ctx.disabled ? '' : 'cursor-pointer'),
                onClick: _cache[1] || (_cache[1] = ($event) => (_ctx.disabled ? false : _ctx.showAssetModal = true))
            }, [
                (_ctx.selectedAsset)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridTokenCard, {
                        key: 0,
                        class: "w-full pt-2 pb-1",
                        "network-id": _ctx.account.network,
                        "wallet-id": _ctx.wallet.id,
                        token: _ctx.selectedAsset.token,
                        "disable-details-modal": true,
                        "send-enabled": true,
                        "auto-submit": true,
                        "prefilled-input": _ctx.selectedAsset.amount,
                        advancedViewEnabled: false,
                        "disable-amount-check": !_ctx.isSource,
                        "manual-update-auto-select": false,
                        onAddToken: _ctx.onTokenUpdate,
                        onInputError: _ctx.onInputError
                    }, null, 8, ["network-id", "wallet-id", "token", "prefilled-input", "disable-amount-check", "onAddToken", "onInputError"]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
            ], 2)),
        (_ctx.showAssetModal)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_Modal, {
                key: 2,
                "full-width-on-mobile": "",
                onClose: _cache[2] || (_cache[2] = ($event) => (_ctx.showAssetModal = false))
            }, {
                header: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SwapInputvue_type_template_id_d900b054_ts_true_hoisted_2, [
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SwapInputvue_type_template_id_d900b054_ts_true_hoisted_3, [
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                                label: _ctx.t(_ctx.textId + (_ctx.isSource ? '.from' : '.to') + '.title')
                            }, null, 8, ["label"]),
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                                text: _ctx.t(_ctx.textId + (_ctx.isSource ? '.from' : '.to') + '.caption')
                            }, null, 8, ["text"])
                        ])
                    ])
                ]),
                content: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SwapInputvue_type_template_id_d900b054_ts_true_hoisted_4, [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridTokenList, {
                            "text-id": _ctx.textId + '.token',
                            "network-id": _ctx.account.network,
                            "wallet-id": _ctx.wallet.id,
                            "token-list": _ctx.availableAssets,
                            "single-entry": true,
                            "send-enabled": false,
                            "simple-select": true,
                            "verified-only": !_ctx.isSource,
                            "is-modal": "",
                            onAddToken: _ctx.onTokenSelect
                        }, null, 8, ["text-id", "network-id", "wallet-id", "token-list", "verified-only", "onAddToken"])
                    ])
                ]),
                _: 1
            }))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
    ], 64));
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/swap/SwapInput.vue?vue&type=template&id=d900b054&ts=true

// EXTERNAL MODULE: ./src/components/ccw/grid/v2/summary/GridTokenList.vue + 9 modules
var GridTokenList = __webpack_require__(84003);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/summary/GridTokenCard.vue + 31 modules
var GridTokenCard = __webpack_require__(77102);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/swap/SwapInput.vue?vue&type=script&lang=ts







/* harmony default export */ const SwapInputvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'SwapInput',
    components: {
        Modal: Modal/* default */.Z,
        GridTokenList: GridTokenList/* default */.Z,
        GridTokenCard: GridTokenCard/* default */.Z,
        GridHeadline: GridHeadline/* default */.Z,
        GridText: GridText/* default */.Z
    },
    props: {
        textId: { type: String, required: true },
        account: { type: Object, required: true },
        wallet: { type: Object, required: true },
        availableAssets: { type: Array, required: true },
        selectedAsset: { type: Object, required: false },
        isSource: { type: Boolean, required: true },
        disabled: { type: Boolean, required: false, default: false },
    },
    emits: ['select', 'update', 'inputError'],
    setup(props, { emit }) {
        const { t } = (0,useTranslation/* useTranslation */.$)();
        const showAssetModal = (0,reactivity_esm_bundler/* ref */.iH)(false);
        function onTokenSelect(token) {
            emit('select', token);
            showAssetModal.value = false;
        }
        function onTokenUpdate(token) {
            emit('update', token);
        }
        function onInputError(error) {
            emit('inputError', error);
        }
        return {
            t,
            showAssetModal,
            onTokenSelect,
            onTokenUpdate,
            onInputError
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/swap/SwapInput.vue?vue&type=script&lang=ts
 
// EXTERNAL MODULE: ./node_modules/vue-loader/dist/exportHelper.js
var exportHelper = __webpack_require__(74260);
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/swap/SwapInput.vue




;
const __exports__ = /*#__PURE__*/(0,exportHelper/* default */.Z)(SwapInputvue_type_script_lang_ts, [['render',SwapInputvue_type_template_id_d900b054_ts_true_render]])

/* harmony default export */ const SwapInput = (__exports__);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/swap/SwapSelection.vue?vue&type=template&id=057e5d6b&ts=true

const SwapSelectionvue_type_template_id_057e5d6b_ts_true_hoisted_1 = { class: "col-span-12 flex flex-row flex-nowrap items-center" };
function SwapSelectionvue_type_template_id_057e5d6b_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_q_toggle = (0,runtime_core_esm_bundler/* resolveComponent */.up)("q-toggle");
    const _component_Tooltip = (0,runtime_core_esm_bundler/* resolveComponent */.up)("Tooltip");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", SwapSelectionvue_type_template_id_057e5d6b_ts_true_hoisted_1, [
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", {
            class: "flex flex-row flex-nowrap items-center cursor-pointer",
            onClick: _cache[0] || (_cache[0] = ($event) => { _ctx.limitEnabled = false; _ctx.$emit('instant'); })
        }, [
            (0,runtime_core_esm_bundler/* createTextVNode */.Uk)((0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('wallet.swap.create.instant.label')) + " ", 1),
            (0,runtime_core_esm_bundler/* createElementVNode */._)("i", {
                class: (0,shared_esm_bundler/* normalizeClass */.C_)(["mdi mdi-flash-outline drop-shadow text-xl ml-1", _ctx.limitEnabled ? 'text-gray-700' : 'text-green-700'])
            }, null, 2)
        ]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_q_toggle, {
            modelValue: _ctx.limitEnabled,
            "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => ((_ctx.limitEnabled) = $event)),
            color: "blue",
            "keep-color": ""
        }, null, 8, ["modelValue"]),
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", {
            class: "flex flex-row flex-nowrap items-center cursor-pointer",
            onClick: _cache[2] || (_cache[2] = ($event) => { _ctx.limitEnabled = true; _ctx.$emit('limit'); })
        }, [
            (0,runtime_core_esm_bundler/* createElementVNode */._)("i", {
                class: (0,shared_esm_bundler/* normalizeClass */.C_)(["mdi mdi-chart-bell-curve text-xl mx-1", _ctx.limitEnabled ? 'text-green-700' : 'text-gray-700'])
            }, null, 2),
            (0,runtime_core_esm_bundler/* createTextVNode */.Uk)(" " + (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('wallet.swap.create.limit.label')), 1)
        ]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_Tooltip, {
            anchor: "top middle",
            offset: [0, 30],
            "transition-show": "scale",
            "transition-hide": "scale"
        }, {
            default: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                (0,runtime_core_esm_bundler/* createTextVNode */.Uk)((0,shared_esm_bundler/* toDisplayString */.zw)(!_ctx.limitEnabled ? _ctx.it('wallet.swap.create.instant.hover') : _ctx.it('wallet.swap.create.limit.hover')), 1)
            ]),
            _: 1
        })
    ]));
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/swap/SwapSelection.vue?vue&type=template&id=057e5d6b&ts=true

// EXTERNAL MODULE: ./src/components/ccw/common/Tooltip.vue + 3 modules
var Tooltip = __webpack_require__(30105);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/swap/SwapSelection.vue?vue&type=script&lang=ts



/* harmony default export */ const SwapSelectionvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'SwapSelection',
    components: {
        Tooltip: Tooltip/* default */.Z
    },
    props: {
        enabled: { type: Boolean, required: false, default: false }
    },
    emits: ['instant', 'limit'],
    setup(props, { emit }) {
        const { it } = (0,useTranslation/* useTranslation */.$)();
        const limitEnabled = (0,reactivity_esm_bundler/* ref */.iH)(props.enabled);
        const setInstantOrder = () => { limitEnabled.value = false; emit('instant'); };
        const setLimitOrder = () => { limitEnabled.value = true; emit('limit'); };
        (0,runtime_core_esm_bundler/* watch */.YP)(limitEnabled, (isLimit) => isLimit ? setLimitOrder() : setInstantOrder());
        (0,runtime_core_esm_bundler/* watch */.YP)(() => props.enabled, (isLimit) => {
            if (isLimit && limitEnabled.value) {
                return;
            }
            isLimit ? setLimitOrder() : setInstantOrder();
        });
        return {
            it,
            limitEnabled,
            setInstantOrder,
            setLimitOrder
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/swap/SwapSelection.vue?vue&type=script&lang=ts
 
// EXTERNAL MODULE: ./node_modules/quasar/src/components/toggle/QToggle.js
var QToggle = __webpack_require__(28886);
// EXTERNAL MODULE: ./node_modules/@quasar/app/lib/webpack/runtime.auto-import.js
var runtime_auto_import = __webpack_require__(7518);
var runtime_auto_import_default = /*#__PURE__*/__webpack_require__.n(runtime_auto_import);
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/swap/SwapSelection.vue




;
const SwapSelection_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(SwapSelectionvue_type_script_lang_ts, [['render',SwapSelectionvue_type_template_id_057e5d6b_ts_true_render]])

/* harmony default export */ const SwapSelection = (SwapSelection_exports_);
;

runtime_auto_import_default()(SwapSelectionvue_type_script_lang_ts, 'components', {QToggle: QToggle/* default */.Z});

;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/swap/LimitOrder.vue?vue&type=template&id=59fcf444&ts=true

const LimitOrdervue_type_template_id_59fcf444_ts_true_hoisted_1 = { class: "w-full flex flex-col sm:flex-row flex-nowrap items-center cc-tabs-button-static cc-rounded px-2 py-2 space-y-2 sm:space-y-0 sm:space-x-4" };
const LimitOrdervue_type_template_id_59fcf444_ts_true_hoisted_2 = { class: "w-full sm:w-auto flex-grow" };
const LimitOrdervue_type_template_id_59fcf444_ts_true_hoisted_3 = { class: "flex flex-row cc-text-xs cc-text-light mr-1" };
const LimitOrdervue_type_template_id_59fcf444_ts_true_hoisted_4 = { class: "ml-1" };
const LimitOrdervue_type_template_id_59fcf444_ts_true_hoisted_5 = /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("span", { class: "mx-1" }, "/", -1);
const LimitOrdervue_type_template_id_59fcf444_ts_true_hoisted_6 = /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("i", { class: "mdi mdi-sync text-lg" }, null, -1);
const LimitOrdervue_type_template_id_59fcf444_ts_true_hoisted_7 = [
    LimitOrdervue_type_template_id_59fcf444_ts_true_hoisted_6
];
function LimitOrdervue_type_template_id_59fcf444_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridInput = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridInput");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", LimitOrdervue_type_template_id_59fcf444_ts_true_hoisted_1, [
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", LimitOrdervue_type_template_id_59fcf444_ts_true_hoisted_2, [
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridInput, {
                "input-text": _ctx.priceInput,
                "onUpdate:inputText": _ctx.validatePriceInput,
                "input-error": _ctx.priceInputError,
                "onUpdate:input-error": _cache[1] || (_cache[1] = ($event) => ((_ctx.priceInputError) = $event)),
                "input-hint": "0",
                alwaysShowInfo: false,
                showReset: false,
                "input-id": "limitprice",
                autocomplete: "off",
                currency: "",
                "decimal-separator": _ctx.decimalSeparator,
                "group-separator": _ctx.groupSeparator,
                "manual-update": _ctx.manualUpdate,
                class: "my-1"
            }, {
                "icon-prepend": (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                    (0,runtime_core_esm_bundler/* createTextVNode */.Uk)(" Price: ")
                ]),
                "icon-append": (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", LimitOrdervue_type_template_id_59fcf444_ts_true_hoisted_3, [
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("span", LimitOrdervue_type_template_id_59fcf444_ts_true_hoisted_4, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.sourceName), 1),
                        LimitOrdervue_type_template_id_59fcf444_ts_true_hoisted_5,
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("span", null, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.targetName), 1)
                    ]),
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("button", {
                        onClick: _cache[0] || (_cache[0] = (0,runtime_dom_esm_bundler/* withModifiers */.iM)(
                        //@ts-ignore
                        (...args) => (_ctx.onPriceInputReset && _ctx.onPriceInputReset(...args)), ["stop"])),
                        class: "cc-text-semi-bold ml-1 cc-btn-secondary-inline px-2 focus:outline-none"
                    }, LimitOrdervue_type_template_id_59fcf444_ts_true_hoisted_7)
                ]),
                _: 1
            }, 8, ["input-text", "onUpdate:inputText", "input-error", "decimal-separator", "group-separator", "manual-update"])
        ])
    ]));
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/swap/LimitOrder.vue?vue&type=template&id=59fcf444&ts=true

// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridInput.vue + 4 modules
var GridInput = __webpack_require__(27209);
// EXTERNAL MODULE: ./src/components/ccw/modal/BaseModal.vue + 4 modules
var BaseModal = __webpack_require__(57044);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/swap/SwapPoolList.vue?vue&type=template&id=5576755b&ts=true

const SwapPoolListvue_type_template_id_5576755b_ts_true_hoisted_1 = { class: "grow-0 shrink-0 w-full flex flex-row flex-nowrap items-start justify-between border-b cc-p" };
const SwapPoolListvue_type_template_id_5576755b_ts_true_hoisted_2 = { class: "flex flex-col cc-text-sz" };
const SwapPoolListvue_type_template_id_5576755b_ts_true_hoisted_3 = { class: "p-4 flex gap-2" };
const SwapPoolListvue_type_template_id_5576755b_ts_true_hoisted_4 = ["onClick"];
const SwapPoolListvue_type_template_id_5576755b_ts_true_hoisted_5 = { class: "flex flex-row items-center justify-between" };
const SwapPoolListvue_type_template_id_5576755b_ts_true_hoisted_6 = { class: "flex flex-row flex-nowrap items-center" };
const SwapPoolListvue_type_template_id_5576755b_ts_true_hoisted_7 = ["src"];
const SwapPoolListvue_type_template_id_5576755b_ts_true_hoisted_8 = { class: "cc-text-semi-bold cc-text-md" };
const SwapPoolListvue_type_template_id_5576755b_ts_true_hoisted_9 = { class: "flex flex-row flex-nowrap items-center ml-10 mt-0.5" };
const SwapPoolListvue_type_template_id_5576755b_ts_true_hoisted_10 = { class: "ml-1" };
const SwapPoolListvue_type_template_id_5576755b_ts_true_hoisted_11 = /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("span", { class: "mx-1" }, "/", -1);
const SwapPoolListvue_type_template_id_5576755b_ts_true_hoisted_12 = { class: "flex flex-row justify-between cc-text-color" };
const SwapPoolListvue_type_template_id_5576755b_ts_true_hoisted_13 = { class: "cc-text-slate-0" };
const SwapPoolListvue_type_template_id_5576755b_ts_true_hoisted_14 = { class: "flex flex-row justify-between cc-text-color" };
const SwapPoolListvue_type_template_id_5576755b_ts_true_hoisted_15 = { class: "cc-text-slate-0" };
const SwapPoolListvue_type_template_id_5576755b_ts_true_hoisted_16 = { class: "w-full flex flex-col flex-nowrap" };
const SwapPoolListvue_type_template_id_5576755b_ts_true_hoisted_17 = { class: "flex flex-row justify-between cc-text-color" };
const SwapPoolListvue_type_template_id_5576755b_ts_true_hoisted_18 = { class: "cc-text-slate-0" };
const SwapPoolListvue_type_template_id_5576755b_ts_true_hoisted_19 = { class: "flex flex-row justify-between cc-text-color" };
const SwapPoolListvue_type_template_id_5576755b_ts_true_hoisted_20 = { class: "cc-text-slate-0" };
const SwapPoolListvue_type_template_id_5576755b_ts_true_hoisted_21 = { class: "flex flex-row flex-nowrap" };
const SwapPoolListvue_type_template_id_5576755b_ts_true_hoisted_22 = { class: "flex flex-row justify-between cc-text-color" };
const SwapPoolListvue_type_template_id_5576755b_ts_true_hoisted_23 = { class: "cc-text-slate-0" };
const SwapPoolListvue_type_template_id_5576755b_ts_true_hoisted_24 = { class: "grid grid-cols-12 cc-gap p-2 w-full" };
function SwapPoolListvue_type_template_id_5576755b_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridHeadline = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridHeadline");
    const _component_FormattedAmount = (0,runtime_core_esm_bundler/* resolveComponent */.up)("FormattedAmount");
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    const _component_GridButtonSecondary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonSecondary");
    const _component_GridButtonPrimary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonPrimary");
    const _component_Modal = (0,runtime_core_esm_bundler/* resolveComponent */.up)("Modal");
    return (_ctx.showModal)
        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_Modal, {
            key: 0,
            onClose: _cache[0] || (_cache[0] = ($event) => (_ctx.$emit('closeModal')))
        }, (0,runtime_core_esm_bundler/* createSlots */.Nv)({
            header: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SwapPoolListvue_type_template_id_5576755b_ts_true_hoisted_1, [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SwapPoolListvue_type_template_id_5576755b_ts_true_hoisted_2, [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                            label: _ctx.t('wallet.swap.create.limit.provider')
                        }, null, 8, ["label"])
                    ])
                ])
            ]),
            content: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SwapPoolListvue_type_template_id_5576755b_ts_true_hoisted_3, [
                    ((0,runtime_core_esm_bundler/* openBlock */.wg)(true), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, (0,runtime_core_esm_bundler/* renderList */.Ko)(_ctx.poolList.filter(p => p.batcherFee.token === '.'), (pool, index) => {
                        return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", {
                            key: index,
                            class: "grow shrink flex flex-col flex-nowrap cc-area-light cc-p cc-tabs-button cursor-pointer",
                            onClick: ($event) => (_ctx.onPoolSelected(pool))
                        }, [
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SwapPoolListvue_type_template_id_5576755b_ts_true_hoisted_5, [
                                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SwapPoolListvue_type_template_id_5576755b_ts_true_hoisted_6, [
                                    (_ctx.getProvider(pool.provider).image.length > 0)
                                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("img", {
                                            key: 0,
                                            class: "w-8 h-8 mr-2",
                                            loading: "lazy",
                                            src: _ctx.getProvider(pool.provider).image,
                                            alt: "provider logo"
                                        }, null, 8, SwapPoolListvue_type_template_id_5576755b_ts_true_hoisted_7))
                                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                                    (0,runtime_core_esm_bundler/* createElementVNode */._)("span", SwapPoolListvue_type_template_id_5576755b_ts_true_hoisted_8, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.getProvider(pool.provider).name), 1)
                                ]),
                                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SwapPoolListvue_type_template_id_5576755b_ts_true_hoisted_9, [
                                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_FormattedAmount, {
                                        "is-whole-number": "",
                                        hideFractionIfZero: "",
                                        amount: _ctx.getPoolPrice(pool),
                                        currency: "",
                                        decimals: _ctx.decimalPrecision(pool),
                                        class: "cursor-pointer"
                                    }, null, 8, ["amount", "decimals"]),
                                    (0,runtime_core_esm_bundler/* createElementVNode */._)("span", SwapPoolListvue_type_template_id_5576755b_ts_true_hoisted_10, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.sourceName), 1),
                                    SwapPoolListvue_type_template_id_5576755b_ts_true_hoisted_11,
                                    (0,runtime_core_esm_bundler/* createElementVNode */._)("span", null, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.targetName), 1)
                                ])
                            ]),
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, {
                                hr: "",
                                label: _ctx.t('wallet.swap.create.limit.liquidity'),
                                class: "w-full"
                            }, null, 8, ["label"]),
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SwapPoolListvue_type_template_id_5576755b_ts_true_hoisted_12, [
                                (0,runtime_core_esm_bundler/* createElementVNode */._)("span", SwapPoolListvue_type_template_id_5576755b_ts_true_hoisted_13, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.sourceName), 1),
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_FormattedAmount, {
                                    hideFractionIfZero: "",
                                    amount: _ctx.priceInverted(pool) ? pool.tokenB.amount : pool.tokenA.amount,
                                    currency: "",
                                    decimals: _ctx.sourceMetadata.tokenRegistryMetadata?.decimals ?? 0,
                                    class: "cursor-pointer"
                                }, null, 8, ["amount", "decimals"])
                            ]),
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SwapPoolListvue_type_template_id_5576755b_ts_true_hoisted_14, [
                                (0,runtime_core_esm_bundler/* createElementVNode */._)("span", SwapPoolListvue_type_template_id_5576755b_ts_true_hoisted_15, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.targetName), 1),
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_FormattedAmount, {
                                    hideFractionIfZero: "",
                                    amount: _ctx.priceInverted(pool) ? pool.tokenA.amount : pool.tokenB.amount,
                                    currency: "",
                                    decimals: _ctx.targetMetadata.tokenRegistryMetadata?.decimals ?? 0,
                                    class: "cursor-pointer"
                                }, null, 8, ["amount", "decimals"])
                            ]),
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, {
                                hr: "",
                                label: _ctx.t('wallet.swap.create.limit.fees'),
                                class: "w-full"
                            }, null, 8, ["label"]),
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SwapPoolListvue_type_template_id_5576755b_ts_true_hoisted_16, [
                                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SwapPoolListvue_type_template_id_5576755b_ts_true_hoisted_17, [
                                    (0,runtime_core_esm_bundler/* createElementVNode */._)("span", SwapPoolListvue_type_template_id_5576755b_ts_true_hoisted_18, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.swap.create.info.poolfee')), 1),
                                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_FormattedAmount, {
                                        percent: "",
                                        hideFractionIfZero: "",
                                        amount: pool.fee.toString(),
                                        decimals: _ctx.getPercentDecimals(pool.fee, false),
                                        class: "cursor-pointer"
                                    }, null, 8, ["amount", "decimals"])
                                ]),
                                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SwapPoolListvue_type_template_id_5576755b_ts_true_hoisted_19, [
                                    (0,runtime_core_esm_bundler/* createElementVNode */._)("span", SwapPoolListvue_type_template_id_5576755b_ts_true_hoisted_20, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.swap.create.info.batcherfee')), 1),
                                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SwapPoolListvue_type_template_id_5576755b_ts_true_hoisted_21, [
                                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_FormattedAmount, {
                                            hideFractionIfZero: "",
                                            amount: pool.batcherFee.amount.toString(),
                                            class: "cursor-pointer"
                                        }, null, 8, ["amount"])
                                    ])
                                ]),
                                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SwapPoolListvue_type_template_id_5576755b_ts_true_hoisted_22, [
                                    (0,runtime_core_esm_bundler/* createElementVNode */._)("span", SwapPoolListvue_type_template_id_5576755b_ts_true_hoisted_23, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.swap.create.info.deposit')), 1),
                                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_FormattedAmount, {
                                        hideFractionIfZero: "",
                                        amount: pool.deposit.toString(),
                                        class: "cursor-pointer"
                                    }, null, 8, ["amount"])
                                ])
                            ])
                        ], 8, SwapPoolListvue_type_template_id_5576755b_ts_true_hoisted_4));
                    }), 128))
                ])
            ]),
            _: 2
        }, [
            (_ctx.showAutoSelectButton)
                ? {
                    name: "footer",
                    fn: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SwapPoolListvue_type_template_id_5576755b_ts_true_hoisted_24, [
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonSecondary, {
                                label: _ctx.t('common.label.cancel'),
                                link: _ctx.onCancel,
                                class: (0,shared_esm_bundler/* normalizeClass */.C_)(["col-span-6", _ctx.poolList.length > 2 ? 'sm:col-span-3' : ''])
                            }, null, 8, ["label", "link", "class"]),
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonPrimary, {
                                label: _ctx.t('wallet.swap.button.auto'),
                                link: _ctx.onAutoSelect,
                                class: (0,shared_esm_bundler/* normalizeClass */.C_)(["col-span-6", _ctx.poolList.length > 2 ? 'sm:col-start-10 sm:col-span-3' : ''])
                            }, null, 8, ["label", "link", "class"])
                        ])
                    ]),
                    key: "0"
                }
                : undefined
        ]), 1024))
        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true);
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/swap/SwapPoolList.vue?vue&type=template&id=5576755b&ts=true

// EXTERNAL MODULE: ../ccw-lib2/core/lib/BigMathLib.ts + 1 modules
var BigMathLib = __webpack_require__(99149);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/swap/SwapPoolList.vue?vue&type=script&lang=ts













/* harmony default export */ const SwapPoolListvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'SwapPoolList',
    components: {
        Tooltip: Tooltip/* default */.Z,
        GridSpace: GridSpace/* default */.Z,
        GridInput: GridInput/* default */.Z,
        GridButtonPrimary: GridButtonPrimary/* default */.Z,
        GridButtonSecondary: GridButtonSecondary/* default */.Z,
        GridHeadline: GridHeadline/* default */.Z,
        FormattedAmount: FormattedAmount/* default */.Z,
        Modal: Modal/* default */.Z
    },
    props: {
        showModal: { type: Boolean, required: true },
        poolList: { type: Array, required: true },
        sourceMetadata: { type: Object, required: true },
        targetMetadata: { type: Object, required: true },
        sourceName: { type: String, required: true, default: '' },
        targetName: { type: String, required: true, default: '' },
        showAutoSelectButton: { type: Boolean, required: false, default: false },
    },
    emits: ['poolUpdate', 'closeModal'],
    setup(props, { emit }) {
        const { t } = (0,useTranslation/* useTranslation */.$)();
        const { getPercentDecimals, getDecimalNumber, getDisplayDecimals } = (0,useFormatter/* useFormatter */.G)();
        const { getProvider } = (0,useSwapLib/* useSwapLib */.a)();
        const sourceDecimals = (0,runtime_core_esm_bundler/* computed */.Fl)(() => props.sourceMetadata?.tokenRegistryMetadata?.decimals ?? 0);
        const targetDecimals = (0,runtime_core_esm_bundler/* computed */.Fl)(() => props.targetMetadata?.tokenRegistryMetadata?.decimals ?? 0);
        const pairDecimalNbr = (0,runtime_core_esm_bundler/* computed */.Fl)(() => {
            const sourceNbr = sourceDecimals.value > 0 ? getDecimalNumber(sourceDecimals.value) : 1;
            const targetNbr = targetDecimals.value > 0 ? getDecimalNumber(targetDecimals.value) : 1;
            return BigMathLib.divide(sourceNbr, targetNbr);
        });
        const priceInverted = (pool) => props.sourceMetadata ? pool.tokenA.token !== props.sourceMetadata.policy + '.' + props.sourceMetadata.name : false;
        const getPoolPrice = (pool) => priceInverted(pool) ? BigMathLib.divide(BigMathLib.divide(1, pool.price), pairDecimalNbr.value) : BigMathLib.divide(pool.price, pairDecimalNbr.value);
        const decimalPrecision = (pool) => getDisplayDecimals(getPoolPrice(pool));
        const onPoolSelected = (pool) => emit('poolUpdate', pool);
        const onCancel = () => emit('closeModal');
        const onAutoSelect = () => emit('poolUpdate', null);
        return {
            t,
            BML: BigMathLib, pairDecimalNbr,
            priceInverted,
            decimalPrecision,
            getPoolPrice,
            getPercentDecimals,
            onPoolSelected,
            getProvider,
            onCancel,
            onAutoSelect
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/swap/SwapPoolList.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/swap/SwapPoolList.vue




;
const SwapPoolList_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(SwapPoolListvue_type_script_lang_ts, [['render',SwapPoolListvue_type_template_id_5576755b_ts_true_render]])

/* harmony default export */ const SwapPoolList = (SwapPoolList_exports_);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/swap/LimitOrder.vue?vue&type=script&lang=ts











/* harmony default export */ const LimitOrdervue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'LimitOrder',
    components: {
        SwapPoolList: SwapPoolList,
        Tooltip: Tooltip/* default */.Z,
        GridSpace: GridSpace/* default */.Z,
        GridInput: GridInput/* default */.Z,
        FormattedAmount: FormattedAmount/* default */.Z,
        BaseModal: BaseModal/* default */.Z
    },
    props: {
        poolList: { type: Array, required: true },
        limitPool: { type: Object, required: true },
        sourceMetadata: { type: Object, required: true },
        targetMetadata: { type: Object, required: true },
        invertPrice: { type: Boolean, required: true, default: false },
        sourceName: { type: String, required: true, default: '' },
        targetName: { type: String, required: true, default: '' },
    },
    emits: ['priceUpdate', 'poolUpdate'],
    setup(props, { emit }) {
        const { t } = (0,useTranslation/* useTranslation */.$)();
        const { languageTag, formatAmountString, getNumberFormatSeparators, valueFromFormattedString, getDecimalNumber, getDisplayDecimals } = (0,useFormatter/* useFormatter */.G)();
        const { getProvider } = (0,useSwapLib/* useSwapLib */.a)();
        let formatSeparators = getNumberFormatSeparators();
        const decimalSeparator = (0,reactivity_esm_bundler/* ref */.iH)(formatSeparators.decimal);
        const groupSeparator = (0,reactivity_esm_bundler/* ref */.iH)(formatSeparators.group);
        (0,runtime_core_esm_bundler/* watch */.YP)(() => languageTag.value, () => {
            formatSeparators = getNumberFormatSeparators();
            decimalSeparator.value = formatSeparators.decimal;
            groupSeparator.value = formatSeparators.group;
            onPriceInputReset();
        }, { deep: true });
        const priceInput = (0,reactivity_esm_bundler/* ref */.iH)('');
        const pricePool = (0,reactivity_esm_bundler/* ref */.iH)('');
        const priceInputError = (0,reactivity_esm_bundler/* ref */.iH)('');
        const manualUpdate = (0,reactivity_esm_bundler/* ref */.iH)(0);
        const provider = (0,reactivity_esm_bundler/* ref */.iH)(getProvider(props.limitPool.provider));
        const showProviderModal = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const sourceDecimals = (0,runtime_core_esm_bundler/* computed */.Fl)(() => props.sourceMetadata?.tokenRegistryMetadata?.decimals ?? 0);
        const targetDecimals = (0,runtime_core_esm_bundler/* computed */.Fl)(() => props.targetMetadata?.tokenRegistryMetadata?.decimals ?? 0);
        const pairDecimalNbr = (0,runtime_core_esm_bundler/* computed */.Fl)(() => {
            const sourceNbr = sourceDecimals.value > 0 ? getDecimalNumber(sourceDecimals.value) : 1;
            const targetNbr = targetDecimals.value > 0 ? getDecimalNumber(targetDecimals.value) : 1;
            return BigMathLib.divide(sourceNbr, targetNbr);
        });
        const decimalPrecision = (0,runtime_core_esm_bundler/* computed */.Fl)(() => getDisplayDecimals(pricePool.value));
        function updatePriceInput(amount) {
            if (BigMathLib.isZero(amount)) {
                priceInputError.value = 'Price can\'t be 0.';
            }
            else {
                priceInputError.value = '';
            }
            if (decimalPrecision.value > 0) {
                priceInput.value = formatAmountString(BigMathLib.multiply(amount, getDecimalNumber(decimalPrecision.value)), decimalPrecision.value === 0, true, decimalPrecision.value, decimalPrecision.value);
            }
            else {
                priceInput.value = formatAmountString(BigMathLib.multiply(amount, getDecimalNumber(decimalPrecision.value)), decimalPrecision.value === 0, true);
            }
            emit('priceUpdate', !BigMathLib.isZero(amount) ? amount : null);
        }
        function validatePriceInput(value) {
            if (value) {
                const amount = valueFromFormattedString(value, decimalPrecision.value, true);
                updatePriceInput(amount.number);
            }
            else {
                priceInput.value = '';
                pricePool.value = '';
                priceInputError.value = '';
                emit('priceUpdate', null);
            }
            manualUpdate.value += 1;
        }
        function updatePriceFromPool(pool, inverted) {
            pricePool.value = inverted ? BigMathLib.divide(BigMathLib.divide(1, pool.price), pairDecimalNbr.value) : BigMathLib.divide(pool.price, pairDecimalNbr.value);
            updatePriceInput(pricePool.value);
        }
        function onPriceInputReset() {
            updatePriceFromPool(props.limitPool, props.invertPrice);
        }
        (0,runtime_core_esm_bundler/* watch */.YP)(() => props.limitPool, (newPool) => {
            provider.value = getProvider(newPool.provider);
            updatePriceFromPool(newPool, props.invertPrice);
        }, { deep: true });
        (0,runtime_core_esm_bundler/* watch */.YP)(() => props.invertPrice, (invert) => {
            updatePriceFromPool(props.limitPool, invert);
        });
        (0,runtime_core_esm_bundler/* onMounted */.bv)(() => {
            updatePriceFromPool(props.limitPool, props.invertPrice);
        });
        return {
            t,
            BML: BigMathLib,
            provider,
            showProviderModal,
            priceInput,
            priceInputError,
            manualUpdate,
            decimalPrecision,
            sourceDecimals,
            decimalSeparator,
            groupSeparator,
            formatAmountString,
            validatePriceInput,
            onPriceInputReset,
            getProvider
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/swap/LimitOrder.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/swap/LimitOrder.vue




;
const LimitOrder_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(LimitOrdervue_type_script_lang_ts, [['render',LimitOrdervue_type_template_id_59fcf444_ts_true_render]])

/* harmony default export */ const LimitOrder = (LimitOrder_exports_);
// EXTERNAL MODULE: ./src/pages/ccw/wallet/pages/SignTransaction.vue + 4 modules
var SignTransaction = __webpack_require__(87534);
// EXTERNAL MODULE: ../ccw-lib2/core/ITokenBalance.ts
var ITokenBalance = __webpack_require__(65024);
// EXTERNAL MODULE: ../ccw-lib2/core/IToken.ts
var IToken = __webpack_require__(82798);
// EXTERNAL MODULE: ../ccw-lib2/core/IAssetInfo.ts
var IAssetInfo = __webpack_require__(3892);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/ITokenSwap.ts
var ITokenSwap = __webpack_require__(92291);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/AccountTokensLib_v2.ts
var AccountTokensLib_v2 = __webpack_require__(95875);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/ChainLib.ts
var ChainLib = __webpack_require__(48011);
// EXTERNAL MODULE: ./src/api/NetworkEndpoint.ts
var NetworkEndpoint = __webpack_require__(30979);
// EXTERNAL MODULE: ./src/ext/worker.api.ts
var worker_api = __webpack_require__(45855);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/swap/CreateSwap.vue?vue&type=script&lang=ts

;





























/* harmony default export */ const CreateSwapvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'CreateSwap',
    components: {
        FormattedAmount: FormattedAmount/* default */.Z,
        GridSpace: GridSpace/* default */.Z,
        GridHeadline: GridHeadline/* default */.Z,
        GridText: GridText/* default */.Z,
        GridTextArea: GridTextArea/* default */.Z,
        GridButtonPrimary: GridButtonPrimary/* default */.Z,
        GridButtonSecondary: GridButtonSecondary/* default */.Z,
        GridButtonAbort: GridButtonAbort/* default */.Z,
        SwapInput: SwapInput,
        SwapSelection: SwapSelection,
        LimitOrder: LimitOrder,
        SwapPoolList: SwapPoolList,
        Modal: Modal/* default */.Z,
        SignTransaction: SignTransaction["default"]
    },
    setup() {
        const { t } = (0,useTranslation/* useTranslation */.$)();
        const $q = (0,use_quasar/* default */.Z)();
        const { activeWalletData, activeAccount } = (0,useActiveWallet/* useActiveWallet */.r)();
        const { getAssetInfo } = (0,useTokenLib_v2/* useTokenLibV2 */.P)();
        const { swapRouteList, resolveSwapPools, getProvider } = (0,useSwapLib/* useSwapLib */.a)();
        const { getDecimalNumber, getPercentDecimals, getDisplayDecimals, mapCryptoSymbol } = (0,useFormatter/* useFormatter */.G)();
        const { resetBuildTx, buildSwapTx } = (0,useBuildTx_v3/* useBuildTxV3 */.b)();
        (0,runtime_core_esm_bundler/* onErrorCaptured */.d1)((e) => { console.error('Wallet: Swap: onErrorCaptured', e); return true; });
        const isLoaded = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const showSwapModal = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const muesliPools = (0,reactivity_esm_bundler/* ref */.iH)([]);
        const manualPool = (0,reactivity_esm_bundler/* ref */.iH)(null);
        const swapInfo = (0,reactivity_esm_bundler/* ref */.iH)(null);
        const swapPool = (0,runtime_core_esm_bundler/* computed */.Fl)(() => limitEnabled.value ? (limitPool.value ?? null) : (manualPool.value ?? swapInfo.value?.pool ?? null));
        const provider = (0,runtime_core_esm_bundler/* computed */.Fl)(() => swapPool.value ? getProvider(swapPool.value.provider) : null);
        const showProviderModal = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const onShowProviderModal = () => showProviderModal.value = true;
        const swapInfoDetails = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const limitFeeDetails = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const sourceAssets = (0,reactivity_esm_bundler/* ref */.iH)([]);
        const targetAssets = (0,reactivity_esm_bundler/* ref */.iH)([]);
        const isSelectionSource = (0,reactivity_esm_bundler/* ref */.iH)(true);
        const selectedSource = (0,reactivity_esm_bundler/* ref */.iH)(activeAccount.value ? {
            token: (0,ITokenBalance/* createITokenBalance */.a)({
                name: '',
                policy: '',
                quantity: activeAccount.value.balance.total
            }),
            amount: ''
        } : null);
        const selectedTarget = (0,reactivity_esm_bundler/* ref */.iH)(null);
        const sourceMetadata = (0,reactivity_esm_bundler/* ref */.iH)(activeAccount.value ? (0,IAssetInfo/* createADAMeta */.tc)((0,ChainLib/* getCirculatingSupply */.On)(activeAccount.value.network)) : null);
        const targetMetadata = (0,reactivity_esm_bundler/* ref */.iH)(null);
        const sourceInputError = (0,reactivity_esm_bundler/* ref */.iH)('');
        const targetInputError = (0,reactivity_esm_bundler/* ref */.iH)('');
        const limitEnabled = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const limitPool = (0,reactivity_esm_bundler/* ref */.iH)(null);
        const limitPrice = (0,reactivity_esm_bundler/* ref */.iH)('0');
        const sourceDecimals = (0,runtime_core_esm_bundler/* computed */.Fl)(() => sourceMetadata.value?.tokenRegistryMetadata?.decimals ?? 0);
        const targetDecimals = (0,runtime_core_esm_bundler/* computed */.Fl)(() => targetMetadata.value?.tokenRegistryMetadata?.decimals ?? 0);
        const pairDecimalNbr = (0,runtime_core_esm_bundler/* computed */.Fl)(() => {
            const sourceNbr = sourceDecimals.value > 0 ? getDecimalNumber(sourceDecimals.value) : 1;
            const targetNbr = targetDecimals.value > 0 ? getDecimalNumber(targetDecimals.value) : 1;
            return BigMathLib.divide(sourceNbr, targetNbr);
        });
        const priceInverted = (0,runtime_core_esm_bundler/* computed */.Fl)(() => {
            if (!selectedSource.value) {
                return false;
            }
            const sourceTokenId = selectedSource.value.token.policy + '.' + selectedSource.value.token.name;
            if (limitEnabled.value) {
                if (!limitPool.value) {
                    return false;
                }
                return limitPool.value.tokenA.token !== sourceTokenId;
            }
            else {
                if (!swapInfo.value) {
                    return false;
                }
                return swapInfo.value.pool.tokenA.token !== sourceTokenId;
            }
        });
        const sourceName = (0,runtime_core_esm_bundler/* computed */.Fl)(() => {
            if (!selectedSource.value) {
                return '';
            }
            return mapCryptoSymbol(selectedSource.value.token.policy.length === 0 ? 'ADA' : sourceMetadata.value?.tokenRegistryMetadata?.ticker ?? (0,AccountTokensLib_v2/* formatAssetName */.ZP)(selectedSource.value.token.name));
        });
        const targetName = (0,runtime_core_esm_bundler/* computed */.Fl)(() => {
            if (!selectedTarget.value) {
                return '';
            }
            return mapCryptoSymbol(selectedTarget.value.token.policy.length === 0 ? 'ADA' : targetMetadata.value?.tokenRegistryMetadata?.ticker ?? (0,AccountTokensLib_v2/* formatAssetName */.ZP)(selectedTarget.value.token.name));
        });
        const batcherName = (0,runtime_core_esm_bundler/* computed */.Fl)(() => {
            if (!swapInfo.value || swapInfo.value.pool.batcherFee.token === '.') {
                return mapCryptoSymbol('ADA');
            }
            $q.notify({
                type: 'warning',
                message: t('wallet.swap.error.unsupportedBatcher'),
                position: 'top-left',
                timeout: 4000
            });
            return mapCryptoSymbol(swapInfo.value.pool.batcherFee.token.split('.')[1]);
        });
        const hasInputError = (0,runtime_core_esm_bundler/* computed */.Fl)(() => sourceInputError.value.length > 0 || targetInputError.value.length > 0);
        const priceDiffColor = (0,runtime_core_esm_bundler/* computed */.Fl)(() => {
            if (!swapInfo.value || swapInfo.value.priceDiff.length === 0) {
                return 'cc-text-color';
            }
            if (BigMathLib.compare(swapInfo.value.priceDiff, '<', 0.05)) {
                return 'cc-text-green';
            }
            if (BigMathLib.compare(swapInfo.value.priceDiff, '<', 0.15)) {
                return 'cc-text-yellow';
            }
            else {
                return 'cc-text-red';
            }
        });
        // 0.5% (min 1 ADA) for > 100 ADA swap
        // Only for swaps including ADA in swap pair (TODO: limit to this like muesli?)
        const eternlFee = (0,runtime_core_esm_bundler/* computed */.Fl)(() => {
            if (!selectedSource.value || !selectedTarget.value) {
                return '0';
            }
            if (selectedSource.value.token.policy.length === 0) {
                return getEternlFee(selectedSource.value.amount);
            }
            else if (selectedTarget.value.token.policy.length === 0) {
                return getEternlFee(selectedTarget.value.amount);
            }
            return '0';
        });
        function getEternlFee(amount) {
            if (BigMathLib.isZero(amount)) {
                return '0';
            }
            if (BigMathLib.compare(amount, '>=', 100000000)) {
                const fee = BigMathLib.multiply(amount, 0.005, 0);
                return BigMathLib.compare(fee, '<', 1000000) ? '1000000' : fee;
            }
            return '0';
        }
        function onSourceInputError(error) {
            sourceInputError.value = error;
        }
        function onTargetInputError(error) {
            targetInputError.value = error;
        }
        function updateTargetAssets() {
            targetAssets.value.splice(0);
            if (!selectedSource.value) {
                return;
            }
            const pairs = swapRouteList.value.find(r => r.policyId === selectedSource.value.token.policy && r.assetHexName === selectedSource.value.token.name)?.pairs ?? [];
            for (const pair of pairs) {
                targetAssets.value.push((0,ITokenBalance/* createITokenBalance */.a)({
                    name: pair.name,
                    policy: pair.policyId,
                    quantity: '0'
                }));
            }
        }
        function updateForBestPool(pool, selectedToken, amount) {
            let bestPool = null;
            let bestAmount = '0';
            let poolFee = '0';
            if (pool) {
                const tokenId = selectedToken.token.policy + '.' + selectedToken.token.name;
                const calcAmount = calculateEstAmount(pool, tokenId, amount);
                if ((isSelectionSource.value && BigMathLib.compare(calcAmount.amount, '>', bestAmount)) ||
                    (!isSelectionSource.value && (BigMathLib.isZero(bestAmount) || BigMathLib.compare(calcAmount.amount, '<', bestAmount)))) {
                    bestAmount = calcAmount.amount;
                    poolFee = calcAmount.poolFee;
                    bestPool = pool;
                }
            }
            if (limitEnabled.value) {
                bestAmount = selectedTarget.value.amount;
            }
            bestAmount = bestAmount.length === 0 ? '0' : BigMathLib.round(bestAmount, 0, 'down');
            if (bestPool) {
                const info = (0,ITokenSwap/* createSwapInfo */.Zi)(bestPool);
                info.poolFee = poolFee;
                const sourceTokenId = selectedSource.value.token.policy + '.' + selectedSource.value.token.name;
                const sourceAmount = isSelectionSource.value ? selectedSource.value.amount : bestAmount;
                const targetAmount = isSelectionSource.value ? bestAmount : selectedTarget.value.amount;
                info.estReceive = targetAmount;
                info.minReceive = limitEnabled.value ? targetAmount : BigMathLib.multiply(targetAmount, 1 - info.slippage, 0);
                // Edge case where min receive is zero due to slippage
                if (BigMathLib.isZero(info.minReceive)) {
                    info.minReceive = '1';
                }
                // eff. price & price diff calc.
                // TODO: fix for swap where batcher fee token type is not part of pool, ie batcher fee in ADA but swap where ADA is not either source or target.
                if (bestPool.batcherFee.token === bestPool.tokenA.token || bestPool.batcherFee.token === bestPool.tokenB.token) {
                    if (BigMathLib.isZero(targetAmount)) {
                        return { info: null, amount: '0' };
                    }
                    const isBatchSource = bestPool.batcherFee.token === bestPool.tokenA.token && bestPool.batcherFee.token === sourceTokenId;
                    const price = limitEnabled.value ? limitPrice.value : (isBatchSource ? bestPool.price.toString() : BigMathLib.divide(1, bestPool.price));
                    if (BigMathLib.isZero(price)) {
                        return { info: null, amount: '0' };
                    }
                    const batcherFeeAmount = isBatchSource ? bestPool.batcherFee.amount : BigMathLib.multiply(price, bestPool.batcherFee.amount);
                    let amountAndFee = BigMathLib.add(sourceAmount, batcherFeeAmount);
                    if (selectedSource.value.token.policy.length === 0) {
                        amountAndFee = BigMathLib.add(amountAndFee, getEternlFee(sourceAmount));
                    }
                    else if (selectedTarget.value.token.policy.length === 0) {
                        amountAndFee = BigMathLib.add(amountAndFee, getEternlFee(targetAmount));
                    }
                    info.price = price;
                    info.effPrice = BigMathLib.divide(amountAndFee, targetAmount);
                    info.priceDiff = BigMathLib.subtract(BigMathLib.divide(info.effPrice, price), 1);
                    let sDecimals = sourceDecimals.value;
                    let tDecimals = targetDecimals.value;
                    sDecimals === 0 ? sDecimals = 1 : sDecimals = getDecimalNumber(sDecimals);
                    tDecimals === 0 ? tDecimals = 1 : tDecimals = getDecimalNumber(tDecimals);
                    info.price = BigMathLib.multiply(info.price, tDecimals);
                    info.price = BigMathLib.divide(info.price, sDecimals);
                    info.effPrice = BigMathLib.multiply(info.effPrice, tDecimals);
                    info.effPrice = BigMathLib.divide(info.effPrice, sDecimals);
                }
                else {
                    const price = limitEnabled.value ? limitPrice.value : bestPool.price.toString();
                    info.price = priceInverted ? BigMathLib.divide(BigMathLib.divide(1, price), pairDecimalNbr.value) : BigMathLib.divide(price, pairDecimalNbr.value);
                }
                return { info, amount: bestAmount };
            }
            else {
                return { info: null, amount: '0' };
            }
        }
        // Selects the best pool for this swap and returns the estimated calculated amount for source or target
        function selectBestPool(selectedToken, amount, showWarning = true) {
            const tokenId = selectedToken.token.policy + '.' + selectedToken.token.name;
            let bestPoolInfo = null;
            let bestPoolAmount = '0';
            try {
                for (const pool of (manualPool.value ? [manualPool.value] : muesliPools.value)) {
                    if (pool.batcherFee.token !== '.') {
                        continue;
                    } // We only allow batcher fee in ADA
                    if ((pool.tokenA.token === tokenId && BigMathLib.compare(pool.tokenA.amount, '<', amount)) ||
                        (pool.tokenB.token === tokenId && BigMathLib.compare(pool.tokenB.amount, '<', amount))) {
                        continue;
                    }
                    const bestPool = updateForBestPool(pool, selectedToken, amount);
                    if (!bestPool.info) {
                        continue;
                    }
                    if (!bestPoolInfo || BigMathLib.compare(bestPool.info.effPrice, '<', bestPoolInfo.effPrice)) {
                        bestPoolInfo = bestPool.info;
                        bestPoolAmount = bestPool.amount;
                    }
                }
            }
            catch (err) {
                bestPoolInfo = null;
                bestPoolAmount = '0';
            }
            if (!bestPoolInfo && showWarning) {
                $q.notify({
                    type: 'warning',
                    message: manualPool.value ? t('wallet.swap.error.lowLiqudityInPool') : t('wallet.swap.error.noPoolMatch'),
                    position: 'top-left',
                    timeout: 4000
                });
            }
            return { info: bestPoolInfo, amount: bestPoolAmount };
        }
        // Uses AMM constant product formula (X * Y = K) where
        // X = size in pool of token A
        // Y = size in pool of token B
        // K = constant value as pool change in size based on swapped amount
        // Returns either source or target amount + pool fee amount
        function calculateEstAmount(pool, tokenId, amount) {
            const isTokenA = isSelectionSource.value ? pool.tokenA.token === tokenId : pool.tokenA.token !== tokenId;
            const X = isTokenA ? pool.tokenA.amount : pool.tokenB.amount;
            const Y = isTokenA ? pool.tokenB.amount : pool.tokenA.amount;
            const K = BigMathLib.multiply(X, Y);
            const poolFeeFraction = BigMathLib.divide(pool.fee, 100);
            if (isSelectionSource.value) {
                const poolFee = BigMathLib.multiply(amount, poolFeeFraction);
                const amountMinusFee = BigMathLib.subtract(amount, poolFee);
                const newX = BigMathLib.add(X, amountMinusFee);
                const newY = BigMathLib.divide(K, newX);
                const targetAmount = BigMathLib.subtract(Y, newY);
                return { amount: targetAmount, poolFee };
            }
            else { // target amount requested, reverse calculation
                const newY = BigMathLib.subtract(Y, amount);
                const newX = BigMathLib.divide(K, newY);
                const amountMinusFee = BigMathLib.subtract(newX, X);
                const sourceAmount = BigMathLib.divide(amountMinusFee, BigMathLib.subtract(1, poolFeeFraction));
                const poolFee = BigMathLib.subtract(sourceAmount, amountMinusFee);
                return { amount: sourceAmount, poolFee };
            }
        }
        async function onSourceAssetSelect(token) {
            if (selectedSource.value && (0,IToken/* isEqualITokenList */.Gz)([selectedSource.value.token], [token.token])) {
                // no change
                return;
            }
            swapInfo.value = null;
            selectedSource.value = token;
            sourceMetadata.value = activeAccount.value ? await getAssetInfo(activeAccount.value.network, token.token) : null;
            updateTargetAssets();
            if (selectedTarget.value) {
                if (!targetAssets.value.some(t => t.policy === selectedTarget.value.token.policy && t.name === selectedTarget.value.token.name)) {
                    // previous target not selectable
                    selectedTarget.value = null;
                }
                else {
                    selectedTarget.value.amount = '';
                }
            }
            if (selectedSource.value && selectedTarget.value) {
                await onPairSelected();
            }
        }
        function onSourceAssetUpdate(token) {
            isSelectionSource.value = true;
            if (!selectedSource.value) {
                return;
            }
            selectedSource.value.amount = token.amount;
            if (token.amount.length === 0 || BigMathLib.isZero(token.amount)) {
                swapInfo.value = null;
                selectedTarget.value ? selectedTarget.value.amount = '' : false;
                return;
            }
            if (!selectedTarget.value) {
                return;
            }
            if (limitEnabled.value) {
                const sourceAmount = BigMathLib.divide(selectedSource.value.amount, pairDecimalNbr.value);
                selectedTarget.value.amount = limitPrice.value ? divideByLimitPrice(sourceAmount) : '';
                swapInfo.value = updateForBestPool(limitPool.value, selectedSource.value, selectedSource.value.amount).info;
                if (!onPoolCheckLiquidity(limitPool.value)) {
                    selectedTarget.value.amount = '';
                }
            }
            else {
                swapInfo.value = selectBestPool(selectedSource.value, selectedSource.value.amount).info;
                selectedTarget.value.amount = BigMathLib.round(swapInfo.value?.estReceive ?? '0', 0, 'down');
            }
        }
        async function onTargetAssetSelect(token) {
            if (selectedTarget.value && (0,IToken/* isEqualITokenList */.Gz)([selectedTarget.value.token], [token.token])) {
                // no change
                return;
            }
            swapInfo.value = null;
            selectedTarget.value = token;
            targetMetadata.value = activeAccount.value ? await getAssetInfo(activeAccount.value.network, token.token) : null;
            if (selectedSource.value && selectedTarget.value) {
                await onPairSelected();
                if (selectedSource.value.amount.length > 0 && !BigMathLib.isZero(selectedSource.value.amount)) {
                    onSourceAssetUpdate(selectedSource.value);
                }
            }
        }
        function onTargetAssetUpdate(token) {
            isSelectionSource.value = false;
            if (!selectedTarget.value) {
                return;
            }
            selectedTarget.value.amount = token.amount;
            if (token.amount.length === 0 || BigMathLib.isZero(token.amount)) {
                swapInfo.value = null;
                selectedSource.value ? selectedSource.value.amount = '' : false;
                return;
            }
            if (limitEnabled.value) {
                const targetAmount = BigMathLib.multiply(selectedTarget.value.amount, pairDecimalNbr.value);
                selectedSource.value.amount = limitPrice.value ? multiplyByLimitPrice(targetAmount) : '';
                swapInfo.value = updateForBestPool(limitPool.value, selectedTarget.value, selectedTarget.value.amount).info;
                if (!onPoolCheckLiquidity(limitPool.value)) {
                    selectedSource.value.amount = '';
                }
            }
            else {
                const bestPool = selectBestPool(selectedTarget.value, selectedTarget.value.amount);
                swapInfo.value = bestPool.info;
                selectedSource.value.amount = BigMathLib.round(bestPool.amount, 0, 'up');
            }
        }
        function onLimitEnabled(enabled) {
            swapInfoDetails.value = false;
            limitFeeDetails.value = false;
            if (!selectedSource.value || !selectedTarget.value) {
                limitPool.value = getBestPoolSimple();
                limitEnabled.value = enabled;
                return;
            }
            if (!enabled) {
                limitEnabled.value = enabled;
                isSelectionSource.value ? onSourceAssetUpdate(selectedSource.value) : onTargetAssetUpdate(selectedTarget.value);
            }
            else {
                swapInfo.value = selectBestPool(selectedSource.value, selectedSource.value.amount, false).info;
                limitPool.value = swapInfo.value?.pool ?? getBestPoolSimple();
                limitEnabled.value = enabled;
            }
        }
        const divideByLimitPrice = (sourceAmount) => {
            if (BigMathLib.isZero(limitPrice.value)) {
                return '';
            }
            else {
                return BigMathLib.round(BigMathLib.divide(sourceAmount, limitPrice.value), 0, 'down');
            }
        };
        const multiplyByLimitPrice = (targetAmount) => {
            if (BigMathLib.isZero(limitPrice.value)) {
                return '';
            }
            else {
                return BigMathLib.round(BigMathLib.multiply(targetAmount, limitPrice.value), 0, 'up');
            }
        };
        function onLimitPriceUpdate(price) {
            if (!limitPool.value || !selectedSource.value || !selectedTarget.value) {
                return;
            }
            limitPrice.value = BigMathLib.isZero(price ?? '0') ? '0' : price;
            if (limitPrice.value === '0')
                return;
            if (isSelectionSource.value) {
                if (BigMathLib.isZero(selectedSource.value.amount)) {
                    return;
                }
                const sourceAmount = BigMathLib.divide(selectedSource.value.amount, pairDecimalNbr.value);
                selectedTarget.value.amount = limitPrice.value ? divideByLimitPrice(sourceAmount) : '';
                swapInfo.value = updateForBestPool(limitPool.value, selectedSource.value, selectedSource.value.amount).info;
                if (!onPoolCheckLiquidity(limitPool.value)) {
                    selectedTarget.value.amount = '';
                }
            }
            else {
                if (BigMathLib.isZero(selectedTarget.value.amount)) {
                    return;
                }
                const targetAmount = BigMathLib.multiply(selectedTarget.value.amount, pairDecimalNbr.value);
                selectedSource.value.amount = limitPrice.value ? multiplyByLimitPrice(targetAmount) : '';
                swapInfo.value = updateForBestPool(limitPool.value, selectedTarget.value, selectedTarget.value.amount).info;
                if (!onPoolCheckLiquidity(limitPool.value)) {
                    selectedSource.value.amount = '';
                }
            }
        }
        function onLimitPoolUpdate(pool) {
            onPoolCheckLiquidity(pool) ? limitPool.value = pool : false;
        }
        function onPoolCheckLiquidity(pool) {
            if (!pool || !selectedSource.value || !selectedTarget.value) {
                return false;
            }
            let poolValid = true;
            if (isSelectionSource.value) {
                const tokenId = selectedSource.value.token.policy + '.' + selectedSource.value.token.name;
                if ((pool.tokenA.token === tokenId && BigMathLib.compare(pool.tokenA.amount, '<', selectedSource.value.amount)) ||
                    (pool.tokenB.token === tokenId && BigMathLib.compare(pool.tokenB.amount, '<', selectedSource.value.amount))) {
                    poolValid = false;
                }
            }
            else {
                const tokenId = selectedTarget.value.token.policy + '.' + selectedTarget.value.token.name;
                if ((pool.tokenA.token === tokenId && BigMathLib.compare(pool.tokenA.amount, '<', selectedTarget.value.amount)) ||
                    (pool.tokenB.token === tokenId && BigMathLib.compare(pool.tokenB.amount, '<', selectedTarget.value.amount))) {
                    poolValid = false;
                }
            }
            if (!poolValid) {
                $q.notify({
                    type: 'warning',
                    message: t('wallet.swap.error.lowLiqudityInPool'),
                    position: 'top-left',
                    timeout: 4000
                });
                return false;
            }
            return true;
        }
        function onClearSwapSelection() {
            selectedSource.value = activeAccount.value ? {
                token: (0,ITokenBalance/* createITokenBalance */.a)({
                    name: '',
                    policy: '',
                    quantity: activeAccount.value.balance.total
                }),
                amount: '0'
            } : null;
            selectedTarget.value = null;
            swapInfo.value = null;
            limitEnabled.value = false;
            manualPool.value = null;
            muesliPools.value.splice(0);
            updateTargetAssets();
        }
        async function onPairSelected() {
            if (!activeAccount.value || !selectedSource.value || !selectedTarget.value) {
                return;
            }
            muesliPools.value = await resolveSwapPools(activeAccount.value.network, selectedSource.value.token, selectedTarget.value.token);
            if (limitEnabled.value) {
                swapInfo.value = selectBestPool(selectedSource.value, selectedSource.value.amount, false).info;
                limitPool.value = swapInfo.value?.pool ?? getBestPoolSimple();
            }
        }
        function onPoolSelected(pool) {
            showProviderModal.value = false;
            if (pool && !onPoolCheckLiquidity(pool)) {
                return;
            }
            manualPool.value = pool;
            limitPool.value = pool ?? getBestPoolSimple();
            if (limitEnabled.value || !selectedSource.value || !selectedTarget.value) {
                return;
            }
            if (isSelectionSource.value) {
                onSourceAssetUpdate(selectedSource.value);
            }
            else {
                onTargetAssetUpdate(selectedTarget.value);
            }
        }
        function getBestPoolSimple() {
            if (muesliPools.value.length > 0) {
                let bestPool = muesliPools.value[0];
                for (let i = 1; i < muesliPools.value.length; i++) {
                    if (BigMathLib.compare(muesliPools.value[i].price, '<', bestPool.price)) {
                        bestPool = muesliPools.value[i];
                    }
                }
                return bestPool;
            }
            return null;
        }
        async function onSwapDirection() {
            if (!activeAccount.value || !selectedSource.value || !selectedTarget.value) {
                return;
            }
            swapInfo.value = null;
            let newSource = null;
            let newAmount = selectedTarget.value.amount;
            if (selectedTarget.value.token.policy.length === 0) { // ADA
                newSource = {
                    token: (0,ITokenBalance/* createITokenBalance */.a)({
                        name: '',
                        policy: '',
                        quantity: activeAccount.value.balance.total
                    }),
                    amount: ''
                };
            }
            else {
                const ownAsset = activeAccount.value.balance.tokenBalance.find(t => t.policy === selectedTarget.value.token.policy && t.name === selectedTarget.value.token.name);
                if (ownAsset) {
                    newSource = {
                        token: (0,ITokenBalance/* createITokenBalance */.a)(ownAsset),
                        amount: ''
                    };
                }
                else {
                    $q.notify({
                        type: 'warning',
                        message: t('wallet.swap.error.tokenNotFound'),
                        position: 'top-left',
                        timeout: 4000
                    });
                }
            }
            if (!newSource) {
                return;
            }
            selectedTarget.value = selectedSource.value;
            sourceMetadata.value = await getAssetInfo(activeAccount.value.network, newSource.token);
            targetMetadata.value = await getAssetInfo(activeAccount.value.network, selectedTarget.value.token);
            selectedSource.value = newSource;
            limitEnabled.value ? onLimitPriceUpdate(limitPrice.value) : false;
            if (newAmount.length === 0 || BigMathLib.isZero(newAmount)) {
                selectedSource.value.amount = '';
                updateTargetAssets();
                return;
            }
            isSelectionSource.value = true;
            selectedSource.value.amount = newAmount;
            if (limitEnabled.value) {
                const sourceAmount = BigMathLib.divide(selectedSource.value.amount, pairDecimalNbr.value);
                selectedTarget.value.amount = limitPrice.value ? divideByLimitPrice(sourceAmount) : '';
                swapInfo.value = updateForBestPool(limitPool.value, selectedSource.value, selectedSource.value.amount).info;
            }
            else {
                const bestPool = selectBestPool(selectedSource.value, selectedSource.value.amount);
                swapInfo.value = bestPool.info;
                selectedTarget.value.amount = BigMathLib.round(bestPool.amount, 0, 'down');
            }
            updateTargetAssets();
        }
        async function onSwap() {
            onSwapCancel();
            const swapDatum = await constructSwapDatum();
            const pool = limitEnabled.value ? limitPool.value : (swapInfo.value?.pool ?? null);
            if (pool && activeWalletData.value && activeAccount.value && swapDatum && selectedSource.value && selectedTarget.value) {
                const res = await buildSwapTx(activeWalletData.value, activeAccount.value, selectedSource.value, selectedTarget.value, swapDatum, pool, BigMathLib.isZero(eternlFee.value) ? undefined : eternlFee.value, limitEnabled.value);
                if (res.error) {
                    $q.notify({
                        type: 'negative',
                        message: res.error,
                        position: 'top-left',
                        timeout: 8000
                    });
                    resetBuildTx(activeAccount.value.pub);
                }
                else {
                    showSwapModal.value = true;
                }
            }
        }
        function onSwapCancel() {
            if (activeAccount.value) {
                resetBuildTx(activeAccount.value.pub);
            }
            showSwapModal.value = false;
        }
        async function constructSwapDatum() {
            let error = '';
            if (activeAccount.value && swapInfo.value) {
                let url = NetworkEndpoint/* endPoints */.zH[activeAccount.value.network]?.swap?.ms?.datum;
                if (url && url.length > 0) {
                    const buyTokenPolicyID = selectedTarget.value.token.policy.length === 0 ? '""' : selectedTarget.value.token.policy;
                    const buyTokenNameHex = selectedTarget.value.token.name.length === 0 ? '""' : selectedTarget.value.token.name;
                    const sellTokenPolicyID = selectedSource.value.token.policy.length === 0 ? '""' : selectedSource.value.token.policy;
                    const sellTokenNameHex = selectedSource.value.token.name.length === 0 ? '""' : selectedSource.value.token.name;
                    const urlParams = new URLSearchParams({
                        walletAddr: activeAccount.value.base.payment[0][0].bech32,
                        buyTokenPolicyID: buyTokenPolicyID,
                        buyTokenNameHex: buyTokenNameHex,
                        sellTokenPolicyID: sellTokenPolicyID,
                        sellTokenNameHex: sellTokenNameHex,
                        buyAmount: swapInfo.value.minReceive,
                        sellAmount: BigMathLib.round(selectedSource.value.amount, 0, 'up'),
                        protocol: limitEnabled.value ? limitPool.value.provider : swapInfo.value.pool.provider,
                        poolId: limitEnabled.value ? limitPool.value.poolId : swapInfo.value.pool.poolId
                    });
                    const res = await worker_api/* api.get */.h.get(url + '/?' + urlParams.toString()).catch((err) => {
                        error = err?.message ?? err;
                        console.error('constructSwapDatum:', activeAccount.value.network, err?.message ?? err);
                    });
                    if (res && res.status === 'success') {
                        return res;
                    }
                }
                else {
                    error = t('wallet.swap.error.network');
                    console.error('constructSwapDatum:', error);
                }
            }
            $q.notify({
                type: 'negative',
                message: t('wallet.swap.error.constructSwapDatum') + (error.length > 0 ? `<br>Error: ${error}` : ''),
                position: 'top-left',
                timeout: 5000,
                html: true
            });
            return null;
        }
        (0,runtime_core_esm_bundler/* onMounted */.bv)(async () => {
            if (!activeAccount.value) {
                return;
            }
            if (swapRouteList.value.length === 0) {
                $q.notify({
                    type: 'negative',
                    message: t('wallet.swap.error.routesNotFound'),
                    position: 'top-left',
                    timeout: 5000
                });
                return;
            }
            for (const route of swapRouteList.value) {
                if (route.policyId.length === 0) { // ADA
                    sourceAssets.value.push((0,ITokenBalance/* createITokenBalance */.a)({
                        name: '',
                        policy: '',
                        quantity: activeAccount.value.balance.total
                    }));
                }
                else {
                    const ownAsset = activeAccount.value.balance.tokenBalance.find(t => t.policy === route.policyId && t.name === route.assetHexName);
                    if (ownAsset) {
                        sourceAssets.value.push((0,ITokenBalance/* createITokenBalance */.a)(ownAsset));
                    }
                }
            }
            updateTargetAssets();
            isLoaded.value = true;
        });
        return {
            t,
            BML: BigMathLib,
            activeWalletData,
            activeAccount,
            showSwapModal,
            showProviderModal,
            isLoaded,
            limitEnabled,
            limitPrice,
            limitPool,
            manualPool,
            muesliPools,
            isSelectionSource,
            selectedSource,
            selectedTarget,
            sourceAssets,
            targetAssets,
            sourceName,
            targetName,
            batcherName,
            eternlFee,
            sourceMetadata,
            targetMetadata,
            sourceDecimals,
            targetDecimals,
            hasInputError,
            swapInfo,
            provider,
            swapInfoDetails,
            limitFeeDetails,
            priceDiffColor,
            priceInverted,
            formatAssetName: AccountTokensLib_v2/* formatAssetName */.ZP,
            getPercentDecimals,
            getDisplayDecimals,
            onPoolSelected,
            onShowProviderModal,
            onSourceInputError,
            onTargetInputError,
            onSourceAssetUpdate,
            onSourceAssetSelect,
            onTargetAssetUpdate,
            onTargetAssetSelect,
            onLimitPriceUpdate,
            onLimitPoolUpdate,
            onLimitEnabled,
            onClearSwapSelection,
            onSwapDirection,
            onSwap,
            onSwapCancel,
            getProvider
        };
    }
}));

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/swap/CreateSwap.vue?vue&type=script&lang=ts
 
// EXTERNAL MODULE: ./node_modules/quasar/src/components/spinner/QSpinnerDots.js
var QSpinnerDots = __webpack_require__(34765);
;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/swap/CreateSwap.vue




;


const CreateSwap_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(CreateSwapvue_type_script_lang_ts, [['render',render],['__scopeId',"data-v-0f3c6b6e"]])

/* harmony default export */ const CreateSwap = (CreateSwap_exports_);
;

runtime_auto_import_default()(CreateSwapvue_type_script_lang_ts, 'components', {QSpinnerDots: QSpinnerDots/* default */.Z});

;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/swap/OpenOrders.vue?vue&type=template&id=4ad5b3de&ts=true

const OpenOrdersvue_type_template_id_4ad5b3de_ts_true_hoisted_1 = { class: "col-span-12 flex flex-row flex-nowrap justify-between items-center space-x-4" };
const OpenOrdersvue_type_template_id_4ad5b3de_ts_true_hoisted_2 = { class: "cc-grid" };
const OpenOrdersvue_type_template_id_4ad5b3de_ts_true_hoisted_3 = {
    key: 0,
    class: "col-span-12 flex flex-col flex-nowrap justify-center items-center"
};
function OpenOrdersvue_type_template_id_4ad5b3de_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridHeadline = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridHeadline");
    const _component_GridText = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridText");
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    const _component_q_spinner_dots = (0,runtime_core_esm_bundler/* resolveComponent */.up)("q-spinner-dots");
    const _component_OrderList = (0,runtime_core_esm_bundler/* resolveComponent */.up)("OrderList");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, [
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", OpenOrdersvue_type_template_id_4ad5b3de_ts_true_hoisted_1, [
            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", OpenOrdersvue_type_template_id_4ad5b3de_ts_true_hoisted_2, [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                    label: _ctx.t('wallet.swap.orders.headline'),
                    class: "col-span-12"
                }, null, 8, ["label"]),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                    text: _ctx.t('wallet.swap.orders.caption'),
                    class: "col-span-12 cc-text-sz"
                }, null, 8, ["text"])
            ]),
            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", {
                class: "cc-tabs-button cc-rounded cursor-pointer p-2 capitalize",
                onClick: _cache[0] || (_cache[0] =
                    //@ts-ignore
                    (...args) => (_ctx.onRefreshOrders && _ctx.onRefreshOrders(...args)))
            }, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('common.label.refresh')), 1)
        ]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, {
            hr: "",
            class: "mb-2"
        }),
        (_ctx.isFetchingOrders)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", OpenOrdersvue_type_template_id_4ad5b3de_ts_true_hoisted_3, [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_q_spinner_dots, {
                    color: "gray",
                    size: "3em"
                })
            ]))
            : ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_OrderList, {
                key: 1,
                "open-order-list": _ctx.openOrderList
            }, null, 8, ["open-order-list"]))
    ], 64));
}

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/swap/OpenOrders.vue?vue&type=template&id=4ad5b3de&ts=true

;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/swap/OrderList.vue?vue&type=template&id=3eb8c29c&ts=true

const OrderListvue_type_template_id_3eb8c29c_ts_true_hoisted_1 = {
    key: 1,
    class: "cc-grid"
};
const OrderListvue_type_template_id_3eb8c29c_ts_true_hoisted_2 = { class: "col-span-12 flex flex-row flex-nowrap justify-between space-x-4" };
const OrderListvue_type_template_id_3eb8c29c_ts_true_hoisted_3 = { class: "flex flex-row flex-nowrap items-center" };
const OrderListvue_type_template_id_3eb8c29c_ts_true_hoisted_4 = ["src"];
const OrderListvue_type_template_id_3eb8c29c_ts_true_hoisted_5 = { class: "col-span-12 flex flex-row flex-nowrap justify-between space-x-4" };
const OrderListvue_type_template_id_3eb8c29c_ts_true_hoisted_6 = { class: "whitespace-nowrap" };
const OrderListvue_type_template_id_3eb8c29c_ts_true_hoisted_7 = { class: "col-span-12 flex flex-row flex-nowrap justify-between space-x-4" };
const OrderListvue_type_template_id_3eb8c29c_ts_true_hoisted_8 = { class: "whitespace-nowrap" };
const OrderListvue_type_template_id_3eb8c29c_ts_true_hoisted_9 = { class: "col-span-12 flex flex-row flex-nowrap justify-between space-x-4" };
const OrderListvue_type_template_id_3eb8c29c_ts_true_hoisted_10 = { class: "whitespace-nowrap" };
const OrderListvue_type_template_id_3eb8c29c_ts_true_hoisted_11 = /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("span", { class: "ml-1 mr-0.5" }, "(", -1);
const OrderListvue_type_template_id_3eb8c29c_ts_true_hoisted_12 = { class: "" };
const OrderListvue_type_template_id_3eb8c29c_ts_true_hoisted_13 = /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("span", { class: "mx-1" }, "/", -1);
const OrderListvue_type_template_id_3eb8c29c_ts_true_hoisted_14 = /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("span", { class: "ml-0.5" }, ")", -1);
const OrderListvue_type_template_id_3eb8c29c_ts_true_hoisted_15 = { class: "col-span-12 flex flex-row flex-nowrap justify-between space-x-4" };
const OrderListvue_type_template_id_3eb8c29c_ts_true_hoisted_16 = { class: "whitespace-nowrap" };
const OrderListvue_type_template_id_3eb8c29c_ts_true_hoisted_17 = { class: "w-1/2 flex flex-row flex-nowrap" };
const OrderListvue_type_template_id_3eb8c29c_ts_true_hoisted_18 = { class: "col-span-12 flex justify-end" };
const OrderListvue_type_template_id_3eb8c29c_ts_true_hoisted_19 = {
    key: 1,
    class: "col-span-12 flex justify-center"
};
const OrderListvue_type_template_id_3eb8c29c_ts_true_hoisted_20 = { class: "grow-0 shrink-0 w-full flex flex-row flex-nowrap items-start justify-between border-b cc-p" };
const OrderListvue_type_template_id_3eb8c29c_ts_true_hoisted_21 = { class: "flex flex-col cc-text-sz" };
const OrderListvue_type_template_id_3eb8c29c_ts_true_hoisted_22 = { class: "min-h-40 flex flex-col flex-nowrap space-y-2 p-4 w-full" };
function OrderListvue_type_template_id_3eb8c29c_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridTextArea = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridTextArea");
    const _component_GridTxListTokenDetails = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridTxListTokenDetails");
    const _component_FormattedAmount = (0,runtime_core_esm_bundler/* resolveComponent */.up)("FormattedAmount");
    const _component_q_spinner_dots = (0,runtime_core_esm_bundler/* resolveComponent */.up)("q-spinner-dots");
    const _component_CopyToClipboard = (0,runtime_core_esm_bundler/* resolveComponent */.up)("CopyToClipboard");
    const _component_ExplorerLink = (0,runtime_core_esm_bundler/* resolveComponent */.up)("ExplorerLink");
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    const _component_GridButtonAbort = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonAbort");
    const _component_q_pagination = (0,runtime_core_esm_bundler/* resolveComponent */.up)("q-pagination");
    const _component_GridHeadline = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridHeadline");
    const _component_SignTransaction = (0,runtime_core_esm_bundler/* resolveComponent */.up)("SignTransaction");
    const _component_Modal = (0,runtime_core_esm_bundler/* resolveComponent */.up)("Modal");
    return (_ctx.openOrderList.length === 0)
        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridTextArea, {
            key: 0,
            html: "",
            label: _ctx.t('wallet.swap.orders.empty.label'),
            text: _ctx.t('wallet.swap.orders.empty.text'),
            icon: _ctx.t('wallet.swap.orders.empty.icon'),
            class: "col-span-12",
            "text-c-s-s": "cc-text-normal text-justify",
            css: "cc-rounded cc-banner-gray"
        }, null, 8, ["label", "text", "icon"]))
        : ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", OrderListvue_type_template_id_3eb8c29c_ts_true_hoisted_1, [
            (_ctx.currentPage.length > 0)
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(true), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, { key: 0 }, (0,runtime_core_esm_bundler/* renderList */.Ko)(_ctx.currentPage, (item, index) => {
                    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", {
                        class: "col-span-12 md:col-span-6 grid grid-cols-12 cc-gap cc-area-light cc-p",
                        key: index
                    }, [
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", OrderListvue_type_template_id_3eb8c29c_ts_true_hoisted_2, [
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("span", null, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.swap.orders.label.provider')), 1),
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", OrderListvue_type_template_id_3eb8c29c_ts_true_hoisted_3, [
                                (_ctx.getProvider(item.provider).image.length > 0)
                                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("img", {
                                        key: 0,
                                        class: "w-5 h-5 mr-2",
                                        loading: "lazy",
                                        src: _ctx.getProvider(item.provider).image,
                                        alt: "provider logo"
                                    }, null, 8, OrderListvue_type_template_id_3eb8c29c_ts_true_hoisted_4))
                                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                                (0,runtime_core_esm_bundler/* createElementVNode */._)("span", null, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.getProvider(item.provider).name), 1)
                            ])
                        ]),
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", OrderListvue_type_template_id_3eb8c29c_ts_true_hoisted_5, [
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("span", OrderListvue_type_template_id_3eb8c29c_ts_true_hoisted_6, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.swap.orders.label.from')), 1),
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridTxListTokenDetails, {
                                token: _ctx.getToken(item.from.token, item.from.amount),
                                rightAlign: true
                            }, null, 8, ["token"])
                        ]),
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", OrderListvue_type_template_id_3eb8c29c_ts_true_hoisted_7, [
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("span", OrderListvue_type_template_id_3eb8c29c_ts_true_hoisted_8, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.swap.orders.label.to')), 1),
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridTxListTokenDetails, {
                                token: _ctx.getToken(item.to.token, item.to.amount),
                                rightAlign: true
                            }, null, 8, ["token"])
                        ]),
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", OrderListvue_type_template_id_3eb8c29c_ts_true_hoisted_9, [
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", null, [
                                (0,runtime_core_esm_bundler/* createElementVNode */._)("span", OrderListvue_type_template_id_3eb8c29c_ts_true_hoisted_10, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.swap.orders.label.price')), 1),
                                OrderListvue_type_template_id_3eb8c29c_ts_true_hoisted_11,
                                (0,runtime_core_esm_bundler/* createElementVNode */._)("span", OrderListvue_type_template_id_3eb8c29c_ts_true_hoisted_12, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.getSwapAssetName(item.from.token)), 1),
                                OrderListvue_type_template_id_3eb8c29c_ts_true_hoisted_13,
                                (0,runtime_core_esm_bundler/* createElementVNode */._)("span", null, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.getSwapAssetName(item.to.token)), 1),
                                OrderListvue_type_template_id_3eb8c29c_ts_true_hoisted_14
                            ]),
                            (_ctx.assetMetaMap[item.from.token])
                                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_FormattedAmount, {
                                    key: 0,
                                    hideFractionIfZero: "",
                                    "is-whole-number": "",
                                    amount: _ctx.BML.divide(_ctx.BML.divide(item.from.amount, _ctx.getDecimalNumber(_ctx.getSwapAssetDecimals(item.from.token))), _ctx.BML.divide(item.to.amount, _ctx.getDecimalNumber(_ctx.getSwapAssetDecimals(item.to.token)))),
                                    currency: _ctx.getSwapAssetName(item.from.token),
                                    decimals: _ctx.getSwapAssetDecimals(item.from.token),
                                    class: "cursor-pointer"
                                }, null, 8, ["amount", "currency", "decimals"]))
                                : ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_q_spinner_dots, {
                                    key: 1,
                                    color: "gray"
                                }))
                        ]),
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", OrderListvue_type_template_id_3eb8c29c_ts_true_hoisted_15, [
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("span", OrderListvue_type_template_id_3eb8c29c_ts_true_hoisted_16, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.swap.orders.label.transaction')), 1),
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", OrderListvue_type_template_id_3eb8c29c_ts_true_hoisted_17, [
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_CopyToClipboard, {
                                    "label-hover": _ctx.t('wallet.swap.orders.tx.hover'),
                                    "notification-text": _ctx.t('wallet.swap.orders.tx.hover'),
                                    "label-c-s-s": 'cc-addr',
                                    "copy-text": item.utxo
                                }, null, 8, ["label-hover", "notification-text", "copy-text"]),
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_ExplorerLink, {
                                    truncate: "",
                                    subject: _ctx.getUtxo(item.utxo),
                                    type: "transaction",
                                    label: item.utxo,
                                    "label-c-s-s": 'cc-addr cc-text-white ',
                                    class: (0,shared_esm_bundler/* normalizeClass */.C_)('cc-text-white ')
                                }, null, 8, ["subject", "label"])
                            ])
                        ]),
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, { hr: "" }),
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", OrderListvue_type_template_id_3eb8c29c_ts_true_hoisted_18, [
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonAbort, {
                                class: "px-2",
                                label: _ctx.t('wallet.swap.button.cancelOrder'),
                                onClick: ($event) => (_ctx.onCancelOrder(item))
                            }, null, 8, ["label", "onClick"])
                        ])
                    ]));
                }), 128))
                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
            (_ctx.showPagination)
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", OrderListvue_type_template_id_3eb8c29c_ts_true_hoisted_19, [
                    (_ctx.showPagination)
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_q_pagination, {
                            key: 0,
                            "boundary-numbers": "",
                            unelevated: "",
                            modelValue: _ctx.currentPageNo,
                            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => ((_ctx.currentPageNo) = $event)),
                            "model-value": _ctx.currentPageNo,
                            max: _ctx.maxPages,
                            "max-pages": 6,
                            color: "teal-90",
                            "text-color": "teal-90"
                        }, null, 8, ["modelValue", "model-value", "max"]))
                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                ]))
                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
            (_ctx.showSwapModal)
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_Modal, {
                    key: 2,
                    onClose: _ctx.onSwapCancel
                }, {
                    header: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", OrderListvue_type_template_id_3eb8c29c_ts_true_hoisted_20, [
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", OrderListvue_type_template_id_3eb8c29c_ts_true_hoisted_21, [
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                                    label: _ctx.t('wallet.swap.create.modal.swap.label'),
                                    "do-capitalize": false
                                }, null, 8, ["label"])
                            ])
                        ])
                    ]),
                    content: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", OrderListvue_type_template_id_3eb8c29c_ts_true_hoisted_22, [
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_SignTransaction, {
                                "cancel-emits": "",
                                onCancel: _ctx.onSwapCancel
                            }, null, 8, ["onCancel"])
                        ])
                    ]),
                    _: 1
                }, 8, ["onClose"]))
                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
        ]));
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/swap/OrderList.vue?vue&type=template&id=3eb8c29c&ts=true

// EXTERNAL MODULE: ./src/composables/ccw/useNetworkId.ts
var useNetworkId = __webpack_require__(36648);
// EXTERNAL MODULE: ./src/components/ccw/common/ExplorerLink.vue + 3 modules
var ExplorerLink = __webpack_require__(61413);
// EXTERNAL MODULE: ./src/components/ccw/common/CopyToClipboard.vue + 3 modules
var CopyToClipboard = __webpack_require__(85243);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/txlist/GridTxListTokenDetails.vue + 4 modules
var GridTxListTokenDetails = __webpack_require__(30623);
// EXTERNAL MODULE: ../ccw-lib2/core/INetwork.ts
var INetwork = __webpack_require__(34234);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/csl/CSLStringUtils.ts
var CSLStringUtils = __webpack_require__(55761);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/CSLUtils.ts
var CSLUtils = __webpack_require__(58173);
// EXTERNAL MODULE: ./src/lib/utils/AccountUTxOLists.ts
var AccountUTxOLists = __webpack_require__(97083);
// EXTERNAL MODULE: ./src/lib/CardanoSerializationLib.ts + 1 modules
var CardanoSerializationLib = __webpack_require__(50033);
// EXTERNAL MODULE: ./src/lib/utils/useLocalStorage.ts
var useLocalStorage = __webpack_require__(34787);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/swap/OrderList.vue?vue&type=script&lang=ts

;



























/* harmony default export */ const OrderListvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'OrderList',
    components: {
        GridSpace: GridSpace/* default */.Z,
        GridTextArea: GridTextArea/* default */.Z,
        GridButtonAbort: GridButtonAbort/* default */.Z,
        FormattedAmount: FormattedAmount/* default */.Z,
        ExplorerLink: ExplorerLink/* default */.Z,
        CopyToClipboard: CopyToClipboard/* default */.Z,
        Modal: Modal/* default */.Z,
        GridHeadline: GridHeadline/* default */.Z,
        SignTransaction: SignTransaction["default"],
        GridTxListTokenDetails: GridTxListTokenDetails/* default */.Z
    },
    props: {
        openOrderList: { type: Array, required: true }
    },
    setup(props) {
        const $q = (0,use_quasar/* default */.Z)();
        const { t } = (0,useTranslation/* useTranslation */.$)();
        const { networkId } = (0,useNetworkId/* useNetworkId */.h)();
        const { activeAccount } = (0,useActiveWallet/* useActiveWallet */.r)();
        const { getAssetInfo } = (0,useTokenLib_v2/* useTokenLibV2 */.P)();
        const { getProvider, getEternlFeeWitness } = (0,useSwapLib/* useSwapLib */.a)();
        const { resetBuildTx, setTxSerialized, setWitnessSet } = (0,useBuildTx_v3/* useBuildTxV3 */.b)();
        const { getDecimalNumber } = (0,useFormatter/* useFormatter */.G)();
        const showSwapModal = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const assetMetaMap = (0,reactivity_esm_bundler/* ref */.iH)({});
        let assetMetaRunning = false;
        const itemsOnPage = 10;
        const currentPageNo = (0,reactivity_esm_bundler/* ref */.iH)(1);
        const maxPages = (0,runtime_core_esm_bundler/* computed */.Fl)(() => Math.ceil(props.openOrderList.length / itemsOnPage));
        const showPagination = (0,runtime_core_esm_bundler/* computed */.Fl)(() => props.openOrderList.length > itemsOnPage);
        const currentPageStart = (0,runtime_core_esm_bundler/* computed */.Fl)(() => (currentPageNo.value - 1) * itemsOnPage);
        const currentPage = (0,runtime_core_esm_bundler/* computed */.Fl)(() => props.openOrderList.slice(currentPageStart.value, currentPageStart.value + itemsOnPage));
        async function getCancelTxCBOR(order) {
            let error = '';
            if (activeAccount.value) {
                let url = NetworkEndpoint/* endPoints */.zH[activeAccount.value.network]?.swap?.ms?.cancel;
                if (url && url.length > 0) {
                    const collateralList = (0,CSLStringUtils/* getUtxoCborList */.mQ)(await (0,AccountUTxOLists/* getAccountFilteredCollateralUtxoList */.dw)(activeAccount.value, false));
                    if (collateralList.length === 0) {
                        error = t('wallet.swap.error.collateral');
                    }
                    else {
                        // header + network tag according to CIP-19 (https://cips.cardano.org/cips/cip19)
                        const addrPrefix = '0' + (0,INetwork/* getNetwork */.Hy)(activeAccount.value.network).networkId.toString(16);
                        const urlParams = new URLSearchParams({
                            wallet: addrPrefix + order.ownerPubKeyHash + order.ownerStakeKeyHash,
                            utxo: order.utxo,
                            collateralUtxo: collateralList[0],
                            message: "Cancel Swap Request by Eternl"
                        });
                        const res = await worker_api/* api.get */.h.get(url + '/?' + urlParams.toString()).catch((err) => {
                            error = err?.message ?? err;
                            console.error('getCancelTxCBOR:', activeAccount.value.network, err?.message ?? err);
                        });
                        if (res && res.status === 'success') {
                            return res.cbor;
                        }
                        else if (res && res.reason) {
                            error = res.reason ?? '';
                        }
                    }
                }
                else {
                    error = t('wallet.swap.error.network');
                    console.error('getCancelTxCBOR:', error);
                }
            }
            $q.notify({
                type: 'negative',
                message: t('wallet.swap.error.cancelSwapTransaction') + (error.length > 0 ? `<br>Error: ${error}` : ''),
                position: 'top-left',
                timeout: 5000,
                html: true
            });
            return null;
        }
        async function onCancelOrder(order) {
            const cancelCBOR = await getCancelTxCBOR(order);
            if (activeAccount.value && cancelCBOR) {
                try {
                    const tx = (0,CSLUtils/* getTransaction */.fo)(cancelCBOR);
                    const witnessSet = tx.witness_set();
                    const hasEternlFee = tx.body().inputs().len() === 2 && (!tx.witness_set().vkeys() || tx.witness_set().vkeys()?.len() === 0);
                    if (hasEternlFee) {
                        const eternlFeeWitness = await getEternlFeeWitness(activeAccount.value.network, cancelCBOR);
                        if (!eternlFeeWitness) {
                            $q.notify({
                                type: 'negative',
                                message: t('wallet.swap.error.cancelEternlWitness'),
                                position: 'top-left',
                                timeout: 5000
                            });
                            return;
                        }
                        const vkeyWitnesses = witnessSet.vkeys() ?? CardanoSerializationLib/* Vkeywitnesses.new */.VLl["new"]();
                        vkeyWitnesses.add(CardanoSerializationLib/* Vkeywitness.from_hex */.AF1.from_hex(eternlFeeWitness));
                        witnessSet.set_vkeys(vkeyWitnesses);
                    }
                    resetBuildTx(activeAccount.value.pub);
                    setWitnessSet(activeAccount.value.pub, witnessSet);
                    setTxSerialized(activeAccount.value.pub, cancelCBOR);
                    (0,useLocalStorage/* setCachedPrevPage */.v1)({ page: 'Swap', tabId: 'orders' });
                    showSwapModal.value = true;
                    //gotoWalletPage('SignTransaction')
                }
                catch (err) {
                    console.error('Error: onCancelOrder: tx invalid:', cancelCBOR);
                }
            }
        }
        function onSwapCancel() {
            if (activeAccount.value) {
                resetBuildTx(activeAccount.value.pub);
            }
            showSwapModal.value = false;
        }
        function getToken(token, amount) {
            if (token === '.') { // ADA
                return {
                    policy: '',
                    name: '',
                    quantity: amount
                };
            }
            else {
                const tokenArr = token.split('.');
                return {
                    policy: tokenArr[0],
                    name: tokenArr.length === 2 ? tokenArr[1] : '',
                    quantity: amount
                };
            }
        }
        function getSwapAssetDecimals(token) {
            return assetMetaMap.value[token]?.tokenRegistryMetadata?.decimals ?? 0;
        }
        function getSwapAssetName(token) {
            return (0,AccountTokensLib_v2/* getAssetName */.HW)(getToken(token, ''), assetMetaMap.value[token] ?? null, true);
        }
        function getUtxo(utxo) {
            const _utxo = utxo.split('#');
            return {
                txHash: _utxo[0],
                txIndex: _utxo.length === 2 ? _utxo[1] : ''
            };
        }
        async function getSwapAssetMetadata() {
            if (!networkId.value) {
                return;
            }
            assetMetaRunning = true;
            for (const asset of props.openOrderList) {
                if (!assetMetaMap.value[asset.from.token]) {
                    const assetInfo = await getAssetInfo(networkId.value, getToken(asset.from.token, asset.from.amount));
                    if (assetInfo) {
                        assetMetaMap.value[asset.from.token] = assetInfo;
                    }
                }
                if (!assetMetaMap.value[asset.to.token]) {
                    const assetInfo = await getAssetInfo(networkId.value, getToken(asset.to.token, asset.to.amount));
                    if (assetInfo) {
                        assetMetaMap.value[asset.to.token] = assetInfo;
                    }
                }
            }
            assetMetaRunning = false;
        }
        (0,runtime_core_esm_bundler/* watchEffect */.m0)(async () => {
            if (props.openOrderList && !assetMetaRunning) {
                getSwapAssetMetadata();
            }
        });
        (0,runtime_core_esm_bundler/* onMounted */.bv)(async () => getSwapAssetMetadata());
        return {
            t,
            networkId,
            BML: BigMathLib,
            currentPageNo,
            showPagination,
            maxPages,
            currentPage,
            assetMetaMap,
            getProvider,
            getUtxo,
            getToken,
            getDecimalNumber,
            getSwapAssetDecimals,
            getSwapAssetName,
            onCancelOrder,
            showSwapModal,
            onSwapCancel,
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/swap/OrderList.vue?vue&type=script&lang=ts
 
// EXTERNAL MODULE: ./node_modules/quasar/src/components/pagination/QPagination.js
var QPagination = __webpack_require__(87300);
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/swap/OrderList.vue




;
const OrderList_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(OrderListvue_type_script_lang_ts, [['render',OrderListvue_type_template_id_3eb8c29c_ts_true_render]])

/* harmony default export */ const OrderList = (OrderList_exports_);
;


runtime_auto_import_default()(OrderListvue_type_script_lang_ts, 'components', {QSpinnerDots: QSpinnerDots/* default */.Z,QPagination: QPagination/* default */.Z});

;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/swap/OpenOrders.vue?vue&type=script&lang=ts

;








/* harmony default export */ const OpenOrdersvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'OpenOrders',
    components: {
        GridHeadline: GridHeadline/* default */.Z,
        GridText: GridText/* default */.Z,
        GridSpace: GridSpace/* default */.Z,
        OrderList: OrderList
    },
    setup() {
        const $q = (0,use_quasar/* default */.Z)();
        const { t } = (0,useTranslation/* useTranslation */.$)();
        const { activeAccount } = (0,useActiveWallet/* useActiveWallet */.r)();
        const lastFetch = (0,reactivity_esm_bundler/* ref */.iH)(Date.now());
        const fetchDelay = 5000;
        const isFetchingOrders = (0,reactivity_esm_bundler/* ref */.iH)(true);
        const openOrderList = (0,reactivity_esm_bundler/* ref */.iH)([]);
        async function checkOpenOrders() {
            let error = '';
            if (activeAccount.value) {
                const url = NetworkEndpoint/* endPoints */.zH[activeAccount.value.network]?.swap?.ms?.orders + '/?wallet=' + activeAccount.value.base.payment[0][0].bech32;
                if (url && url.length > 0) {
                    const res = await worker_api/* api.get */.h.get(url).catch((err) => {
                        error = err?.message ?? err;
                        console.error('checkOpenOrders:', activeAccount.value.network, err?.message ?? err);
                    });
                    if (res) {
                        return res;
                    }
                }
                else {
                    error = t('wallet.swap.error.network');
                    console.error('checkOpenOrders:', error);
                }
            }
            $q.notify({
                type: 'negative',
                message: t('wallet.swap.error.checkOpenOrders') + (error.length > 0 ? `<br>Error: ${error}` : ''),
                position: 'top-left',
                timeout: 5000
            });
            return null;
        }
        async function onRefreshOrders() {
            const timeDiff = (lastFetch.value + fetchDelay) - Date.now();
            if (timeDiff > 0) {
                $q.notify({
                    type: 'warning',
                    message: t('wallet.swap.error.fetchDelay').replace('###time###', Math.floor(timeDiff / 1000).toString()),
                    position: 'top-left',
                    timeout: 3000
                });
                return;
            }
            isFetchingOrders.value = true;
            lastFetch.value = Date.now();
            openOrderList.value = await checkOpenOrders() ?? [];
            $q.notify({
                type: 'positive',
                message: t('wallet.swap.orders.refresh'),
                position: 'top-left',
                timeout: 3000
            });
            isFetchingOrders.value = false;
        }
        (0,runtime_core_esm_bundler/* onMounted */.bv)(async () => {
            openOrderList.value = await checkOpenOrders() ?? [];
            isFetchingOrders.value = false;
        });
        return {
            t,
            isFetchingOrders,
            openOrderList,
            onRefreshOrders
        };
    }
}));

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/swap/OpenOrders.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/swap/OpenOrders.vue




;
const OpenOrders_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(OpenOrdersvue_type_script_lang_ts, [['render',OpenOrdersvue_type_template_id_4ad5b3de_ts_true_render]])

/* harmony default export */ const OpenOrders = (OpenOrders_exports_);
;

runtime_auto_import_default()(OpenOrdersvue_type_script_lang_ts, 'components', {QSpinnerDots: QSpinnerDots/* default */.Z});

;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/Swap.vue?vue&type=script&setup=true&lang=ts


const Swapvue_type_script_setup_true_lang_ts_hoisted_1 = { class: "cc-page-wallet cc-text-sz dark:text-cc-gray" };
const Swapvue_type_script_setup_true_lang_ts_hoisted_2 = { class: "col-span-12 flex flex-col xl:flex-row gap-4 items-start flex-nowrap" };
const Swapvue_type_script_setup_true_lang_ts_hoisted_3 = { class: "w-full grid grid-cols-12 cc-gap" };
const Swapvue_type_script_setup_true_lang_ts_hoisted_4 = { class: "w-full grid grid-cols-12 cc-gap" };



/* harmony default export */ const Swapvue_type_script_setup_true_lang_ts = (/*#__PURE__*/(0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    __name: 'Swap',
    setup(__props) {
        const { t } = (0,useTranslation/* useTranslation */.$)();
        return (_ctx, _cache) => {
            return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", Swapvue_type_script_setup_true_lang_ts_hoisted_1, [
                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", Swapvue_type_script_setup_true_lang_ts_hoisted_2, [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", Swapvue_type_script_setup_true_lang_ts_hoisted_3, [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(CreateSwap)
                    ]),
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", Swapvue_type_script_setup_true_lang_ts_hoisted_4, [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(OpenOrders)
                    ])
                ])
            ]));
        };
    }
}));

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/Swap.vue?vue&type=script&setup=true&lang=ts
 
;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/Swap.vue



const Swap_exports_ = Swapvue_type_script_setup_true_lang_ts;

/* harmony default export */ const Swap = (Swap_exports_);

/***/ })

}]);
//# sourceMappingURL=4888.js.map