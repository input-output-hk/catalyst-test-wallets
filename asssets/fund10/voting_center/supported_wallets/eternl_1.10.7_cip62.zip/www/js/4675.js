"use strict";
(this["webpackChunkccw_frontend"] = this["webpackChunkccw_frontend"] || []).push([[4675],{

/***/ 74675:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ WalletRouterViewProxy)
});

// EXTERNAL MODULE: ./node_modules/@vue/runtime-core/dist/runtime-core.esm-bundler.js
var runtime_core_esm_bundler = __webpack_require__(83673);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/layouts/ccw/WalletRouterViewProxy.vue?vue&type=template&id=6608cfaf&ts=true

function render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_router_view = (0,runtime_core_esm_bundler/* resolveComponent */.up)("router-view");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_router_view));
}

;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/layouts/ccw/WalletRouterViewProxy.vue?vue&type=script&lang=ts

/* harmony default export */ const WalletRouterViewProxyvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'WalletRouterViewProxy'
}));

;// CONCATENATED MODULE: ./src/layouts/ccw/WalletRouterViewProxy.vue?vue&type=script&lang=ts
 
// EXTERNAL MODULE: ./node_modules/vue-loader/dist/exportHelper.js
var exportHelper = __webpack_require__(74260);
;// CONCATENATED MODULE: ./src/layouts/ccw/WalletRouterViewProxy.vue




;
const __exports__ = /*#__PURE__*/(0,exportHelper/* default */.Z)(WalletRouterViewProxyvue_type_script_lang_ts, [['render',render]])

/* harmony default export */ const WalletRouterViewProxy = (__exports__);

/***/ })

}]);
//# sourceMappingURL=4675.js.map