"use strict";
(this["webpackChunkccw_frontend"] = this["webpackChunkccw_frontend"] || []).push([[3939],{

/***/ 57481:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Add)
});

// EXTERNAL MODULE: ./node_modules/@vue/runtime-core/dist/runtime-core.esm-bundler.js
var runtime_core_esm_bundler = __webpack_require__(83673);
// EXTERNAL MODULE: ./node_modules/@vue/shared/dist/shared.esm-bundler.js
var shared_esm_bundler = __webpack_require__(62323);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/Add.vue?vue&type=template&id=6bfcde5b&ts=true

const _hoisted_1 = { class: "min-h-16 sm:min-h-20 w-full max-w-full p-3 text-center flex flex-col flex-nowrap justify-center items-center border-t border-b mb-px cc-text-sz cc-bg-white-0" };
const _hoisted_2 = { class: "cc-text-semi-bold" };
const _hoisted_3 = { class: "" };
const _hoisted_4 = { class: "col-span-12 grid grid-cols-12 gap-2 lg:px-16 xl:px-24" };
function render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridButtonLarge = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonLarge");
    const _component_Page = (0,runtime_core_esm_bundler/* resolveComponent */.up)("Page");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_Page, null, {
        header: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_1, [
                (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_2, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('wallet.add.headline')), 1),
                (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_3, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('wallet.add.caption')), 1)
            ])
        ]),
        content: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_4, [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonLarge, {
                    label: _ctx.it('wallet.add.button.create.label'),
                    caption: _ctx.it('wallet.add.button.create.caption'),
                    icon: _ctx.it('wallet.add.button.create.icon'),
                    link: () => { _ctx.gotoPage('WalletCreate'); }
                }, null, 8, ["label", "caption", "icon", "link"]),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonLarge, {
                    label: _ctx.it('wallet.add.button.restore.label'),
                    caption: _ctx.it('wallet.add.button.restore.caption'),
                    icon: _ctx.it('wallet.add.button.restore.icon'),
                    link: () => { _ctx.gotoPage('WalletRestore'); }
                }, null, 8, ["label", "caption", "icon", "link"]),
                (!_ctx.isCapacitorApp && _ctx.hasWebUSB)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridButtonLarge, {
                        key: 0,
                        label: _ctx.it('wallet.add.button.pair.label'),
                        caption: _ctx.it('wallet.add.button.pair.caption'),
                        icon: _ctx.it('wallet.add.button.pair.icon'),
                        link: () => { _ctx.gotoPage('WalletPair'); }
                    }, null, 8, ["label", "caption", "icon", "link"]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonLarge, {
                    label: _ctx.it('wallet.add.button.import.label'),
                    caption: _ctx.it('wallet.add.button.import.caption'),
                    icon: _ctx.it('wallet.add.button.import.icon'),
                    link: () => { _ctx.gotoPage('WalletImport'); }
                }, null, 8, ["label", "caption", "icon", "link"])
            ])
        ]),
        _: 1
    }));
}

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/Add.vue?vue&type=template&id=6bfcde5b&ts=true

// EXTERNAL MODULE: ./node_modules/@vue/reactivity/dist/reactivity.esm-bundler.js
var reactivity_esm_bundler = __webpack_require__(61959);
// EXTERNAL MODULE: ./src/composables/ccw/useTranslation.ts
var useTranslation = __webpack_require__(19376);
// EXTERNAL MODULE: ./src/composables/ccw/useNavigation.ts
var useNavigation = __webpack_require__(52439);
// EXTERNAL MODULE: ./src/components/ccw/Page.vue + 21 modules
var Page = __webpack_require__(53707);
// EXTERNAL MODULE: ./node_modules/@vue/runtime-dom/dist/runtime-dom.esm-bundler.js
var runtime_dom_esm_bundler = __webpack_require__(98880);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/common/GridButtonLarge.vue?vue&type=template&id=14cbb089&ts=true

const GridButtonLargevue_type_template_id_14cbb089_ts_true_hoisted_1 = ["type", "form", "disabled"];
const GridButtonLargevue_type_template_id_14cbb089_ts_true_hoisted_2 = {
    key: 1,
    class: "flex-1 flex flex-col flex-nowrap",
    style: { "text-align": "inherit" }
};
const GridButtonLargevue_type_template_id_14cbb089_ts_true_hoisted_3 = {
    key: 0,
    class: "cc-text-sm cc-text-normal mt-0.5 sm:mt-1"
};
function GridButtonLargevue_type_template_id_14cbb089_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", {
        class: (0,shared_esm_bundler/* normalizeClass */.C_)(["relative group col-span-12 min-h-20 lg:min-h-32 lg:col-span-6 cc-rounded cc-shadow cc-text-semi-bold cc-text-semi-bold flex w-full h-full cc-text-sz border-l-4 border-t border-b cc-bg-white-0", _ctx.c('hover-large') + ' ' + (_ctx.disabled ? 'cc-btn-disabled' : 'cursor-pointer')])
    }, [
        (0,runtime_core_esm_bundler/* createElementVNode */._)("button", {
            onClick: _cache[0] || (_cache[0] = (0,runtime_dom_esm_bundler/* withModifiers */.iM)(($event) => (_ctx.link?.()), ["stop"])),
            class: "focus:outline-none flex-1 flex flex-row flex-nowrap items-center space-x-2 cc-p",
            type: _ctx.type,
            form: _ctx.form,
            disabled: _ctx.disabled,
            style: { "text-align": "inherit" }
        }, [
            (_ctx.icon)
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("i", {
                    key: 0,
                    class: (0,shared_esm_bundler/* normalizeClass */.C_)(["text-3xl w-12 sm:w-16 text-center", _ctx.icon])
                }, null, 2))
                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
            (_ctx.label)
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("span", GridButtonLargevue_type_template_id_14cbb089_ts_true_hoisted_2, [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("span", null, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.label), 1),
                    (_ctx.caption)
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("span", GridButtonLargevue_type_template_id_14cbb089_ts_true_hoisted_3, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.caption), 1))
                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                ]))
                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
        ], 8, GridButtonLargevue_type_template_id_14cbb089_ts_true_hoisted_1)
    ], 2));
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/common/GridButtonLarge.vue?vue&type=template&id=14cbb089&ts=true

// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridButton.vue + 4 modules
var GridButton = __webpack_require__(33808);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/common/GridButtonLarge.vue?vue&type=script&lang=ts



/* harmony default export */ const GridButtonLargevue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'GridButtonLarge',
    components: { GridButton: GridButton/* default */.Z },
    props: {
        label: { type: String },
        caption: { type: String },
        icon: { type: String },
        type: { type: String, required: false, default: 'button' },
        form: { type: String, required: false, default: '' },
        link: { type: Function, default: null },
        disabled: { type: Boolean, default: false }
    },
    setup() {
        const { c } = (0,useTranslation/* useTranslation */.$)();
        return {
            c
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/common/GridButtonLarge.vue?vue&type=script&lang=ts
 
// EXTERNAL MODULE: ./node_modules/vue-loader/dist/exportHelper.js
var exportHelper = __webpack_require__(74260);
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/common/GridButtonLarge.vue




;
const __exports__ = /*#__PURE__*/(0,exportHelper/* default */.Z)(GridButtonLargevue_type_script_lang_ts, [['render',GridButtonLargevue_type_template_id_14cbb089_ts_true_render]])

/* harmony default export */ const GridButtonLarge = (__exports__);
// EXTERNAL MODULE: ./src/lib/utils/useAppMode.ts
var useAppMode = __webpack_require__(4254);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/Add.vue?vue&type=script&lang=ts






/* harmony default export */ const Addvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'Add',
    components: {
        Page: Page/* default */.Z,
        GridButtonLarge: GridButtonLarge
    },
    setup() {
        const { it } = (0,useTranslation/* useTranslation */.$)();
        const { gotoPage } = (0,useNavigation/* useNavigation */.HJ)();
        //@ts-ignore
        const isCapacitorApp = (0,reactivity_esm_bundler/* ref */.iH)({"HOST_API_STAGING":"https://api.staging.eternl.io","HOST_API":"https://api.eternl.io","ENVIRONMENT":"production","TOKEN":"#!l4n56cGPHoHM3Z@xiT&CV8","PEN":"k%%2Gb6^!m8iMIvwlnS2xpWC","MODE":"bex","IS_STAGING":"no"}.MODE === 'capacitor');
        return {
            it,
            gotoPage,
            isCapacitorApp,
            hasWebUSB: useAppMode/* hasWebUSB */.d$
        };
    }
}));

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/Add.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/pages/ccw/wallet/Add.vue




;
const Add_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(Addvue_type_script_lang_ts, [['render',render]])

/* harmony default export */ const Add = (Add_exports_);

/***/ })

}]);
//# sourceMappingURL=3939.js.map