"use strict";
(this["webpackChunkccw_frontend"] = this["webpackChunkccw_frontend"] || []).push([[3855],{

/***/ 54445:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Announcements)
});

// EXTERNAL MODULE: ./node_modules/@vue/runtime-core/dist/runtime-core.esm-bundler.js
var runtime_core_esm_bundler = __webpack_require__(83673);
// EXTERNAL MODULE: ./node_modules/@vue/shared/dist/shared.esm-bundler.js
var shared_esm_bundler = __webpack_require__(62323);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/Announcements.vue?vue&type=template&id=c479460a&scoped=true&ts=true

const _withScopeId = n => ((0,runtime_core_esm_bundler/* pushScopeId */.dD)("data-v-c479460a"), n = n(), (0,runtime_core_esm_bundler/* popScopeId */.Cn)(), n);
const _hoisted_1 = { class: "relative w-full h-full cc-rounded flex flex-row-reverse flex-nowrap" };
const _hoisted_2 = { class: "relative h-full flex-1 overflow-hidden focus:outline-none flex flex-col flex-nowrap" };
const _hoisted_3 = { class: "cc-page-wallet cc-text-sz pt-4 sm:pt-6 md:pt-14 px-4 sm:px-8" };
const _hoisted_4 = {
    key: 0,
    class: "col-span-12 mt-2 pt-4 flex justify-center items-center"
};
const _hoisted_5 = {
    key: 1,
    class: "col-span-12 mt-2 pt-4 grid gap-6 lg:grid-cols-1 lg:gap-x-5 lg:gap-y-4"
};
const _hoisted_6 = { class: "text-sm" };
const _hoisted_7 = ["datetime"];
const _hoisted_8 = ["href"];
const _hoisted_9 = /*#__PURE__*/ _withScopeId(() => /*#__PURE__*/ (0,runtime_core_esm_bundler/* createElementVNode */._)("i", { class: "mdi mdi-open-in-new mx-1" }, null, -1));
const _hoisted_10 = ["innerHTML"];
const _hoisted_11 = ["innerHTML"];
function render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridHeadline = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridHeadline");
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    const _component_q_spinner_dots = (0,runtime_core_esm_bundler/* resolveComponent */.up)("q-spinner-dots");
    const _component_Tooltip = (0,runtime_core_esm_bundler/* resolveComponent */.up)("Tooltip");
    const _component_Page = (0,runtime_core_esm_bundler/* resolveComponent */.up)("Page");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_1, [
        (0,runtime_core_esm_bundler/* createElementVNode */._)("main", _hoisted_2, [
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_Page, {
                containerCSS: '',
                "align-top": ""
            }, {
                content: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_3, [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                            label: _ctx.it('announcements.headline'),
                            class: "cc-text-2xl sm:mt-4"
                        }, null, 8, ["label"]),
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, { hr: "" }),
                        (_ctx.showSpinner)
                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_4, [
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_q_spinner_dots, {
                                    color: "grey",
                                    size: "3em"
                                })
                            ]))
                            : ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_5, [
                                ((0,runtime_core_esm_bundler/* openBlock */.wg)(true), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, (0,runtime_core_esm_bundler/* renderList */.Ko)(_ctx.announcements, (post, index) => {
                                    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", {
                                        key: post.datetime + '.' + index
                                    }, [
                                        (0,runtime_core_esm_bundler/* createElementVNode */._)("p", _hoisted_6, [
                                            (0,runtime_core_esm_bundler/* createElementVNode */._)("time", {
                                                datetime: post.datetime
                                            }, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.formatDatetime(post.datetime, true, false)), 9, _hoisted_7),
                                            (0,runtime_core_esm_bundler/* createElementVNode */._)("a", {
                                                href: post.targetUrl,
                                                target: "_blank"
                                            }, [
                                                _hoisted_9,
                                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_Tooltip, {
                                                    anchor: "top middle",
                                                    "transition-show": "scale",
                                                    "transition-hide": "scale"
                                                }, {
                                                    default: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                                                        (0,runtime_core_esm_bundler/* createTextVNode */.Uk)((0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('announcements.openWiki')), 1)
                                                    ]),
                                                    _: 1
                                                })
                                            ], 8, _hoisted_8)
                                        ]),
                                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", null, [
                                            (0,runtime_core_esm_bundler/* createElementVNode */._)("h1", {
                                                class: "cc-text-md font-semibold",
                                                innerHTML: post.headline
                                            }, null, 8, _hoisted_10),
                                            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", {
                                                innerHTML: post.summary
                                            }, null, 8, _hoisted_11)
                                        ]),
                                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, {
                                            class: "pt-4",
                                            hr: ""
                                        })
                                    ]));
                                }), 128))
                            ]))
                    ])
                ]),
                _: 1
            })
        ])
    ]));
}

;// CONCATENATED MODULE: ./src/pages/ccw/Announcements.vue?vue&type=template&id=c479460a&scoped=true&ts=true

// EXTERNAL MODULE: ./node_modules/@vue/reactivity/dist/reactivity.esm-bundler.js
var reactivity_esm_bundler = __webpack_require__(61959);
// EXTERNAL MODULE: ./src/composables/ccw/useTranslation.ts
var useTranslation = __webpack_require__(19376);
// EXTERNAL MODULE: ./src/composables/ccw/store/useFormatter.ts
var useFormatter = __webpack_require__(16938);
// EXTERNAL MODULE: ./src/components/ccw/Page.vue + 21 modules
var Page = __webpack_require__(53707);
// EXTERNAL MODULE: ./src/components/ccw/common/Tooltip.vue + 3 modules
var Tooltip = __webpack_require__(30105);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridHeadline.vue + 3 modules
var GridHeadline = __webpack_require__(63593);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridSpace.vue + 4 modules
var GridSpace = __webpack_require__(14740);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridText.vue + 4 modules
var GridText = __webpack_require__(96834);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridButtonPrimary.vue + 3 modules
var GridButtonPrimary = __webpack_require__(12559);
// EXTERNAL MODULE: ./src/lib/utils/useAppMode.ts
var useAppMode = __webpack_require__(4254);
// EXTERNAL MODULE: ./src/lib/utils/useLocalStorage.ts
var useLocalStorage = __webpack_require__(34787);
// EXTERNAL MODULE: ./src/ext/worker.api.ts
var worker_api = __webpack_require__(45855);
// EXTERNAL MODULE: ./node_modules/dexie/dist/modern/dexie.min.mjs
var dexie_min = __webpack_require__(39387);
;// CONCATENATED MODULE: ./src/db/AnnouncementDB.ts

class AnnouncementsDB extends dexie_min/* default */.ZP {
    list;
    constructor() {
        super('eternl-announcements');
        this.version(2).stores({
            list: 'headline'
        });
    }
}
const dbMap = {};
const getDB = async (id = 'announcements') => {
    let db = dbMap[id];
    if (!db) {
        db = new AnnouncementsDB();
        dbMap[id] = db;
    }
    if (!db.isOpen()) {
        await db.open();
    }
    return db;
};
const getAll = () => getDB().then(db => db.list.toArray());
const put = (item) => getDB().then(db => db.list.put(item));
const bulkPut = (list) => getDB().then(db => db.list.bulkPut(list));
const clear = () => getDB().then(db => db.list.clear());
const remove = () => dexie_min/* default.delete */.ZP["delete"]('eternl-announcements');
/* harmony default export */ const AnnouncementDB = ({
    getAll,
    put,
    bulkPut,
    clear,
    remove
});

;// CONCATENATED MODULE: ./src/lib/ExtAnnouncements.ts



const getAnnouncements = async (networkId, language = 'en') => {
    const announcementsDb = await loadAnnouncements(networkId, language);
    if (announcementsDb.length === 0 || (0,useLocalStorage/* getLastAnnouncementCheck */.c_)() + 60 * 60 * 1000 < Date.now()) {
        const announcements = await fetchAnnouncements(networkId, language);
        await AnnouncementDB.clear();
        await AnnouncementDB.bulkPut(announcements);
        (0,useLocalStorage/* setLastAnnouncementCheck */.R1)(Date.now());
        return announcements;
    }
    else {
        return announcementsDb;
    }
};
const loadAnnouncements = async (networkId, language = 'en') => {
    return (await AnnouncementDB.getAll())
        .filter((ann) => ann.language === language)
        .sort((a, b) => b.datetime - a.datetime);
};
const fetchAnnouncements = async (networkId, language = 'en') => {
    const url = '/' + networkId + '/v1/misc/announcements';
    const res = await worker_api/* api.post */.h.post(url, {
        lang: language
    }).catch((err) => {
        throw new Error('Announcements can not be fetched.');
    });
    if (res) {
        return res.data;
    }
    return [];
};

;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/Announcements.vue?vue&type=script&lang=ts












/* harmony default export */ const Announcementsvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'Announcements',
    components: {
        GridButtonPrimary: GridButtonPrimary/* default */.Z,
        GridText: GridText/* default */.Z,
        GridSpace: GridSpace/* default */.Z,
        GridHeadline: GridHeadline/* default */.Z,
        Page: Page/* default */.Z,
        Tooltip: Tooltip/* default */.Z
    },
    setup() {
        const { it } = (0,useTranslation/* useTranslation */.$)();
        const { formatDatetime } = (0,useFormatter/* useFormatter */.G)();
        const announcements = (0,reactivity_esm_bundler/* ref */.iH)([]);
        const showSpinner = (0,reactivity_esm_bundler/* ref */.iH)(true);
        const isBexApp = (0,reactivity_esm_bundler/* ref */.iH)("bex" === 'bex');
        (0,runtime_core_esm_bundler/* onBeforeMount */.wF)(async () => {
            announcements.value = (await getAnnouncements('mainnet', ((0,useLocalStorage/* getAppLanguage */.s)() ?? 'en').split('-')[0]))
                .filter((entry) => {
                if (useAppMode/* isIosApp */.jv) {
                    return entry.ios;
                }
                else if (useAppMode/* isAndroidApp */.S_) {
                    return entry.android;
                }
                else if (isBexApp.value) {
                    return entry.bex;
                }
                else {
                    return entry.web;
                }
            }).sort((a, b) => a.datetime < b.datetime ? 1 : -1);
            showSpinner.value = false;
        });
        return {
            it,
            announcements,
            formatDatetime,
            showSpinner
        };
    }
}));

;// CONCATENATED MODULE: ./src/pages/ccw/Announcements.vue?vue&type=script&lang=ts
 
// EXTERNAL MODULE: ./node_modules/vue-loader/dist/exportHelper.js
var exportHelper = __webpack_require__(74260);
// EXTERNAL MODULE: ./node_modules/quasar/src/components/spinner/QSpinnerDots.js
var QSpinnerDots = __webpack_require__(34765);
// EXTERNAL MODULE: ./node_modules/@quasar/app/lib/webpack/runtime.auto-import.js
var runtime_auto_import = __webpack_require__(7518);
var runtime_auto_import_default = /*#__PURE__*/__webpack_require__.n(runtime_auto_import);
;// CONCATENATED MODULE: ./src/pages/ccw/Announcements.vue




;


const __exports__ = /*#__PURE__*/(0,exportHelper/* default */.Z)(Announcementsvue_type_script_lang_ts, [['render',render],['__scopeId',"data-v-c479460a"]])

/* harmony default export */ const Announcements = (__exports__);
;

runtime_auto_import_default()(Announcementsvue_type_script_lang_ts, 'components', {QSpinnerDots: QSpinnerDots/* default */.Z});


/***/ })

}]);
//# sourceMappingURL=3855.js.map