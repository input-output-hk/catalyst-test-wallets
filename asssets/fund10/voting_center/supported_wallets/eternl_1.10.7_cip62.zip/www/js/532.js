"use strict";
(this["webpackChunkccw_frontend"] = this["webpackChunkccw_frontend"] || []).push([[532],{

/***/ 40532:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "_downloadJSON": () => (/* binding */ _downloadJSON),
/* harmony export */   "_downloadText": () => (/* binding */ _downloadText),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const _downloadJSON = async (dbEntry) => {
    if (!dbEntry) {
        return false;
    }
    const blob = new Blob([JSON.stringify(dbEntry)], { type: "text/json" });
    const link = document.createElement("a");
    link.download = 'eternl-' + dbEntry.name.toLowerCase().replace(/\s/g, '-') + '-' + dbEntry.id.toLowerCase().replace(/\s/g, '-') + '.json';
    link.href = window.URL.createObjectURL(blob);
    link.target = '_system';
    link.dataset.downloadurl = ["text/json", link.download, link.href].join(":");
    const evt = new MouseEvent("click", {
        view: window,
        bubbles: true,
        cancelable: true,
    });
    link.dispatchEvent(evt);
    link.remove();
    return true;
};
const _downloadText = async (text, fileName) => {
    if (!text) {
        return false;
    }
    const blob = new Blob([text], { type: "plain/text" });
    const link = document.createElement("a");
    link.download = fileName;
    link.href = window.URL.createObjectURL(blob);
    link.target = '_system';
    link.dataset.downloadurl = ["plain/text", link.download, link.href].join(":");
    const evt = new MouseEvent("click", {
        view: window,
        bubbles: true,
        cancelable: true,
    });
    link.dispatchEvent(evt);
    link.remove();
    return true;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_downloadJSON);


/***/ })

}]);
//# sourceMappingURL=532.js.map