"use strict";
(this["webpackChunkccw_frontend"] = this["webpackChunkccw_frontend"] || []).push([[5390,5134],{

/***/ 37205:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Collateral)
});

// EXTERNAL MODULE: ./node_modules/@vue/runtime-core/dist/runtime-core.esm-bundler.js
var runtime_core_esm_bundler = __webpack_require__(83673);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/Collateral.vue?vue&type=template&id=7c0fe261&ts=true

const _hoisted_1 = { class: "cc-page-wallet cc-text-sz" };
function render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridTextArea = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridTextArea");
    const _component_GridButtonSecondary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonSecondary");
    const _component_SendConfirm = (0,runtime_core_esm_bundler/* resolveComponent */.up)("SendConfirm");
    const _component_SendSubmit = (0,runtime_core_esm_bundler/* resolveComponent */.up)("SendSubmit");
    const _component_GridSteps = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSteps");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_1, [
        (_ctx.showLowFundsWarning)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridTextArea, {
                key: 0,
                label: _ctx.t('wallet.settings.collateral.warning.fundslow.label'),
                text: _ctx.t('wallet.settings.collateral.warning.fundslow.text'),
                icon: _ctx.t('wallet.settings.collateral.warning.fundslow.icon'),
                class: "col-span-12 mt-2 sm:mt-4",
                "text-c-s-s": "cc-text-normal text-justify flex justify-start items-center",
                css: "cc-rounded cc-banner-warning"
            }, null, 8, ["label", "text", "icon"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSteps, {
            onBack: _ctx.goBack,
            steps: _ctx.optionsSteps,
            currentStep: _ctx.currentStep,
            "small-c-s-s": "pr-20 xs:pr-20 lg:pr-24"
        }, {
            step0: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_SendConfirm, {
                    onSubmit: _ctx.gotoNext,
                    account: _ctx.activeAccount,
                    wallet: _ctx.activeWalletData,
                    "unsigned-tx": _ctx.tx,
                    "text-id": "wallet.send.step.confirm"
                }, {
                    btnBack: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonSecondary, {
                            label: _ctx.t('common.label.cancel'),
                            link: _ctx.goBack,
                            class: "col-start-0 col-span-6 sm:col-span-3 lg:col-start-0 lg:col-span-3"
                        }, null, 8, ["label", "link"])
                    ]),
                    _: 1
                }, 8, ["onSubmit", "account", "wallet", "unsigned-tx"])
            ]),
            step1: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_SendSubmit, {
                    onError: _ctx.onSubmitError,
                    onSending: _ctx.onTxSending,
                    onPending: _ctx.onTxPending,
                    onConfirmed: _ctx.onTxConfirmed,
                    "text-id": "wallet.send.step.submit"
                }, {
                    btnBack: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                        (_ctx.hasSubmitError)
                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridButtonSecondary, {
                                key: 0,
                                label: _ctx.t('common.label.retry'),
                                link: _ctx.goBack,
                                class: "col-start-0 col-span-6 lg:col-start-0 lg:col-span-3 mt-4"
                            }, null, 8, ["label", "link"]))
                            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                    ]),
                    _: 1
                }, 8, ["onError", "onSending", "onPending", "onConfirmed"])
            ]),
            _: 1
        }, 8, ["onBack", "steps", "currentStep"])
    ]));
}

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/Collateral.vue?vue&type=template&id=7c0fe261&ts=true

// EXTERNAL MODULE: ./node_modules/@vue/reactivity/dist/reactivity.esm-bundler.js
var reactivity_esm_bundler = __webpack_require__(61959);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/BigMathLib.ts + 1 modules
var BigMathLib = __webpack_require__(99149);
// EXTERNAL MODULE: ./src/composables/ccw/useTranslation.ts
var useTranslation = __webpack_require__(19376);
// EXTERNAL MODULE: ./src/composables/ccw/useNavigation.ts
var useNavigation = __webpack_require__(52439);
// EXTERNAL MODULE: ./src/composables/ccw/store/useBuildTx_v3.ts + 1 modules
var useBuildTx_v3 = __webpack_require__(72107);
// EXTERNAL MODULE: ./src/composables/ccw/store/useActiveWallet.ts
var useActiveWallet = __webpack_require__(52144);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/AccountLib.ts
var AccountLib = __webpack_require__(19276);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/send/SendAddrInput.vue + 29 modules
var SendAddrInput = __webpack_require__(99677);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/send/SendMetadataInput.vue + 4 modules
var SendMetadataInput = __webpack_require__(8794);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/send/SendAssetsInput.vue + 4 modules
var SendAssetsInput = __webpack_require__(40123);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/send/SendConfirm.vue + 4 modules
var SendConfirm = __webpack_require__(12662);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/send/SendSubmit.vue + 3 modules
var SendSubmit = __webpack_require__(65778);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridHeadline.vue + 3 modules
var GridHeadline = __webpack_require__(63593);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridText.vue + 4 modules
var GridText = __webpack_require__(96834);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridSpace.vue + 4 modules
var GridSpace = __webpack_require__(14740);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridSteps.vue + 14 modules
var GridSteps = __webpack_require__(58217);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridTextArea.vue + 4 modules
var GridTextArea = __webpack_require__(15660);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridButtonPrimary.vue + 3 modules
var GridButtonPrimary = __webpack_require__(12559);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridButtonSecondary.vue + 3 modules
var GridButtonSecondary = __webpack_require__(72713);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/staking/GridStakePoolList.vue + 4 modules
var GridStakePoolList = __webpack_require__(20099);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/Collateral.vue?vue&type=script&lang=ts




















/* harmony default export */ const Collateralvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'Collateral',
    components: {
        GridStakePoolList: GridStakePoolList/* default */.Z,
        GridSpace: GridSpace/* default */.Z,
        GridHeadline: GridHeadline/* default */.Z,
        GridText: GridText/* default */.Z,
        GridTextArea: GridTextArea/* default */.Z,
        GridSteps: GridSteps/* default */.Z,
        GridButtonPrimary: GridButtonPrimary/* default */.Z,
        GridButtonSecondary: GridButtonSecondary/* default */.Z,
        SendAddrInput: SendAddrInput/* default */.Z,
        SendMetadataInput: SendMetadataInput/* default */.Z,
        SendAssetsInput: SendAssetsInput/* default */.Z,
        SendConfirm: SendConfirm/* default */.Z,
        SendSubmit: SendSubmit/* default */.Z,
    },
    setup() {
        const { t } = (0,useTranslation/* useTranslation */.$)();
        const { gotoWalletPage, openWalletPage } = (0,useNavigation/* useNavigation */.HJ)();
        const currentStep = (0,reactivity_esm_bundler/* ref */.iH)(0);
        const { getBuildStatus, getBuiltTx } = (0,useBuildTx_v3/* useBuildTxV3 */.b)();
        const { activeWalletId, activeWalletData, activeAccount } = (0,useActiveWallet/* useActiveWallet */.r)();
        const tx = (0,runtime_core_esm_bundler/* computed */.Fl)(() => {
            if (!activeAccount.value) {
                return null;
            }
            return getBuiltTx(activeAccount.value?.pub);
        });
        const hasSubmitError = (0,runtime_core_esm_bundler/* computed */.Fl)(() => (activeAccount.value ? (getBuildStatus(activeAccount.value.pub) === useBuildTx_v3/* IBuildStatus.error */.k.error) : null));
        (0,runtime_core_esm_bundler/* onErrorCaptured */.d1)((e) => { console.error('Wallet: Send: onErrorCaptured', e); return true; });
        let showLowFundsWarning = false;
        //Do not allow direct calling of the page!
        if (tx.value == null) {
            openWalletPage('WalletSettings', activeWalletId.value, 'collateral');
        }
        if (activeAccount.value) {
            let percentOfBalance = BigMathLib.multiply(BigMathLib.divide((0,AccountLib/* minCollateral */._0)(activeAccount.value?.network ?? null), activeAccount.value.balance.total), 100);
            if (BigMathLib.compare(percentOfBalance, '>', 10)) {
                showLowFundsWarning = true;
            }
        }
        if (tx.value === null) {
            showLowFundsWarning = false;
        }
        const optionsSteps = (0,reactivity_esm_bundler/* reactive */.qj)([
            { id: 'confirm', label: t('wallet.delegation.steps.stepper.confirm') },
            { id: 'submit', label: t('wallet.delegation.steps.stepper.submit') }
        ]);
        function goBack() {
            if (currentStep.value === 0) {
                openWalletPage('WalletSettings', activeWalletId.value, 'collateral');
            }
            if (currentStep.value === 1) {
                currentStep.value = 0;
            }
        }
        function gotoNext() {
            if (currentStep.value === 0) {
                currentStep.value = 1;
            }
        }
        function onSubmitError() { console.error('submit error!!'); }
        function onTxSending() { }
        function onTxPending() {
            gotoWalletPage('Transactions', 'pending');
        }
        function onTxConfirmed() { }
        return {
            t,
            activeWalletData,
            activeAccount,
            tx,
            optionsSteps,
            currentStep,
            goBack,
            gotoNext,
            onSubmitError,
            onTxSending,
            onTxPending,
            onTxConfirmed,
            hasSubmitError,
            showLowFundsWarning
        };
    }
}));

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/Collateral.vue?vue&type=script&lang=ts
 
// EXTERNAL MODULE: ./node_modules/vue-loader/dist/exportHelper.js
var exportHelper = __webpack_require__(74260);
;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/Collateral.vue




;
const __exports__ = /*#__PURE__*/(0,exportHelper/* default */.Z)(Collateralvue_type_script_lang_ts, [['render',render]])

/* harmony default export */ const Collateral = (__exports__);

/***/ })

}]);
//# sourceMappingURL=5390.js.map