"use strict";
(this["webpackChunkccw_frontend"] = this["webpackChunkccw_frontend"] || []).push([[6592],{

/***/ 79680:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Summary)
});

// EXTERNAL MODULE: ./node_modules/@vue/runtime-core/dist/runtime-core.esm-bundler.js
var runtime_core_esm_bundler = __webpack_require__(83673);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/Summary.vue?vue&type=template&id=34267156&ts=true

const _hoisted_1 = { class: "cc-page-wallet" };
function render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridAccountBalance = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridAccountBalance");
    const _component_GridAccountTokenBalance = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridAccountTokenBalance");
    const _component_GridHeadline = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridHeadline");
    const _component_GridText = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridText");
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    const _component_GridAccountUtxoList = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridAccountUtxoList");
    const _component_AccountList = (0,runtime_core_esm_bundler/* resolveComponent */.up)("AccountList");
    const _component_GridTabs = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridTabs");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_1, [
        (_ctx.activeAccount)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridTabs, {
                key: 0,
                tabs: _ctx.optionsTabs
            }, {
                tab0: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                    (_ctx.activeAccount)
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridAccountBalance, {
                            key: 0,
                            account: _ctx.activeAccount,
                            "enabled-collateral": _ctx.activeWalletEnabledCollateral,
                            syncing: _ctx.isActiveWalletSyncing ?? true
                        }, null, 8, ["account", "enabled-collateral", "syncing"]))
                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                ]),
                tab1: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                    (_ctx.activeAccount && _ctx.activeWalletId)
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridAccountTokenBalance, {
                            key: 0,
                            account: _ctx.activeAccount,
                            "sv-account": _ctx.activeSVAccount,
                            "wallet-id": _ctx.activeWalletId
                        }, null, 8, ["account", "sv-account", "wallet-id"]))
                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                ]),
                tab2: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                        label: _ctx.t('wallet.summary.utxo.headline')
                    }, null, 8, ["label"]),
                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                        text: _ctx.t('wallet.summary.utxo.caption')
                    }, null, 8, ["text"]),
                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, {
                        hr: "",
                        class: "col-span-12"
                    }),
                    (_ctx.activeAccount)
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridAccountUtxoList, {
                            key: 0,
                            account: _ctx.activeAccount,
                            "enabled-collateral": _ctx.activeWalletEnabledCollateral
                        }, null, 8, ["account", "enabled-collateral"]))
                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                ]),
                tab3: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_AccountList)
                ]),
                _: 1
            }, 8, ["tabs"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
    ]));
}

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/Summary.vue?vue&type=template&id=34267156&ts=true

// EXTERNAL MODULE: ./node_modules/@vue/reactivity/dist/reactivity.esm-bundler.js
var reactivity_esm_bundler = __webpack_require__(61959);
// EXTERNAL MODULE: ./src/composables/ccw/useTranslation.ts
var useTranslation = __webpack_require__(19376);
// EXTERNAL MODULE: ./src/composables/ccw/state/useBalanceVisible.ts
var useBalanceVisible = __webpack_require__(31611);
// EXTERNAL MODULE: ./src/composables/ccw/store/useActiveWallet.ts
var useActiveWallet = __webpack_require__(52144);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridHeadline.vue + 3 modules
var GridHeadline = __webpack_require__(63593);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridSpace.vue + 4 modules
var GridSpace = __webpack_require__(14740);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridText.vue + 4 modules
var GridText = __webpack_require__(96834);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridTabs.vue + 4 modules
var GridTabs = __webpack_require__(49510);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/summary/GridAccountBalance.vue?vue&type=template&id=ffcc8fd2&ts=true

function GridAccountBalancevue_type_template_id_ffcc8fd2_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_AccountBalance = (0,runtime_core_esm_bundler/* resolveComponent */.up)("AccountBalance");
    const _component_Rewards = (0,runtime_core_esm_bundler/* resolveComponent */.up)("Rewards");
    const _component_DelegationHistory = (0,runtime_core_esm_bundler/* resolveComponent */.up)("DelegationHistory");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, [
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_AccountBalance, {
            account: _ctx.account,
            "stake-info": _ctx.stakeInfo,
            syncing: _ctx.syncing,
            "enabled-collateral": _ctx.enabledCollateral
        }, null, 8, ["account", "stake-info", "syncing", "enabled-collateral"]),
        (_ctx.stakeKey)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_Rewards, {
                key: 0,
                account: _ctx.account,
                syncing: _ctx.syncing,
                "stake-info": _ctx.stakeInfo,
                "stake-key": _ctx.stakeKey
            }, null, 8, ["account", "syncing", "stake-info", "stake-key"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (_ctx.stakeKey)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_DelegationHistory, {
                key: 1,
                "stake-info": _ctx.stakeInfo,
                "stake-key": _ctx.stakeKey
            }, null, 8, ["stake-info", "stake-key"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
    ], 64));
}

// EXTERNAL MODULE: ./node_modules/@vue/shared/dist/shared.esm-bundler.js
var shared_esm_bundler = __webpack_require__(62323);
// EXTERNAL MODULE: ./node_modules/@vue/runtime-dom/dist/runtime-dom.esm-bundler.js
var runtime_dom_esm_bundler = __webpack_require__(98880);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/summary/AccountBalance.vue?vue&type=template&id=3dcb92c6&ts=true

const AccountBalancevue_type_template_id_3dcb92c6_ts_true_hoisted_1 = { class: "col-span-12 md:col-span-5 cc-text-sz space-y-2" };
const _hoisted_2 = {
    key: 0,
    class: "relative col-span-4 mb-1 cc-text-semi-bold flex justify-between items-center"
};
const _hoisted_3 = {
    key: 0,
    class: "mdi mdi-circle text-xs ml-0.5 cc-text-green",
    style: { "line-height": "0.0rem" }
};
const _hoisted_4 = { class: "cc-text-xs cc-text-normal" };
const _hoisted_5 = { class: "cc-area-light flex flex-row flex-nowrap justify-between items-center p-3 md:px-3" };
const _hoisted_6 = { class: "cc-flex-fixed flex flex-col flex-nowrap whitespace-nowrap cc-text-sz" };
const _hoisted_7 = { class: "cc-text-bold" };
const _hoisted_8 = { class: "cc-text-inactive" };
const _hoisted_9 = { class: "cc-text-inactive" };
const _hoisted_10 = {
    key: 1,
    class: "cc-text-inactive"
};
const _hoisted_11 = { class: "mdi mdi-information-outline" };
const _hoisted_12 = {
    key: 2,
    class: "cc-text-inactive"
};
const _hoisted_13 = { class: "mdi mdi-information-outline" };
const _hoisted_14 = { class: "flex-1 ml-4 flex flex-col flex-nowrap justify-end overflow-hidden cc-text-sz" };
function AccountBalancevue_type_template_id_3dcb92c6_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_Tooltip = (0,runtime_core_esm_bundler/* resolveComponent */.up)("Tooltip");
    const _component_FormattedAmount = (0,runtime_core_esm_bundler/* resolveComponent */.up)("FormattedAmount");
    const _component_AccountUtxoBalance = (0,runtime_core_esm_bundler/* resolveComponent */.up)("AccountUtxoBalance");
    const _component_WalletSVBalance = (0,runtime_core_esm_bundler/* resolveComponent */.up)("WalletSVBalance");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", AccountBalancevue_type_template_id_3dcb92c6_ts_true_hoisted_1, [
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", null, [
            (_ctx.account)
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_2, [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("span", null, [
                        (0,runtime_core_esm_bundler/* createTextVNode */.Uk)((0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.getAccountName(_ctx.account.pub)) + " ", 1),
                        (_ctx.isDappAccount)
                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("i", _hoisted_3))
                            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                    ]),
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_4, "(" + (0,shared_esm_bundler/* toDisplayString */.zw)('m/' + _ctx.account.path[0] + '\'/' + _ctx.account.path[1] + '\'/' + _ctx.account.path[2] + '\'') + ")", 1)
                ]))
                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_5, [
                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_6, [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_7, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('common.balance.total')), 1),
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_8, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('common.balance.balance')), 1),
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_9, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('common.balance.rewards')), 1),
                    (_ctx.showControlledStake)
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("span", {
                            key: 0,
                            class: "cc-text-inactive cursor-pointer",
                            onClick: _cache[0] || (_cache[0] = (0,runtime_dom_esm_bundler/* withModifiers */.iM)(($event) => (_ctx.showStakingBreakdown = !_ctx.showStakingBreakdown), ["stop"]))
                        }, [
                            (0,runtime_core_esm_bundler/* createTextVNode */.Uk)((0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('common.balance.stake.total.label')) + " ", 1),
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("i", {
                                class: (0,shared_esm_bundler/* normalizeClass */.C_)(["relative text-sm -ml-0.5", _ctx.showStakingBreakdown ? 'mdi mdi-chevron-down' : 'mdi mdi-chevron-right'])
                            }, [
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_Tooltip, {
                                    "transition-show": "scale",
                                    "transition-hide": "scale"
                                }, {
                                    default: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                                        (0,runtime_core_esm_bundler/* createTextVNode */.Uk)((0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('common.balance.stake.total.hover')), 1)
                                    ]),
                                    _: 1
                                })
                            ], 2)
                        ]))
                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                    (_ctx.showStakingBreakdown && _ctx.showControlledStake)
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("span", _hoisted_10, [
                            (0,runtime_core_esm_bundler/* createTextVNode */.Uk)((0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('common.balance.stake.controlled.label')) + " ", 1),
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("i", _hoisted_11, [
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_Tooltip, {
                                    "transition-show": "scale",
                                    "transition-hide": "scale"
                                }, {
                                    default: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                                        (0,runtime_core_esm_bundler/* createTextVNode */.Uk)((0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('common.balance.stake.controlled.hover')), 1)
                                    ]),
                                    _: 1
                                })
                            ])
                        ]))
                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                    (_ctx.showStakingBreakdown && _ctx.showControlledStake)
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("span", _hoisted_12, [
                            (0,runtime_core_esm_bundler/* createTextVNode */.Uk)((0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('common.balance.stake.external.label')) + " ", 1),
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("i", _hoisted_13, [
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_Tooltip, {
                                    "transition-show": "scale",
                                    "transition-hide": "scale"
                                }, {
                                    default: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                                        (0,runtime_core_esm_bundler/* createTextVNode */.Uk)((0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('common.balance.stake.external.hover')), 1)
                                    ]),
                                    _: 1
                                })
                            ])
                        ]))
                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                ]),
                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_14, [
                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_FormattedAmount, {
                        amount: _ctx.account.balance.total,
                        "text-c-s-s": "w-full justify-end"
                    }, null, 8, ["amount"]),
                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_FormattedAmount, {
                        amount: _ctx.account.balance.lovelace,
                        "text-c-s-s": "w-full justify-end cc-text-inactive"
                    }, null, 8, ["amount"]),
                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_FormattedAmount, {
                        amount: _ctx.account.balance.rewards,
                        "text-c-s-s": "w-full justify-end cc-text-inactive"
                    }, null, 8, ["amount"]),
                    (_ctx.showControlledStake)
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_FormattedAmount, {
                            key: 0,
                            amount: _ctx.totalStake,
                            "text-c-s-s": "w-full justify-end cc-text-inactive"
                        }, null, 8, ["amount"]))
                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                    (_ctx.showStakingBreakdown && _ctx.showControlledStake)
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_FormattedAmount, {
                            key: 1,
                            amount: _ctx.controlledStake,
                            "text-c-s-s": "w-full justify-end cc-text-inactive"
                        }, null, 8, ["amount"]))
                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                    (_ctx.showStakingBreakdown && _ctx.showControlledStake)
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_FormattedAmount, {
                            key: 2,
                            amount: _ctx.externalStake,
                            "text-c-s-s": "w-full justify-end cc-text-inactive"
                        }, null, 8, ["amount"]))
                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                ])
            ])
        ]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_AccountUtxoBalance, {
            account: _ctx.account,
            syncing: _ctx.syncing,
            "enabled-collateral": _ctx.enabledCollateral,
            class: "mt-3"
        }, null, 8, ["account", "syncing", "enabled-collateral"]),
        (!_ctx.isCustomNetwork)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_WalletSVBalance, {
                key: 0,
                class: "mt-3"
            }))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
    ]));
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/summary/AccountBalance.vue?vue&type=template&id=3dcb92c6&ts=true

// EXTERNAL MODULE: ./src/composables/ccw/useNetworkId.ts
var useNetworkId = __webpack_require__(36648);
// EXTERNAL MODULE: ./src/composables/ccw/store/useDAppWallet.ts
var useDAppWallet = __webpack_require__(35053);
// EXTERNAL MODULE: ./src/composables/ccw/store/useWalletList.ts
var useWalletList = __webpack_require__(4905);
// EXTERNAL MODULE: ./src/components/ccw/common/FormattedAmount.vue + 3 modules
var FormattedAmount = __webpack_require__(6200);
// EXTERNAL MODULE: ./src/components/ccw/common/Tooltip.vue + 3 modules
var Tooltip = __webpack_require__(30105);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/summary/AccountUtxoBalance.vue + 4 modules
var AccountUtxoBalance = __webpack_require__(32256);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/summary/WalletSVBalance.vue?vue&type=template&id=a2b88b92&ts=true

const WalletSVBalancevue_type_template_id_a2b88b92_ts_true_hoisted_1 = {
    key: 0,
    class: "col-span-12 md:col-span-5 2xl:col-span-5 cc-text-sz"
};
const WalletSVBalancevue_type_template_id_a2b88b92_ts_true_hoisted_2 = { class: "relative mb-1 cc-text-semi-bold flex items-center" };
const WalletSVBalancevue_type_template_id_a2b88b92_ts_true_hoisted_3 = { class: "flex flex-row flex-nowrap ml-1.5" };
const WalletSVBalancevue_type_template_id_a2b88b92_ts_true_hoisted_4 = { class: "cc-area-light grid grid-cols-12 justify-start items-start p-3 md:px-3" };
const WalletSVBalancevue_type_template_id_a2b88b92_ts_true_hoisted_5 = {
    key: 0,
    class: "col-span-12 flex flex-row w-full justify-between cc-text-green"
};
const WalletSVBalancevue_type_template_id_a2b88b92_ts_true_hoisted_6 = { class: "cc-text-bold" };
const WalletSVBalancevue_type_template_id_a2b88b92_ts_true_hoisted_7 = { class: "col-span-12 flex flex-row w-full justify-between items-center cc-text-red" };
const WalletSVBalancevue_type_template_id_a2b88b92_ts_true_hoisted_8 = { class: "cc-text-bold" };
const WalletSVBalancevue_type_template_id_a2b88b92_ts_true_hoisted_9 = {
    key: 2,
    class: "col-span-12 flex flex-row w-full justify-between"
};
const WalletSVBalancevue_type_template_id_a2b88b92_ts_true_hoisted_10 = { class: "cc-text-inactive" };
const WalletSVBalancevue_type_template_id_a2b88b92_ts_true_hoisted_11 = {
    key: 3,
    class: "col-span-12 flex flex-row w-full justify-between"
};
const WalletSVBalancevue_type_template_id_a2b88b92_ts_true_hoisted_12 = { class: "cc-text-inactive" };
const WalletSVBalancevue_type_template_id_a2b88b92_ts_true_hoisted_13 = {
    key: 4,
    class: "col-span-12 flex flex-row w-full justify-between"
};
const WalletSVBalancevue_type_template_id_a2b88b92_ts_true_hoisted_14 = { class: "cc-text-inactive" };
const _hoisted_15 = {
    key: 5,
    class: "col-span-12 flex flex-row w-full justify-between"
};
const _hoisted_16 = { class: "cc-text-inactive" };
const _hoisted_17 = { class: "text-right truncate" };
const _hoisted_18 = { class: "cc-text-semi-bold" };
const _hoisted_19 = {
    key: 6,
    class: "col-span-12 flex flex-row w-full justify-between"
};
const _hoisted_20 = { class: "cc-text-inactive" };
const _hoisted_21 = { class: "text-right truncate" };
const _hoisted_22 = { class: "cc-text-semi-bold" };
function WalletSVBalancevue_type_template_id_a2b88b92_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_FormattedAmount = (0,runtime_core_esm_bundler/* resolveComponent */.up)("FormattedAmount");
    const _component_q_spinner_dots = (0,runtime_core_esm_bundler/* resolveComponent */.up)("q-spinner-dots");
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    return (!_ctx.BML.isZero(_ctx.svLockTotal) || !_ctx.BML.isZero(_ctx.svRedeemableTotal))
        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", WalletSVBalancevue_type_template_id_a2b88b92_ts_true_hoisted_1, [
            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", WalletSVBalancevue_type_template_id_a2b88b92_ts_true_hoisted_2, [
                (0,runtime_core_esm_bundler/* createElementVNode */._)("span", null, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('common.label.stakingvault')), 1),
                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", WalletSVBalancevue_type_template_id_a2b88b92_ts_true_hoisted_3, [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("i", {
                        class: "pr-1.5 mdi mdi-arrow-right-circle-outline cursor-pointer",
                        onClick: _cache[0] || (_cache[0] =
                            //@ts-ignore
                            (...args) => (_ctx.gotoStakingVault && _ctx.gotoStakingVault(...args)))
                    })
                ])
            ]),
            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", WalletSVBalancevue_type_template_id_a2b88b92_ts_true_hoisted_4, [
                (!_ctx.BML.isZero(_ctx.svRedeemableTotal))
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", WalletSVBalancevue_type_template_id_a2b88b92_ts_true_hoisted_5, [
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", WalletSVBalancevue_type_template_id_a2b88b92_ts_true_hoisted_6, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('common.balance.svRedeemable')), 1),
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_FormattedAmount, {
                            amount: _ctx.svRedeemableTotal,
                            class: "justify-end"
                        }, null, 8, ["amount"])
                    ]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", WalletSVBalancevue_type_template_id_a2b88b92_ts_true_hoisted_7, [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", WalletSVBalancevue_type_template_id_a2b88b92_ts_true_hoisted_8, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('common.balance.lockedTotal')), 1),
                    (_ctx.isActiveWalletPreparing)
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_q_spinner_dots, {
                            key: 0,
                            color: "gray",
                            class: "cc-text-inactive ml-3"
                        }))
                        : ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_FormattedAmount, {
                            key: 1,
                            amount: _ctx.svLockTotal,
                            class: "justify-end",
                            "hide-fraction-if-zero": ""
                        }, null, 8, ["amount"]))
                ]),
                (!_ctx.isActiveWalletPreparing)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridSpace, {
                        key: 1,
                        hr: "",
                        class: "my-1"
                    }))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                (!_ctx.BML.isZero(_ctx.svLockedRewards))
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", WalletSVBalancevue_type_template_id_a2b88b92_ts_true_hoisted_9, [
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", WalletSVBalancevue_type_template_id_a2b88b92_ts_true_hoisted_10, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('common.balance.svLockedRewards')), 1),
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_FormattedAmount, {
                            amount: _ctx.svLockedRewards,
                            class: "justify-end"
                        }, null, 8, ["amount"])
                    ]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                (!_ctx.BML.isZero(_ctx.svRedeemableRewards))
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", WalletSVBalancevue_type_template_id_a2b88b92_ts_true_hoisted_11, [
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", WalletSVBalancevue_type_template_id_a2b88b92_ts_true_hoisted_12, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('common.balance.svRedeemableRewards')), 1),
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_FormattedAmount, {
                            amount: _ctx.svRedeemableRewards,
                            class: "justify-end"
                        }, null, 8, ["amount"])
                    ]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                (!_ctx.BML.isZero(_ctx.svExternalTotal))
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", WalletSVBalancevue_type_template_id_a2b88b92_ts_true_hoisted_13, [
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", WalletSVBalancevue_type_template_id_a2b88b92_ts_true_hoisted_14, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('common.balance.svExternal')), 1),
                        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_FormattedAmount, {
                            amount: _ctx.svExternalTotal,
                            class: "justify-end"
                        }, null, 8, ["amount"])
                    ]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                (!_ctx.isActiveWalletPreparing)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_15, [
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_16, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('common.balance.svActiveLocks')), 1),
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_17, [
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_18, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.svLockCnt), 1)
                        ])
                    ]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                (_ctx.svRedeemableCnt > 0)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_19, [
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_20, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('common.balance.svRedeemableLocks')), 1),
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_21, [
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_22, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.svRedeemableCnt), 1)
                        ])
                    ]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
            ])
        ]))
        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true);
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/summary/WalletSVBalance.vue?vue&type=template&id=a2b88b92&ts=true

// EXTERNAL MODULE: ./node_modules/quasar/src/composables/use-quasar.js
var use_quasar = __webpack_require__(48825);
// EXTERNAL MODULE: ./src/composables/ccw/useNavigation.ts
var useNavigation = __webpack_require__(52439);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/TimeLockUtils.ts
var TimeLockUtils = __webpack_require__(4367);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/BigMathLib.ts + 1 modules
var BigMathLib = __webpack_require__(99149);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/summary/WalletSVBalance.vue?vue&type=script&lang=ts

;








/* harmony default export */ const WalletSVBalancevue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'WalletSVBalance',
    components: {
        GridSpace: GridSpace/* default */.Z,
        FormattedAmount: FormattedAmount/* default */.Z
    },
    setup() {
        const $q = (0,use_quasar/* default */.Z)();
        const { networkId } = (0,useNetworkId/* useNetworkId */.h)();
        const { it } = (0,useTranslation/* useTranslation */.$)();
        const { activeSVAccount, isActiveWalletSyncing, isActiveWalletPreparing } = (0,useActiveWallet/* useActiveWallet */.r)();
        const { gotoWalletPage } = (0,useNavigation/* useNavigation */.HJ)();
        const svLockTotal = (0,reactivity_esm_bundler/* ref */.iH)('0');
        const svRedeemableTotal = (0,reactivity_esm_bundler/* ref */.iH)('0');
        const svLockedRewards = (0,reactivity_esm_bundler/* ref */.iH)('0');
        const svRedeemableRewards = (0,reactivity_esm_bundler/* ref */.iH)('0');
        const svExternalTotal = (0,reactivity_esm_bundler/* ref */.iH)('0');
        const svLockCnt = (0,reactivity_esm_bundler/* ref */.iH)(0);
        const svRedeemableCnt = (0,reactivity_esm_bundler/* ref */.iH)(0);
        const svLockMesmerizerCnt = (0,reactivity_esm_bundler/* ref */.iH)(0);
        async function updateSVSummary() {
            if (!activeSVAccount.value || isActiveWalletPreparing.value) {
                reset();
                return;
            }
            try {
                const svLists = (0,TimeLockUtils/* updateSVMetaList */.ZL)(activeSVAccount.value);
                svLockCnt.value = svLists.lockedList.length;
                svRedeemableCnt.value = svLists.redeemableList.length;
                svLockMesmerizerCnt.value = activeSVAccount.value.balance.tokenBalance.length;
                let totalRedeemable = '0';
                let lockedRewards = '0';
                let redeemableRewards = '0';
                let totalExternal = '0';
                for (const svLock of svLists.redeemableList) {
                    if (svLock.utxo) {
                        totalRedeemable = BigMathLib.add(totalRedeemable, svLock.utxo.output);
                        const external = svLists.externalList.filter(e => e.utxo && e.utxo.paymentAddr.bech32 === svLock.utxo.paymentAddr.bech32);
                        totalRedeemable = external.reduce((acc, ext) => BigMathLib.add(acc, ext.utxo.output), totalRedeemable);
                    }
                }
                for (const svLock of svLists.externalList) {
                    if (svLock.utxo) {
                        let reward = svLists.lockedList.find(lock => lock.utxo && lock.utxo?.paymentAddr.bech32 === svLock.utxo.paymentAddr.bech32 &&
                            lock.meta.rewards.svPoolRewards === svLock.utxo.output);
                        if (reward) {
                            lockedRewards = BigMathLib.add(lockedRewards, svLock.utxo.output);
                            continue;
                        }
                        reward = svLists.redeemableList.find(lock => lock.utxo && lock.utxo?.paymentAddr.bech32 === svLock.utxo.paymentAddr.bech32 &&
                            lock.meta.rewards.svPoolRewards === svLock.utxo.output);
                        if (reward) {
                            redeemableRewards = BigMathLib.add(redeemableRewards, svLock.utxo.output);
                            continue;
                        }
                        totalExternal = BigMathLib.add(totalExternal, svLock.utxo.output);
                    }
                }
                svLockTotal.value = svLists.lockedList.reduce((acc, lock) => BigMathLib.add(acc, lock.utxo?.output ?? '0'), '0');
                svRedeemableTotal.value = totalRedeemable;
                svLockedRewards.value = lockedRewards;
                svRedeemableRewards.value = redeemableRewards;
                svExternalTotal.value = totalExternal;
            }
            catch (e) {
                $q.notify({
                    type: 'negative',
                    message: 'error: ' + (e?.message ?? 'no error message'),
                    position: 'top-left',
                    timeout: 5000
                });
            }
        }
        function reset() {
            svLockTotal.value = '0';
            svRedeemableTotal.value = '0';
            svLockCnt.value = 0;
            svLockMesmerizerCnt.value = 0;
        }
        (0,runtime_core_esm_bundler/* watch */.YP)(() => activeSVAccount.value, () => updateSVSummary());
        (0,runtime_core_esm_bundler/* watch */.YP)(() => isActiveWalletSyncing.value, (newValue) => { if (!newValue)
            updateSVSummary(); });
        (0,runtime_core_esm_bundler/* onMounted */.bv)(() => updateSVSummary());
        const gotoStakingVault = () => {
            gotoWalletPage('StakingVault');
        };
        return {
            it,
            BML: BigMathLib,
            activeSVAccount,
            isActiveWalletPreparing,
            svLockTotal,
            svRedeemableTotal,
            svLockedRewards,
            svRedeemableRewards,
            svExternalTotal,
            svLockCnt,
            svRedeemableCnt,
            gotoStakingVault,
            adaSymbol: (0,runtime_core_esm_bundler/* computed */.Fl)(() => networkId.value === 'mainnet' ? it('common.symbol.ada') : it('common.symbol.tada')),
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/summary/WalletSVBalance.vue?vue&type=script&lang=ts
 
// EXTERNAL MODULE: ./node_modules/vue-loader/dist/exportHelper.js
var exportHelper = __webpack_require__(74260);
// EXTERNAL MODULE: ./node_modules/quasar/src/components/spinner/QSpinnerDots.js
var QSpinnerDots = __webpack_require__(34765);
// EXTERNAL MODULE: ./node_modules/@quasar/app/lib/webpack/runtime.auto-import.js
var runtime_auto_import = __webpack_require__(7518);
var runtime_auto_import_default = /*#__PURE__*/__webpack_require__.n(runtime_auto_import);
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/summary/WalletSVBalance.vue




;
const __exports__ = /*#__PURE__*/(0,exportHelper/* default */.Z)(WalletSVBalancevue_type_script_lang_ts, [['render',WalletSVBalancevue_type_template_id_a2b88b92_ts_true_render]])

/* harmony default export */ const WalletSVBalance = (__exports__);
;

runtime_auto_import_default()(WalletSVBalancevue_type_script_lang_ts, 'components', {QSpinnerDots: QSpinnerDots/* default */.Z});

;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/summary/AccountBalance.vue?vue&type=script&lang=ts










/* harmony default export */ const AccountBalancevue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'AccountBalance',
    components: {
        Tooltip: Tooltip/* default */.Z,
        AccountUtxoBalance: AccountUtxoBalance/* default */.Z,
        WalletSVBalance: WalletSVBalance,
        FormattedAmount: FormattedAmount/* default */.Z
    },
    props: {
        account: { type: Object, required: true },
        stakeInfo: { type: Object, required: false, default: null },
        syncing: { type: Boolean, required: true },
        enabledCollateral: { type: Boolean, required: false, default: false }
    },
    setup(props) {
        const { isCustomNetwork } = (0,useNetworkId/* useNetworkId */.h)();
        const { it } = (0,useTranslation/* useTranslation */.$)();
        const { dappAccount } = (0,useDAppWallet/* useDAppWallet */.I)();
        const { getAccountName } = (0,useWalletList/* useWalletList */.M)();
        const totalStake = (0,runtime_core_esm_bundler/* computed */.Fl)(() => (props.stakeInfo !== null ? BigMathLib.add(props.stakeInfo.balance.lovelace, props.account.balance.rewards) : '0'));
        const controlledStake = (0,runtime_core_esm_bundler/* computed */.Fl)(() => (!BigMathLib.isZero(totalStake.value) ? BigMathLib.subtract(totalStake.value, BigMathLib.subtract(totalStake.value, props.account.balance.total)) : '0'));
        const externalStake = (0,runtime_core_esm_bundler/* computed */.Fl)(() => (!BigMathLib.isZero(totalStake.value) ? BigMathLib.subtract(totalStake.value, props.account.balance.total) : '0'));
        const showControlledStake = (0,runtime_core_esm_bundler/* computed */.Fl)(() => (externalStake.value !== '0'));
        const isDappAccount = (0,runtime_core_esm_bundler/* computed */.Fl)(() => (dappAccount.value?.pub ?? null) === props.account.pub);
        const showStakingBreakdown = (0,reactivity_esm_bundler/* ref */.iH)(false);
        return {
            it,
            isCustomNetwork,
            showControlledStake,
            totalStake,
            controlledStake,
            externalStake,
            showStakingBreakdown,
            isDappAccount,
            getAccountName
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/summary/AccountBalance.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/summary/AccountBalance.vue




;
const AccountBalance_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(AccountBalancevue_type_script_lang_ts, [['render',AccountBalancevue_type_template_id_3dcb92c6_ts_true_render]])

/* harmony default export */ const AccountBalance = (AccountBalance_exports_);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/summary/Rewards.vue?vue&type=template&id=2e039491&ts=true

const Rewardsvue_type_template_id_2e039491_ts_true_hoisted_1 = { class: "col-span-12 md:col-span-7 cc-text-sz" };
const Rewardsvue_type_template_id_2e039491_ts_true_hoisted_2 = { class: "w-full grid grid-cols-12 cc-gap cc-text-sz" };
const Rewardsvue_type_template_id_2e039491_ts_true_hoisted_3 = { class: "col-span-12 sm:col-span-6" };
const Rewardsvue_type_template_id_2e039491_ts_true_hoisted_4 = { class: "col-span-12 sm:col-span-6" };
function Rewardsvue_type_template_id_2e039491_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_RewardChart = (0,runtime_core_esm_bundler/* resolveComponent */.up)("RewardChart");
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    const _component_GridStakeAddr = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridStakeAddr");
    const _component_GridHeadline = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridHeadline");
    const _component_GridText = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridText");
    const _component_GridButtonSecondary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonSecondary");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", Rewardsvue_type_template_id_2e039491_ts_true_hoisted_1, [
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_RewardChart, { "stake-info": _ctx.stakeInfo }, null, 8, ["stake-info"]),
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", Rewardsvue_type_template_id_2e039491_ts_true_hoisted_2, [
            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, { class: "my-0.5" }),
            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", Rewardsvue_type_template_id_2e039491_ts_true_hoisted_3, [
                (_ctx.stakeKey)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridStakeAddr, {
                        key: 0,
                        "stake-info": _ctx.stakeInfo,
                        "stake-key": _ctx.stakeKey,
                        "wallet-ident": _ctx.plateTextPart
                    }, null, 8, ["stake-info", "stake-key", "wallet-ident"]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
            ]),
            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", Rewardsvue_type_template_id_2e039491_ts_true_hoisted_4, [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                    label: _ctx.it('wallet.summary.withdrawal.label')
                }, null, 8, ["label"]),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                    text: _ctx.it('wallet.summary.withdrawal.text')
                }, null, 8, ["text"]),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, { class: "my-1" }),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonSecondary, {
                    class: "w-full text-right truncate mt-1",
                    disabled: !_ctx.showWithdrawButton,
                    type: 'button',
                    label: _ctx.syncing ? _ctx.it('wallet.summary.withdrawal.button.syncing')
                        : (!_ctx.showWithdrawButton ? _ctx.it('wallet.summary.withdrawal.button.norewards')
                            : _ctx.it('wallet.summary.withdrawal.button.label')),
                    onClick: _cache[0] || (_cache[0] = (0,runtime_dom_esm_bundler/* withModifiers */.iM)(($event) => (_ctx.makeWithdrawal()), ["stop"]))
                }, null, 8, ["disabled", "label"])
            ])
        ])
    ]));
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/summary/Rewards.vue?vue&type=template&id=2e039491&ts=true

// EXTERNAL MODULE: ./src/composables/ccw/store/useBuildTx_v3.ts + 1 modules
var useBuildTx_v3 = __webpack_require__(72107);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/summary/GridStakeAddr.vue?vue&type=template&id=acd36c7c&ts=true

const GridStakeAddrvue_type_template_id_acd36c7c_ts_true_hoisted_1 = { class: "flex flex-col col-span-12 items-start" };
const GridStakeAddrvue_type_template_id_acd36c7c_ts_true_hoisted_2 = { class: "flex flex-row flex-nowrap col-span-12 items-start" };
const GridStakeAddrvue_type_template_id_acd36c7c_ts_true_hoisted_3 = {
    key: 0,
    class: "cc-text-xs cc-text-normal justify-end cc-text-color-caption ml-5 mt-1"
};
const GridStakeAddrvue_type_template_id_acd36c7c_ts_true_hoisted_4 = {
    key: 1,
    class: "cc-text-xs cc-text-normal justify-end cc-text-color-caption ml-5 mt-1"
};
function GridStakeAddrvue_type_template_id_acd36c7c_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridHeadline = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridHeadline");
    const _component_CopyToClipboard = (0,runtime_core_esm_bundler/* resolveComponent */.up)("CopyToClipboard");
    const _component_ExplorerLink = (0,runtime_core_esm_bundler/* resolveComponent */.up)("ExplorerLink");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, [
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
            label: _ctx.t('wallet.summary.stakeinfo.key.label')
        }, null, 8, ["label"]),
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", GridStakeAddrvue_type_template_id_acd36c7c_ts_true_hoisted_1, [
            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", GridStakeAddrvue_type_template_id_acd36c7c_ts_true_hoisted_2, [
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_CopyToClipboard, {
                    "label-hover": _ctx.t('wallet.transactions.button.copy.address.hover'),
                    "notification-text": _ctx.t('wallet.transactions.button.copy.address.notify'),
                    "copy-text": _ctx.stakeKey.bech32,
                    class: "flex inline-flex items-center justify-center"
                }, null, 8, ["label-hover", "notification-text", "copy-text"]),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_ExplorerLink, {
                    subject: _ctx.stakeKey,
                    type: 'stake',
                    label: _ctx.stakeKey.bech32,
                    "label-c-s-s": 'cc-addr'
                }, null, 8, ["subject", "label"])
            ]),
            (_ctx.pathInfo?.length)
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("span", GridStakeAddrvue_type_template_id_acd36c7c_ts_true_hoisted_3, "(" + (0,shared_esm_bundler/* toDisplayString */.zw)('m/' + _ctx.pathInfo[0] + '\'/' + _ctx.pathInfo[1] + '\'/' + _ctx.pathInfo[2] + '\'/' + _ctx.pathInfo[3] + '/' + _ctx.pathInfo[4] + '') + ")", 1))
                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
            (_ctx.walletIdent)
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("span", GridStakeAddrvue_type_template_id_acd36c7c_ts_true_hoisted_4, "(" + (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.walletIdent) + ")", 1))
                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
        ])
    ], 64));
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/summary/GridStakeAddr.vue?vue&type=template&id=acd36c7c&ts=true

// EXTERNAL MODULE: ./src/components/ccw/common/CopyToClipboard.vue + 3 modules
var CopyToClipboard = __webpack_require__(85243);
// EXTERNAL MODULE: ./src/components/ccw/common/ExplorerLink.vue + 3 modules
var ExplorerLink = __webpack_require__(61413);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/summary/GridStakeAddr.vue?vue&type=script&lang=ts







/* harmony default export */ const GridStakeAddrvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'GridStakeAddr',
    components: {
        GridSpace: GridSpace/* default */.Z,
        GridHeadline: GridHeadline/* default */.Z,
        GridText: GridText/* default */.Z,
        ExplorerLink: ExplorerLink/* default */.Z,
        CopyToClipboard: CopyToClipboard/* default */.Z
    },
    props: {
        stakeKey: { type: Object, default: '' },
        stakeInfo: { type: Object, default: '' },
        walletIdent: { type: String, default: '' }
    },
    setup(props) {
        const { t } = (0,useTranslation/* useTranslation */.$)();
        const pathInfo = (0,reactivity_esm_bundler/* ref */.iH)([]);
        pathInfo.value = props.stakeKey.path ?? null;
        return {
            t,
            pathInfo
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/summary/GridStakeAddr.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/summary/GridStakeAddr.vue




;
const GridStakeAddr_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(GridStakeAddrvue_type_script_lang_ts, [['render',GridStakeAddrvue_type_template_id_acd36c7c_ts_true_render]])

/* harmony default export */ const GridStakeAddr = (GridStakeAddr_exports_);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/summary/RewardChart.vue?vue&type=template&id=78eb2698&ts=true

const RewardChartvue_type_template_id_78eb2698_ts_true_hoisted_1 = { class: "relative cc-text-sz w-full flex flex-col flex-nowrap justify-start items-start" };
const RewardChartvue_type_template_id_78eb2698_ts_true_hoisted_2 = { class: "w-full col-span-12 mb-1 cc-text-semi-bold flex justify-between items-center" };
const RewardChartvue_type_template_id_78eb2698_ts_true_hoisted_3 = { class: "w-full col-span-12 flex cc-area-light p-2 pr-3 md:pl-2.5 md:pr-4" };
const RewardChartvue_type_template_id_78eb2698_ts_true_hoisted_4 = {
    ref: "canvasRef",
    width: "1200",
    height: "500",
    class: "flex-1",
    "aria-label": "rewards chart",
    role: "img"
};
function RewardChartvue_type_template_id_78eb2698_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", RewardChartvue_type_template_id_78eb2698_ts_true_hoisted_1, [
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", RewardChartvue_type_template_id_78eb2698_ts_true_hoisted_2, [
            (0,runtime_core_esm_bundler/* createElementVNode */._)("span", null, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('common.label.rewardsHistory')), 1)
        ]),
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", RewardChartvue_type_template_id_78eb2698_ts_true_hoisted_3, [
            (0,runtime_core_esm_bundler/* createElementVNode */._)("canvas", RewardChartvue_type_template_id_78eb2698_ts_true_hoisted_4, null, 512)
        ])
    ]));
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/summary/RewardChart.vue?vue&type=template&id=78eb2698&ts=true

// EXTERNAL MODULE: ./node_modules/chart.js/dist/chart.js + 2 modules
var dist_chart = __webpack_require__(61212);
// EXTERNAL MODULE: ./src/composables/ccw/store/useFormatter.ts
var useFormatter = __webpack_require__(16938);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/ChainLib.ts
var ChainLib = __webpack_require__(48011);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/summary/RewardChart.vue?vue&type=script&lang=ts









dist_chart/* Chart.register */.kL.register(dist_chart/* ArcElement */.qi, dist_chart/* LineElement */.jn, dist_chart/* BarElement */.ZL, dist_chart/* PointElement */.od, dist_chart/* BarController */.vn, dist_chart/* BubbleController */.N0, dist_chart/* DoughnutController */.jI, dist_chart/* LineController */.ST, dist_chart/* PieController */.tt, dist_chart/* PolarAreaController */.CV, dist_chart/* RadarController */.Xi, dist_chart/* ScatterController */.ho, dist_chart/* CategoryScale */.uw, dist_chart/* LinearScale */.f$, dist_chart/* LogarithmicScale */.WV, dist_chart/* RadialLinearScale */.l7, dist_chart/* TimeScale */.FB, dist_chart/* TimeSeriesScale */.RM, dist_chart/* Decimation */.WY, dist_chart/* Filler */.Gu, dist_chart/* Legend */.De, dist_chart/* Title */.Dx, dist_chart/* Tooltip */.u);
/* harmony default export */ const RewardChartvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'RewardChart',
    components: {},
    props: {
        stakeInfo: { type: Object, required: false, default: null }
    },
    setup(props) {
        const { it } = (0,useTranslation/* useTranslation */.$)();
        const { networkId } = (0,useNetworkId/* useNetworkId */.h)();
        const { formatDatetime, formatADAString, formatADAValue, getDecimalNumber } = (0,useFormatter/* useFormatter */.G)();
        const { isBalanceVisible } = (0,useBalanceVisible/* useBalanceVisible */.c)();
        const decimalNumber = getDecimalNumber();
        const canvasRef = (0,reactivity_esm_bundler/* ref */.iH)(null);
        let chart = null;
        let chartData = [];
        let chartLabels = [];
        let isPlaceHolder = false;
        let currentStakeInfo = props.stakeInfo?.bech32;
        function renderChart() {
            const ctx = canvasRef.value?.getContext('2d') ?? null;
            if (ctx && chartData.length > 0) {
                if (chart) {
                    chart.destroy();
                }
                //rgb(142, 255, 214)
                //original bg color rgba(54, 162, 235, 0.2)
                // Original line colo rgba(54, 162, 235, 1)
                let backgroundColorPreset, borderColorPreset;
                const element = document.getElementsByTagName("html");
                // if (element[0].classList.contains('dark')) {
                //   backgroundColorPreset = 'rgba(142, 255, 214, 0.2)';
                //   borderColorPreset = 'rgba(142, 255, 214, 1)';
                // } else {
                backgroundColorPreset = 'rgba(54, 162, 235, 0.2)';
                borderColorPreset = 'rgba(54, 162, 235, 1)';
                // }
                chart = new dist_chart/* Chart */.kL(ctx, {
                    type: 'bar',
                    data: {
                        labels: chartLabels,
                        datasets: [{
                                label: 'Rewards',
                                data: chartData,
                                backgroundColor: backgroundColorPreset,
                                borderColor: borderColorPreset,
                                borderWidth: 1
                            }]
                    },
                    options: {
                        plugins: {
                            tooltip: {
                                callbacks: {
                                    title: function (context) {
                                        const epochNo = Number(context[0].label?.substr(1) ?? 0);
                                        if (epochNo === 0)
                                            return 'Epoch Invalid';
                                        return 'Epoch ' + epochNo;
                                    },
                                    footer: function (context) {
                                        const epochNo = Number(context[0].label?.substr(1) ?? 0);
                                        if (epochNo === 0)
                                            return 'Epoch Invalid';
                                        return formatDatetime((0,ChainLib/* getEpochStart */.iT)(networkId.value, epochNo + 2).timestamp);
                                    },
                                    label: function (context) {
                                        let label = '';
                                        const lovelace = Number.isNaN(context.parsed.y) ? '0' : BigMathLib.multiply(context.parsed.y, decimalNumber);
                                        if (context.parsed.y !== null) {
                                            label = ' ' + formatADAString(lovelace, isBalanceVisible.value);
                                        }
                                        return label;
                                    },
                                    labelTextColor: function (context) {
                                        return '#34D399';
                                    },
                                },
                                bodyFont: {
                                    weight: 'bold'
                                },
                                footerFont: {
                                    size: 10
                                }
                            },
                        },
                        scales: {
                            y: {
                                beginAtZero: true,
                                display: isBalanceVisible.value
                            }
                        },
                        locale: 'en-US'
                    },
                    // @ts-ignore
                    crosshair: {
                        enabled: false,
                        sync: {
                            enabled: false
                        },
                        pan: {
                            enabled: false
                        },
                        snap: {
                            enabled: false
                        },
                    }
                });
            }
        }
        function generateChartData() {
            let currentEpochNo = (0,ChainLib/* getCalculatedEpoch */.uJ)(networkId.value);
            currentStakeInfo = props.stakeInfo?.bech32;
            //  && chartData.length === 0
            if ((currentEpochNo && props.stakeInfo) || (isPlaceHolder && props.stakeInfo)) {
                chartLabels.length = 0;
                chartData.length = 0;
                isPlaceHolder = false;
                let minEpoch = props.stakeInfo.rewardList.reduce(((previousValue, currentValue) => currentValue.epochEarned < previousValue ? currentValue.epochEarned : previousValue), Number.MAX_SAFE_INTEGER);
                if (minEpoch === Number.MAX_SAFE_INTEGER) { // no rewards
                    for (let i = currentEpochNo - 10; i < currentEpochNo; i++) {
                        chartLabels.push('e' + i);
                        chartData.push({ x: 0, y: 0 });
                    }
                }
                else {
                    if (minEpoch < currentEpochNo - 20) {
                        minEpoch = Math.max(minEpoch, currentEpochNo - 20);
                        chartLabels.push('...');
                        chartData.push({ y: 0, x: '...' });
                    }
                    for (let i = minEpoch; i < currentEpochNo - 1; i++) {
                        const reward = props.stakeInfo.rewardList.find(item => item.epochEarned === i);
                        if (reward) {
                            chartLabels.push('e' + reward.epochEarned);
                            chartData.push({ y: parseFloat(formatADAValue(reward.amount)), x: reward.epochEarned });
                        }
                        else {
                            chartLabels.push('e' + i);
                            chartData.push({ x: 0, y: 0 });
                        }
                    }
                }
                renderChart();
            }
            else if (currentEpochNo && chartData.length === 0) {
                isPlaceHolder = true;
                for (let i = currentEpochNo - 5; i < currentEpochNo; i++) {
                    chartLabels.push('epoch ' + i);
                    chartData.push({ x: 0, y: 0 });
                }
                renderChart();
            }
        }
        (0,runtime_core_esm_bundler/* onMounted */.bv)(() => { generateChartData(); });
        (0,runtime_core_esm_bundler/* watch */.YP)(() => props.stakeInfo, () => {
            if (props.stakeInfo?.bech32 !== currentStakeInfo) {
                generateChartData();
            }
        });
        (0,runtime_core_esm_bundler/* watch */.YP)(isBalanceVisible, (value, oldValue, onCleanup) => {
            generateChartData();
        });
        return {
            it,
            canvasRef
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/summary/RewardChart.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/summary/RewardChart.vue




;
const RewardChart_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(RewardChartvue_type_script_lang_ts, [['render',RewardChartvue_type_template_id_78eb2698_ts_true_render]])

/* harmony default export */ const RewardChart = (RewardChart_exports_);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridButtonSecondary.vue + 3 modules
var GridButtonSecondary = __webpack_require__(72713);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/summary/Rewards.vue?vue&type=script&lang=ts

;










/* harmony default export */ const Rewardsvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'Rewards',
    components: {
        RewardChart: RewardChart,
        GridStakeAddr: GridStakeAddr,
        GridSpace: GridSpace/* default */.Z,
        GridHeadline: GridHeadline/* default */.Z,
        GridText: GridText/* default */.Z,
        GridButtonSecondary: GridButtonSecondary/* default */.Z,
    },
    props: {
        account: { type: Object, required: true },
        syncing: { type: Boolean, required: true },
        stakeInfo: { type: Object, required: false, default: null },
        stakeKey: { type: Object, required: false, default: null }
    },
    setup(props) {
        const { it } = (0,useTranslation/* useTranslation */.$)();
        const { gotoWalletPage } = (0,useNavigation/* useNavigation */.HJ)();
        const { buildWithdrawTx } = (0,useBuildTx_v3/* useBuildTxV3 */.b)();
        const $q = (0,use_quasar/* default */.Z)();
        const { activeWalletData, activeWalletPlate, activeAccount } = (0,useActiveWallet/* useActiveWallet */.r)();
        const showWithdrawButton = (0,runtime_core_esm_bundler/* computed */.Fl)(() => parseInt(props.account.balance.rewards) > 0 && !props.syncing);
        const plateTextPart = (0,reactivity_esm_bundler/* ref */.iH)('');
        (0,runtime_core_esm_bundler/* watchEffect */.m0)(() => {
            if (activeWalletPlate.value) {
                const plate = activeWalletPlate.value;
                if (plate.image) {
                    plateTextPart.value = plate.text;
                }
            }
        });
        async function makeWithdrawal() {
            if (!activeWalletData.value || !activeAccount.value)
                return;
            const res = await buildWithdrawTx(activeWalletData.value, activeAccount.value);
            if (res.error) {
                $q.notify({
                    type: 'negative',
                    message: res.error,
                    position: 'top-left',
                    timeout: 8000
                });
            }
            else {
                gotoWalletPage('Withdrawal');
            }
        }
        return {
            it,
            showWithdrawButton,
            makeWithdrawal,
            plateTextPart
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/summary/Rewards.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/summary/Rewards.vue




;
const Rewards_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(Rewardsvue_type_script_lang_ts, [['render',Rewardsvue_type_template_id_2e039491_ts_true_render]])

/* harmony default export */ const Rewards = (Rewards_exports_);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/summary/DelegationHistory.vue?vue&type=template&id=0d03cc13&scoped=true&ts=true

const _withScopeId = n => (_pushScopeId("data-v-0d03cc13"), n = n(), _popScopeId(), n);
const DelegationHistoryvue_type_template_id_0d03cc13_scoped_true_ts_true_hoisted_1 = { class: "col-span-12 md:col-span-6 2xl:col-span-4 flex flex-col flex-nowrap justify-center items-center" };
const DelegationHistoryvue_type_template_id_0d03cc13_scoped_true_ts_true_hoisted_2 = { class: "cc-text-sx cc-text-bold" };
const DelegationHistoryvue_type_template_id_0d03cc13_scoped_true_ts_true_hoisted_3 = { class: "cc-text-xs cc-text-color-caption mb-1" };
const DelegationHistoryvue_type_template_id_0d03cc13_scoped_true_ts_true_hoisted_4 = {
    key: 1,
    class: "overflow-hidden cc-area-undelegated flex-1 w-full min-h-40 inline-flex flex-col flex-nowrap justify-start items-start"
};
const DelegationHistoryvue_type_template_id_0d03cc13_scoped_true_ts_true_hoisted_5 = { class: "relative w-full flex-1 overflow-hidden flex justify-center items-center" };
const DelegationHistoryvue_type_template_id_0d03cc13_scoped_true_ts_true_hoisted_6 = { class: "flex-1 w-full h-full flex flex-col flex-nowrap justify-center items-center" };
const DelegationHistoryvue_type_template_id_0d03cc13_scoped_true_ts_true_hoisted_7 = { class: "col-span-12 md:col-span-6 2xl:col-span-4 flex flex-col flex-nowrap justify-center items-center" };
const DelegationHistoryvue_type_template_id_0d03cc13_scoped_true_ts_true_hoisted_8 = { class: "cc-text-sx cc-text-bold" };
const DelegationHistoryvue_type_template_id_0d03cc13_scoped_true_ts_true_hoisted_9 = { class: "cc-text-xs cc-text-color-caption mb-1" };
const DelegationHistoryvue_type_template_id_0d03cc13_scoped_true_ts_true_hoisted_10 = {
    key: 1,
    class: "overflow-hidden cc-area-undelegated flex-1 w-full min-h-40 inline-flex flex-col flex-nowrap justify-start items-start"
};
const DelegationHistoryvue_type_template_id_0d03cc13_scoped_true_ts_true_hoisted_11 = { class: "relative w-full flex-1 overflow-hidden flex justify-center items-center" };
const DelegationHistoryvue_type_template_id_0d03cc13_scoped_true_ts_true_hoisted_12 = { class: "flex-1 w-full h-full flex flex-col flex-nowrap justify-center items-center" };
const DelegationHistoryvue_type_template_id_0d03cc13_scoped_true_ts_true_hoisted_13 = { class: "col-span-12 md:col-span-6 2xl:col-span-4 flex flex-col flex-nowrap justify-center items-center" };
const DelegationHistoryvue_type_template_id_0d03cc13_scoped_true_ts_true_hoisted_14 = { class: "cc-text-sx cc-text-bold" };
const DelegationHistoryvue_type_template_id_0d03cc13_scoped_true_ts_true_hoisted_15 = { class: "cc-text-xs cc-text-color-caption mb-1" };
const DelegationHistoryvue_type_template_id_0d03cc13_scoped_true_ts_true_hoisted_16 = {
    key: 1,
    class: "overflow-hidden cc-area-undelegated flex-1 w-full min-h-40 inline-flex flex-col flex-nowrap justify-start items-start"
};
const DelegationHistoryvue_type_template_id_0d03cc13_scoped_true_ts_true_hoisted_17 = { class: "relative w-full flex-1 overflow-hidden flex justify-center items-center" };
const DelegationHistoryvue_type_template_id_0d03cc13_scoped_true_ts_true_hoisted_18 = { class: "flex-1 w-full h-full flex flex-col flex-nowrap justify-center items-center" };
const DelegationHistoryvue_type_template_id_0d03cc13_scoped_true_ts_true_hoisted_19 = { class: "col-span-12 item-text" };
const DelegationHistoryvue_type_template_id_0d03cc13_scoped_true_ts_true_hoisted_20 = { class: "cc-area-light flex flex-col flex-nowrap p-2 md:px-4 mt-2" };
const DelegationHistoryvue_type_template_id_0d03cc13_scoped_true_ts_true_hoisted_21 = { class: "w-full flex flex-row flex-nowrap" };
const DelegationHistoryvue_type_template_id_0d03cc13_scoped_true_ts_true_hoisted_22 = { class: "w-10 sm:w-12 cc-flex-fixed cc-text-bold text-left mr-1" };
const _hoisted_23 = { class: "flex-1 cc-text-bold text-left mr-1" };
const _hoisted_24 = { class: "cc-flex-fixed cc-text-bold text-right" };
const _hoisted_25 = { class: "w-10 sm:w-12 cc-flex-fixed text-left mr-1" };
const _hoisted_26 = { class: "w-full flex-1 text-left mr-1 whitespace-nowrap truncate mr-2" };
const _hoisted_27 = {
    key: 0,
    class: "flex flex-row flex-nowrap justify-start items-center cc-space-x"
};
const _hoisted_28 = { class: "item-text truncate" };
const _hoisted_29 = {
    key: 1,
    class: "flex flex-row flex-nowrap justify-start items-center cc-space-x"
};
const _hoisted_30 = { class: "item-text-poolid truncate text-xs" };
const _hoisted_31 = {
    key: 0,
    class: ""
};
const _hoisted_32 = { class: "cc-flex-fixed text-right" };
const _hoisted_33 = {
    key: 0,
    class: "flex flex-row flex-nowrap items-center justify-end cc-text-semi-bold"
};
const _hoisted_34 = {
    key: 0,
    class: "cc-text-red"
};
const _hoisted_35 = {
    key: 1,
    class: "cc-text-green"
};
const _hoisted_36 = {
    key: 2,
    class: "cc-text-inactive"
};
const _hoisted_37 = {
    key: 2,
    class: "flex flex-row flex-nowrap items-center justify-end"
};
const _hoisted_38 = { class: "cc-text-semi-bold cc-text-yellow" };
const _hoisted_39 = {
    key: 3,
    class: "flex flex-row flex-nowrap items-center justify-end"
};
const _hoisted_40 = { class: "cc-text-semi-bold cc-text-yellow" };
const _hoisted_41 = {
    key: 4,
    class: "flex flex-row flex-nowrap items-center justify-end"
};
const _hoisted_42 = { class: "cc-text-semi-bold cc-text-inactive" };
const _hoisted_43 = { class: "cc-text-xs cc-text-color-caption" };
const _hoisted_44 = { class: "w-10 sm:w-12 cc-flex-fixed text-left mr-1" };
const _hoisted_45 = { class: "w-full flex-1 text-left mr-1 whitespace-nowrap truncate mr-2" };
const _hoisted_46 = { class: "flex flex-row flex-nowrap justify-start items-center cc-space-x" };
const _hoisted_47 = { class: "item-text truncate" };
const _hoisted_48 = { class: "cc-flex-fixed text-right" };
const _hoisted_49 = { class: "cc-text-xs cc-text-color-caption" };
function DelegationHistoryvue_type_template_id_0d03cc13_scoped_true_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    const _component_GridHeadline = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridHeadline");
    const _component_GridText = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridText");
    const _component_GridStakePoolList = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridStakePoolList");
    const _component_FormattedAmount = (0,runtime_core_esm_bundler/* resolveComponent */.up)("FormattedAmount");
    const _component_q_pagination = (0,runtime_core_esm_bundler/* resolveComponent */.up)("q-pagination");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, [
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, {
            hr: "",
            class: "mt-2 mb-1"
        }),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
            label: _ctx.t('wallet.summary.stakeinfo.upcoming.label')
        }, null, 8, ["label"]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
            text: _ctx.t('wallet.summary.stakeinfo.upcoming.caption')
        }, null, 8, ["text"]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, {
            hr: "",
            class: "mt-1 mb-1"
        }),
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", DelegationHistoryvue_type_template_id_0d03cc13_scoped_true_ts_true_hoisted_1, [
            (0,runtime_core_esm_bundler/* createElementVNode */._)("span", DelegationHistoryvue_type_template_id_0d03cc13_scoped_true_ts_true_hoisted_2, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.summary.stakeinfo.upcoming.current')) + ": " + (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.currentEpochNo), 1),
            (0,runtime_core_esm_bundler/* createElementVNode */._)("span", DelegationHistoryvue_type_template_id_0d03cc13_scoped_true_ts_true_hoisted_3, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.formatDatetime(_ctx.currentEpochStart)), 1),
            (_ctx.currentEpochDelegation.length > 0)
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridStakePoolList, {
                    key: 0,
                    poolList: _ctx.currentEpochDelegation,
                    delegatedPoolList: _ctx.currentEpochDelegation
                }, null, 8, ["poolList", "delegatedPoolList"]))
                : ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", DelegationHistoryvue_type_template_id_0d03cc13_scoped_true_ts_true_hoisted_4, [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", DelegationHistoryvue_type_template_id_0d03cc13_scoped_true_ts_true_hoisted_5, [
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", DelegationHistoryvue_type_template_id_0d03cc13_scoped_true_ts_true_hoisted_6, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.delegation.info.undelegated')), 1)
                    ])
                ]))
        ]),
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", DelegationHistoryvue_type_template_id_0d03cc13_scoped_true_ts_true_hoisted_7, [
            (0,runtime_core_esm_bundler/* createElementVNode */._)("span", DelegationHistoryvue_type_template_id_0d03cc13_scoped_true_ts_true_hoisted_8, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.summary.stakeinfo.upcoming.next')) + ": " + (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.currentEpochNo + 1), 1),
            (0,runtime_core_esm_bundler/* createElementVNode */._)("span", DelegationHistoryvue_type_template_id_0d03cc13_scoped_true_ts_true_hoisted_9, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.formatDatetime(_ctx.nextEpochStart)), 1),
            (_ctx.nextDelegation.length > 0)
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridStakePoolList, {
                    key: 0,
                    poolList: _ctx.nextDelegation,
                    delegatedPoolList: _ctx.nextDelegation
                }, null, 8, ["poolList", "delegatedPoolList"]))
                : ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", DelegationHistoryvue_type_template_id_0d03cc13_scoped_true_ts_true_hoisted_10, [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", DelegationHistoryvue_type_template_id_0d03cc13_scoped_true_ts_true_hoisted_11, [
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", DelegationHistoryvue_type_template_id_0d03cc13_scoped_true_ts_true_hoisted_12, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.delegation.info.undelegated')), 1)
                    ])
                ]))
        ]),
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", DelegationHistoryvue_type_template_id_0d03cc13_scoped_true_ts_true_hoisted_13, [
            (0,runtime_core_esm_bundler/* createElementVNode */._)("span", DelegationHistoryvue_type_template_id_0d03cc13_scoped_true_ts_true_hoisted_14, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.summary.stakeinfo.upcoming.epoch')) + ": " + (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.currentEpochNo + 2), 1),
            (0,runtime_core_esm_bundler/* createElementVNode */._)("span", DelegationHistoryvue_type_template_id_0d03cc13_scoped_true_ts_true_hoisted_15, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.formatDatetime(_ctx.afterNextEpochStart)), 1),
            (_ctx.afterNextDelegations.length > 0)
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridStakePoolList, {
                    key: 0,
                    poolList: _ctx.afterNextDelegations,
                    delegatedPoolList: _ctx.afterNextDelegations
                }, null, 8, ["poolList", "delegatedPoolList"]))
                : ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", DelegationHistoryvue_type_template_id_0d03cc13_scoped_true_ts_true_hoisted_16, [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", DelegationHistoryvue_type_template_id_0d03cc13_scoped_true_ts_true_hoisted_17, [
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", DelegationHistoryvue_type_template_id_0d03cc13_scoped_true_ts_true_hoisted_18, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.delegation.info.undelegated')), 1)
                    ])
                ]))
        ]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, {
            hr: "",
            class: "mt-2 mb-1"
        }),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
            label: _ctx.t('wallet.summary.stakeinfo.history.label')
        }, null, 8, ["label"]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
            text: _ctx.t('wallet.summary.stakeinfo.history.caption')
        }, null, 8, ["text"]),
        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", DelegationHistoryvue_type_template_id_0d03cc13_scoped_true_ts_true_hoisted_19, [
            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", DelegationHistoryvue_type_template_id_0d03cc13_scoped_true_ts_true_hoisted_20, [
                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", DelegationHistoryvue_type_template_id_0d03cc13_scoped_true_ts_true_hoisted_21, [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", DelegationHistoryvue_type_template_id_0d03cc13_scoped_true_ts_true_hoisted_22, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.summary.stakeinfo.history.epoch')), 1),
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_23, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.summary.stakeinfo.history.pool')), 1),
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_24, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.summary.stakeinfo.history.rewards')), 1)
                ]),
                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, {
                    hr: "",
                    class: "my-1"
                }),
                ((0,runtime_core_esm_bundler/* openBlock */.wg)(true), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, (0,runtime_core_esm_bundler/* renderList */.Ko)(_ctx.epochData, (ed, edIndex) => {
                    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", {
                        class: "w-full flex flex-col flex-nowrap",
                        key: 'epochData' + ed.epochNo + ed.rewards.type
                    }, [
                        (edIndex !== 0)
                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridSpace, {
                                key: 0,
                                hr: "",
                                class: "my-0.5"
                            }))
                            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                        (ed.rewards.type === 'member')
                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", {
                                key: 1,
                                class: (0,shared_esm_bundler/* normalizeClass */.C_)(["flex flex-row flex-nowrap justify-start items-center item-text", ed.isCurrentEpoch ? ' ' : ''])
                            }, [
                                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_25, (0,shared_esm_bundler/* toDisplayString */.zw)(ed.epochNo), 1),
                                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_26, [
                                    (ed.poolItem.length > 0)
                                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_27, [
                                            (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_28, (0,shared_esm_bundler/* toDisplayString */.zw)(ed.poolItem[0].md?.ticker ? '[' + ed.poolItem[0].md?.ticker + ']' :  null ?? _ctx.t('common.label.noname')) + " " + (0,shared_esm_bundler/* toDisplayString */.zw)(ed.poolItem[0].md?.name ?? ''), 1)
                                        ]))
                                        : ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_29, [
                                            (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_30, [
                                                (ed.delegation?.poolHash.bech32)
                                                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("span", _hoisted_31, (0,shared_esm_bundler/* toDisplayString */.zw)(ed.delegation?.poolHash.bech32) + " (no data available)", 1))
                                                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                                            ])
                                        ]))
                                ]),
                                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_32, [
                                    (ed.state === 0)
                                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_33, [
                                            (ed.deregistration)
                                                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("span", _hoisted_34, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.delegation.info.deregistered')), 1))
                                                : (ed.registration)
                                                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("span", _hoisted_35, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.delegation.info.registered')), 1))
                                                    : ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("span", _hoisted_36, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.delegation.info.undelegated')), 1))
                                        ]))
                                        : (ed.rewards && ed.state === 1)
                                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_FormattedAmount, {
                                                key: 1,
                                                amount: ed.rewards?.amount,
                                                colored: ed.rewards?.amount !== '0',
                                                "text-c-s-s": 'justify-end ' + (ed.rewards?.amount === '0' ? 'cc-text-red' : '')
                                            }, null, 8, ["amount", "colored", "text-c-s-s"]))
                                            : (ed.state === 2)
                                                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_37, [
                                                    (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_38, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.delegation.info.pending')), 1)
                                                ]))
                                                : (ed.state === 3)
                                                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_39, [
                                                        (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_40, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.delegation.info.producing')), 1)
                                                    ]))
                                                    : ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_41, [
                                                        (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_42, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.delegation.info.delegated')), 1)
                                                    ])),
                                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_43, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.formatDatetime(ed.tsSpendable)), 1)
                                ])
                            ], 2))
                            : ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", {
                                key: 2,
                                class: (0,shared_esm_bundler/* normalizeClass */.C_)(["flex flex-row flex-nowrap justify-start items-center item-text", ed.isCurrentEpoch ? ' ' : ''])
                            }, [
                                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_44, (0,shared_esm_bundler/* toDisplayString */.zw)(ed.epochNo), 1),
                                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_45, [
                                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_46, [
                                        (0,runtime_core_esm_bundler/* createElementVNode */._)("span", _hoisted_47, [
                                            (0,runtime_core_esm_bundler/* createElementVNode */._)("span", null, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.t('wallet.summary.stakeinfo.history.' + ed.rewards.type)), 1)
                                        ])
                                    ])
                                ]),
                                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_48, [
                                    (ed.rewards)
                                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_FormattedAmount, {
                                            key: 0,
                                            amount: ed.rewards?.amount,
                                            colored: ed.rewards?.amount !== '0',
                                            "text-c-s-s": 'justify-end ' + (ed.rewards?.amount === '0' ? 'cc-text-red' : '')
                                        }, null, 8, ["amount", "colored", "text-c-s-s"]))
                                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_49, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.formatDatetime(ed.tsSpendable)), 1)
                                ])
                            ], 2))
                    ]));
                }), 128)),
                (_ctx.showPagination)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridSpace, {
                        key: 0,
                        hr: "",
                        class: "mt-0.5 mb-2"
                    }))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                (_ctx.showPagination)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_q_pagination, {
                        key: 1,
                        modelValue: _ctx.currentPage,
                        "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => ((_ctx.currentPage) = $event)),
                        "model-value": _ctx.currentPage,
                        max: _ctx.maxPages,
                        "max-pages": 6,
                        "boundary-numbers": "",
                        flat: "",
                        color: "teal-90",
                        "text-color": "teal-90",
                        "active-color": "teal-90",
                        "active-text-color": "teal-90",
                        "active-design": "unelevated",
                        class: "self-center"
                    }, null, 8, ["modelValue", "model-value", "max"]))
                    : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
            ])
        ])
    ], 64));
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/summary/DelegationHistory.vue?vue&type=template&id=0d03cc13&scoped=true&ts=true

// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridPoolLogo.vue + 4 modules
var GridPoolLogo = __webpack_require__(15761);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/staking/GridStakePoolList.vue + 4 modules
var GridStakePoolList = __webpack_require__(20099);
// EXTERNAL MODULE: ./src/composables/ccw/store/useDelegationHistory.ts
var useDelegationHistory = __webpack_require__(22096);
// EXTERNAL MODULE: ./src/composables/ccw/store/usePoolAPI.ts
var usePoolAPI = __webpack_require__(8614);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/summary/DelegationHistory.vue?vue&type=script&lang=ts











/* harmony default export */ const DelegationHistoryvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'DelegationHistory',
    components: {
        GridText: GridText/* default */.Z,
        GridSpace: GridSpace/* default */.Z,
        GridHeadline: GridHeadline/* default */.Z,
        GridPoolLogo: GridPoolLogo/* default */.Z,
        GridStakePoolList: GridStakePoolList/* default */.Z,
        FormattedAmount: FormattedAmount/* default */.Z
    },
    props: {
        stakeInfo: { type: Object, required: false, default: null },
        stakeKey: { type: Object, required: false, default: null }
    },
    setup(props) {
        const { t } = (0,useTranslation/* useTranslation */.$)();
        const { poolList } = (0,usePoolAPI/* usePoolAPI */.b)();
        const { formatDatetime } = (0,useFormatter/* useFormatter */.G)();
        const { generateDelegationHistory } = (0,useDelegationHistory/* useDelegationHistory */.I)();
        let _currentEpochNo = (0,reactivity_esm_bundler/* ref */.iH)(0);
        let _currentEpochStart = (0,reactivity_esm_bundler/* ref */.iH)(0);
        let _nextEpochStart = (0,reactivity_esm_bundler/* ref */.iH)(0);
        let _afterNextEpochStart = (0,reactivity_esm_bundler/* ref */.iH)(0);
        let _currentEpochDelegation = (0,reactivity_esm_bundler/* ref */.iH)([]);
        let _nextDelegation = (0,reactivity_esm_bundler/* ref */.iH)([]);
        let _afterNextDelegations = (0,reactivity_esm_bundler/* ref */.iH)([]);
        let _epochData = (0,reactivity_esm_bundler/* ref */.iH)([]);
        const hasDelegation = (0,runtime_core_esm_bundler/* computed */.Fl)(() => _currentEpochDelegation.value.length > 0 ||
            _nextDelegation.value.length > 0 ||
            _afterNextDelegations.value.length > 0);
        const itemsOnPage = 20;
        const currentPage = (0,reactivity_esm_bundler/* ref */.iH)(1);
        const showPagination = (0,runtime_core_esm_bundler/* computed */.Fl)(() => _epochData.value.length > itemsOnPage);
        const currentPageStart = (0,runtime_core_esm_bundler/* computed */.Fl)(() => (currentPage.value - 1) * itemsOnPage);
        const maxPages = (0,runtime_core_esm_bundler/* computed */.Fl)(() => Math.ceil(_epochData.value.length / itemsOnPage));
        const _epochDataFiltered = (0,runtime_core_esm_bundler/* computed */.Fl)(() => _epochData.value.slice(currentPageStart.value, currentPageStart.value + itemsOnPage));
        function generateDelegationList() {
            const { epochData, currentEpochNo, currentEpochStart, nextEpochStart, afterNextEpochStart, currentEpochDelegation, nextDelegation, afterNextDelegations } = generateDelegationHistory(props.stakeKey, props.stakeInfo);
            _currentEpochNo.value = currentEpochNo;
            _currentEpochStart.value = currentEpochStart;
            _nextEpochStart.value = nextEpochStart;
            _afterNextEpochStart.value = afterNextEpochStart;
            _epochData.value = epochData;
            _currentEpochDelegation.value = currentEpochDelegation;
            _nextDelegation.value = nextDelegation;
            _afterNextDelegations.value = afterNextDelegations;
        }
        (0,runtime_core_esm_bundler/* watchEffect */.m0)(() => {
            if ( /*(props.stakeInfo.deregistrationList.length ||
              props.stakeInfo.delegationList.length ||
              props.stakeInfo.registrationList.length) &&*/poolList.value.length > 0) {
                generateDelegationList();
            }
            else {
                generateDelegationList();
            }
        });
        function isValidImg(pool) {
            const src = pool.mde?.info?.url_png_icon_64x64 || pool.mde?.adapools?.url_png_icon_64x64;
            return (src && src.startsWith('https://'));
        }
        return {
            t,
            formatDatetime,
            isValidImg,
            hasDelegation,
            showPagination,
            currentPage,
            maxPages,
            currentEpochNo: _currentEpochNo,
            currentEpochStart: _currentEpochStart,
            nextEpochStart: _nextEpochStart,
            afterNextEpochStart: _afterNextEpochStart,
            epochData: _epochDataFiltered,
            currentEpochDelegation: _currentEpochDelegation,
            nextDelegation: _nextDelegation,
            afterNextDelegations: _afterNextDelegations,
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/summary/DelegationHistory.vue?vue&type=script&lang=ts
 
// EXTERNAL MODULE: ./node_modules/quasar/src/components/pagination/QPagination.js
var QPagination = __webpack_require__(87300);
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/summary/DelegationHistory.vue




;


const DelegationHistory_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(DelegationHistoryvue_type_script_lang_ts, [['render',DelegationHistoryvue_type_template_id_0d03cc13_scoped_true_ts_true_render],['__scopeId',"data-v-0d03cc13"]])

/* harmony default export */ const DelegationHistory = (DelegationHistory_exports_);
;

runtime_auto_import_default()(DelegationHistoryvue_type_script_lang_ts, 'components', {QPagination: QPagination/* default */.Z});

;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/summary/GridAccountBalance.vue?vue&type=script&lang=ts





/* harmony default export */ const GridAccountBalancevue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'GridAccountBalance',
    components: {
        AccountBalance: AccountBalance,
        AccountUtxoBalance: AccountUtxoBalance/* default */.Z,
        Rewards: Rewards,
        DelegationHistory: DelegationHistory
    },
    props: {
        account: { type: Object, required: true },
        syncing: { type: Boolean, required: true },
        enabledCollateral: { type: Boolean, required: false, default: false }
    },
    setup(props) {
        const stakeInfo = (0,reactivity_esm_bundler/* ref */.iH)(props.account?.base.stake.length > 0 ? props.account.base.stake[0] : null);
        const stakeKey = (0,reactivity_esm_bundler/* ref */.iH)(props.account?.keys.stake.length > 0 ? props.account.keys.stake[0] : null);
        (0,runtime_core_esm_bundler/* watch */.YP)(() => props.account, () => {
            if (props.account?.keys.stake.length > 0) {
                stakeKey.value = props.account.keys.stake[0];
            }
            else {
                stakeKey.value = null;
            }
            if (props.account?.base.stake.length > 0) {
                stakeInfo.value = props.account.base.stake[0];
            }
            else {
                stakeInfo.value = null;
            }
        });
        return {
            stakeInfo,
            stakeKey
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/summary/GridAccountBalance.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/summary/GridAccountBalance.vue




;
const GridAccountBalance_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(GridAccountBalancevue_type_script_lang_ts, [['render',GridAccountBalancevue_type_template_id_ffcc8fd2_ts_true_render]])

/* harmony default export */ const GridAccountBalance = (GridAccountBalance_exports_);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/summary/GridAccountUtxoList.vue + 4 modules
var GridAccountUtxoList = __webpack_require__(10329);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/summary/GridAccountTokenBalance.vue?vue&type=template&id=3ffc34c0&ts=true

function GridAccountTokenBalancevue_type_template_id_3ffc34c0_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridHeadline = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridHeadline");
    const _component_GridText = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridText");
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    const _component_GridTokenList = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridTokenList");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, [
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
            label: _ctx.t('wallet.summary.token.headline')
        }, null, 8, ["label"]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
            text: _ctx.t('wallet.summary.token.caption')
        }, null, 8, ["text"]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, {
            hr: "",
            class: "mb-2"
        }),
        (_ctx.account)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridTokenList, {
                key: 0,
                "token-list": _ctx.tokenList,
                "network-id": _ctx.account.network,
                "wallet-id": _ctx.walletId,
                "send-enabled": false
            }, null, 8, ["token-list", "network-id", "wallet-id"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
    ], 64));
}

// EXTERNAL MODULE: ./src/components/ccw/grid/v2/summary/GridTokenList.vue + 9 modules
var GridTokenList = __webpack_require__(84003);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/summary/GridAccountTokenBalance.vue?vue&type=script&lang=ts






/* harmony default export */ const GridAccountTokenBalancevue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'GridAccountTokenBalance',
    components: {
        GridHeadline: GridHeadline/* default */.Z,
        GridText: GridText/* default */.Z,
        GridSpace: GridSpace/* default */.Z,
        GridTokenList: GridTokenList/* default */.Z
    },
    props: {
        account: { type: Object, required: true },
        svAccount: { type: Object, required: false },
        walletId: { type: String, required: false, default: '' },
    },
    setup(props) {
        const { t } = (0,useTranslation/* useTranslation */.$)();
        const tokenList = props.account ?
            (props.svAccount ? props.account.balance.tokenBalance.concat(props.svAccount.balance.tokenBalance) : props.account.balance.tokenBalance) : [];
        return {
            t,
            tokenList
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/summary/GridAccountTokenBalance.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/summary/GridAccountTokenBalance.vue




;
const GridAccountTokenBalance_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(GridAccountTokenBalancevue_type_script_lang_ts, [['render',GridAccountTokenBalancevue_type_template_id_3ffc34c0_ts_true_render]])

/* harmony default export */ const GridAccountTokenBalance = (GridAccountTokenBalance_exports_);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/accounts/AccountList.vue?vue&type=template&id=3a11c6dd&ts=true

const AccountListvue_type_template_id_3a11c6dd_ts_true_hoisted_1 = { class: "col-span-12 grid grid-cols-12 cc-gap cc-text-sz" };
function AccountListvue_type_template_id_3a11c6dd_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridHeadline = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridHeadline");
    const _component_GridText = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridText");
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    const _component_AccountItem = (0,runtime_core_esm_bundler/* resolveComponent */.up)("AccountItem");
    const _component_GridTextArea = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridTextArea");
    const _component_SignAddAccount = (0,runtime_core_esm_bundler/* resolveComponent */.up)("SignAddAccount");
    const _component_ConfirmationModal = (0,runtime_core_esm_bundler/* resolveComponent */.up)("ConfirmationModal");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", AccountListvue_type_template_id_3a11c6dd_ts_true_hoisted_1, [
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
            label: _ctx.it('wallet.summary.accounts.headline')
        }, null, 8, ["label"]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
            text: _ctx.it('wallet.summary.accounts.caption')
        }, null, 8, ["text"]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, {
            hr: "",
            class: "col-span-12"
        }),
        ((0,runtime_core_esm_bundler/* openBlock */.wg)(true), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, (0,runtime_core_esm_bundler/* renderList */.Ko)(_ctx.activeAccountList, (account) => {
            return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_AccountItem, {
                key: account.pub,
                account: account,
                "is-active-account": account.pub === (_ctx.activeAccount?.pub ?? ''),
                syncing: _ctx.isActiveWalletSyncing ?? true,
                onOnActivateAccount: _ctx.onActivateAccount,
                onOnRemoveAccount: _ctx.openDeleteModal
            }, null, 8, ["account", "is-active-account", "syncing", "onOnActivateAccount", "onOnRemoveAccount"]));
        }), 128)),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridTextArea, {
            class: "col-span-12",
            css: "cc-area-highlight cc-text-semi-bold",
            dense: "",
            label: _ctx.it('wallet.summary.accounts.notice.label'),
            text: _ctx.it('wallet.summary.accounts.notice.text'),
            icon: _ctx.it('wallet.summary.accounts.notice.icon')
        }, null, 8, ["label", "text", "icon"]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, {
            hr: "",
            class: "mt-1 col-span-12"
        }),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_SignAddAccount, {
            "text-id": "wallet.summary.accounts.confirm",
            class: "col-span-12 mb-0 sm:mb-1 lg:mb-2"
        }),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_ConfirmationModal, {
            "show-modal": _ctx.showDeleteModal,
            title: _ctx.it('wallet.summary.accounts.remove.label'),
            caption: _ctx.it('wallet.summary.accounts.remove.caption'),
            onConfirm: _ctx.onRemoveAccount
        }, null, 8, ["show-modal", "title", "caption", "onConfirm"])
    ]));
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/accounts/AccountList.vue?vue&type=template&id=3a11c6dd&ts=true

;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/accounts/SignAddAccount.vue?vue&type=template&id=611576e8&ts=true

const SignAddAccountvue_type_template_id_611576e8_ts_true_hoisted_1 = { class: "grid grid-cols-12 cc-gap" };
const SignAddAccountvue_type_template_id_611576e8_ts_true_hoisted_2 = { class: "grow-0 shrink-0 w-full flex flex-row flex-nowrap items-start justify-between border-b cc-p" };
const SignAddAccountvue_type_template_id_611576e8_ts_true_hoisted_3 = { class: "flex flex-col cc-text-sz" };
const SignAddAccountvue_type_template_id_611576e8_ts_true_hoisted_4 = {
    key: 0,
    class: "col-span-12 flex flex-row flex-nowrap whitespace-pre-wrap p-4"
};
const SignAddAccountvue_type_template_id_611576e8_ts_true_hoisted_5 = { class: "w-full py-0 grid grid-cols-3 lg:grid-cols-4 gap-1.5 xs:gap-2" };
const SignAddAccountvue_type_template_id_611576e8_ts_true_hoisted_6 = ["onClick"];
const SignAddAccountvue_type_template_id_611576e8_ts_true_hoisted_7 = {
    key: 0,
    class: "w-full border-2 absolute top-[99%] z-20 h-8 flex box-border left-0 z-max cc-text-bold cursor-pointer rounded-t-none box-shadow"
};
const SignAddAccountvue_type_template_id_611576e8_ts_true_hoisted_8 = { class: "flex flex-nowrap clear-both cc-bg-light-0 z-max w-full flex flex-nowrap divide-x grid grid-cols-2 box-content" };
const SignAddAccountvue_type_template_id_611576e8_ts_true_hoisted_9 = ["onClick"];
const SignAddAccountvue_type_template_id_611576e8_ts_true_hoisted_10 = {
    key: 0,
    class: "mdi mdi-check cursor-pointer mx-1 z-max"
};
const SignAddAccountvue_type_template_id_611576e8_ts_true_hoisted_11 = ["onClick"];
const SignAddAccountvue_type_template_id_611576e8_ts_true_hoisted_12 = {
    key: 0,
    class: "mdi mdi-close cursor-pointer mx-1"
};
const SignAddAccountvue_type_template_id_611576e8_ts_true_hoisted_13 = { class: "w-full flex flex-nowrap items-center justify-center min-h-10" };
const SignAddAccountvue_type_template_id_611576e8_ts_true_hoisted_14 = {
    key: 0,
    class: "grow pl-6 text-center flex-1 flex items-center justify-start align-middle justify-center tracking-normal"
};
const SignAddAccountvue_type_template_id_611576e8_ts_true_hoisted_15 = ["onKeydown", "onUpdate:modelValue", "on:lostFocus", "min", "max"];
const SignAddAccountvue_type_template_id_611576e8_ts_true_hoisted_16 = { class: "flex grow-0 flex-1 items-center justify-start align-middle justify-center" };
const SignAddAccountvue_type_template_id_611576e8_ts_true_hoisted_17 = ["onClick"];
const SignAddAccountvue_type_template_id_611576e8_ts_true_hoisted_18 = ["onClick"];
const SignAddAccountvue_type_template_id_611576e8_ts_true_hoisted_19 = {
    key: 2,
    class: "mdi mdi-close-circle-outline w-4 mr-2 opacity-0"
};
const SignAddAccountvue_type_template_id_611576e8_ts_true_hoisted_20 = { class: "grid grid-cols-12 cc-gap p-4 w-full" };
const SignAddAccountvue_type_template_id_611576e8_ts_true_hoisted_21 = {
    key: 1,
    class: "col-span-12"
};
const SignAddAccountvue_type_template_id_611576e8_ts_true_hoisted_22 = {
    key: 2,
    class: "col-span-12 grid grid-cols-12 cc-gap mb-2 lg:mb-0"
};
const SignAddAccountvue_type_template_id_611576e8_ts_true_hoisted_23 = { class: "col-span-12 flex flex-row flex-nowrap items-center whitespace-pre-wrap cc-text-sz" };
function SignAddAccountvue_type_template_id_611576e8_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_AccountCreationOverlay = (0,runtime_core_esm_bundler/* resolveComponent */.up)("AccountCreationOverlay");
    const _component_GridButtonPrimary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonPrimary");
    const _component_GridHeadline = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridHeadline");
    const _component_GridText = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridText");
    const _component_GridFormSignWithPassword = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridFormSignWithPassword");
    const _component_LedgerTransport = (0,runtime_core_esm_bundler/* resolveComponent */.up)("LedgerTransport");
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    const _component_IconInfo = (0,runtime_core_esm_bundler/* resolveComponent */.up)("IconInfo");
    const _component_IconError = (0,runtime_core_esm_bundler/* resolveComponent */.up)("IconError");
    const _component_Modal = (0,runtime_core_esm_bundler/* resolveComponent */.up)("Modal");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", SignAddAccountvue_type_template_id_611576e8_ts_true_hoisted_1, [
        (_ctx.walletCreateInProgress)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_AccountCreationOverlay, {
                key: 0,
                status: _ctx.walletCreationStatus
            }, null, 8, ["status"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonPrimary, {
            label: _ctx.t(_ctx.textId + '.button.add'),
            link: _ctx.openDialog,
            disabled: _ctx.isDisabled,
            class: "col-start-0 col-span-6 sm:col-start-10 sm:col-span-3"
        }, null, 8, ["label", "link", "disabled"]),
        (!_ctx.accountLimitReached)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridButtonPrimary, {
                key: 1,
                label: "Discover accounts",
                link: _ctx.openDiscoverDialog,
                disabled: _ctx.isDisabled,
                class: "col-start-7 col-span-6 sm:col-start-10 sm:col-span-3"
            }, null, 8, ["link", "disabled"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (_ctx.showDialog)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_Modal, {
                key: 2,
                narrow: "",
                "full-width-on-mobile": "",
                onClose: _ctx.closeDialog
            }, {
                header: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SignAddAccountvue_type_template_id_611576e8_ts_true_hoisted_2, [
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SignAddAccountvue_type_template_id_611576e8_ts_true_hoisted_3, [
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
                                label: _ctx.discoverDialog ? _ctx.t('wallet.create.account.discover.title') : _ctx.t(_ctx.textId + '.button.add')
                            }, null, 8, ["label"]),
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridText, {
                                text: _ctx.discoverDialog ? _ctx.t('wallet.create.account.discover.caption').replace('####accountLimit####', _ctx.accountLimit) : _ctx.t('wallet.summary.accounts.add.caption')
                            }, null, 8, ["text"])
                        ])
                    ])
                ]),
                content: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                    (!_ctx.discoverDialog)
                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", SignAddAccountvue_type_template_id_611576e8_ts_true_hoisted_4, [
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SignAddAccountvue_type_template_id_611576e8_ts_true_hoisted_5, [
                                ((0,runtime_core_esm_bundler/* openBlock */.wg)(true), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, (0,runtime_core_esm_bundler/* renderList */.Ko)(_ctx.accountSlots, (item, index) => {
                                    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", {
                                        key: index,
                                        onClick: (0,runtime_dom_esm_bundler/* withModifiers */.iM)(($event) => (_ctx.addToSelection($event, item)), ["stop"]),
                                        class: (0,shared_esm_bundler/* normalizeClass */.C_)(["relative noselect cc-area-light cc-text-bold cursor-pointer cc-text-sz h-10 min-h-10 -z-1", '  ' +
                                                ((_ctx.slotAccountMap[index] === _ctx.activeAccount.index) ? 'cc-btn-disabled' : '') + '  ' +
                                                ((_ctx.accountsToAdd.includes(index) || _ctx.activeAccountIndexes.includes(_ctx.slotAccountMap[index])) && !_ctx.accountsToRemove.includes(_ctx.slotAccountMap[index]) ? ' ring-2 cc-ring-highlight ' : ' ')])
                                    }, [
                                        (_ctx.slotEditMap[index])
                                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", SignAddAccountvue_type_template_id_611576e8_ts_true_hoisted_7, [
                                                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SignAddAccountvue_type_template_id_611576e8_ts_true_hoisted_8, [
                                                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", {
                                                        class: "flex w-full items-center justify-evenly",
                                                        onClick: ($event) => { _ctx.submitIndexAdd($event, index, item); }
                                                    }, [
                                                        (_ctx.slotEditMap[index])
                                                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("i", SignAddAccountvue_type_template_id_611576e8_ts_true_hoisted_10))
                                                            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                                                    ], 8, SignAddAccountvue_type_template_id_611576e8_ts_true_hoisted_9),
                                                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", {
                                                        class: "flex w-full items-center justify-evenly",
                                                        onClick: ($event) => (_ctx.onResetIndexAdd(index, $event))
                                                    }, [
                                                        (_ctx.slotEditMap[index])
                                                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("i", SignAddAccountvue_type_template_id_611576e8_ts_true_hoisted_12))
                                                            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                                                    ], 8, SignAddAccountvue_type_template_id_611576e8_ts_true_hoisted_11)
                                                ])
                                            ]))
                                            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SignAddAccountvue_type_template_id_611576e8_ts_true_hoisted_13, [
                                            (!_ctx.slotEditMap[index])
                                                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("span", SignAddAccountvue_type_template_id_611576e8_ts_true_hoisted_14, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.slotEditValueMap[index]), 1))
                                                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                                            (_ctx.slotEditMap[index])
                                                ? (0,runtime_core_esm_bundler/* withDirectives */.wy)(((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("input", {
                                                    key: 1,
                                                    onKeydown: [
                                                        (0,runtime_dom_esm_bundler/* withKeys */.D2)(($event) => { _ctx.submitIndexAdd($event, index, item); }, ["enter"]),
                                                        (0,runtime_dom_esm_bundler/* withKeys */.D2)(($event) => (_ctx.onResetIndexAdd(index, $event)), ["esc"])
                                                    ],
                                                    type: "number",
                                                    "onUpdate:modelValue": ($event) => ((_ctx.slotEditValueMap[index]) = $event),
                                                    onClick: _cache[0] || (_cache[0] = (0,runtime_dom_esm_bundler/* withModifiers */.iM)((event) => event.stopPropagation(), ["stop"])),
                                                    "on:lostFocus": ($event) => (_ctx.validateIndexToAdd(index, item)),
                                                    ref_for: true,
                                                    ref: (event) => _ctx.setItemRef(event, index),
                                                    min: _ctx.minAccountIndex,
                                                    max: _ctx.maxAccountIndex,
                                                    class: "w-full border-2 cc-bg-light-0 border-0 cc-text-color pointer-cursor w-full rounded-t-md text-left"
                                                }, null, 40, SignAddAccountvue_type_template_id_611576e8_ts_true_hoisted_15)), [
                                                    [runtime_dom_esm_bundler/* vModelText */.nr, _ctx.slotEditValueMap[index]]
                                                ])
                                                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                                            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SignAddAccountvue_type_template_id_611576e8_ts_true_hoisted_16, [
                                                (!_ctx.activeAccountIndexes.includes(_ctx.slotAccountMap[index]) && !_ctx.accountsToRemove.includes(_ctx.slotAccountMap[index]) && !_ctx.slotEditMap[index])
                                                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("i", {
                                                        key: 0,
                                                        class: "mdi mdi-pencil cursor-pointer w-4 mr-2",
                                                        onClick: ($event) => (_ctx.editSlot($event, index))
                                                    }, null, 8, SignAddAccountvue_type_template_id_611576e8_ts_true_hoisted_17))
                                                    : (_ctx.activeAccountIndexes.includes(_ctx.slotAccountMap[index]) && !_ctx.indexToAdd.includes(_ctx.slotAccountMap[index]) && _ctx.activeAccount.index !== index && !_ctx.accountsToRemove.includes(_ctx.slotAccountMap[index]))
                                                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("i", {
                                                            key: 1,
                                                            class: "text-2xl mdi mdi-close-circle-outline w-4 mr-4 cursor-pointer",
                                                            onClick: ($event) => (_ctx.addToRemoveList($event, index))
                                                        }, null, 8, SignAddAccountvue_type_template_id_611576e8_ts_true_hoisted_18))
                                                        : (!_ctx.slotEditMap[index])
                                                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("i", SignAddAccountvue_type_template_id_611576e8_ts_true_hoisted_19))
                                                            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                                            ])
                                        ])
                                    ], 10, SignAddAccountvue_type_template_id_611576e8_ts_true_hoisted_6));
                                }), 128))
                            ])
                        ]))
                        : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                ]),
                footer: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                    (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SignAddAccountvue_type_template_id_611576e8_ts_true_hoisted_20, [
                        (!_ctx.isConfirmed && _ctx.isMnemonic)
                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridFormSignWithPassword, {
                                key: 0,
                                onSubmit: _ctx.onSubmitPassword,
                                class: "col-span-12",
                                autocomplete: "off",
                                onDoFormReset: _ctx.resetInput,
                                "submit-enable": !_ctx.inputMapContainsError && !_ctx.isDisabled,
                                "skip-validation": "",
                                "submit-label": _ctx.discoverDialog ? 'common.label.discover' : 'common.label.sign'
                            }, null, 8, ["onSubmit", "onDoFormReset", "submit-enable", "submit-label"]))
                            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                        (_ctx.isLedger && !_ctx.isConfirmed)
                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", SignAddAccountvue_type_template_id_611576e8_ts_true_hoisted_21, [
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_LedgerTransport),
                                (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, { hr: "" })
                            ]))
                            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                        ((_ctx.isLedger || _ctx.isTrezor || _ctx.signError.length > 0) && !_ctx.isConfirmed)
                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", SignAddAccountvue_type_template_id_611576e8_ts_true_hoisted_22, [
                                (0,runtime_core_esm_bundler/* createElementVNode */._)("div", SignAddAccountvue_type_template_id_611576e8_ts_true_hoisted_23, [
                                    (_ctx.signError.length === 0)
                                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_IconInfo, {
                                            key: 0,
                                            class: "w-7 flex-none mr-2"
                                        }))
                                        : ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_IconError, {
                                            key: 1,
                                            class: "w-7 flex-none mr-2"
                                        })),
                                    (_ctx.signError.length === 0)
                                        ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridText, {
                                            key: 2,
                                            text: _ctx.t(_ctx.textId + (_ctx.discoverDialog ? '.discoverInfo' : '.info') + (_ctx.isLedger ? '.ledger' : '.trezor'))
                                        }, null, 8, ["text"]))
                                        : ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridText, {
                                            key: 3,
                                            text: _ctx.signError
                                        }, null, 8, ["text"]))
                                ])
                            ]))
                            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                        (_ctx.isLedger || _ctx.isTrezor)
                            ? (0,runtime_core_esm_bundler/* renderSlot */.WI)(_ctx.$slots, "btnBack", { key: 3 })
                            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
                        (_ctx.isLedger || _ctx.isTrezor)
                            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridButtonPrimary, {
                                key: 4,
                                label: _ctx.discoverDialog ? 'Discover accounts' : _ctx.t(_ctx.textId + '.button.sign'),
                                link: _ctx.discoverDialog ? _ctx.discoverAccount : _ctx.onGenerateAccount,
                                disabled: _ctx.inputMapContainsError || _ctx.isDisabled || (_ctx.accountsToAdd.length === 0 && !_ctx.discoverDialog),
                                class: "col-start-0 col-span-12 lg:col-start-7 lg:col-span-6"
                            }, null, 8, ["label", "link", "disabled"]))
                            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                    ])
                ]),
                _: 3
            }, 8, ["onClose"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
    ]));
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/accounts/SignAddAccount.vue?vue&type=template&id=611576e8&ts=true

// EXTERNAL MODULE: ./src/composables/ccw/store/useTrezorDevice.ts
var useTrezorDevice = __webpack_require__(83368);
// EXTERNAL MODULE: ./src/composables/ccw/store/useLedgerDevice.ts
var useLedgerDevice = __webpack_require__(47617);
// EXTERNAL MODULE: ./src/components/ccw/overlay/AccountCreationOverlay.vue + 4 modules
var AccountCreationOverlay = __webpack_require__(21928);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridInput.vue + 4 modules
var GridInput = __webpack_require__(27209);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/icons/IconPencil.vue + 4 modules
var IconPencil = __webpack_require__(44814);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridButtonPrimary.vue + 3 modules
var GridButtonPrimary = __webpack_require__(12559);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/icons/IconInfo.vue + 4 modules
var IconInfo = __webpack_require__(31599);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/icons/IconCheck.vue + 4 modules
var IconCheck = __webpack_require__(59548);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/icons/IconError.vue + 4 modules
var IconError = __webpack_require__(66934);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/forms/GridFormSignWithPassword.vue + 3 modules
var GridFormSignWithPassword = __webpack_require__(58315);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/settings/LedgerTransport.vue + 4 modules
var LedgerTransport = __webpack_require__(44844);
// EXTERNAL MODULE: ./src/components/ccw/modal/Modal.vue + 4 modules
var Modal = __webpack_require__(61017);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/WalletLib.ts + 1 modules
var WalletLib = __webpack_require__(46805);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/AccountLib.ts
var AccountLib = __webpack_require__(19276);
// EXTERNAL MODULE: ./src/lib/ExtAppWalletManagerLib.ts
var ExtAppWalletManagerLib = __webpack_require__(12736);
// EXTERNAL MODULE: ./src/lib/utils/WalletCreationStatusMapper.ts
var WalletCreationStatusMapper = __webpack_require__(7387);
// EXTERNAL MODULE: ../ccw-lib2/core/IAppWalletCreationStatus.ts
var IAppWalletCreationStatus = __webpack_require__(87117);
// EXTERNAL MODULE: ./src/ext/AppWalletManager.ts + 1 modules
var AppWalletManager = __webpack_require__(33931);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/CSLConstants.ts
var CSLConstants = __webpack_require__(22798);
// EXTERNAL MODULE: ../ccw-lib2/core/lib/LibUtils.ts
var LibUtils = __webpack_require__(10751);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/accounts/SignAddAccount.vue?vue&type=script&lang=ts

;



























const addHDAccount = ExtAppWalletManagerLib/* AWM.addHDAccount */.b.addHDAccount;
/* harmony default export */ const SignAddAccountvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'SignAddAccount',
    components: {
        AccountCreationOverlay: AccountCreationOverlay/* default */.Z,
        GridFormSignWithPassword: GridFormSignWithPassword/* default */.Z,
        GridHeadline: GridHeadline/* default */.Z,
        GridText: GridText/* default */.Z,
        GridSpace: GridSpace/* default */.Z,
        GridButtonPrimary: GridButtonPrimary/* default */.Z,
        GridInput: GridInput/* default */.Z,
        Modal: Modal/* default */.Z,
        IconPencil: IconPencil/* default */.Z,
        IconInfo: IconInfo/* default */.Z,
        IconCheck: IconCheck/* default */.Z,
        IconError: IconError/* default */.Z,
        LedgerTransport: LedgerTransport/* default */.Z
    },
    props: {
        type: { type: String, required: false, default: '' },
        textId: { type: String, required: true, default: '' },
        showLabel: { type: Boolean, required: false, default: true }
    },
    emits: ['submit'],
    setup(props, { emit }) {
        const { t } = (0,useTranslation/* useTranslation */.$)();
        const { initiateTrezor, getTrezorPublicKey, getTrezorDerivationTypeFromWalletId } = (0,useTrezorDevice/* useTrezorDevice */.S)();
        const { initiateLedger, getLedgerPublicKey } = (0,useLedgerDevice/* useLedgerDevice */.t)();
        const $q = (0,use_quasar/* default */.Z)();
        const accountIndexToAdd = (0,reactivity_esm_bundler/* ref */.iH)();
        const accountIndexError = (0,reactivity_esm_bundler/* ref */.iH)();
        const { isActiveWalletSyncing, activeAccountList, activeWalletData, activeWalletId, activeAccount, } = (0,useActiveWallet/* useActiveWallet */.r)();
        const { getWalletById } = (0,useWalletList/* useWalletList */.M)();
        const { networkId } = (0,useNetworkId/* useNetworkId */.h)();
        const accountLimitReached = (0,runtime_core_esm_bundler/* computed */.Fl)(() => (activeWalletData.value?.accounts.length ?? 1) > WalletLib/* accountLimit */.JN);
        const spendingPassword = (0,reactivity_esm_bundler/* ref */.iH)('');
        const signError = (0,reactivity_esm_bundler/* ref */.iH)('');
        const isConfirmed = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const isDisabled = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const showDialog = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const isMnemonic = (0,runtime_core_esm_bundler/* computed */.Fl)(() => (activeAccount.value?.signType ?? '') === 'mnemonic');
        const isLedger = (0,runtime_core_esm_bundler/* computed */.Fl)(() => (activeAccount.value?.signType ?? '') === 'ledger');
        const isTrezor = (0,runtime_core_esm_bundler/* computed */.Fl)(() => (activeAccount.value?.signType ?? '') === 'trezor');
        const walletCreateInProgress = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const walletCreationStatus = (0,reactivity_esm_bundler/* ref */.iH)('');
        const minAccountIndex = (0,reactivity_esm_bundler/* ref */.iH)(null);
        const resetInput = () => {
            accountsToRemove.value = [];
            accountsToAdd.value = [];
        };
        const showAmountInfo = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const showIndexInfo = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const maxAccountIndex = 10000;
        const amountToAdd = (0,runtime_core_esm_bundler/* computed */.Fl)(() => {
            return [...Array(WalletLib/* accountLimit */.JN - activeAccountList.value.length).keys()];
        });
        const indexToAdd = (0,runtime_core_esm_bundler/* computed */.Fl)(() => {
            let activeIndexes = activeAccountList.value.map((value) => value.index);
            return [...Array(WalletLib/* accountLimit */.JN).keys()].filter((index) => !activeIndexes.includes(index));
        });
        // the tiles that are displayed. Always numbered ascending from 0 to account limit
        const accountSlots = (0,reactivity_esm_bundler/* ref */.iH)([...Array(WalletLib/* accountLimit */.JN).keys()]);
        // the mapping from 'slot number' => 'account that slot is showing'
        const slotAccountMap = (0,reactivity_esm_bundler/* ref */.iH)([]);
        // what account is currently being edited
        const slotEditMap = (0,reactivity_esm_bundler/* ref */.iH)([...Array(WalletLib/* accountLimit */.JN).fill(false)]);
        // contains the values (actual account indexes) that were edited
        const slotEditValueMap = (0,reactivity_esm_bundler/* ref */.iH)([]);
        // contains errors for the map inputs, empty input = no error
        const slotEditErrorMap = (0,reactivity_esm_bundler/* ref */.iH)([...Array(WalletLib/* accountLimit */.JN).fill('')]);
        const slotInputFields = (0,reactivity_esm_bundler/* ref */.iH)([]);
        const restSlotMap = () => {
            accountSlots.value = [...Array(WalletLib/* accountLimit */.JN).keys()];
            slotAccountMap.value = [];
            slotEditMap.value = [...Array(WalletLib/* accountLimit */.JN).fill(false)];
            slotEditValueMap.value = [];
            slotEditErrorMap.value = [...Array(WalletLib/* accountLimit */.JN).fill('')];
        };
        // aggregated check to see if submit button can be enabled
        const inputMapContainsError = (0,runtime_core_esm_bundler/* computed */.Fl)(() => slotEditErrorMap.value.some((error, index) => error !== ''));
        (0,runtime_core_esm_bundler/* onBeforeMount */.wF)(() => {
            buildAccountIndexSlotMap();
        });
        const buildAccountIndexSlotMap = () => {
            restSlotMap();
            // create a mapping from account slot to actual account
            // always sort depending on account used
            const accountsUsed = activeWalletData.value?.accounts.reduceRight((indexList, currentAccount) => {
                return indexList.concat([currentAccount.index]);
            }, []).sort((indexA, indexB) => indexA > indexB ? 1 : -1) ?? [];
            /**
             * Build up a list of account mapping up to the max account limit. Fill up the gaps if possible with non used
             * accounts to make the layout more consistent.
             *
             * There are 2 cases:
             * Case 1: All used accounts fall within the first 24 (max-accounts) => fill all slots with numbers 0 to 23 and map the accounts that are used into the slots
             * Case 2: More then first 24 accounts are used => use the first elements as the used account and the build an ascending list of accounts up to account limit
             * e.g.
             * - Case1: Accounts used 0 to 23 => 24 accounts used, highest account 23 => 24 > 23 =>  every tile is from 0 to 23 is used with corresponding account
             * - Case1: Accounts used [0, 1, 3, 10] =>  4 accounts used, the highest account number 10  => 24 > 10 -> fill consecutive cells with ascending numbers 0..23
             * - Case2: Accounts used [0, 1, 10, 24] => 4 accounts used, the highest account number 24  => 24 !> 24 -> fill first 4 with 0,1,10,24 and then rest 2..9, 11..22
             * - Case2: Accounts used [0, 100, 200] => 3  accounts used, the highest account number 200 => 24 !> 200 -> fill first 4 with 0,100,200 and then rest 2..21
             */
            const highestAccountNumber = Math.max(...accountsUsed);
            let fillAscending = true;
            if (accountsUsed.length <= WalletLib/* accountLimit */.JN && highestAccountNumber > WalletLib/* accountLimit */.JN - 1) {
                fillAscending = false;
            }
            while (slotAccountMap.value.length <= WalletLib/* accountLimit */.JN - 1) {
                const slotIndexToFill = slotAccountMap.value.length;
                if (fillAscending) {
                    slotAccountMap.value.push(slotIndexToFill);
                }
                else {
                    // find account to used that is not part of slotAccountMap
                    const accountIndexToAdd = accountsUsed.find((accountIndex) => !slotAccountMap.value.includes(accountIndex));
                    if (accountIndexToAdd !== undefined) {
                        slotAccountMap.value.push(accountIndexToAdd);
                    }
                    else {
                        let indexToAdd = 0;
                        while (slotAccountMap.value.includes(indexToAdd)) {
                            indexToAdd++;
                        }
                        if (minAccountIndex.value === null)
                            minAccountIndex.value = indexToAdd;
                        slotAccountMap.value.push(indexToAdd);
                    }
                }
            }
            // Map them to the editMap
            slotAccountMap.value.forEach((accountIndex, slotIndex) => slotEditValueMap.value[slotIndex] = String(accountIndex));
        };
        const editSlot = (event, slotNumber) => {
            event.stopPropagation();
            slotEditMap.value[slotNumber] = true;
            (0,runtime_core_esm_bundler/* nextTick */.Y3)(() => {
                slotInputFields.value[slotNumber].focus();
            });
        };
        const onResetIndexAdd = (index, e) => {
            e.stopPropagation();
            slotEditMap.value[index] = false;
            slotEditValueMap.value[index] = String(slotAccountMap.value[index]);
            addToSelection(e, index, false, true);
            clearErrorForInput(index);
            updateErrorMessage();
        };
        const validateIndexToAdd = (index, item) => {
            submitIndexAdd(null, index, item);
        };
        const submitIndexAdd = (event, index, item) => {
            if (check(index)) {
                slotEditMap.value[index] = false;
                isDisabled.value = false;
                addToSelection(event, item, true);
            }
            else {
                event?.stopPropagation();
                slotInputFields.value[index].focus();
            }
        };
        const check = (index) => {
            signError.value = '';
            if (slotEditValueMap.value[index].length === 0 || Number.isNaN(slotEditValueMap.value[index])) {
                addSlotError(index, t(props.textId + '.error.noNumber'));
                return false;
            }
            if (Number(slotEditValueMap.value[index]) > maxAccountIndex) {
                addSlotError(index, t(props.textId + '.error.maxAccount').replace('###MAX###', String(maxAccountIndex)));
                return false;
            }
            signError.value = '';
            const accountToAdd = Number(slotEditValueMap.value[index]);
            // check that added index is not already used by an active account
            const accountIndexUsed = activeAccountList.value.find((account) => account.index === accountToAdd);
            if (accountIndexUsed) {
                const indexUsed = slotAccountMap.value.indexOf(accountToAdd);
                if (indexUsed !== -1) {
                    addSlotError(index, t(props.textId + '.error.inUse').replace('###INDEX###', String(accountToAdd)).replace('###SLOT###', String(indexUsed + 1)));
                    return false;
                }
            }
            // check that we do not have duplicate indexes in currently edited entries
            const indexUsedInEdit = slotEditValueMap.value.find((value, editIndex) => Number(value) === accountToAdd && editIndex !== index);
            if (indexUsedInEdit !== undefined) {
                addSlotError(index, t(props.textId + '.error.enable').replace('###INDEX###', String(accountToAdd)).replace('###SLOT###', String(Number(indexUsedInEdit) + 1)));
                return false;
            }
            clearErrorForInput(index);
            return true;
        };
        const addSlotError = (index, error) => {
            slotEditErrorMap.value[index] = error;
            updateErrorMessage();
        };
        const updateErrorMessage = () => {
            if (!inputMapContainsError.value) {
                signError.value = '';
            }
            else {
                signError.value = 'Slot errors: \n' + slotEditErrorMap.value.reduceRight((text, entry) => entry != '' ? text = entry + '\n' + text : text, '');
            }
        };
        const clearErrorForInput = (index) => {
            slotEditErrorMap.value[index] = '';
        };
        const activeAccountIndexes = (0,runtime_core_esm_bundler/* computed */.Fl)(() => activeAccountList.value.map((value) => value.index));
        const accountsToAdd = (0,reactivity_esm_bundler/* ref */.iH)([]);
        const accountsToRemove = (0,reactivity_esm_bundler/* ref */.iH)([]);
        const isActive = (index) => {
            return activeAccountList.value.map((value) => value.index).includes(index);
        };
        const canBeAdded = (index) => {
            if (!isActive(Number(slotEditValueMap.value[index])) && !accountsToAdd.value.includes(index)) {
                return true;
            }
            if (accountsToRemove.value.includes(Number(slotEditValueMap.value[index]))) {
                return true;
            }
            if (accountsToRemove.value.includes(index)) {
                return true;
            }
            if (slotEditMap.value[index]) {
                return false;
            }
            return false;
        };
        const canBeRemoved = (index) => {
            if (!isActive(index)) {
                return false;
            }
            return true;
        };
        const addToSelection = (event, index, force = false, forceRemoval = false) => {
            event?.stopPropagation();
            if (!forceRemoval && (canBeAdded(index) || force)) {
                if (accountsToRemove.value.includes(Number(slotEditValueMap.value[index]))) {
                    accountsToRemove.value.splice(accountsToRemove.value.indexOf(Number(slotEditValueMap.value[index])), 1);
                }
                accountsToAdd.value.push(index);
            }
            else {
                if (accountsToAdd.value.includes(index)) {
                    accountsToAdd.value.splice(accountsToAdd.value.indexOf(index), 1);
                }
            }
            updateErrorMessage();
        };
        const addToRemoveList = (event, index) => {
            event.stopPropagation();
            if (canBeRemoved(slotAccountMap.value[index])) {
                if (accountsToAdd.value.includes(slotAccountMap.value[index])) {
                    accountsToAdd.value.splice(accountsToAdd.value.indexOf(slotAccountMap.value[index]), 1);
                }
                accountsToRemove.value.push(slotAccountMap.value[index]);
            }
        };
        (0,runtime_core_esm_bundler/* watch */.YP)(spendingPassword, () => signError.value = '');
        function checkMaxAccounts() {
            const wallet = activeWalletData.value;
            if (wallet) {
                isDisabled.value = wallet.accounts.length >= WalletLib/* accountLimit */.JN;
                if (isDisabled.value) {
                    signError.value = t(props.textId + '.error.accountLimit');
                }
                else {
                    signError.value = '';
                }
            }
        }
        checkMaxAccounts();
        function onSubmit() { emit('submit'); }
        const discoverDialog = (0,reactivity_esm_bundler/* ref */.iH)(false);
        const openDiscoverDialog = () => {
            openDialog(true);
        };
        const openDialog = (discover = false) => {
            buildAccountIndexSlotMap();
            discoverDialog.value = discover;
            showDialog.value = true;
        };
        const removeAccounts = async () => {
            accountsToRemove.value.forEach((account) => {
                activeAccountList.value
                    .filter((activeAccount) => activeAccount.index === account)
                    .map(async (accountToRemove) => await (0,AppWalletManager.removeHDAccount)(activeWalletId.value, { accountPubBech32: (0,AccountLib/* prepareAccountKey */.Cl)(accountToRemove.pub) }));
            });
        };
        async function onSubmitPassword(payload) {
            const wallet = activeWalletData.value;
            if (!wallet)
                return;
            if (discoverDialog.value) {
                await discoverAccount(payload.password);
                return;
            }
            if (wallet.signType === 'mnemonic' && (0,WalletLib/* verifyRootKeyPassword */.WM)(wallet, payload.password)) {
                spendingPassword.value = payload.password;
                if (activeAccountList.value.length >= 24) {
                    signError.value = t(props.textId + '.error.accountLimit');
                    isDisabled.value = true;
                    return;
                }
                isDisabled.value = false;
                let accountCreationSuccess = true;
                walletCreateInProgress.value = true;
                if (accountsToRemove.value.length > 0) {
                    walletCreationStatus.value = (0,WalletCreationStatusMapper/* getStatusInfo */.I)((0,IAppWalletCreationStatus/* createIAppWalletCreationStatus */.e)("initCreation", wallet.id), t);
                    await removeAccounts();
                }
                for (let i = 0; i < accountsToAdd.value.length; i++) {
                    const accountToAdd = Number(slotEditValueMap.value[accountsToAdd.value[i]]);
                    accountCreationSuccess &&= await addHDAccount(wallet.id, {
                        password: payload.password,
                        accountIndex: accountToAdd,
                        accountPubBech32: null
                    });
                    walletCreationStatus.value = (0,WalletCreationStatusMapper/* getStatusInfo */.I)((0,IAppWalletCreationStatus/* createIAppWalletCreationStatus */.e)("createAccount", wallet.id, i + 1, accountsToAdd.value.length), t);
                }
                walletCreateInProgress.value = false;
                if (!accountCreationSuccess) {
                    signError.value = t(props.textId + '.error.general');
                }
                else {
                    showDialog.value = false;
                    resetInput();
                    $q.notify({
                        type: 'positive',
                        message: 'Account added.',
                        position: 'top-left',
                        timeout: 3000
                    });
                }
                buildAccountIndexSlotMap();
                checkMaxAccounts();
            }
            else {
                signError.value = t(props.textId + '.error.password');
            }
        }
        async function onGenerateAccount() {
            const wallet = activeWalletData.value;
            if (!wallet || !activeAccount.value)
                return;
            if ((isLedger.value || isTrezor.value)) {
                signError.value = '';
                isDisabled.value = false;
                $q.loading.show({
                    message: t(props.textId + '.loading.' + activeAccount.value?.signType),
                    html: true
                });
                const pubKeyList = [];
                try {
                    const currentActiveAccount = wallet.accounts.find((account) => account.index === activeAccount.value.index);
                    if (!currentActiveAccount)
                        return;
                    const accountIndexesToAdd = slotEditValueMap.value
                        .map((value, index) => accountsToAdd.value.includes(index) ? Number(value) : null)
                        .filter((index) => index !== null);
                    if (accountIndexesToAdd.length > 0) {
                        // add current account index to front so we can compare against it
                        accountIndexesToAdd.unshift(currentActiveAccount.index);
                        if (isLedger.value) {
                            await initiateLedger(null, undefined, undefined, activeWalletId.value);
                            pubKeyList.push(...(await getLedgerPublicKey(CSLConstants/* purpose.hdwallet */.Gr.hdwallet, 0, 0, accountIndexesToAdd)));
                        }
                        else if (isTrezor.value) {
                            await initiateTrezor(undefined, activeWalletId.value);
                            pubKeyList.push(...(await getTrezorPublicKey(CSLConstants/* purpose.hdwallet */.Gr.hdwallet, 0, 0, accountIndexesToAdd, getTrezorDerivationTypeFromWalletId(activeWalletId.value ?? ''))));
                        }
                    }
                    if (pubKeyList.length === 0 && accountsToRemove.value.length === 0) {
                        signError.value = t(props.textId + '.error.nokey');
                        $q.loading.hide();
                    }
                    else if (currentActiveAccount.pub !== pubKeyList[0] && accountIndexesToAdd.length > 0) {
                        signError.value = t(props.textId + '.error.mismatch');
                        $q.loading.hide();
                    }
                    else {
                        $q.loading.hide();
                        let accountCreationSuccess = true;
                        walletCreateInProgress.value = true;
                        if (accountsToRemove.value.length > 0) {
                            walletCreationStatus.value = (0,WalletCreationStatusMapper/* getStatusInfo */.I)((0,IAppWalletCreationStatus/* createIAppWalletCreationStatus */.e)("initCreation", wallet.id), t);
                            await removeAccounts();
                        }
                        for (let i = 0; i < accountIndexesToAdd.length; i++) {
                            accountCreationSuccess = await addHDAccount(wallet.id, {
                                password: null,
                                accountIndex: accountIndexesToAdd[i],
                                accountPubBech32: (0,AccountLib/* prepareAccountKey */.Cl)(pubKeyList[i])
                            });
                            walletCreationStatus.value = (0,WalletCreationStatusMapper/* getStatusInfo */.I)((0,IAppWalletCreationStatus/* createIAppWalletCreationStatus */.e)("createAccount", wallet.id, i + 1, accountIndexesToAdd.length), t);
                        }
                        walletCreateInProgress.value = false;
                        if (!accountCreationSuccess) {
                            signError.value = t(props.textId + '.error.general');
                        }
                        else {
                            showDialog.value = false;
                            resetInput();
                            $q.notify({
                                type: 'positive',
                                message: 'Account added.',
                                position: 'top-left',
                                timeout: 3000
                            });
                        }
                        checkMaxAccounts();
                    }
                }
                catch (err) {
                    $q.loading.hide();
                    signError.value = err.message;
                }
                if (signError.value.length === 0) {
                    isConfirmed.value = true;
                    setTimeout(() => {
                        onSubmit();
                        buildAccountIndexSlotMap();
                    }, 25);
                }
            }
            else {
                signError.value = t(props.textId + '.error.nohw');
            }
        }
        const getAccountIdxTOCreate = (wallet) => {
            // build list of pub keys for non-existing accounts
            const existingAccounts = wallet.accounts.reduceRight((indexed, account) => indexed.concat([account.index]), []);
            return [...Array(WalletLib/* accountLimit */.JN - (existingAccounts.length - 1)).keys()].filter((index) => !existingAccounts.includes(index));
        };
        const buildPubKeyListOfWallet = async (wallet, accountsToCreateIdx) => {
            const pubKeyList = [];
            if (accountsToCreateIdx.length > 0) {
                if (isLedger.value) {
                    await initiateLedger(null, undefined, undefined, activeWalletId.value);
                    pubKeyList.push(...(await getLedgerPublicKey(CSLConstants/* purpose.hdwallet */.Gr.hdwallet, 0, 0, accountsToCreateIdx)));
                }
                else if (isTrezor.value) {
                    await initiateTrezor(undefined, activeWalletId.value);
                    pubKeyList.push(...(await getTrezorPublicKey(CSLConstants/* purpose.hdwallet */.Gr.hdwallet, 0, 0, accountsToCreateIdx, getTrezorDerivationTypeFromWalletId(activeWalletId.value ?? ''))));
                }
            }
            else {
                return [];
            }
            return pubKeyList;
        };
        const discoverHwAccounts = async () => {
            const creationHook = async (status) => {
                walletCreationStatus.value = (0,WalletCreationStatusMapper/* getStatusInfo */.I)(status, t);
            };
            const wallet = getWalletById(activeWalletId.value);
            if (!wallet || !wallet.wallet) {
                return;
            }
            signError.value = '';
            isDisabled.value = false;
            try {
                $q.loading.show({
                    message: t(props.textId + '.loading.' + activeAccount.value?.signType),
                    html: true
                });
                const accountIndexes = getAccountIdxTOCreate(wallet.wallet);
                const pubKeyList = await buildPubKeyListOfWallet(wallet.wallet, accountIndexes);
                $q.loading.hide();
                await (0,LibUtils/* sleep */._v)(50);
                const indexedKeyList = [];
                for (let i = accountIndexes.length - 1; i >= 0; i--) {
                    indexedKeyList[accountIndexes[i]] = pubKeyList.pop();
                }
                walletCreateInProgress.value = true;
                // check which pub keys need to be created
                const accountsToCreate = await (0,WalletLib/* createAdditionalAccountsHardwareWallet */.l0)(networkId.value, wallet.wallet, indexedKeyList, creationHook);
                let accountCreationSuccess = true;
                for (let i = 0; i < accountsToCreate.length; i++) {
                    accountCreationSuccess = await addHDAccount(wallet.wallet.id, {
                        password: null,
                        accountIndex: accountsToCreate[i].index,
                        accountPubBech32: (0,AccountLib/* prepareAccountKey */.Cl)(accountsToCreate[i].pub)
                    });
                    walletCreationStatus.value = (0,WalletCreationStatusMapper/* getStatusInfo */.I)((0,IAppWalletCreationStatus/* createIAppWalletCreationStatus */.e)("createAccount", wallet.wallet.id, i + 1, accountsToCreate.length), t);
                }
                $q.notify({
                    type: 'positive',
                    message: 'Accounts added.',
                    position: 'top-left',
                    timeout: 3000
                });
                showDialog.value = false;
            }
            catch (err) {
                $q.loading.hide();
                signError.value = err.message;
            }
        };
        const discoverMnemonicAccount = async (password) => {
            const creationHook = async (status) => {
                walletCreationStatus.value = (0,WalletCreationStatusMapper/* getStatusInfo */.I)(status, t);
            };
            const wallet = getWalletById(activeWalletId.value);
            if (!wallet || !wallet.wallet) {
                return;
            }
            walletCreateInProgress.value = true;
            try {
                const accountsToCreate = await (0,WalletLib/* createAdditionalAccountsMnemonic */.yx)(networkId.value, wallet.wallet, password, creationHook);
                let accountCreationSuccess = true;
                for (let i = 0; i < accountsToCreate.length; i++) {
                    const accountToAdd = accountsToCreate[i];
                    accountCreationSuccess &&= await addHDAccount(wallet.wallet.id, {
                        password: password,
                        accountIndex: accountToAdd.index,
                        accountPubBech32: null
                    });
                    walletCreationStatus.value = (0,WalletCreationStatusMapper/* getStatusInfo */.I)((0,IAppWalletCreationStatus/* createIAppWalletCreationStatus */.e)("createAccount", wallet.wallet.id, i + 1, accountsToCreate.length), t);
                }
                $q.notify({
                    type: 'positive',
                    message: 'Accounts added.',
                    position: 'top-left',
                    timeout: 3000
                });
                showDialog.value = false;
            }
            catch (error) {
                signError.value = 'wrong password';
            }
        };
        const discoverAccount = async (password = '') => {
            discoverDialog.value = true;
            if (!networkId.value) {
                return;
            }
            if ((isLedger.value || isTrezor.value)) {
                await discoverHwAccounts();
            }
            else {
                await discoverMnemonicAccount(password);
            }
            walletCreateInProgress.value = false;
        };
        const toggleShowAmountInfo = () => { showAmountInfo.value = !showAmountInfo.value; };
        const toggleShowIndexInfo = () => { showIndexInfo.value = !showIndexInfo.value; };
        const closeDialog = (e) => {
            showDialog.value = false;
            isConfirmed.value = false;
            slotEditMap.value.forEach((editFlag, editIndex) => {
                slotEditMap.value[editIndex] = false;
                clearErrorForInput(editIndex);
            });
            updateErrorMessage();
            resetInput();
        };
        const setItemRef = (el, index) => {
            if (el && !slotInputFields.value[index]) {
                slotInputFields.value[index] = el;
            }
        };
        return {
            t,
            isMnemonic,
            isLedger,
            isTrezor,
            isConfirmed,
            isDisabled,
            spendingPassword,
            signError,
            amountToAdd,
            showDialog,
            indexToAdd,
            showAmountInfo,
            showIndexInfo,
            openDialog,
            openDiscoverDialog,
            toggleShowAmountInfo,
            toggleShowIndexInfo,
            walletCreationStatus,
            walletCreateInProgress,
            accountLimit: WalletLib/* accountLimit */.JN,
            minAccountIndex,
            onGenerateAccount,
            onSubmit,
            onSubmitPassword,
            accountSlots,
            slotAccountMap,
            addToSelection,
            accountsToAdd,
            activeAccount,
            activeAccountIndexes,
            accountsToRemove,
            addToRemoveList,
            resetInput,
            discoverAccount,
            accountLimitReached,
            discoverDialog,
            accountIndexError,
            accountIndexToAdd,
            onResetIndexAdd,
            validateIndexToAdd,
            submitIndexAdd,
            editSlot,
            slotEditMap,
            slotEditValueMap,
            inputMapContainsError,
            closeDialog,
            maxAccountIndex,
            slotInputFields,
            setItemRef
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/accounts/SignAddAccount.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/accounts/SignAddAccount.vue




;
const SignAddAccount_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(SignAddAccountvue_type_script_lang_ts, [['render',SignAddAccountvue_type_template_id_611576e8_ts_true_render]])

/* harmony default export */ const SignAddAccount = (SignAddAccount_exports_);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridTextArea.vue + 4 modules
var GridTextArea = __webpack_require__(15660);
// EXTERNAL MODULE: ./src/components/ccw/modal/ConfirmationModal.vue + 4 modules
var ConfirmationModal = __webpack_require__(65455);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/accounts/AccountItem.vue?vue&type=template&id=d9c4fbe0&ts=true

const AccountItemvue_type_template_id_d9c4fbe0_ts_true_hoisted_1 = { class: "col-span-12 sm:col-span-6 xl:col-span-4 grid grid-cols-12 cc-gap" };
function AccountItemvue_type_template_id_d9c4fbe0_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_AccountItemBalance = (0,runtime_core_esm_bundler/* resolveComponent */.up)("AccountItemBalance");
    const _component_AccountItemDelegation = (0,runtime_core_esm_bundler/* resolveComponent */.up)("AccountItemDelegation");
    const _component_GridButtonWarning = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonWarning");
    const _component_GridButtonPrimary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonPrimary");
    const _component_GridSpace = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSpace");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", AccountItemvue_type_template_id_d9c4fbe0_ts_true_hoisted_1, [
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_AccountItemBalance, {
            account: _ctx.account,
            "is-active-account": _ctx.isActiveAccount,
            syncing: _ctx.syncing,
            "allow-editing-name": true
        }, null, 8, ["account", "is-active-account", "syncing"]),
        (_ctx.stakeKey)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_AccountItemDelegation, {
                key: 0,
                "is-active-account": _ctx.isActiveAccount,
                "stake-info": _ctx.stakeInfo,
                "stake-key": _ctx.stakeKey
            }, null, 8, ["is-active-account", "stake-info", "stake-key"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (!_ctx.isActiveAccount)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridButtonWarning, {
                key: 1,
                label: _ctx.it('common.label.remove'),
                link: _ctx.onRemoveAccount,
                disabled: _ctx.isActiveAccount,
                "btn-style": "cc-text-md cc-btn-warning-light",
                class: "col-start-1 col-span-6"
            }, null, 8, ["label", "link", "disabled"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonPrimary, {
            class: (0,shared_esm_bundler/* normalizeClass */.C_)([_ctx.isActiveAccount ? 'opacity-0' : '', "col-start-7 col-span-6"]),
            label: _ctx.isActiveAccount ? _ctx.it('common.label.activeAccount') : _ctx.it('common.label.activate'),
            link: _ctx.onActivateAccount,
            disabled: _ctx.isActiveAccount
        }, null, 8, ["class", "label", "link", "disabled"]),
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridSpace, {
            hr: "",
            class: "mt-1.5 col-span-12"
        })
    ]));
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/accounts/AccountItem.vue?vue&type=template&id=d9c4fbe0&ts=true

// EXTERNAL MODULE: ./src/components/ccw/grid/v2/accounts/AccountItemBalance.vue + 4 modules
var AccountItemBalance = __webpack_require__(20285);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/accounts/AccountItemDelegation.vue?vue&type=template&id=23374433&scoped=true&ts=true

const AccountItemDelegationvue_type_template_id_23374433_scoped_true_ts_true_withScopeId = n => (_pushScopeId("data-v-23374433"), n = n(), _popScopeId(), n);
const AccountItemDelegationvue_type_template_id_23374433_scoped_true_ts_true_hoisted_1 = { class: "col-span-12 grid grid-cols-12" };
const AccountItemDelegationvue_type_template_id_23374433_scoped_true_ts_true_hoisted_2 = { class: "relative w-full flex-1 overflow-hidden flex justify-center items-center" };
const AccountItemDelegationvue_type_template_id_23374433_scoped_true_ts_true_hoisted_3 = { class: "flex-1 w-full h-full flex flex-col flex-nowrap justify-center items-center" };
function AccountItemDelegationvue_type_template_id_23374433_scoped_true_ts_true_render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridStakePoolList = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridStakePoolList");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", AccountItemDelegationvue_type_template_id_23374433_scoped_true_ts_true_hoisted_1, [
        (_ctx.afterNextDelegations.length > 0)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridStakePoolList, {
                key: 0,
                poolList: _ctx.afterNextDelegations,
                delegatedPoolList: _ctx.afterNextDelegations,
                selected: _ctx.isActiveAccount,
                "info-only": ""
            }, null, 8, ["poolList", "delegatedPoolList", "selected"]))
            : (_ctx.nextDelegation.length > 0)
                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridStakePoolList, {
                    key: 1,
                    poolList: _ctx.nextDelegation,
                    delegatedPoolList: _ctx.nextDelegation,
                    selected: _ctx.isActiveAccount,
                    "info-only": ""
                }, null, 8, ["poolList", "delegatedPoolList", "selected"]))
                : (_ctx.currentEpochDelegation.length > 0)
                    ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridStakePoolList, {
                        key: 2,
                        poolList: _ctx.currentEpochDelegation,
                        delegatedPoolList: _ctx.currentEpochDelegation,
                        selected: _ctx.isActiveAccount,
                        "info-only": ""
                    }, null, 8, ["poolList", "delegatedPoolList", "selected"]))
                    : ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", {
                        key: 3,
                        class: (0,shared_esm_bundler/* normalizeClass */.C_)(["col-span-12 overflow-hidden cc-area-undelegated flex-1 w-full min-h-16 inline-flex flex-col flex-nowrap justify-start items-start", (_ctx.isActiveAccount ? 'cc-selected' : 'cc-not-selected') + ' '])
                    }, [
                        (0,runtime_core_esm_bundler/* createElementVNode */._)("div", AccountItemDelegationvue_type_template_id_23374433_scoped_true_ts_true_hoisted_2, [
                            (0,runtime_core_esm_bundler/* createElementVNode */._)("div", AccountItemDelegationvue_type_template_id_23374433_scoped_true_ts_true_hoisted_3, (0,shared_esm_bundler/* toDisplayString */.zw)(_ctx.it('wallet.delegation.info.undelegated')), 1)
                        ])
                    ], 2))
    ]));
}

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/accounts/AccountItemDelegation.vue?vue&type=template&id=23374433&scoped=true&ts=true

// EXTERNAL MODULE: ../ccw-lib2/core/lib/CSLDerivation.ts
var CSLDerivation = __webpack_require__(18247);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/accounts/AccountItemDelegation.vue?vue&type=script&lang=ts










/* harmony default export */ const AccountItemDelegationvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'AccountItemDelegation',
    components: {
        GridText: GridText/* default */.Z,
        GridSpace: GridSpace/* default */.Z,
        GridHeadline: GridHeadline/* default */.Z,
        GridPoolLogo: GridPoolLogo/* default */.Z,
        GridStakePoolList: GridStakePoolList/* default */.Z
    },
    props: {
        stakeInfo: { type: Object, required: false, default: null },
        isActiveAccount: { type: Boolean, required: false, default: false },
        stakeKey: { type: Object, required: false, default: null }
    },
    setup(props) {
        const { it } = (0,useTranslation/* useTranslation */.$)();
        const { poolList } = (0,usePoolAPI/* usePoolAPI */.b)();
        const { generateDelegationHistory } = (0,useDelegationHistory/* useDelegationHistory */.I)();
        let _currentEpochNo = (0,reactivity_esm_bundler/* ref */.iH)(0);
        let _currentEpochStart = (0,reactivity_esm_bundler/* ref */.iH)(0);
        let _nextEpochStart = (0,reactivity_esm_bundler/* ref */.iH)(0);
        let _afterNextEpochStart = (0,reactivity_esm_bundler/* ref */.iH)(0);
        let _currentEpochDelegation = (0,reactivity_esm_bundler/* ref */.iH)([]);
        let _nextDelegation = (0,reactivity_esm_bundler/* ref */.iH)([]);
        let _afterNextDelegations = (0,reactivity_esm_bundler/* ref */.iH)([]);
        let _epochData = (0,reactivity_esm_bundler/* ref */.iH)([]);
        const hasDelegation = (0,runtime_core_esm_bundler/* computed */.Fl)(() => _currentEpochDelegation.value.length > 0 ||
            _nextDelegation.value.length > 0 ||
            _afterNextDelegations.value.length > 0);
        const itemsOnPage = 20;
        const currentPage = (0,reactivity_esm_bundler/* ref */.iH)(1);
        const showPagination = (0,runtime_core_esm_bundler/* computed */.Fl)(() => _epochData.value.length > itemsOnPage);
        const currentPageStart = (0,runtime_core_esm_bundler/* computed */.Fl)(() => (currentPage.value - 1) * itemsOnPage);
        const maxPages = (0,runtime_core_esm_bundler/* computed */.Fl)(() => Math.ceil(_epochData.value.length / itemsOnPage));
        const _epochDataFiltered = (0,runtime_core_esm_bundler/* computed */.Fl)(() => _epochData.value.slice(currentPageStart.value, currentPageStart.value + itemsOnPage));
        function generateDelegationList() {
            const { epochData, currentEpochNo, currentEpochStart, nextEpochStart, afterNextEpochStart, currentEpochDelegation, nextDelegation, afterNextDelegations } = generateDelegationHistory(props.stakeKey, props.stakeInfo);
            _currentEpochNo.value = currentEpochNo;
            _currentEpochStart.value = currentEpochStart;
            _nextEpochStart.value = nextEpochStart;
            _afterNextEpochStart.value = afterNextEpochStart;
            _epochData.value = epochData;
            _currentEpochDelegation.value = currentEpochDelegation;
            _nextDelegation.value = nextDelegation;
            _afterNextDelegations.value = afterNextDelegations;
        }
        (0,runtime_core_esm_bundler/* watchEffect */.m0)(() => {
            // if(!props.stakeInfo) return
            if ( /*(props.stakeInfo.deregistrationList.length ||
              props.stakeInfo.delegationList.length ||
              props.stakeInfo.registrationList.length) &&*/poolList.value.length > 0) {
                generateDelegationList();
            }
            else {
                generateDelegationList();
            }
        });
        function isValidImg(pool) {
            const src = pool.mde?.stakeInfo?.url_png_icon_64x64 || pool.mde?.adapools?.url_png_icon_64x64;
            return (src && src.startsWith('https://'));
        }
        const stakeKeyPath = (0,reactivity_esm_bundler/* ref */.iH)('\n' + (0,CSLDerivation/* getStringDerivationPath */.Ad)(props.stakeKey.path));
        return {
            it,
            isValidImg,
            stakeKeyPath,
            hasDelegation,
            showPagination,
            currentPage,
            maxPages,
            currentEpochNo: _currentEpochNo,
            currentEpochStart: _currentEpochStart,
            nextEpochStart: _nextEpochStart,
            afterNextEpochStart: _afterNextEpochStart,
            epochData: _epochDataFiltered,
            currentEpochDelegation: _currentEpochDelegation,
            nextDelegation: _nextDelegation,
            afterNextDelegations: _afterNextDelegations,
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/accounts/AccountItemDelegation.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/accounts/AccountItemDelegation.vue




;


const AccountItemDelegation_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(AccountItemDelegationvue_type_script_lang_ts, [['render',AccountItemDelegationvue_type_template_id_23374433_scoped_true_ts_true_render],['__scopeId',"data-v-23374433"]])

/* harmony default export */ const AccountItemDelegation = (AccountItemDelegation_exports_);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridButtonWarning.vue + 3 modules
var GridButtonWarning = __webpack_require__(63691);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/accounts/AccountItem.vue?vue&type=script&lang=ts








/* harmony default export */ const AccountItemvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'AccountItem',
    emits: [
        'onActivateAccount',
        'onRemoveAccount'
    ],
    components: {
        GridButtonPrimary: GridButtonPrimary/* default */.Z,
        GridButtonWarning: GridButtonWarning/* default */.Z,
        GridSpace: GridSpace/* default */.Z,
        AccountItemBalance: AccountItemBalance/* default */.Z,
        AccountItemDelegation: AccountItemDelegation
    },
    props: {
        account: { type: Object, required: true },
        isActiveAccount: { type: Boolean, required: true },
        syncing: { type: Boolean, required: true }
    },
    setup(props, { emit }) {
        const { it } = (0,useTranslation/* useTranslation */.$)();
        const stakeInfo = (0,reactivity_esm_bundler/* ref */.iH)(props.account.base.stake.length > 0 ? props.account.base.stake[0] : null);
        const stakeKey = (0,reactivity_esm_bundler/* ref */.iH)(null);
        (0,runtime_core_esm_bundler/* watch */.YP)(() => props.account.base.stake.length, () => {
            if (props.account?.base.stake.length > 0) {
                stakeInfo.value = props.account.base.stake[0];
            }
            else {
                stakeInfo.value = null;
            }
        });
        (0,runtime_core_esm_bundler/* watchEffect */.m0)(() => {
            if (stakeInfo.value) {
                stakeKey.value = (0,AccountLib/* getOwnedKeyFromAddressBech32 */.yb)(props.account, stakeInfo.value.bech32, 'stake');
            }
            if (!stakeKey.value) {
                stakeKey.value = props.account.keys.stake[0];
            }
        });
        function onActivateAccount() { emit('onActivateAccount', props.account.pub); }
        function onRemoveAccount() { emit('onRemoveAccount', props.account.pub); }
        return {
            it,
            stakeInfo,
            stakeKey,
            onActivateAccount,
            onRemoveAccount
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/accounts/AccountItem.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/accounts/AccountItem.vue




;
const AccountItem_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(AccountItemvue_type_script_lang_ts, [['render',AccountItemvue_type_template_id_d9c4fbe0_ts_true_render]])

/* harmony default export */ const AccountItem = (AccountItem_exports_);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/components/ccw/grid/v2/accounts/AccountList.vue?vue&type=script&lang=ts

;














const removeHDAccount = ExtAppWalletManagerLib/* AWM.removeHDAccount */.b.removeHDAccount;
/* harmony default export */ const AccountListvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'AccountList',
    components: {
        GridTextArea: GridTextArea/* default */.Z,
        GridAccountBalance: GridAccountBalance,
        GridAccountUtxoList: GridAccountUtxoList/* default */.Z,
        AccountItem: AccountItem,
        GridText: GridText/* default */.Z,
        GridSpace: GridSpace/* default */.Z,
        GridHeadline: GridHeadline/* default */.Z,
        SignAddAccount: SignAddAccount,
        ConfirmationModal: ConfirmationModal/* default */.Z
    },
    setup() {
        const { it } = (0,useTranslation/* useTranslation */.$)();
        const { gotoWalletPage } = (0,useNavigation/* useNavigation */.HJ)();
        const { isActiveWalletSyncing, activeAccount, activeWalletData, activeAccountList, setActiveAccount } = (0,useActiveWallet/* useActiveWallet */.r)();
        const $q = (0,use_quasar/* default */.Z)();
        const showDeleteModal = (0,reactivity_esm_bundler/* ref */.iH)({ display: false });
        const selectedPubKey = (0,reactivity_esm_bundler/* ref */.iH)();
        function onActivateAccount(pub) {
            if (pub) {
                setActiveAccount(pub);
                gotoWalletPage('Summary', 'accounts');
            }
        }
        const openDeleteModal = (pub) => {
            selectedPubKey.value = pub;
            showDeleteModal.value.display = true;
        };
        async function onRemoveAccount() {
            if (selectedPubKey.value) {
                const wallet = activeWalletData.value;
                if (!wallet)
                    return;
                const success = await removeHDAccount(wallet.id, { accountPubBech32: (0,AccountLib/* prepareAccountKey */.Cl)(selectedPubKey.value) });
                if (!success) {
                    $q.notify({
                        type: 'negative',
                        message: 'Account could not be removed.',
                        position: 'top-left',
                        timeout: 3000
                    });
                }
                else {
                    $q.notify({
                        type: 'positive',
                        message: 'Account removed.',
                        position: 'top-left',
                        timeout: 3000
                    });
                }
            }
            showDeleteModal.value.display = false;
        }
        return {
            it,
            onActivateAccount,
            onRemoveAccount,
            isActiveWalletSyncing,
            activeAccount,
            activeAccountList,
            openDeleteModal,
            showDeleteModal
        };
    }
}));

;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/accounts/AccountList.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/components/ccw/grid/v2/accounts/AccountList.vue




;
const AccountList_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(AccountListvue_type_script_lang_ts, [['render',AccountListvue_type_template_id_3a11c6dd_ts_true_render]])

/* harmony default export */ const AccountList = (AccountList_exports_);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/Summary.vue?vue&type=script&lang=ts














/* harmony default export */ const Summaryvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'Summary',
    components: {
        GridTabs: GridTabs/* default */.Z,
        GridAccountBalance: GridAccountBalance,
        GridAccountUtxoList: GridAccountUtxoList/* default */.Z,
        GridAccountTokenBalance: GridAccountTokenBalance,
        GridText: GridText/* default */.Z,
        GridSpace: GridSpace/* default */.Z,
        GridHeadline: GridHeadline/* default */.Z,
        AccountList: AccountList
    },
    setup() {
        const { t } = (0,useTranslation/* useTranslation */.$)();
        const { isActiveWalletSyncing, activeWalletEnabledCollateral, activeAccount, activeSVAccount, activeAccountList, activeWalletId } = (0,useActiveWallet/* useActiveWallet */.r)();
        const { isBalanceVisible, setBalanceVisible } = (0,useBalanceVisible/* useBalanceVisible */.c)();
        (0,runtime_core_esm_bundler/* onErrorCaptured */.d1)((e) => { console.error('Summary: onErrorCaptured', e); return true; });
        const optionsTabs = (0,reactivity_esm_bundler/* reactive */.qj)([
            { id: 'summary', label: t('menu.wallet.account.submenu.summary'), index: 0 },
            { id: 'tokens', label: t('menu.wallet.account.submenu.tokenList'), index: 1 },
            { id: 'utxos', label: t('menu.wallet.account.submenu.utxoList'), index: 2 },
            { id: 'accounts', label: t('menu.wallet.account.submenu.accountList'), index: 3 }
        ]);
        return {
            t,
            optionsTabs,
            onErrorCaptured: runtime_core_esm_bundler/* onErrorCaptured */.d1,
            isActiveWalletSyncing,
            activeWalletEnabledCollateral,
            activeAccount,
            activeSVAccount,
            activeAccountList,
            activeWalletId,
            isBalanceVisible,
            setBalanceVisible
        };
    }
}));

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/Summary.vue?vue&type=script&lang=ts
 
;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/Summary.vue




;
const Summary_exports_ = /*#__PURE__*/(0,exportHelper/* default */.Z)(Summaryvue_type_script_lang_ts, [['render',render]])

/* harmony default export */ const Summary = (Summary_exports_);

/***/ })

}]);
//# sourceMappingURL=6592.js.map