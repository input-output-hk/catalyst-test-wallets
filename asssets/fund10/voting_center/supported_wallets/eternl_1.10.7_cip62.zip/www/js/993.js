"use strict";
(this["webpackChunkccw_frontend"] = this["webpackChunkccw_frontend"] || []).push([[993,5134],{

/***/ 74516:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Deregistration)
});

// EXTERNAL MODULE: ./node_modules/@vue/runtime-core/dist/runtime-core.esm-bundler.js
var runtime_core_esm_bundler = __webpack_require__(83673);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[4]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/Deregistration.vue?vue&type=template&id=a57c5d54&ts=true

const _hoisted_1 = { class: "cc-page-wallet cc-text-sz" };
function render(_ctx, _cache, $props, $setup, $data, $options) {
    const _component_GridHeadline = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridHeadline");
    const _component_GridTextArea = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridTextArea");
    const _component_GridButtonSecondary = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridButtonSecondary");
    const _component_SendConfirm = (0,runtime_core_esm_bundler/* resolveComponent */.up)("SendConfirm");
    const _component_SendSubmit = (0,runtime_core_esm_bundler/* resolveComponent */.up)("SendSubmit");
    const _component_GridSteps = (0,runtime_core_esm_bundler/* resolveComponent */.up)("GridSteps");
    return ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_1, [
        (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridHeadline, {
            label: _ctx.t('wallet.deregistration.headline')
        }, null, 8, ["label"]),
        (_ctx.isRegistered && _ctx.rewards !== '0')
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridTextArea, {
                key: 0,
                label: _ctx.t('wallet.deregistration.rewards.label'),
                text: _ctx.t('wallet.deregistration.rewards.text').replace('###rewards###', _ctx.formatADAString(_ctx.rewards, true)),
                icon: _ctx.t('wallet.deregistration.rewards.icon'),
                class: "col-span-12 mt-2 sm:mt-4",
                "text-c-s-s": "cc-text-normal text-justify",
                css: "cc-input-info cc-rounded "
            }, null, 8, ["label", "text", "icon"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true),
        (_ctx.isRegistered)
            ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridSteps, {
                key: 1,
                onBack: _ctx.goBack,
                steps: _ctx.optionsSteps,
                currentStep: _ctx.currentStep,
                "small-c-s-s": "pr-20 xs:pr-20 lg:pr-24"
            }, {
                step0: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_SendConfirm, {
                        onSubmit: _ctx.gotoNext,
                        account: _ctx.activeAccount,
                        wallet: _ctx.activeWalletData,
                        "unsigned-tx": _ctx.tx,
                        "text-id": "wallet.send.step.confirm"
                    }, {
                        btnBack: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                            (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_GridButtonSecondary, {
                                label: _ctx.t('common.label.cancel'),
                                link: _ctx.goBack,
                                class: "col-start-0 col-span-6 lg:col-start-0 lg:col-span-3"
                            }, null, 8, ["label", "link"])
                        ]),
                        _: 1
                    }, 8, ["onSubmit", "account", "wallet", "unsigned-tx"])
                ]),
                step1: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                    (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_SendSubmit, {
                        onError: _ctx.onSubmitError,
                        onSending: _ctx.onTxSending,
                        onPending: _ctx.onTxPending,
                        onConfirmed: _ctx.onTxConfirmed,
                        "text-id": "wallet.send.step.submit"
                    }, {
                        btnBack: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [
                            (_ctx.hasSubmitError)
                                ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_GridButtonSecondary, {
                                    key: 0,
                                    label: _ctx.t('common.label.retry'),
                                    link: _ctx.goBack,
                                    class: "col-start-0 col-span-6 lg:col-start-0 lg:col-span-3 mt-4"
                                }, null, 8, ["label", "link"]))
                                : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
                        ]),
                        _: 1
                    }, 8, ["onError", "onSending", "onPending", "onConfirmed"])
                ]),
                _: 1
            }, 8, ["onBack", "steps", "currentStep"]))
            : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)
    ]));
}

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/Deregistration.vue?vue&type=template&id=a57c5d54&ts=true

// EXTERNAL MODULE: ./node_modules/@vue/reactivity/dist/reactivity.esm-bundler.js
var reactivity_esm_bundler = __webpack_require__(61959);
// EXTERNAL MODULE: ./src/composables/ccw/useTranslation.ts
var useTranslation = __webpack_require__(19376);
// EXTERNAL MODULE: ./src/composables/ccw/useNavigation.ts
var useNavigation = __webpack_require__(52439);
// EXTERNAL MODULE: ./src/composables/ccw/store/useFormatter.ts
var useFormatter = __webpack_require__(16938);
// EXTERNAL MODULE: ./src/composables/ccw/store/useActiveWallet.ts
var useActiveWallet = __webpack_require__(52144);
// EXTERNAL MODULE: ./src/composables/ccw/store/useBuildTx_v3.ts + 1 modules
var useBuildTx_v3 = __webpack_require__(72107);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/send/SendConfirm.vue + 4 modules
var SendConfirm = __webpack_require__(12662);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/send/SendSubmit.vue + 3 modules
var SendSubmit = __webpack_require__(65778);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridHeadline.vue + 3 modules
var GridHeadline = __webpack_require__(63593);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridSteps.vue + 14 modules
var GridSteps = __webpack_require__(58217);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridTextArea.vue + 4 modules
var GridTextArea = __webpack_require__(15660);
// EXTERNAL MODULE: ./src/components/ccw/grid/v2/common/GridButtonSecondary.vue + 3 modules
var GridButtonSecondary = __webpack_require__(72713);
;// CONCATENATED MODULE: ./node_modules/@quasar/app/lib/webpack/loader.js.transform-quasar-imports.js!./node_modules/ts-loader/index.js??clonedRuleSet-3.use[0]!./node_modules/@quasar/app/lib/webpack/loader.vue.auto-import-quasar.js??ruleSet[0].use[0]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[1]!./src/pages/ccw/wallet/pages/Deregistration.vue?vue&type=script&lang=ts












/* harmony default export */ const Deregistrationvue_type_script_lang_ts = ((0,runtime_core_esm_bundler/* defineComponent */.aZ)({
    name: 'Deregistration',
    components: {
        GridHeadline: GridHeadline/* default */.Z,
        GridTextArea: GridTextArea/* default */.Z,
        GridSteps: GridSteps/* default */.Z,
        GridButtonSecondary: GridButtonSecondary/* default */.Z,
        SendConfirm: SendConfirm/* default */.Z,
        SendSubmit: SendSubmit/* default */.Z,
    },
    setup() {
        const { t } = (0,useTranslation/* useTranslation */.$)();
        const { gotoWalletPage } = (0,useNavigation/* useNavigation */.HJ)();
        const { getBuildStatus, getBuiltTx } = (0,useBuildTx_v3/* useBuildTxV3 */.b)();
        const tx = (0,runtime_core_esm_bundler/* computed */.Fl)(() => {
            if (!activeAccount.value) {
                return null;
            }
            return getBuiltTx(activeAccount.value?.pub);
        });
        const { formatADAString } = (0,useFormatter/* useFormatter */.G)();
        const { activeWalletData, activeAccount } = (0,useActiveWallet/* useActiveWallet */.r)();
        const currentStep = (0,reactivity_esm_bundler/* ref */.iH)(0);
        (0,runtime_core_esm_bundler/* onErrorCaptured */.d1)((e) => { console.error('Wallet: Send: onErrorCaptured', e); return true; });
        const isRegistered = activeAccount.value ? activeAccount.value.base.stake.length > 0 && activeAccount.value.base.stake[0].registered : false;
        const rewards = activeAccount.value ? activeAccount.value.balance.rewards : '0';
        if (!isRegistered || !tx.value) {
            gotoWalletPage('WalletSettings');
        }
        const hasSubmitError = (0,runtime_core_esm_bundler/* computed */.Fl)(() => (activeAccount.value ? (getBuildStatus(activeAccount.value.pub) === useBuildTx_v3/* IBuildStatus.error */.k.error) : null));
        const optionsSteps = (0,reactivity_esm_bundler/* reactive */.qj)([
            { id: 'confirm', label: t('wallet.deregistration.steps.stepper.confirm') },
            { id: 'submit', label: t('wallet.deregistration.steps.stepper.submit') }
        ]);
        function goBack() {
            if (currentStep.value === 0) {
                gotoWalletPage('WalletSettings');
            }
            if (currentStep.value === 1) {
                currentStep.value = 0;
            }
        }
        function gotoNext() {
            if (currentStep.value === 0) {
                currentStep.value = 1;
            }
        }
        function onSubmitError() { console.error('submit error!!'); }
        function onTxSending() { }
        function onTxPending() {
            gotoWalletPage('Transactions', 'pending');
        }
        function onTxConfirmed() { }
        return {
            t,
            activeWalletData,
            activeAccount,
            tx,
            optionsSteps,
            currentStep,
            formatADAString,
            goBack,
            gotoNext,
            onSubmitError,
            onTxSending,
            onTxPending,
            onTxConfirmed,
            hasSubmitError,
            isRegistered,
            rewards
        };
    }
}));

;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/Deregistration.vue?vue&type=script&lang=ts
 
// EXTERNAL MODULE: ./node_modules/vue-loader/dist/exportHelper.js
var exportHelper = __webpack_require__(74260);
;// CONCATENATED MODULE: ./src/pages/ccw/wallet/pages/Deregistration.vue




;
const __exports__ = /*#__PURE__*/(0,exportHelper/* default */.Z)(Deregistrationvue_type_script_lang_ts, [['render',render]])

/* harmony default export */ const Deregistration = (__exports__);

/***/ })

}]);
//# sourceMappingURL=993.js.map